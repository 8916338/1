package com.shanqiu.app;

import android.content.Context;

/**
 * 配色预设。「静蓝」置顶且是默认（DEFAULT_ID）；
 * 「无色」是最早那版素白配色，「暖橙」是上一版默认，用户都能在「更多 → 主题」里切。
 * 另外几套是浅色系（偏蓝 / 偏白 / 偏灰，底子都很浅）。
 *
 * 主题只影响浏览器自己的界面（状态栏、面板、弹窗、按钮、错误页），
 * 不往网页里注入任何配色 —— 内置页和在线网页一样，用页面自己写的样式。
 *
 * 结构性原则（回应「叶顶叶底像拼接的」）：
 *   每套配色只定义 核心色（强调色 / 主文字 / 次要文字 / 图标 / 页面底色），
 *   其余全部由页面底色派生 ——
 *     面板底色 panel = 页面底色 page（完全同一个颜色，弹窗和页面是一个整体）
 *     分隔线 border  = page 混入少量 text（同色调，只比底色深一点）
 *     按压底色 press = 强调色混入 page（同色调的浅强调）
 *     禁用色 dim     = 次要文字混入 page
 *   这样任何主题下，页面、闪电球面板、弹窗、卡片、分隔线都是同一个色调，
 *   不再出现「面板一种白、页面另一种白」的拼接感。
 *
 * 颜色用紧凑的 spec 字符串定义（id|名称|accent|text|sub|icon|page|dark[|press|border]）。
 * 末尾两个可选字段用于完整还原 2.0.1 那四套原版的按压底色 / 边框色，
 * 不填则按上面的派生规则自动生成。
 */
public final class Theme {

    public static final class Palette {
        public final String id;
        public final String name;
        /** 主色：按下态文字、图标、强调线、进度条 */
        public final int accent;
        /** 按压底色 / 浅强调底（由 page 派生） */
        public final int press;
        /** 面板底色 / 弹窗底色 / 内置页卡片色（= page，同一个颜色） */
        public final int panel;
        /** 分隔线 / 边框（由 page 派生，同色调略深） */
        public final int border;
        /** 主文字 */
        public final int text;
        /** 次要文字 */
        public final int sub;
        /** 图标常态颜色 */
        public final int icon;
        /** 禁用态（由 page 派生） */
        public final int dim;
        /** 内容区底色：根布局 / WebView 背景 / 内置页 --bg */
        public final int page;
        /** 成功色 */
        public final int ok;
        /** 警示色 */
        public final int warn;
        /** 是否深色主题 */
        public final boolean dark;

        Palette(String id, String name, int accent, int press, int panel, int border,
                int text, int sub, int icon, int dim, int page, int ok, int warn, boolean dark) {
            this.id = id;
            this.name = name;
            this.accent = accent;
            this.press = press;
            this.panel = panel;
            this.border = border;
            this.text = text;
            this.sub = sub;
            this.icon = icon;
            this.dim = dim;
            this.page = page;
            this.ok = ok;
            this.warn = warn;
            this.dark = dark;
        }
    }

    /** 成功色 / 警示色：所有主题共用，深浅色各一组 */
    private static final int OK_LIGHT = 0xFF16A34A;
    private static final int WARN_LIGHT = 0xFFD97706;
    private static final int OK_DARK = 0xFF34D399;
    private static final int WARN_DARK = 0xFFFBBF24;

    private static final String[] SPECS = {
            // id|名称|accent|text|sub|icon|page|dark[|press|border]
            // 第 0 套「静蓝」：默认主题，置顶
            "blue|静蓝|0xFF2563EB|0xFF2F3B4C|0xFF8E9AAC|0xFF7E8CA0|0xFFFFFFFF|0|0xFFEDF2FE|0xFFE4E8F0",
            // 2.0.1 的原版主题（按压底色 / 边框色按当时原值还原）
            "orange|暖橙|0xFFE64A19|0xFF3B4655|0xFF9AA3B2|0xFF8B96A5|0xFFFFFFFF|0|0xFFFFF1EC|0xFFE8EAEE",
            "plain|无色|0xFF2F3B4C|0xFF111827|0xFF8B96A5|0xFF7E8CA0|0xFFF7F8FA|0",
            "green|青绿|0xFF0E9F6E|0xFF2C3F39|0xFF8AA098|0xFF7C948B|0xFFFFFFFF|0|0xFFE8F7F1|0xFFE2EDE8",
            "violet|墨紫|0xFF7C3AED|0xFF3A3247|0xFF978DA8|0xFF8B7FA0|0xFFFFFFFF|0|0xFFF2EDFE|0xFFE8E2F5",
            // 浅色系补充：偏蓝 / 偏白 / 偏灰，底色都很浅，次级色全部按派生规则自动生成
            "cloud|云白|0xFF4C86D6|0xFF28313F|0xFF94A0B0|0xFF8D99A9|0xFFFCFDFE|0",
            "ice|浅蓝|0xFF2E7BC4|0xFF22344A|0xFF8CA1B8|0xFF859AB0|0xFFF3F8FC|0",
            "fog|浅灰|0xFF4E6E9E|0xFF2E3540|0xFF99A2AE|0xFF919BA7|0xFFF5F6F8|0",
    };

    private static final Palette[] ALL = new Palette[SPECS.length];

    /** 默认配色：静蓝（列表第一位） */
    public static final String DEFAULT_ID = "blue";

    /** DEFAULT_ID 在 SPECS 里的下标（静态块里算好，找不到就是 0） */
    private static final int DEFAULT_INDEX;

    static {
        for (int i = 0; i < SPECS.length; i++) {
            String[] s = SPECS[i].split("\\|");
            int accent = Long.decode(s[2]).intValue();
            int text = Long.decode(s[3]).intValue();
            int sub = Long.decode(s[4]).intValue();
            int icon = Long.decode(s[5]).intValue();
            int page = Long.decode(s[6]).intValue();
            boolean dark = "1".equals(s[7]);
            // 一切次级颜色都从页面底色派生，保证整个界面是同一个色调
            // （spec 末尾带可选 press/border 时按原值还原，如 2.0.1 的四套）
            int panel = page;                              // 弹窗、面板 = 页面底色
            int border = s.length > 9 ? Long.decode(s[9]).intValue()
                    : blendRaw(page, text, 0.16f);         // 边框：同色调略深
            int press = s.length > 8 ? Long.decode(s[8]).intValue()
                    : blendRaw(page, accent, 0.10f);       // 按压：页面底色混少量强调色（浅色块）
            int dim = blendRaw(sub, page, 0.40f);          // 禁用：同色调更淡
            ALL[i] = new Palette(s[0], s[1], accent, press, panel, border,
                    text, sub, icon, dim, page,
                    dark ? OK_DARK : OK_LIGHT, dark ? WARN_DARK : WARN_LIGHT, dark);
        }
        int found = 0;
        for (int i = 0; i < ALL.length; i++) {
            if (DEFAULT_ID.equals(ALL[i].id)) {
                found = i;
                break;
            }
        }
        DEFAULT_INDEX = found;
    }

    private Theme() {
    }

    public static int count() {
        return ALL.length;
    }

    public static String nameOf(int i) {
        return ALL[clamp(i)].name;
    }

    public static String idOf(int i) {
        return ALL[clamp(i)].id;
    }

    public static boolean isDark(int i) {
        return ALL[clamp(i)].dark;
    }

    public static int indexOf(String id) {
        for (int i = 0; i < ALL.length; i++) {
            if (ALL[i].id.equals(id)) return i;
        }
        return DEFAULT_INDEX;
    }

    public static Palette of(int i) {
        return ALL[clamp(i)];
    }

    /** 当前生效的配色（默认静蓝） */
    public static Palette get(Context c) {
        return ALL[clamp(Prefs.themeIndex(c))];
    }

    private static int clamp(int i) {
        if (i < 0) return 0;
        if (i >= ALL.length) return 0;
        return i;
    }

    /** fg 混入 bg（ratio = fg 占比），返回不透明色 */
    public static int blend(int fg, int bg, float ratio) {
        return blendRaw(bg, fg, ratio);
    }

    private static int blendRaw(int bg, int fg, float ratio) {
        int fr = (fg >> 16) & 0xFF, fgc = (fg >> 8) & 0xFF, fb = fg & 0xFF;
        int br = (bg >> 16) & 0xFF, bgc = (bg >> 8) & 0xFF, bb = bg & 0xFF;
        int r = Math.round(br + (fr - br) * ratio);
        int g = Math.round(bgc + (fgc - bgc) * ratio);
        int b = Math.round(bb + (fb - bb) * ratio);
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }

}
