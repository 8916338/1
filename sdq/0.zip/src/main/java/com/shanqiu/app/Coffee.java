package com.shanqiu.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Bitmap;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONObject;

/**
 * 赞助：显示赞助码。
 *
 * 赞助信息优先读 app-config.json 的 coffee 段（编译进 Config，写死在壳里）：
 *   "coffee": { "qr": "https://…/zsm.jpg", "qq": "123456", "tip": "…" }
 * 这样即使 assets/data.json 被整套替换、网页改版，赞赏码也不会丢。
 * 没配 coffee 时才回落到内置 data.json 的 site.sponsor（兼容老工程）。
 * 两个来源都空 → 菜单里不出现这一项。
 */
public final class Coffee {

    /** 兜底值，留空表示「没有配置就不显示」 */
    private static final String DEFAULT_QR = Config.COFFEE_QR;
    private static final String DEFAULT_QQ = Config.COFFEE_QQ;

    private Coffee() {
    }

    public static void show(final Activity a) {
        if (a == null) return;

        String[] info = sponsor(a);
        final String qr = info[0];
        final String qq = info[1];

        final int pad = Ui.dp(a, 20);

        LinearLayout box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER_HORIZONTAL);
        box.setPadding(pad, Ui.dp(a, 4), pad, 0);

        final ImageView img = new ImageView(a);
        img.setScaleType(ImageView.ScaleType.FIT_CENTER);
        img.setAdjustViewBounds(true);
        img.setClickable(true);
        img.setLongClickable(true);
        // 长按才保存：和网页里长按图片保存的行为保持一致，避免误触
        img.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                if (v.getTag() == null) return false;
                v.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS);
                saveQr(a, (Bitmap) v.getTag());
                return true;
            }
        });
        img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Ui.toast(a, "长按二维码可保存到相册");
            }
        });
        LinearLayout.LayoutParams ilp = new LinearLayout.LayoutParams(
                Ui.dp(a, 210), ViewGroup.LayoutParams.WRAP_CONTENT);
        ilp.gravity = Gravity.CENTER_HORIZONTAL;
        box.addView(img, ilp);

        final TextView loading = new TextView(a);
        loading.setText("正在加载赞赏码…");
        loading.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f);
        loading.setTextColor(0xFF9AA3B2);
        loading.setGravity(Gravity.CENTER);
        box.addView(loading);

        TextView tip = new TextView(a);
        tip.setText(TextUtils.isEmpty(Config.COFFEE_TIP)
                ? "微信扫码 · 长按二维码保存到相册" : Config.COFFEE_TIP);
        tip.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f);
        tip.setTextColor(0xFF6B7280);
        tip.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        tlp.topMargin = Ui.dp(a, 10);
        box.addView(tip, tlp);

        if (!TextUtils.isEmpty(qq)) {
            TextView q = new TextView(a);
            q.setText("凭赞助截图加我好友   有好资源先分享给你 QQ：" + qq + "（点击复制）");
            q.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f);
            q.setTextColor(0xFFE64A19);
            q.setGravity(Gravity.CENTER);
            q.setPadding(0, Ui.dp(a, 8), 0, Ui.dp(a, 8));
            q.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Route.copy(a, qq, "QQ 号已复制");
                }
            });
            box.addView(q, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        }

        AlertDialog.Builder b = new AlertDialog.Builder(a);
        b.setTitle("赞助");
        b.setView(box);
        b.setNegativeButton("关闭", null);
        final AlertDialog d = b.create();
        try {
            d.show();
        } catch (Throwable t) {
            return;
        }

        new Thread(new Runnable() {
            @Override
            public void run() {
                Bitmap bmp = null;
                try {
                    bmp = Img.load(a, qr, null, 900);
                } catch (Throwable ignored) {
                }
                final Bitmap out = bmp;
                a.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            if (out != null) {
                                img.setImageBitmap(out);
                                img.setTag(out);          // 长按保存用
                                loading.setVisibility(View.GONE);
                            } else {
                                loading.setText("收款码没加载出来，检查一下网络再试");
                            }
                        } catch (Throwable ignored) {
                        }
                    }
                });
            }
        }).start();
    }

    /** 二维码存相册：和长按图片保存走同一套落盘逻辑 */
    private static void saveQr(final Activity a, final Bitmap bmp) {
        if (bmp == null) return;
        Ui.toast(a, "正在保存二维码…");
        new Thread(new Runnable() {
            @Override
            public void run() {
                String msg;
                try {
                    String path = Saver.toAlbum(a, bmp, "赞助二维码");
                    msg = "已保存到 " + path;
                } catch (Throwable t) {
                    msg = "保存失败：" + (t.getMessage() == null ? "未知原因" : t.getMessage());
                }
                final String out = msg;
                a.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Ui.toast(a, out);
                    }
                });
            }
        }).start();
    }

    /** 有没有配赞助信息（决定菜单里要不要出现这一项） */
    public static boolean hasSponsor(android.content.Context c) {
        String[] info = sponsor(c);
        return !TextUtils.isEmpty(info[0]) || !TextUtils.isEmpty(info[1]);
    }

    /**
     * 赞助码：先看壳里写死的 Config（打包时决定），没有再读内置 data.json。
     * 返回 {二维码地址, QQ号}，两个都可能为空。
     */
    public static String[] sponsor(android.content.Context a) {
        String qr = DEFAULT_QR, qq = DEFAULT_QQ;
        if (!TextUtils.isEmpty(qr) || !TextUtils.isEmpty(qq)) {
            return new String[]{qr, qq};
        }
        try {
            java.io.InputStream in = a.getAssets().open("data.json");
            byte[] buf = new byte[(int) Math.min(in.available(), 4 * 1024 * 1024)];
            int n = in.read(buf);
            in.close();
            if (n > 0) {
                JSONObject o = new JSONObject(new String(buf, 0, n, "UTF-8"));
                JSONObject s = o.optJSONObject("site");
                JSONObject sp = s == null ? null : s.optJSONObject("sponsor");
                if (sp != null) {
                    String q = sp.optString("qr", "");
                    if (!TextUtils.isEmpty(q)) qr = q;
                    String k = sp.optString("qq", "");
                    if (!TextUtils.isEmpty(k)) qq = k;
                }
            }
        } catch (Throwable ignored) {
        }
        return new String[]{qr, qq};
    }
}
