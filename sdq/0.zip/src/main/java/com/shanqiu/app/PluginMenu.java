package com.shanqiu.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Typeface;
import android.net.Uri;
import android.text.InputType;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;

import com.shanqiu.app.PluginStore.Plugin;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * 「更多 → 插件」以及底部青色按钮点进来的管理界面。
 *
 * 一个页面里做三件事：
 *   · 看装了哪些插件、各自管哪些站点、版本多少
 *   · 开关 / 换一份 / 删除
 *   · 装新的：粘一个地址下载，或者点右边的文件夹图标从手机里选
 *
 * 装进来之后源码会复制到私有目录，原文件删掉、网址失效都不影响使用。
 */
public final class PluginMenu {

    /** 系统文件选择器的请求码 */
    public static final int REQ_PICK = 0x9A21;

    private static AlertDialog current;

    private PluginMenu() {
    }

    // ------------------------------------------------------------ 入口

    /** 从「更多 → 插件」进：显示全部插件 */
    public static void show(final MainActivity a) {
        build(a, null);
    }

    /** 从底部青色按钮进：只显示当前网站生效的插件，并给个装新的入口 */
    public static void manageFor(final MainActivity a, String url) {
        build(a, url);
    }

    private static void build(final MainActivity a, final String url) {
        if (a == null || a.isFinishing() || a.isDestroyed()) return;
        dismiss();

        List<Plugin> all = PluginStore.list(a);
        List<Plugin> hit = url == null ? all : PluginStore.matchFor(a, url);

        LinearLayout box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);
        int pad = Ui.dp(a, 18);
        box.setPadding(pad, Ui.dp(a, 6), pad, Ui.dp(a, 2));

        TextView head = new TextView(a);
        String host = "";
        try {
            host = Uri.parse(url).getHost();
        } catch (Throwable ignored) {
        }
        head.setText(url == null
                ? "已安装 " + all.size() + " 个插件"
                : (TextUtils.isEmpty(host) ? "本页插件" : host + " 上生效的插件"));
        head.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f);
        head.setTextColor(Shell.of(a).sub);
        box.addView(head);

        TextView tip = new TextView(a);
        tip.setText(url == null
                ? "插件按自己声明的网站自动加载。装好就存在浏览器里，原文件删了也不影响。"
                : "这些插件已经自动加载进来了，点一行可以禁用、换一份或删除。");
        tip.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f);
        tip.setTextColor(Shell.of(a).sub);
        LinearLayout.LayoutParams tipLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        tipLp.topMargin = Ui.dp(a, 4);
        tipLp.bottomMargin = Ui.dp(a, 8);
        box.addView(tip, tipLp);

        if (hit.isEmpty()) {
            TextView empty = new TextView(a);
            empty.setText(url == null
                    ? "还没有插件。点下面的「安装插件」粘个地址，或者从手机里选一个 .js 文件。"
                    : "这个网站没有生效的插件。");
            empty.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f);
            empty.setTextColor(Shell.of(a).text);
            empty.setPadding(0, Ui.dp(a, 10), 0, Ui.dp(a, 10));
            box.addView(empty);
        } else {
            ScrollView sv = new ScrollView(a);
            LinearLayout listBox = new LinearLayout(a);
            listBox.setOrientation(LinearLayout.VERTICAL);
            for (final Plugin p : hit) listBox.addView(row(a, p, url));
            sv.addView(listBox, new ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, Math.min(Ui.dp(a, 320),
                    Ui.dp(a, 76) * Math.max(1, hit.size())));
            box.addView(sv, slp);
        }

        // 装新的
        TextView add = new TextView(a);
        add.setText("＋ 安装插件");
        add.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f);
        add.setTextColor(0xFF2196F3);
        add.setGravity(Gravity.CENTER);
        add.setPadding(0, Ui.dp(a, 14), 0, Ui.dp(a, 10));
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                installDialog(a, url);
            }
        });
        box.addView(add, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        AlertDialog.Builder b = new AlertDialog.Builder(a);
        b.setTitle("插件");
        b.setView(box);
        b.setNegativeButton("关闭", null);
        current = Ui.show(b.create());
    }

    /** 一行插件：名字 + 版本/站点，右边一个开关 */
    private static View row(final MainActivity a, final Plugin p, final String url) {
        LinearLayout row = new LinearLayout(a);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, Ui.dp(a, 9), 0, Ui.dp(a, 9));

        LinearLayout text = new LinearLayout(a);
        text.setOrientation(LinearLayout.VERTICAL);

        TextView name = new TextView(a);
        name.setText(p.name + (TextUtils.isEmpty(p.version) ? "" : "  " + p.version));
        name.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14.5f);
        name.setTextColor(Shell.of(a).text);
        name.setTypeface(Typeface.DEFAULT_BOLD);
        text.addView(name);

        TextView sub = new TextView(a);
        String s = p.site;
        if (!TextUtils.isEmpty(p.source)) s += " · " + shorten(p.source);
        sub.setText(s);
        sub.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f);
        sub.setTextColor(Shell.of(a).sub);
        sub.setSingleLine(true);
        sub.setEllipsize(TextUtils.TruncateAt.END);
        text.addView(sub);

        row.addView(text, new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        final Switch sw = new Switch(a);
        sw.setChecked(p.enabled);
        sw.setOnCheckedChangeListener(new android.widget.CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(android.widget.CompoundButton btn, boolean checked) {
                if (checked == p.enabled) return;
                PluginStore.setEnabled(a, p.id, checked);
                Ui.toast(a, checked ? "已启用「" + p.name + "」，刷新页面生效"
                        : "已禁用「" + p.name + "」，刷新页面生效");
            }
        });
        row.addView(sw, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        row.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                detail(a, p, url);
            }
        });
        return row;
    }

    private static String shorten(String s) {
        if (s == null) return "";
        String t = s;
        int i = t.indexOf("://");
        if (i > 0) t = t.substring(i + 3);
        return t.length() > 38 ? t.substring(0, 36) + "…" : t;
    }

    // ------------------------------------------------------------ 详情

    private static void detail(final MainActivity a, final Plugin p, final String url) {
        dismiss();
        StringBuilder msg = new StringBuilder();
        msg.append("版本：").append(TextUtils.isEmpty(p.version) ? "未标注" : p.version).append("\n");
        msg.append("适用网站：").append(p.site).append("\n");
        msg.append("来源：").append(TextUtils.isEmpty(p.source) ? "未知" : p.source).append("\n");
        try {
            SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.CHINA);
            msg.append("安装时间：").append(f.format(new Date(p.installedAt)));
        } catch (Throwable ignored) {
        }

        AlertDialog.Builder b = new AlertDialog.Builder(a);
        b.setTitle(p.name);
        b.setMessage(msg.toString());
        b.setPositiveButton(p.enabled ? "禁用" : "启用", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface d, int w) {
                PluginStore.setEnabled(a, p.id, !p.enabled);
                Ui.toast(a, p.enabled ? "已禁用，刷新页面生效" : "已启用，刷新页面生效");
                build(a, url);
            }
        });
        b.setNeutralButton("换一份", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface d, int w) {
                pickFile(a, url);
            }
        });
        b.setNegativeButton("删除", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface d, int w) {
                confirmDelete(a, p, url);
            }
        });
        current = Ui.show(b.create());
    }

    private static void confirmDelete(final MainActivity a, final Plugin p, final String url) {
        new AlertDialog.Builder(a)
                .setTitle("删除「" + p.name + "」？")
                .setMessage("插件文件会从浏览器里一起删掉，这个网站以后不再自动加载。想再用手动重装一次即可。")
                .setPositiveButton("删除", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        PluginStore.remove(a, p.id);
                        Ui.toast(a, "已删除「" + p.name + "」");
                        build(a, url);
                    }
                })
                .setNegativeButton("取消", null)
                .show();
    }

    // ------------------------------------------------------------ 安装

    private static void installDialog(final MainActivity a, final String backUrl) {
        dismiss();

        LinearLayout box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);
        int pad = Ui.dp(a, 18);
        box.setPadding(pad, Ui.dp(a, 8), pad, Ui.dp(a, 4));

        TextView tip = new TextView(a);
        tip.setText("粘一个插件地址（.js / .user.js），或者点右边的文件夹从手机里选。");
        tip.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f);
        tip.setTextColor(Shell.of(a).sub);
        box.addView(tip);

        LinearLayout row = new LinearLayout(a);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams rowLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        rowLp.topMargin = Ui.dp(a, 10);
        box.addView(row, rowLp);

        final EditText et = new EditText(a);
        et.setHint("https://example.com/github-zh.user.js");
        et.setHintTextColor(Shell.of(a).sub);
        et.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f);
        et.setTextColor(Shell.of(a).text);
        et.setSingleLine(true);
        et.setInputType(InputType.TYPE_TEXT_VARIATION_URI);
        row.addView(et, new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        ImageView folder = new ImageView(a);
        folder.setImageResource(R.drawable.ic_q_open_file);
        folder.setPadding(Ui.dp(a, 8), Ui.dp(a, 8), Ui.dp(a, 8), Ui.dp(a, 8));
        folder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pickFile(a, backUrl);
            }
        });
        row.addView(folder, new LinearLayout.LayoutParams(
                Ui.dp(a, 42), Ui.dp(a, 42)));

        AlertDialog.Builder b = new AlertDialog.Builder(a);
        b.setTitle("安装插件");
        b.setView(box);
        b.setPositiveButton("安装", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface d, int w) {
                String url = et.getText() == null ? "" : et.getText().toString().trim();
                if (TextUtils.isEmpty(url)) {
                    Ui.toast(a, "先填插件地址，或者点文件夹选一个文件");
                    return;
                }
                doInstallUrl(a, url, backUrl);
            }
        });
        b.setNegativeButton("取消", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface d, int w) {
                build(a, backUrl);
            }
        });
        current = Ui.show(b.create());
    }

    private static void doInstallUrl(final MainActivity a, String url, final String backUrl) {
        Ui.toast(a, "正在下载…");
        PluginStore.installUrl(a, url, new PluginStore.Callback() {
            @Override
            public void done(Plugin p, String error) {
                afterInstall(a, p, error, backUrl);
            }
        });
    }

    private static void afterInstall(MainActivity a, Plugin p, String error, String backUrl) {
        if (error != null) {
            new AlertDialog.Builder(a)
                    .setTitle("装不上")
                    .setMessage(error + "\n\n插件文件要能被浏览器执行，头部得有 ==UserScript== 和 @match。")
                    .setPositiveButton("知道了", null)
                    .show();
            return;
        }
        // 首次装好给一段说明，讲清楚它会自己跑、去哪儿关
        AlertDialog.Builder b = new AlertDialog.Builder(a);
        b.setTitle("已安装「" + p.name + "」");
        b.setMessage("适用网站：" + p.site + "\n\n"
                + "打开这些网站时会自动加载，页面底部浮出青色按钮就是它；"
                + "点按钮可以随时禁用、换一份或删除。\n\n"
                + "已经开着的页面刷新一下即可生效。");
        b.setPositiveButton("知道了", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface d, int w) {
                build(a, backUrl);
            }
        });
        current = Ui.show(b.create());
    }

    // ------------------------------------------------------------ 选文件

    private static void pickFile(MainActivity a, String backUrl) {
        dismiss();
        try {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("*/*");
            a.startActivityForResult(i, REQ_PICK);
        } catch (Throwable t) {
            Ui.toast(a, "这台设备没有文件选择器");
        }
    }

    /** MainActivity.onActivityResult 转发进来；返回 true 表示这个结果归插件管 */
    public static boolean onResult(final MainActivity a, int requestCode, int resultCode, Intent data) {
        if (requestCode != REQ_PICK) return false;
        if (resultCode != Activity.RESULT_OK || data == null || data.getData() == null) return true;
        Ui.toast(a, "正在读取…");
        PluginStore.installUri(a, data.getData(), new PluginStore.Callback() {
            @Override
            public void done(Plugin p, String error) {
                afterInstall(a, p, error, null);
            }
        });
        return true;
    }

    private static void dismiss() {
        if (current != null) {
            try {
                current.dismiss();
            } catch (Throwable ignored) {
            }
            current = null;
        }
    }
}
