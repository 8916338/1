package com.shanqiu.app;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * 浏览历史（闪电球 → 历史）。
 *
 * 只存本机的最近 300 条，地址 + 标题 + 时间；
 * 不采集任何设备信息，也不会联网上传。
 * 看隐私网站的用户可以在面板里一键清空。
 */
public final class History {

    private static final String PREF = "shell_history";
    private static final String K_LIST = "list";
    private static final int MAX = 300;

    public static final class Item {
        public String url;
        public String title;
        public long time;
    }

    private History() {
    }

    /** 记录一次访问；同一地址只保留最近一次（等于把它挪到最前） */
    public static void record(Context c, String url, String title) {
        if (c == null || url == null) return;
        String u = url.trim();
        if (u.length() == 0 || u.startsWith("about:") || u.startsWith("javascript:")
                || u.startsWith("data:") || u.startsWith("blob:")) {
            return;
        }
        // 内置页面里的 index.html?v= 版本号变化不算新记录
        try {
            List<Item> all = load(c);
            ArrayList<Item> out = new ArrayList<>();
            Item it = new Item();
            it.url = u;
            it.title = title == null ? "" : title.trim();
            it.time = System.currentTimeMillis();
            out.add(it);
            for (Item old : all) {
                if (old.url == null || old.url.equals(u)) continue;
                out.add(old);
                if (out.size() >= MAX) break;
            }
            save(c, out);
        } catch (Throwable ignored) {
        }
    }

    public static List<Item> load(Context c) {
        ArrayList<Item> out = new ArrayList<>();
        try {
            SharedPreferences sp = c.getSharedPreferences(PREF, Context.MODE_PRIVATE);
            String raw = sp.getString(K_LIST, "[]");
            JSONArray arr = new JSONArray(raw == null ? "[]" : raw);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.optJSONObject(i);
                if (o == null) continue;
                Item it = new Item();
                it.url = o.optString("url", "");
                it.title = o.optString("title", "");
                it.time = o.optLong("time", 0);
                if (it.url.length() > 0) out.add(it);
            }
        } catch (Throwable ignored) {
        }
        return out;
    }

    private static void save(Context c, List<Item> items) {
        try {
            JSONArray arr = new JSONArray();
            for (Item it : items) {
                JSONObject o = new JSONObject();
                o.put("url", it.url);
                o.put("title", it.title);
                o.put("time", it.time);
                arr.put(o);
            }
            c.getSharedPreferences(PREF, Context.MODE_PRIVATE)
                    .edit().putString(K_LIST, arr.toString()).apply();
        } catch (Throwable ignored) {
        }
    }

    public static void clear(Context c) {
        try {
            c.getSharedPreferences(PREF, Context.MODE_PRIVATE)
                    .edit().remove(K_LIST).apply();
        } catch (Throwable ignored) {
        }
    }

    public static void remove(Context c, String url) {
        List<Item> all = load(c);
        ArrayList<Item> out = new ArrayList<>();
        for (Item it : all) {
            if (url != null && url.equals(it.url)) continue;
            out.add(it);
        }
        save(c, out);
    }
}
