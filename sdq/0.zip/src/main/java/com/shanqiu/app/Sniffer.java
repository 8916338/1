package com.shanqiu.app;

import android.text.TextUtils;
import android.webkit.WebView;

import org.json.JSONArray;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;

/**
 * 视频嗅探 + 页面内播放。
 *
 * 网页里的播放器有两种情况壳管不了：
 *   1. 播放器是第三方 iframe，全屏按钮走的是它自己的逻辑，点了没反应；
 *   2. 视频地址是动态拼出来的（HLS 的 m3u8），页面里根本没有 &lt;video src&gt;。
 *
 * 与其去猜各家播放器的全屏实现，不如把「真正的视频地址」抓出来，
 * 交给壳内置的播放器全屏播 —— 这条路对任何站点都成立。
 *
 * 抓取来源四处：
 *   · WebView 的网络请求（shouldInterceptRequest）：m3u8 / mp4 / mpd 等；
 *   · 页面 DOM：video / source 的 src、currentSrc；
 *   · performance 资源列表：blob 播放、JS 拉的播放列表也能抓到；
 *   · 页面里的 player_aaaa（苹果 CMS 系站点）：进页面就有地址，不用等播放。
 *
 * 只记地址，不改网页。列表按抓到的先后倒序，最多 40 条。
 *
 * 另有「页面内播放」（playInPage）：有些站点的视频是加密流，地址抓到了
 * 也播不了；那就别抓地址，把壳自己的播放器直接叠在网页那块视频的位置上 ——
 * 它看着还在网页原来的地方，但全屏按钮是我们自己画的了。
 */
public final class Sniffer {

    private Sniffer() {
    }

    private static final int MAX = 40;

    /** 视频类后缀（.ts 是 HLS 的分片，不单独列，否则一屏全是碎片） */
    private static final String[] EXT = {
            ".m3u8", ".mp4", ".m4v", ".webm", ".flv", ".mkv", ".mov", ".mpd", ".avi", ".3gp",
    };

    public static final class Hit {
        public String url;
        public String kind;
        public long time;
    }

    /** 抓到过的地址：key = 去掉参数的地址，value = 最近一次完整地址 */
    private static final LinkedHashMap<String, Hit> HITS = new LinkedHashMap<>();

    /** 网络线程往里写，主线程读，统一加锁 */
    private static synchronized void put(String url, String kind) {
        if (TextUtils.isEmpty(url)) return;
        String key = stripQuery(url);
        Hit h = new Hit();
        h.url = url;
        h.kind = kind;
        h.time = System.currentTimeMillis();
        // 重新放一次，保证「最近出现的在最前面」
        HITS.remove(key);
        HITS.put(key, h);
        while (HITS.size() > MAX) {
            String first = HITS.keySet().iterator().next();
            HITS.remove(first);
        }
    }

    /** 网络层回调：任何一条请求都过一遍，命中视频特征就记下来 */
    public static void note(String url) {
        if (TextUtils.isEmpty(url)) return;
        String u = url.toLowerCase(Locale.US);
        if (!(u.startsWith("http://") || u.startsWith("https://"))) return;
        for (String e : EXT) {
            int at = u.indexOf(e);
            if (at < 0) continue;
            // 后缀后面只能是结尾、? 或 #，避免 xxx.mp4.html 这种误判
            int after = at + e.length();
            if (after < u.length()) {
                char c = u.charAt(after);
                if (c != '?' && c != '#' && c != '&') continue;
            }
            put(url, e.substring(1));
            return;
        }
        // 没有扩展名但明显是 HLS 清单的也收
        if (u.contains("format=m3u8") || u.contains("type=m3u8")
                || u.contains("/hls/") || u.contains("playlist.m3u")) {
            put(url, "m3u8");
        }
    }

    /** 页面加载完后问一次 DOM + performance，补上网络层看不到的地址 */
    public static void collect(final WebView w) {
        if (w == null) return;
        final String js = "(function(){try{var out=[];"
                + "function add(u){if(u&&typeof u==='string'&&u.indexOf('http')===0&&out.indexOf(u)<0)out.push(u);}"
                // ① 播放器数据：苹果 CMS（MacCMS）系的站点会把地址写在 player_aaaa 里，
                //    encrypt 0 = 明文，1 = escape，2 = base64(escape)
                //    这一类网页从头到尾没有一个 <video>，全靠播放器脚本自己拼，
                //    网络层也只在点了播放之后才看得到 —— 这里提前拿现成的
                + "function dec(u,e){try{"
                + "if(!u)return '';"
                + "if(e==1)return unescape(u);"
                + "if(e==2)return unescape(atob(u));"
                + "return u;}catch(x){return u;}}"
                + "try{var pd=window.player_aaaa;"
                + "if(pd&&pd.url){add(dec(pd.url,pd.encrypt));add(dec(pd.url_next,pd.encrypt));}}catch(e){}"
                // ② 页面里的 video / audio
                + "var vs=document.querySelectorAll('video,audio');"
                + "for(var i=0;i<vs.length;i++){var v=vs[i];add(v.currentSrc);add(v.src);"
                + "var s=v.querySelectorAll?v.querySelectorAll('source'):[];"
                + "for(var j=0;j<s.length;j++)add(s[j].src);}"
                // ③ 加载过的资源：blob 播放、JS 拉的播放列表都在这里
                + "try{var es=performance.getEntriesByType('resource');"
                + "for(var k=0;k<es.length;k++){var n=es[k].name||'';"
                + "if(/\\.(m3u8|mp4|m4v|webm|flv|mkv|mov|mpd)(\\?|#|$)/i.test(n)||n.indexOf('format=m3u8')>0)add(n);}}catch(e){}"
                + "return JSON.stringify(out.slice(0,30));}catch(e){return '[]';}})()";
        try {
            w.evaluateJavascript(js, new android.webkit.ValueCallback<String>() {
                @Override
                public void onReceiveValue(String value) {
                    try {
                        JSONArray arr = new JSONArray(unquote(value));
                        for (int i = 0; i < arr.length(); i++) note(arr.optString(i));
                    } catch (Throwable ignored) {
                    }
                }
            });
        } catch (Throwable ignored) {
        }
    }

    /** 最近抓到的地址（新的在前） */
    public static synchronized List<Hit> hits() {
        ArrayList<Hit> out = new ArrayList<>(HITS.values());
        java.util.Collections.reverse(out);
        return out;
    }

    public static synchronized int count() {
        return HITS.size();
    }

    public static synchronized void clear() {
        HITS.clear();
    }

    // ------------------------------------------------------------ 面板

    public static void show(final MainActivity a) {
        if (a == null) return;
        // 打开面板前再补一次 DOM / performance，减少「刚进页面还没抓到」的空白
        collect(a.currentWeb());

        final List<Hit> list = hits();
        if (list.isEmpty()) {
            Ui.show(new android.app.AlertDialog.Builder(a)
                    .setTitle("视频嗅探")
                    .setMessage("这一页还没抓到视频地址。\n\n"
                            + "先让视频播起来（哪怕只播几秒），再回来看这里。\n"
                            + "抓不到的情况：视频走的是加密流、或者播放器把地址藏在加密脚本里。")
                    .setNegativeButton("知道了", null)
                    .create());
            return;
        }

        final String[] items = new String[list.size()];
        for (int i = 0; i < list.size(); i++) {
            Hit h = list.get(i);
            items[i] = nameOf(h) + "\n" + hostOf(h.url) + " · " + h.kind.toUpperCase(Locale.US);
        }

        android.app.AlertDialog.Builder b = new android.app.AlertDialog.Builder(a);
        b.setTitle("视频嗅探 · " + list.size() + " 个地址");
        b.setItems(items, new android.content.DialogInterface.OnClickListener() {
            @Override
            public void onClick(android.content.DialogInterface d, int which) {
                final Hit h = list.get(which);
                // 两种播法：先在网页原位播（能全屏、位置不变），
                // 播不了再退到独立播放器
                Ui.showList(new android.app.AlertDialog.Builder(a)
                        .setTitle(nameOf(h))
                        .setItems(new String[]{"在网页里播（原位全屏）", "用独立播放器播"},
                                new android.content.DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(android.content.DialogInterface d2, int w2) {
                                        if (w2 == 0) playInPage(a, h.url, nameOf(h));
                                        else PlayerActivity.play(a, h.url, nameOf(h));
                                    }
                                })
                        .setNegativeButton("取消", null)
                        .create());
            }
        });
        b.setNegativeButton("取消", null);
        b.setNeutralButton("复制链接", new android.content.DialogInterface.OnClickListener() {
            @Override
            public void onClick(android.content.DialogInterface d, int which) {
                StringBuilder sb = new StringBuilder();
                for (Hit h : list) sb.append(h.url).append('\n');
                Route.copyText(a, sb.toString().trim());
            }
        });
        b.setPositiveButton("重新嗅探", new android.content.DialogInterface.OnClickListener() {
            @Override
            public void onClick(android.content.DialogInterface d, int w) {
                collect(a.currentWeb());
                a.getWindow().getDecorView().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        show(a);
                    }
                }, 350);
            }
        });
        Ui.showList(b.create());
    }

    private static String nameOf(Hit h) {
        try {
            String p = h.url;
            int cut = p.indexOf('?');
            if (cut > 0) p = p.substring(0, cut);
            int slash = p.lastIndexOf('/');
            String name = slash >= 0 ? p.substring(slash + 1) : p;
            return TextUtils.isEmpty(name) ? h.kind.toUpperCase(Locale.US) : name;
        } catch (Throwable t) {
            return h.kind;
        }
    }

    private static String hostOf(String url) {
        try {
            android.net.Uri u = android.net.Uri.parse(url);
            String h = u.getHost();
            return TextUtils.isEmpty(h) ? "" : h;
        } catch (Throwable t) {
            return "";
        }
    }

    private static String stripQuery(String url) {
        int q = url.indexOf('?');
        return q > 0 ? url.substring(0, q) : url;
    }

    // ------------------------------------------------------------ 一键在网页里看

    /** 页面上有没有视频（有才让点，没有就直说） */
    public static void watch(final MainActivity a) {
        if (a == null) return;
        final WebView w = a.currentWeb();
        if (w == null) {
            Ui.toast(a, "页面还没准备好");
            return;
        }

        // ① 已经抓到地址了：直接用，不必再问页面
        List<Hit> hits = hits();
        if (!hits.isEmpty()) {
            Hit h = hits.get(0);
            playInPage(a, h.url, nameOf(h));
            return;
        }

        // ② 没抓到：问页面里有没有 video，有的话就地接管它的地址
        String js = "(function(){try{"
                + "var v=document.querySelector('video');"
                + "if(!v)return 'none';"
                + "var s=v.currentSrc||v.src||'';"
                + "if(!s){var so=v.querySelector('source');if(so)s=so.src||'';}"
                + "return s||'blank';}catch(e){return 'none';}})()";
        try {
            w.evaluateJavascript(js, new android.webkit.ValueCallback<String>() {
                @Override
                public void onReceiveValue(String value) {
                    String v = unquote(value);
                    if ("none".equals(v) || TextUtils.isEmpty(v)) {
                        Ui.show(new android.app.AlertDialog.Builder(a)
                                .setTitle("这一页没找到视频")
                                .setMessage("先把视频播起来（哪怕只播几秒），再从菜单里点"
                                        + "「视频嗅探」选地址播放。\n\n"
                                        + "有些站点的播放器藏在 iframe 里，"
                                        + "长按那个播放区域、在浏览器里打开它再试。")
                                .setNegativeButton("知道了", null)
                                .create());
                        return;
                    }
                    if ("blank".equals(v)) {
                        Ui.toast(a, "视频还在加载，先让画面出来再点");
                        return;
                    }
                    playInPage(a, v, "网页视频");
                }
            });
        } catch (Throwable t) {
            Ui.toast(a, "这一页没法接管播放");
        }
    }

    // ------------------------------------------------------------ 页面内播放

    /** 当前被接管播放的 WebView（换页 / 切窗口时收回） */
    private static final java.util.WeakHashMap<WebView, Boolean> BOUND =
            new java.util.WeakHashMap<>();

    /**
     * 把网页里的视频接管过来：量出那块 video 的屏幕坐标，
     * 让壳把自己的播放器叠在同一个位置上。
     *
     * 为什么不能靠网页自己全屏：全屏权限归浏览器宿主，网页只能「请求」，
     * WebView 又默认不理会这个请求（第三方 iframe 更是完全不认）——
     * 所以干脆不请求，我们自己就是宿主。
     *
     * 实现上不在页面里插任何节点，只量坐标。少动 DOM 就少一半出错的机会
     * （站点一刷新、一改样式，插进去的节点就错位了）。
     */
    public static void playInPage(final MainActivity a, final String url, final String title) {
        if (a == null || TextUtils.isEmpty(url)) return;
        final WebView w = a.currentWeb();
        if (w == null) {
            Ui.toast(a, "页面还没准备好");
            return;
        }
        // 宁可量到别的东西也别量不到 —— 短视频站点常常整页找不出一个 <video>
        // （播放器全在 iframe 里），所以退路一路铺到「整屏」。
        String js = "(function(){"
                + "function box(el){try{var b=el.getBoundingClientRect();"
                + "if(b&&b.width>=40&&b.height>=40)return b;}catch(e){}return null;}"
                + "function byTag(t){try{var a=document.querySelectorAll(t);"
                + "for(var i=0;i<a.length;i++){var b=box(a[i]);if(b)return b;}}catch(e){}return null;}"
                + "try{var vs=document.querySelectorAll('video');"
                + "for(var i=0;i<vs.length;i++){try{vs[i].pause();}catch(e){}}}catch(e){}"
                + "var r=byTag('video')||byTag('iframe')||byTag('canvas');"
                + "if(!r)return 'full';"
                + "return JSON.stringify([Math.round(Math.max(0,r.left)),"
                + "Math.round(Math.max(0,r.top)),Math.round(r.width),Math.round(r.height)]);"
                + "})()";
        try {
            w.evaluateJavascript(js, new android.webkit.ValueCallback<String>() {
                @Override
                public void onReceiveValue(String value) {
                    String v = unquote(value);
                    // 页面里量不到视频位置：铺满整个可用区域（0,0 当作左上角，
                    // 播放器那边会按根布局的尺寸夹一次）
                    int[] rect = "full".equals(v) ? new int[]{0, 0, 0, 0} : parseRect(v);
                    if (rect == null) {
                        PlayerActivity.play(a, url, title);
                        return;
                    }
                    BOUND.put(w, Boolean.TRUE);
                    PlayerActivity.embed(a, url, title, rect);
                }
            });
        } catch (Throwable t) {
            PlayerActivity.play(a, url, title);
        }
    }

    /** 收回：只清状态，页面上本来就没留东西 */
    public static void unembed(WebView w) {
        if (w == null) return;
        BOUND.remove(w);
    }

    /** 这个 WebView 当前是否被接管在播放 */
    public static boolean isEmbedded(WebView w) {
        return w != null && BOUND.containsKey(w);
    }

    /** evaluateJavascript 回来的是带引号的 JSON 字符串，拆两层 */
    private static String unquote(String v) {
        if (v == null) return "";
        String s = v.trim();
        if (s.length() >= 2 && s.startsWith("\"") && s.endsWith("\"")) {
            s = s.substring(1, s.length() - 1)
                    .replace("\\\"", "\"")
                    .replace("\\\\", "\\")
                    .replace("\\/", "/");
        }
        return s;
    }

    private static int[] parseRect(String json) {
        if (TextUtils.isEmpty(json) || "none".equals(json)) return null;
        try {
            JSONArray arr = new JSONArray(json);
            if (arr.length() < 4) return null;
            return new int[]{arr.getInt(0), arr.getInt(1), arr.getInt(2), arr.getInt(3)};
        } catch (Throwable t) {
            return null;
        }
    }
}
