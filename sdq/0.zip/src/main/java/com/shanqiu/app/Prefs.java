package com.shanqiu.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.Build;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.webkit.CookieManager;
import android.webkit.WebSettings;
import android.webkit.WebStorage;
import android.webkit.WebView;

import java.util.ArrayList;

/**
 * 「更多」面板里的浏览设置，全部存在本机 SharedPreferences。
 *
 * 六项：
 *   隐私模式     —— 不写浏览历史、退出清 Cookie / 缓存 / 表单
 *   手机 / 电脑版 —— 用桌面 UA + 页面按桌面宽度布局
 *   浏览器标识   —— 默认 / Chrome / Safari / Edge / 微信
 *   屏幕方向     —— 跟随系统 / 竖屏 / 横屏
 *   字体大小     —— 80% / 100% / 120% / 150%
 *   主题         —— 静蓝（默认）/ 暖橙 / 无色 / 青绿 / 墨紫 / 浅色三款
 *
 * 本类是纯设置面板 + 一组静态读写，没有可裁剪依赖。
 */
public final class Prefs {

    private static final String PREF = "vie_settings";

    private static final String K_PRIVACY = "privacy";
    private static final String K_DESKTOP = "desktop";
    private static final String K_UA = "ua";
    private static final String K_ORIENT = "orientation";
    private static final String K_FONT = "font";
    /** 主题按 id 存（"plain" / "blue" …），这样以后加预设、调顺序都不会串 */
    private static final String K_THEME_ID = "theme_id";
    /** 旧版本存的是下标，读一次迁移成 id 就删掉 */
    private static final String K_THEME_OLD = "theme";
    /** 默认配色换过两次（无色 → 暖橙 → 静蓝），每次只迁移一次，之后用户自己的选择说了算 */
    private static final String K_THEME_DEFAULT_BLUE = "theme_default_blue";
    // 初始页（用户在「更多 → 初始页」里改的，优先于打包配置）
    private static final String K_START_URL = "start_url";
    private static final String K_START_FILE = "start_file";
    /** 用户在「初始页」里自定义的名称，用于副行显示 */
    private static final String K_START_NAME = "start_name";
    // 网页控制（更多 → 网页控制）：网页的跳转和 JS 弹窗先停住，由用户放行
    private static final String K_GUARD = "guard";
    // 阅读模式（防误触）：网页里的链接点了也不跳
    private static final String K_READ = "readmode";
    /** 底部那颗按钮的首次说明已经弹过了 */
    private static final String K_GUARD_INTRO = "guard_intro";
    // ---- 教程弹窗统一闸门：三个节点各只弹一次，10 秒内的后到者被合并掉 ----
    private static final String K_TUTORIAL_AT = "tutorial_at";
    private static final long TUTORIAL_WINDOW_MS = 10000L;
    public static final String TUT_GUARD = "tut_guard";
    public static final String TUT_PLUGIN_INSTALL = "tut_plugin_install";
    public static final String TUT_PLUGIN_PAGE = "tut_plugin_page";

    /** 浏览器标识预设：id / 名称 / UA（空字符串表示系统默认） */
    static final String[][] UA_PRESETS = {
            {"default", "默认（本机 WebView）", ""},
            {"chrome", "Chrome 安卓",
                    "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 "
                            + "(KHTML, like Gecko) Chrome/122.0.0.0 Mobile Safari/537.36"},
            {"safari", "Safari iPhone",
                    "Mozilla/5.0 (iPhone; CPU iPhone OS 17_3 like Mac OS X) "
                            + "AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.3 "
                            + "Mobile/15E148 Safari/604.1"},
            {"edge", "Edge 安卓",
                    "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 "
                            + "(KHTML, like Gecko) Chrome/122.0.0.0 Mobile Safari/537.36 "
                            + "EdgA/122.0.0.0"},
            {"wechat", "微信内置",
                    "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 "
                            + "(KHTML, like Gecko) Version/4.0 Chrome/116.0.0.0 "
                            + "Mobile Safari/537.36 MicroMessenger/8.0.47"},
    };

    static final String UA_DESKTOP =
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                    + "(KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36";

    static final String[] ORIENT_NAMES = {"跟随系统", "锁定竖屏", "锁定横屏"};
    static final int[] ORIENT_VALUES = {
            android.content.pm.ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED,
            android.content.pm.ActivityInfo.SCREEN_ORIENTATION_PORTRAIT,
            android.content.pm.ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE,
    };

    static final int[] FONT_VALUES = {80, 100, 120, 150};

    private Prefs() {
    }

    private static SharedPreferences sp(Context c) {
        return c.getSharedPreferences(PREF, Context.MODE_PRIVATE);
    }

    // ------------------------------------------------------------ 读写

    public static boolean privacy(Context c) {
        return sp(c).getBoolean(K_PRIVACY, false);
    }

    public static boolean desktop(Context c) {
        return sp(c).getBoolean(K_DESKTOP, false);
    }

    public static String uaId(Context c) {
        return sp(c).getString(K_UA, "default");
    }

    public static int uaIndex(Context c) {
        String id = uaId(c);
        for (int i = 0; i < UA_PRESETS.length; i++) {
            if (UA_PRESETS[i][0].equals(id)) return i;
        }
        return 0;
    }

    public static String uaName(Context c) {
        return UA_PRESETS[uaIndex(c)][1];
    }

    public static int orientationIndex(Context c) {
        int i = sp(c).getInt(K_ORIENT, 0);
        return i < 0 || i >= ORIENT_NAMES.length ? 0 : i;
    }

    public static int fontPercent(Context c) {
        int v = sp(c).getInt(K_FONT, 100);
        for (int f : FONT_VALUES) if (f == v) return v;
        return 100;
    }

    public static int themeIndex(Context c) {
        String id = sp(c).getString(K_THEME_ID, "");
        if (TextUtils.isEmpty(id)) id = migrateTheme(c);
        id = migrateDefaultTheme(c, id);
        return Theme.indexOf(id);
    }

    /**
     * 默认配色换成「静蓝」的一次性迁移。
     *
     * 只挪还停在上一版默认「暖橙」上的用户（也就是没自己挑过主题的），
     * 迁移过一次就打标记；之后用户自己选了什么（包括故意选回暖橙）都不会再被覆盖。
     */
    private static String migrateDefaultTheme(Context c, String id) {
        SharedPreferences sp = sp(c);
        if (sp.getBoolean(K_THEME_DEFAULT_BLUE, false)) return id;
        sp.edit().putBoolean(K_THEME_DEFAULT_BLUE, true).apply();
        if (!"orange".equals(id)) return id;
        sp.edit().putString(K_THEME_ID, Theme.DEFAULT_ID).apply();
        return Theme.DEFAULT_ID;
    }

    /**
     * 旧版主题是按数组下标存的（0=静蓝 … 9=海夜）。
     * 现在存的都是 id，直接沿用下标会串色，这里按 id 换一次。
     */
    private static String migrateTheme(Context c) {
        String[] old = {"blue", "orange", "green", "violet", "sakura", "sky",
                "night", "ink", "ember", "sea"};
        int o = sp(c).getInt(K_THEME_OLD, -1);
        String id = (o >= 0 && o < old.length) ? old[o] : Theme.DEFAULT_ID;
        sp(c).edit().putString(K_THEME_ID, id).remove(K_THEME_OLD).apply();
        return id;
    }

    static void setThemeIndex(Context c, int i) {
        sp(c).edit()
                .putString(K_THEME_ID, Theme.idOf(i))
                .putBoolean(K_THEME_DEFAULT_BLUE, true)   // 用户自己选的，别再被默认值迁移覆盖
                .apply();
    }

    // ------------------------------------------------------------ 初始页

    /** 用户自选的在线初始页（空 = 没设） */
    public static String startUrl(Context c) {
        return sp(c).getString(K_START_URL, "");
    }

    /** 用户自选的内置初始页文件名（空 = 没设） */
    public static String startFile(Context c) {
        return sp(c).getString(K_START_FILE, "");
    }

    static void setStartFile(Context c, String file) {
        sp(c).edit().putString(K_START_FILE, file == null ? "" : file)
                .putString(K_START_URL, "").apply();
    }

    static void setStartUrl(Context c, String url) {
        sp(c).edit().putString(K_START_URL, url == null ? "" : url)
                .putString(K_START_FILE, "").apply();
    }

    /** 清掉自选初始页，回到打包时的预设 */
    static void clearStart(Context c) {
        sp(c).edit().remove(K_START_URL).remove(K_START_FILE).apply();
    }

    /**
     * 教程弹窗统一闸门：每个 tag 一生只认一次，且 10 秒内只放一个出来。
     *
     * 返回 true  = 这次可以弹说明，
     * 返回 false = 这个节点弹过了，或 10 秒内刚弹过别的（被合并掉，不排队补弹）。
     *
     * 无论弹不弹，tag 都会记为已处理 —— 三个节点（网页控制首次说明 /
     * 首次装插件 / 网页首次载入插件）合起来最多看到一条，不会连着糊三层。
     */
    public static boolean tutorialOnce(Context c, String tag) {
        if (c == null || TextUtils.isEmpty(tag)) return false;
        SharedPreferences s = sp(c);
        if (s.getBoolean(tag, false)) return false;
        long now = System.currentTimeMillis();
        long last = s.getLong(K_TUTORIAL_AT, 0);
        boolean allow = now - last >= TUTORIAL_WINDOW_MS;
        s.edit().putBoolean(tag, true)
                .putLong(K_TUTORIAL_AT, allow ? now : last).apply();
        return allow;
    }

    private static void put(Context c, String k, boolean v) {
        sp(c).edit().putBoolean(k, v).apply();
    }

    private static void put(Context c, String k, int v) {
        sp(c).edit().putInt(k, v).apply();
    }

    private static void put(Context c, String k, String v) {
        sp(c).edit().putString(k, v).apply();
    }

    // ------------------------------------------------------------ 生效

    /** 把当前设置套到前台 WebView（切换窗口、重建 WebView 后都要再调一次） */
    public static void apply(MainActivity a) {
        if (a == null) return;
        WebView w = a.currentWeb();
        if (w != null) applyTo(a, w);
        try {
            a.setRequestedOrientation(ORIENT_VALUES[orientationIndex(a)]);
        } catch (Throwable ignored) {
        }
    }

    /**
     * 把当前设置套到「任意一个」WebView 上。
     * 新窗口 / 后台窗口在 loadUrl 之前就要调，否则第一个页面会按默认 UA
     * 渲染完才改，看起来就是「手机/电脑切换、浏览器标识不完全生效」。
     */
    public static void applyTo(Context c, WebView w) {
        if (w == null) return;
        try {
            WebSettings s = w.getSettings();
            s.setTextZoom(fontPercent(c));
            // 传 null = 恢复系统默认 UA（切回「默认」标识时必须走这里）
            s.setUserAgentString(uaOf(c));
            s.setUseWideViewPort(true);
            // 两种模式都「按整页宽度缩放适配」：
            // 旧写法在电脑版时关掉 overview，宽屏网页（固定 1200/1440 布局）
            // 会只显示左上角、必须横向拖动 —— 这就是「电脑版部分网页无效」的原因。
            s.setLoadWithOverviewMode(true);
            s.setDefaultTextEncodingName("UTF-8");
            if (desktop(c)) {
                // 桌面 UA 拿到的是宽屏布局，交给 WebView 等比缩到屏宽，再允许双指放大
                s.setSupportZoom(true);
                s.setBuiltInZoomControls(true);
                s.setDisplayZoomControls(false);
                s.setTextZoom(100);
                s.setUseWideViewPort(true);
            } else {
                s.setSupportZoom(true);
                s.setBuiltInZoomControls(true);
                s.setDisplayZoomControls(false);
            }
            s.setCacheMode(privacy(c)
                    ? WebSettings.LOAD_NO_CACHE : WebSettings.LOAD_DEFAULT);
        } catch (Throwable ignored) {
        }
        if (c instanceof MainActivity) applyWebDark((MainActivity) c, w);
    }

    /**
     * 把主题的深浅应用到网页渲染。
     *
     * 重点修「深色渲染不彻底、反差严重、极度丑陋」：
     * 旧做法是 API 29-32 开 FORCE_DARK 做算法反色 —— 它把文字、图片、
     * 各个区块各转各的，经常一半深一半白，反差刺眼，这就是「渲染不彻底」的根源。
     * 现在的策略：
     *   - Android 13+（API 33）：setAlgorithmicDarkeningAllowed，系统新策略
     *     优先用网页自己声明的深色模式（prefers-color-scheme），网页支持就
     *     整套变深，不支持就保持原样，绝不做半吊子反转；
     *   - Android 12 及以下：直接不做反色（FORCE_DARK_OFF），网页保持原样；
     *     深色体现在浏览器界面和内置页（CSS 变量注入）上。
     * 配合 MainActivity 给第三方页注入 color-scheme:dark，支持深色的
     * 表单控件、滚动条也会跟着变深。
     * 浅色主题显式全部关掉，不跟系统「强制深色」打架。
     */
    public static void applyWebDark(MainActivity a, WebView w) {
        if (w == null) return;
        boolean dark = Theme.isDark(themeIndex(a));
        try {
            WebSettings s = w.getSettings();
            if (Build.VERSION.SDK_INT >= 33) {
                s.setAlgorithmicDarkeningAllowed(dark);
            } else if (Build.VERSION.SDK_INT >= 29) {
                s.setForceDark(WebSettings.FORCE_DARK_OFF);
            }
        } catch (Throwable ignored) {
        }
    }

    /** 当前应该用的 UA；返回 null 表示用系统默认 */
    public static String uaOf(Context c) {
        if (desktop(c)) return UA_DESKTOP;
        String id = uaId(c);
        for (String[] p : UA_PRESETS) {
            if (p[0].equals(id)) {
                return TextUtils.isEmpty(p[2]) ? null : p[2];
            }
        }
        return null;
    }

    /** 打开 / 关闭隐私模式：开的那一刻就把残留清掉 */
    public static void setPrivacy(MainActivity a, boolean on) {
        put(a, K_PRIVACY, on);
        if (!on) {
            apply(a);
            return;
        }
        try {
            CookieManager cm = CookieManager.getInstance();
            cm.removeAllCookies(null);
            cm.flush();
        } catch (Throwable ignored) {
        }
        try {
            WebStorage.getInstance().deleteAllData();
        } catch (Throwable ignored) {
        }
        WebView w = a.currentWeb();
        if (w != null) {
            try {
                w.clearHistory();
                w.clearFormData();
                w.clearCache(true);
                w.clearSslPreferences();
            } catch (Throwable ignored) {
            }
        }
        apply(a);
    }

    /** 切换隐私模式（更多面板用） */
    public static void togglePrivacy(MainActivity a) {
        setPrivacy(a, !privacy(a));
        Ui.toast(a, privacy(a) ? "隐私模式已开启" : "隐私模式已关闭");
    }

    /** 切换手机版 / 电脑版（更多面板用） */
    public static void toggleDesktop(MainActivity a) {
        put(a, K_DESKTOP, !desktop(a));
        apply(a);
        a.reloadKeepPosition();
        Ui.toast(a, desktop(a) ? "已切换为电脑版" : "已切换为手机版");
    }

    // ------------------------------------------------------------ 跳转拦截

    /** 跳转拦截是否开启（NavGuard 读这个） */
    public static boolean guard(Context c) {
        return sp(c).getBoolean(K_GUARD, false);
    }

    /** 切换网页控制（管理面板用）：关掉的同时把队列、临时决策、标语一起清掉 */
    public static void toggleGuard(MainActivity a) {
        boolean on = !guard(a);
        put(a, K_GUARD, on);
        NavGuard.clear(a);
        NavGuard.sync(a);
        Ui.toast(a, on
                ? "网页控制已开启：网页的跳转和弹窗会先停下来，由你决定"
                : "网页控制已关闭：网页照常跳转、照常弹窗");
    }

    /** 底部按钮的首次说明弹过没有 */
    public static boolean guardIntro(Context c) {
        return sp(c).getBoolean(K_GUARD_INTRO, false);
    }

    public static void setGuardIntro(Context c) {
        put(c, K_GUARD_INTRO, true);
    }

    // ------------------------------------------------------------ 阅读模式（防误触）

    /** 阅读模式是否开启：网页里的链接点了也不跳，防止误触隐藏块 */
    public static boolean read(Context c) {
        return sp(c).getBoolean(K_READ, false);
    }

    /** 阅读模式开关（入口在网页底部那颗按钮的面板里，开着时按钮不隐藏） */
    public static void setRead(MainActivity a, boolean on) {
        put(a, K_READ, on);
        NavGuard.sync(a);
    }

    /** 退出时清理（只在隐私模式下） */
    public static void onExit(MainActivity a) {
        if (a == null || !privacy(a)) return;
        try {
            CookieManager cm = CookieManager.getInstance();
            cm.removeAllCookies(null);
            cm.flush();
        } catch (Throwable ignored) {
        }
        try {
            WebStorage.getInstance().deleteAllData();
        } catch (Throwable ignored) {
        }
        WebView w = a.currentWeb();
        if (w != null) {
            try {
                w.clearCache(true);
                w.clearFormData();
                w.clearHistory();
            } catch (Throwable ignored) {
            }
        }
    }

    // ------------------------------------------------------------ 面板

    public static void chooseUa(final MainActivity a) {
        String[] items = new String[UA_PRESETS.length];
        for (int i = 0; i < UA_PRESETS.length; i++) items[i] = UA_PRESETS[i][1];
        // 与「屏幕方向 / 初始页」同一套弹窗：一行一个独立色块 + 选中对勾
        Ui.choose(a, "浏览器标识", items, uaIndex(a), new Ui.Choice() {
            @Override
            public void onPick(int which) {
                if (which < 0 || which >= UA_PRESETS.length) return;
                put(a, K_UA, UA_PRESETS[which][0]);
                apply(a);
                a.reloadKeepPosition();
                Ui.toast(a, "标识已切换为 " + UA_PRESETS[which][1]);
            }
        });
    }

    public static void chooseOrientation(final MainActivity a) {
        // 一行一个独立色块的弹窗（系统 setSingleChoiceItems 会把选项糊成一整块）
        Ui.choose(a, "屏幕方向", ORIENT_NAMES, orientationIndex(a), new Ui.Choice() {
            @Override
            public void onPick(int which) {
                if (which < 0 || which >= ORIENT_NAMES.length) return;
                put(a, K_ORIENT, which);
                try {
                    a.setRequestedOrientation(ORIENT_VALUES[which]);
                } catch (Throwable ignored) {
                }
            }
        });
    }

    // ------------------------------------------------------------ 字体大小（拖动）

    static final int FONT_MIN = 70;
    static final int FONT_MAX = 200;
    static final int FONT_STEP = 5;

    /**
     * 字体大小：拖动调节。
     *
     * 拖动时立刻把当前网页的 textZoom 改掉，松手就是最终值 ——
     * 不用「选一项 → 关弹窗 → 看效果 → 再进来调」来回折腾。
     * 取消则还原成进来之前的百分比。
     */
    public static void chooseFont(final MainActivity a) {
        final int origin = fontPercent(a);

        final int pad = Ui.dp(a, 20);
        LinearLayout box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(pad, Ui.dp(a, 8), pad, Ui.dp(a, 0));

        final TextView value = new TextView(a);
        value.setText(origin + "%");
        value.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 22f);
        value.setTextColor(Shell.of(a).text);
        value.setGravity(android.view.Gravity.CENTER);
        box.addView(value, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView hint = new TextView(a);
        hint.setText("左右拖动，网页文字实时变化");
        hint.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 12f);
        hint.setTextColor(Shell.of(a).sub);
        hint.setGravity(android.view.Gravity.CENTER);
        LinearLayout.LayoutParams hlp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        hlp.topMargin = Ui.dp(a, 2);
        hlp.bottomMargin = Ui.dp(a, 6);
        box.addView(hint, hlp);

        SeekBar sb = new SeekBar(a);
        sb.setMax((FONT_MAX - FONT_MIN) / FONT_STEP);
        sb.setProgress(Math.max(0, Math.min(sb.getMax(), (origin - FONT_MIN) / FONT_STEP)));
        box.addView(sb, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        final int[] picked = {origin};
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar bar, int progress, boolean fromUser) {
                int v = FONT_MIN + progress * FONT_STEP;
                picked[0] = v;
                value.setText(v + "%");
                WebView w = a.currentWeb();
                if (w != null) {
                    try {
                        w.getSettings().setTextZoom(v);
                    } catch (Throwable ignored) {
                    }
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar bar) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar bar) {
            }
        });

        AlertDialog.Builder b = new AlertDialog.Builder(a);
        b.setTitle("字体大小");
        b.setView(box);
        b.setPositiveButton("确定", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface d, int w) {
                put(a, K_FONT, picked[0]);
                WebView web = a.currentWeb();
                if (web != null) {
                    try {
                        web.getSettings().setTextZoom(picked[0]);
                    } catch (Throwable ignored) {
                    }
                }
            }
        });
        b.setNegativeButton("取消", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface d, int w) {
                WebView web = a.currentWeb();
                if (web != null) {
                    try {
                        web.getSettings().setTextZoom(origin);
                    } catch (Throwable ignored) {
                    }
                }
            }
        });
        Ui.show(b.create());
    }

    /**
     * 主题切换：不弹选择框，点一下换下一套、循环往复，立即生效 ——
     * 浏览器界面、当前网页、开着的面板和弹窗全部跟着换色
     * （面板在 MoreMenu 里重开一次，重新取色）。
     */
    public static void cycleTheme(final MainActivity a) {
        int n = Theme.count();
        int next = (themeIndex(a) + 1) % n;
        setThemeIndex(a, next);
        a.rethemeNow();
        Ui.toast(a, "主题：" + Theme.nameOf(next) + "（" + (next + 1) + "/" + n + "）");
        MoreMenu.show(a);   // 面板重开，弹窗颜色立即体现
    }

    // ------------------------------------------------------------ 初始页

    /**
     * 「更多 → 初始页」的副标题：显示这一项的名字，不是网址。
     *
     * 优先级：用户自定义的名字 → startPages 里匹配到的名字 → 网址兜底。
     */
    public static String startName(MainActivity a) {
        String custom = sp(a).getString(K_START_NAME, "");
        if (!TextUtils.isEmpty(custom)) return custom;

        String target = startTarget(a);
        if (TextUtils.isEmpty(target)) return "默认首页";

        String hit = nameOfTarget(target);
        return TextUtils.isEmpty(hit) ? target : hit;
    }

    /** 在 START_PAGES_JSON 里找这个地址/文件对应的名字 */
    private static String nameOfTarget(String target) {
        if (TextUtils.isEmpty(target)) return "";
        try {
            org.json.JSONArray arr = Config.startPages();
            for (int i = 0; i < arr.length(); i++) {
                org.json.JSONObject o = arr.optJSONObject(i);
                if (o == null) continue;
                String name = o.optString("name", "");
                if (TextUtils.isEmpty(name)) continue;
                String url = o.optString("url", "");
                String file = o.optString("file", "");
                if (!TextUtils.isEmpty(url) && sameUrl(url, target)) return name;
                if (!TextUtils.isEmpty(file)
                        && sameUrl(Site.ORIGIN + "/" + file, target)) return name;
            }
        } catch (Throwable ignored) {
        }
        return "";
    }

    private static boolean sameUrl(String x, String y) {
        if (x == null || y == null) return false;
        return x.trim().replaceAll("/+$", "").equalsIgnoreCase(
                y.trim().replaceAll("/+$", ""));
    }

    /** 当前生效的初始页地址（用户自选 → 打包预设 → 内置首页），null 表示没有独立初始页 */
    public static String startTarget(MainActivity a) {
        String su = startUrl(a);
        if (!TextUtils.isEmpty(su)) return su;
        String sf = startFile(a);
        if (!TextUtils.isEmpty(sf)) return Site.ORIGIN + "/" + sf;
        if (!TextUtils.isEmpty(Config.START_URL)) return Config.START_URL;
        if (!TextUtils.isEmpty(Config.START_FILE)) return Site.ORIGIN + "/" + Config.START_FILE;
        return null;
    }

    /**
     * 初始页设置：列出 app-config.json 里 startPages 预设的每一项（显示名称），
     * 最后一行「自定义」可以自己填名称 + 网址。
     *
     * 没有「恢复打包默认」—— 想回到打包值，直接重装或在 startPages 里配好即可。
     */
    public static void chooseStart(final MainActivity a) {
        final ArrayList<String> names = new ArrayList<>();
        final ArrayList<String> targets = new ArrayList<>();

        try {
            org.json.JSONArray arr = Config.startPages();
            for (int i = 0; i < arr.length(); i++) {
                org.json.JSONObject o = arr.optJSONObject(i);
                if (o == null) continue;
                String name = o.optString("name", "");
                String url = o.optString("url", "");
                String file = o.optString("file", "");
                String target = !TextUtils.isEmpty(url) ? url
                        : (TextUtils.isEmpty(file) ? "" : Site.ORIGIN + "/" + file);
                if (TextUtils.isEmpty(target)) continue;
                names.add(TextUtils.isEmpty(name) ? target : name);
                targets.add(target);
            }
        } catch (Throwable ignored) {
        }

        names.add("自定义");

        String cur = startTarget(a);
        int curIdx = -1;
        for (int i = 0; i < targets.size(); i++) {
            if (sameUrl(targets.get(i), cur)) {
                curIdx = i;
                break;
            }
        }

        final String[] items = names.toArray(new String[0]);
        Ui.choose(a, "初始页", items, curIdx, new Ui.Choice() {
            @Override
            public void onPick(int which) {
                if (which == targets.size()) {
                    inputStart(a);
                    return;
                }
                if (which < 0 || which >= targets.size()) return;
                String target = targets.get(which);
                setStartTarget(a, target);
                put(a, K_START_NAME, names.get(which));
                applyStart(a);
            }
        });
    }

    /** 把「地址或内置文件」拆成可以存的两半 */
    private static void setStartTarget(MainActivity a, String target) {
        if (TextUtils.isEmpty(target)) return;
        String origin = Site.ORIGIN + "/";
        if (target.startsWith(origin)) {
            setStartFile(a, target.substring(origin.length()));
        } else {
            setStartUrl(a, target);
        }
    }

    /** 自定义初始页：名称 + 网址，两个都能填 */
    private static void inputStart(final MainActivity a) {
        final int pad = Ui.dp(a, 20);
        LinearLayout box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(pad, Ui.dp(a, 6), pad, Ui.dp(a, 2));

        TextView t1 = new TextView(a);
        t1.setText("名称");
        t1.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 12f);
        t1.setTextColor(Shell.of(a).sub);
        box.addView(t1);

        final EditText etName = new EditText(a);
        etName.setSingleLine(true);
        etName.setHint("给这个初始页起个名字");
        etName.setText(startName(a));
        etName.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 14f);
        box.addView(etName);

        TextView t2 = new TextView(a);
        t2.setText("网址");
        t2.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 12f);
        t2.setTextColor(Shell.of(a).sub);
        LinearLayout.LayoutParams lp2 = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp2.topMargin = Ui.dp(a, 10);
        box.addView(t2, lp2);

        final EditText etUrl = new EditText(a);
        etUrl.setSingleLine(true);
        etUrl.setHint("https://");
        etUrl.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 14f);
        etUrl.setInputType(android.text.InputType.TYPE_TEXT_VARIATION_URI);
        String cur = startUrl(a);
        if (!TextUtils.isEmpty(cur)) etUrl.setText(cur);
        box.addView(etUrl);

        AlertDialog.Builder b = new AlertDialog.Builder(a);
        b.setTitle("自定义初始页");
        b.setView(box);
        b.setNegativeButton("取消", null);
        b.setPositiveButton("保存", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface d, int w) {
                String u = Bookmarks.normalize(String.valueOf(etUrl.getText()).trim());
                if (TextUtils.isEmpty(u) || !Route.isHttp(u)) {
                    Ui.toast(a, "只支持 http / https 网址");
                    return;
                }
                String n = String.valueOf(etName.getText()).trim();
                setStartUrl(a, u);
                put(a, K_START_NAME, TextUtils.isEmpty(n) ? u : n);
                applyStart(a);
            }
        });
        Ui.show(b.create());
    }

    /** 改完初始页立刻生效：提示 + 下一次打开时加载 */
    private static void applyStart(final MainActivity a) {
        Ui.toast(a, "初始页已设置，下次打开生效");
    }

    /** 清掉用户自定义的初始页（回到打包预设） */
    static void resetStartName(Context c) {
        sp(c).edit().remove(K_START_NAME).apply();
    }

}
