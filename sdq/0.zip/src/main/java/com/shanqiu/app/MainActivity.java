package com.shanqiu.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.ClipData;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.graphics.Bitmap;
import android.graphics.PorterDuff;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.provider.Settings;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.ValueCallback;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceError;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.JsResult;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.io.File;
import java.util.ArrayList;

/**
 * 纯壳。
 *
 * 行为约定（全部在这里落地）：
 *  1. 页面里点普通链接 → 在壳内加载，绝不跳浏览器
 *  2. 页面里点 .apk / .zip 等下载链接 → 弹面板问「下载 / 交给浏览器 / 复制」
 *  3. 页面里点 mqq:// weixin:// 之类的协议 → 弹系统应用选择器
 *  4. 长按图片 → 保存图片 / 分享图片
 *  5. 长按链接 → 用浏览器打开 / 复制链接 / 收藏
 *  6. 右下闪电球 → 刷新 / 收藏本页 / 前进后退 / 回启动页 / 备份站点 / 书签 / 喝咖啡
 */
public class MainActivity extends Activity {

    public static final String EXTRA_URL = "extra_url";

    private static final int REQ_FILE = 1001;

    private FrameLayout root;
    private WebView web;
    private ProgressBar bar;
    private View errorView;
    private Fab fab;

    /** 网页视频全屏时的容器：铺满整个窗口，黑色底 */
    private FrameLayout fullLayer;
    private View customView;
    private WebChromeClient.CustomViewCallback customCallback;
    private boolean fullscreen;
    /** 全屏里右上角的「横屏 / 竖屏」切换按钮 */
    private TextView rotateBtn;
    /** 每次进全屏自增，异步探测回来的旧结果直接丢弃 */
    private int orientSeq;
    private boolean orientDecided;
    /** 全屏时锁的方向，退出时恢复 */
    private int normalOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED;
    /** 进全屏前的系统栏可见性，退出时原样还原 */
    private int normalUiVisibility = 0;
    /** 系统开了「旋转锁定」时 SENSOR 不会转，需要补一记强制横屏 */
    private boolean forceLandscapeIfStuck;

    private Downloader downloader;
    private ValueCallback<Uri[]> fileCallback;

    private File pendingApk;

    private final Handler ui = new Handler(Looper.getMainLooper());
    private long pressSeq = 0;
    private long lastSheetAt = 0;

    /** 正在加载首页（在线主站），失败要回落内置页 */
    private boolean expectingHome;
    /** 本次是否已经回落过，避免来回跳 */
    private boolean fellBack;
    /** 在线主站多久没加载完就认为打不开 */
    private static final long HOME_TIMEOUT_MS = 12000;
    private final Runnable homeTimeout = new Runnable() {
        @Override
        public void run() {
            if (!expectingHome || fellBack) return;
            fallbackToBuiltin("在线站点响应超时");
        }
    };

    // ================================================================ 生命周期

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        downloader = new Downloader(this);

        root = new FrameLayout(this);
        applyPageColor(null);

        web = new WebView(this);
        applyPageColor(web);
        root.addView(web, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        bar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        bar.setMax(100);
        try {
            bar.getProgressDrawable().setColorFilter(
                    Shell.of(this).accent, PorterDuff.Mode.SRC_IN);
        } catch (Throwable ignored) {
        }
        FrameLayout.LayoutParams blp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 3));
        blp.gravity = Gravity.TOP;
        bar.setLayoutParams(blp);
        bar.setVisibility(View.GONE);
        root.addView(bar);

        setContentView(root);
        applySystemBarInsets();

        setupFullLayer();
        setupWeb();
        setupFab();
        // 跳转拦截的底部胶囊按钮（挂在网页底部，有拦截内容时才浮出来）
        NavGuard.attach(this);
        Prefs.apply(this);
        FabRegistry.autoUpdateCheck(this);

        if (!getSharedPreferences("shell_tip", MODE_PRIVATE).getBoolean("tipped", false)) {
            getSharedPreferences("shell_tip", MODE_PRIVATE).edit()
                    .putBoolean("tipped", true).apply();
            ui.postDelayed(new Runnable() {
                @Override
                public void run() {
                    Ui.toast(MainActivity.this,
                            "右下角闪电球是菜单 · 长按图片可保存");
                }
            }, 2200);
        }
        String start = getIntent() == null ? null : getIntent().getStringExtra(EXTRA_URL);
        if (TextUtils.isEmpty(start)) loadStart();
        else web.loadUrl(start);
    }

    // ================================================================ 主题

    /**
     * 换肤。壳和网页分开处理：
     *   · 壳（进度条、错误层、根布局）= Shell 配色，独立逻辑；
     *   · 网页（WebView 底色、内置页变量、深色策略）= Theme 配色。
     * 壳的颜色不会写进网页，网页也不会被壳色染到。
     */
    public void applyTheme() {
        Theme.Palette p = Shell.of(this);
        applyPageColor(root);
        applyPageColor(web);
        try {
            bar.getProgressDrawable().setColorFilter(p.accent, PorterDuff.Mode.SRC_IN);
        } catch (Throwable ignored) {
        }
        if (errorView != null) {
            // 错误页是浏览器自己的界面，跟壳色走
            errorView.setBackgroundColor(p.page);
        }
        Prefs.applyWebDark(this, web);
    }

    /** 主题切换后让当前页面立刻换色（只换浏览器自己的界面，网页保持原样） */
    public void rethemeNow() {
        applyTheme();
    }

    /**
     * 给内容区上底色。
     *
     * root 是浏览器本体的一部分，用壳的面板底色；
     * WebView 必须用中性色（白 / 深色主题下黑），绝不拿主题色去染 ——
     * 网页里没铺背景的区块会透出这层颜色，用主题色就会「壳色染进网页」。
     */
    private void applyPageColor(View v) {
        if (v == null) {
            if (root != null) root.setBackgroundColor(Shell.of(this).panel);
            return;
        }
        boolean dark = Theme.isDark(Prefs.themeIndex(this));
        v.setBackgroundColor(dark ? 0xFF000000 : 0xFFFFFFFF);
    }

    /**
     * Android 15（API 35）开始，targetSdk ≥ 35 的应用被强制 edge-to-edge：
     * 窗口不再自己避开状态栏和手势条，页面会直接顶到状态栏底下，顶部一截被挡住。
     * 这里统一按系统栏高度给根布局补上下内边距。
     *
     * 低版本系统（状态栏本来就给内容让了位）回调拿到的 inset 是 0，
     * 不会重复加；视频全屏时系统栏被隐藏，inset 也变 0，画面照样铺满。
     */
    private void applySystemBarInsets() {
        root.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
            @Override
            public WindowInsets onApplyWindowInsets(View v, WindowInsets insets) {
                int top;
                int bottom;
                if (Build.VERSION.SDK_INT >= 30) {
                    android.graphics.Insets sb = insets.getInsets(WindowInsets.Type.systemBars());
                    top = sb.top;
                    bottom = sb.bottom;
                } else {
                    top = insets.getSystemWindowInsetTop();
                    bottom = insets.getSystemWindowInsetBottom();
                }
                if (v.getPaddingTop() != top || v.getPaddingBottom() != bottom) {
                    v.setPadding(0, top, 0, bottom);
                    // 子 View 的 margin 是相对 padding 内沿的，可用高度变小了，
                    // 贴底摆放的闪电球会被挤出可视区，这里重新夹一次
                    if (fab != null) fab.clampIntoView();
                }
                return insets;
            }
        });
        root.requestApplyInsets();
    }

    /**
     * 打开首页（首页按钮 / 错误页「返回首页」走这里）。
     * 优先级：app-config.json 里 pages 指定的 home 页（在线或内置）→
     * 在线站点（Config.ONLINE，打不开自动回落内置页）→ 内置 index.html。
     */
    public void loadHome() {
        if (web == null) return;
        hideError();
        ui.removeCallbacks(homeTimeout);
        fellBack = false;

        // pages 里明确指定的在线启动页
        if (!TextUtils.isEmpty(Config.HOME_URL)) {
            expectingHome = true;
            ui.postDelayed(homeTimeout, HOME_TIMEOUT_MS);
            beginLoading();
            web.loadUrl(Config.HOME_URL);
            return;
        }

        if (!Site.hasOnline()) {
            expectingHome = false;
            web.loadUrl(Site.builtinUrl(this));
            return;
        }

        expectingHome = true;
        ui.postDelayed(homeTimeout, HOME_TIMEOUT_MS);
        web.loadUrl(Config.ONLINE);
    }

    /**
     * 打开初始页（App 启动时走这里，和首页是两回事）。
     * 优先级：用户在「更多 → 初始页」改过的 → app-config.json 里 start:true 的页面
     * → 没配就等于首页。
     * 初始页是在线地址时带 12 秒超时，打不开回落内置首页。
     */
    public void loadStart() {
        if (web == null) return;
        String t = Prefs.startTarget(this);
        if (TextUtils.isEmpty(t)) {
            loadHome();
            return;
        }
        hideError();
        ui.removeCallbacks(homeTimeout);
        fellBack = false;
        boolean online = Route.isHttp(t) && !Site.HOST.equals(Route.hostOf(t));
        expectingHome = online;
        if (online) ui.postDelayed(homeTimeout, HOME_TIMEOUT_MS);
        beginLoading();
        web.loadUrl(t);
    }

    /** 在线站点打不开时的兜底：切到 APK 自带的页面，别让用户对着白屏 */
    private void fallbackToBuiltin(String why) {
        if (web == null || fellBack) return;
        fellBack = true;
        expectingHome = false;
        ui.removeCallbacks(homeTimeout);
        hideError();
        Ui.toast(this, why + "，已切到内置页面");
        web.loadUrl(Site.builtinUrl(this));
    }

    /**
     * 用户自己跳走了（点书签、输入网址、前进后退），就别再拿「首页加载」的规则去兜底，
     * 否则 12 秒一到会把用户正在看的页面顶掉。
     */
    private void cancelHomeExpect() {
        if (!expectingHome) return;
        expectingHome = false;
        ui.removeCallbacks(homeTimeout);
    }

    private void setupFab() {
        // 整颗球都可以关掉（app-config.json → fab.enabled=false）
        if (!Config.FAB_ENABLED) {
            return;
        }
        fab = new Fab(this);
        root.addView(fab, fab.params());
        fab.setTap(new Fab.Tap() {
            @Override
            public void onTap() {
                // 再点一下球就收起，和网页那颗的行为一致
                if (QuickMenu.isOpen()) {
                    QuickMenu.dismissAll();
                    return;
                }
                Menu.show(MainActivity.this);
            }
        });
        fab.restorePosition();
    }

    /** 给菜单定位用的锚点 */
    public Fab fab() {
        return fab;
    }

    /**
     * 叠在最上面的那一层（壳自己的播放器就挂这儿）。
     * 直接用 Activity 的根布局，位置是屏幕坐标，和网页里量出来的位置对得上。
     */
    public FrameLayout overlayRoot() {
        return root;
    }

    // ================================================================ 视频全屏

    /**
     * WebView 只负责「请求全屏」，真正把画面铺满屏幕是壳的事。
     * 没有 onShowCustomView 时，网页里点视频全屏按钮会毫无反应（画面还是小窗），
     * 这就是「小屏不能横屏全屏」的根因。
     */
    private void setupFullLayer() {
        fullLayer = new FrameLayout(this);
        fullLayer.setBackgroundColor(0xFF000000);
        fullLayer.setVisibility(View.GONE);
        fullLayer.setClickable(true);
        root.addView(fullLayer, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        // 记住进全屏前窗口的样子，退出时原样还原，
        // 否则会把普通页面顶到状态栏底下（内容被遮住一截）
        normalUiVisibility = getWindow().getDecorView().getSystemUiVisibility();
    }

    /** 进入全屏：接管网页给的 SurfaceView / 播放器 View */
    private void enterFullscreen(View view, int requestedOrientation,
                                 WebChromeClient.CustomViewCallback callback) {
        if (view == null) {
            if (callback != null) {
                try {
                    callback.onCustomViewHidden();
                } catch (Throwable ignored) {
                }
            }
            return;
        }
        // 已经有一层在播了，把旧的回调告诉网页，避免网页以为还停在全屏
        if (customView != null) {
            if (callback != null) {
                try {
                    callback.onCustomViewHidden();
                } catch (Throwable ignored) {
                }
            }
            return;
        }

        QuickMenu.dismissAll();
        hideError();
        if (bar != null) bar.setVisibility(View.GONE);

        customView = view;
        customCallback = callback;
        fullscreen = true;
        orientDecided = false;
        final int seq = ++orientSeq;

        if (fab != null) fab.setVisibility(View.GONE);
        fullLayer.removeAllViews();
        fullLayer.addView(view, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        fullLayer.setVisibility(View.VISIBLE);
        fullLayer.bringToFront();
        addRotateButton();

        hideSystemBars();

        try {
            normalOrientation = getRequestedOrientation();
        } catch (Throwable ignored) {
        }

        if (isExplicitOrientation(requestedOrientation)) {
            // 网页自己锁了方向（screen.orientation.lock），听网页的
            orientDecided = true;
            applyFullscreenOrientation(requestedOrientation);
        } else {
            // 先问页面里 <video> 的真实宽高比（最准），拿不到再按播放器 View 的形状判断
            probeVideoRatio(seq);
            ui.postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (seq != orientSeq || !fullscreen || orientDecided) return;
                    decideByViewSize(seq);
                }
            }, 300);
        }

        // 旋转 + 系统栏收起需要一个消息循环，补一次避免部分机型闪一下状态栏
        ui.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (!fullscreen) return;
                hideSystemBars();
                // 用户开着「旋转锁定」时 SENSOR_LANDSCAPE 不会生效，
                // 这时退一步用强制横屏，保证全屏一定是横的
                if (forceLandscapeIfStuck
                        && getResources().getConfiguration().orientation
                        != android.content.res.Configuration.ORIENTATION_LANDSCAPE) {
                    try {
                        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
                    } catch (Throwable ignored) {
                    }
                }
            }
        }, 360);
    }

    /** 网页是否明确指定了方向 */
    private boolean isExplicitOrientation(int o) {
        return o == ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
                || o == ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                || o == ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
                || o == ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
                || o == ActivityInfo.SCREEN_ORIENTATION_REVERSE_LANDSCAPE
                || o == ActivityInfo.SCREEN_ORIENTATION_REVERSE_PORTRAIT;
    }

    /**
     * 问页面：正在全屏的那个 video 的 videoWidth / videoHeight 是多少。
     * 这是判断「该竖屏还是横屏」最可靠的数据 —— 网页里的小窗尺寸可能被 CSS 改过，
     * 但 videoWidth/videoHeight 永远是片源本身的宽高。
     */
    private void probeVideoRatio(final int seq) {
        if (web == null) return;
        final String js = "(function(){try{"
                + "var f=document.fullscreenElement||document.documentElement;"
                + "var v=f&&f.querySelector?f.querySelector('video'):null;"
                + "if(!v){var a=document.querySelectorAll('video');"
                + "v=a.length?a[a.length-1]:null;}"
                + "if(!v)return '';"
                + "var w=v.videoWidth||v.clientWidth||0,h=v.videoHeight||v.clientHeight||0;"
                + "if(!w||!h)return '';return (w/h).toFixed(3);"
                + "}catch(e){return '';}})()";
        try {
            web.evaluateJavascript(js, new ValueCallback<String>() {
                @Override
                public void onReceiveValue(String value) {
                    if (seq != orientSeq || !fullscreen || orientDecided) return;
                    float r = parseRatio(value);
                    if (r <= 0f) return;
                    orientDecided = true;
                    applyFullscreenOrientation(r < 0.87f
                            ? ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
                            : ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
                }
            });
        } catch (Throwable ignored) {
        }
    }

    private float parseRatio(String json) {
        if (json == null) return 0f;
        String s = json.trim().replace("\"", "");
        if (s.length() == 0 || "null".equals(s)) return 0f;
        try {
            return Float.parseFloat(s);
        } catch (Throwable t) {
            return 0f;
        }
    }

    /** 兜底：按播放器 View 在进全屏前的形状判断 */
    private void decideByViewSize(int seq) {
        if (seq != orientSeq || customView == null) return;
        orientDecided = true;
        int w = customView.getWidth();
        int h = customView.getHeight();
        boolean tall = w > 0 && h > 0 && h > w * 1.15f;
        applyFullscreenOrientation(tall
                ? ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
                : ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
    }

    private void applyFullscreenOrientation(int want) {
        try {
            if (getRequestedOrientation() != want) setRequestedOrientation(want);
        } catch (Throwable ignored) {
        }
        forceLandscapeIfStuck = want == ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE;
        updateRotateButton();
    }

    // ---------------------------------------------------------------- 强制翻转

    /** 全屏右上角那颗「横屏 / 竖屏」按钮：识别错了可以手动掰回来 */
    private void addRotateButton() {
        rotateBtn = new TextView(this);
        rotateBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f);
        rotateBtn.setTextColor(0xFFFFFFFF);
        rotateBtn.setGravity(Gravity.CENTER);
        rotateBtn.setIncludeFontPadding(false);
        rotateBtn.setClickable(true);

        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.OVAL);
        bg.setColor(0x59000000);
        bg.setStroke(Math.max(1, Ui.dp(this, 0.8f)), 0x66FFFFFF);
        rotateBtn.setBackground(bg);

        rotateBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toggleFullscreenOrientation();
            }
        });

        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                Ui.dp(this, 48), Ui.dp(this, 48));
        lp.gravity = Gravity.TOP | Gravity.END;
        lp.topMargin = Ui.dp(this, 12);
        lp.rightMargin = Ui.dp(this, 12);
        fullLayer.addView(rotateBtn, lp);

        updateRotateButton();
    }

    private void updateRotateButton() {
        if (rotateBtn == null) return;
        boolean land = getResources().getConfiguration().orientation
                == android.content.res.Configuration.ORIENTATION_LANDSCAPE;
        // 按钮上写的是「点了会切成什么」，不是当前状态
        rotateBtn.setText(land ? "竖屏" : "横屏");
    }

    private void toggleFullscreenOrientation() {
        boolean land = getResources().getConfiguration().orientation
                == android.content.res.Configuration.ORIENTATION_LANDSCAPE;
        // 手动掰过之后，别再让自动判断和「旋转锁定兜底」把方向改回去
        orientSeq++;
        orientDecided = true;
        forceLandscapeIfStuck = false;
        try {
            setRequestedOrientation(land
                    ? ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
                    : ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        } catch (Throwable ignored) {
        }
    }

    /** 退出全屏。notifyWeb=true 表示是壳这边主动退（返回键），要通知网页 */
    private void exitFullscreen(boolean notifyWeb) {
        if (!fullscreen && customView == null) return;

        fullscreen = false;
        forceLandscapeIfStuck = false;
        orientDecided = false;
        orientSeq++;
        rotateBtn = null;

        try {
            fullLayer.removeAllViews();
            fullLayer.setVisibility(View.GONE);
        } catch (Throwable ignored) {
        }
        customView = null;

        showSystemBars();

        try {
            setRequestedOrientation(normalOrientation);
        } catch (Throwable ignored) {
        }
        normalOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED;

        if (fab != null) {
            fab.setVisibility(View.VISIBLE);
            fab.bringToFront();
        }

        final WebChromeClient.CustomViewCallback cb = customCallback;
        customCallback = null;
        if (notifyWeb && cb != null) {
            try {
                cb.onCustomViewHidden();
            } catch (Throwable ignored) {
            }
        }
    }

    private void hideSystemBars() {
        try {
            View d = getWindow().getDecorView();
            d.setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

            // 老 flag 在新系统上属于兼容路径，Android 11+ 再走一遍新接口，
            // 保证 targetSdk 35（强制 edge-to-edge）时全屏也能真的铺满
            if (Build.VERSION.SDK_INT >= 30) {
                WindowInsetsController c = getWindow().getInsetsController();
                if (c != null) {
                    c.hide(WindowInsets.Type.systemBars());
                    c.setSystemBarsBehavior(
                            WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
                }
                if (root != null) root.setPadding(0, 0, 0, 0);
            }
        } catch (Throwable ignored) {
        }
    }

    private void showSystemBars() {
        try {
            View d = getWindow().getDecorView();
            d.setSystemUiVisibility(normalUiVisibility);
            getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

            if (Build.VERSION.SDK_INT >= 30) {
                WindowInsetsController c = getWindow().getInsetsController();
                if (c != null) c.show(WindowInsets.Type.systemBars());
                if (root != null) root.requestApplyInsets();
            }
        } catch (Throwable ignored) {
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        String u = intent == null ? null : intent.getStringExtra(EXTRA_URL);
        if (!TextUtils.isEmpty(u)) {
            cancelHomeExpect();
            beginLoading();
            web.loadUrl(u);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (fullscreen) hideSystemBars();
        // 从「安装未知应用」设置页回来 → 继续装
        if (pendingApk != null) {
            File f = pendingApk;
            if (Build.VERSION.SDK_INT < 26 || getPackageManager().canRequestPackageInstalls()) {
                pendingApk = null;
                doInstall(f);
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (Scan.onResult(this, requestCode, resultCode, data)) return;
        // 下载面板「移动 / 复制」选系统文件夹（SAF）的结果
        if (requestCode == DownloadsDialog.REQ_TREE) {
            DownloadsDialog.onTreeResult(this, requestCode, resultCode, data);
            return;
        }
        if (requestCode == REQ_FILE) {
            if (fileCallback == null) return;
            Uri[] out = null;
            try {
                out = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
            } catch (Throwable ignored) {
            }
            fileCallback.onReceiveValue(out);
            fileCallback = null;
        }
    }

    @Override
    public void onConfigurationChanged(android.content.res.Configuration cfg) {
        super.onConfigurationChanged(cfg);
        // 清单里声明了 configChanges，旋转时不会重建 Activity（视频不会被打断），
        // 但系统栏状态会被重置，这里补回来
        if (fullscreen) {
            updateRotateButton();
            ui.postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (fullscreen) hideSystemBars();
                }
            }, 80);
        }
    }

    @Override
    protected void onDestroy() {
        QuickMenu.dismissAll();
        ui.removeCallbacks(homeTimeout);
        NavGuard.detach(this);
        try {
            Prefs.onExit(this);
        } catch (Throwable ignored) {
        }
        // 先撤掉全屏图层，别让播放器的 SurfaceView 跟着 Activity 一起泄漏
        try {
            exitFullscreen(false);
        } catch (Throwable ignored) {
        }
        try {
            if (web != null) {
                web.stopLoading();
                web.setWebChromeClient(null);
                web.setWebViewClient(null);
                web.loadUrl("about:blank");
                root.removeView(web);
                web.destroy();
                web = null;
            }
        } catch (Throwable ignored) {
        }
        FabRegistry.destroyBackgrounds();
        super.onDestroy();
    }

    // ================================================================ WebView

    @SuppressWarnings("SetJavaScriptEnabled")
    private void setupWeb() {
        configureWebView(web);
    }

    /**
     * 给任意一个 WebView 装上设置和回调。
     * 前台页和后台页（features.background）走同一份配置，行为完全一致。
     */
    @SuppressWarnings("SetJavaScriptEnabled")
    private void configureWebView(final WebView w) {
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setLoadsImagesAutomatically(true);
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(true);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setTextZoom(100);

        // 页面查找结果 → 查找条上的「第几处 / 共几处」
        w.setFindListener(new WebView.FindListener() {
            @Override
            public void onFindResultReceived(int activeMatchOrdinal, int numberOfMatches,
                                             boolean isDoneCounting) {
                FindBar.onResult(activeMatchOrdinal, numberOfMatches);
            }
        });
        if (Build.VERSION.SDK_INT >= 21) {
            s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        }
        // 滚动相关：部分 ROM 默认关闭，导致页面整页滑不动
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(true);
        if (Build.VERSION.SDK_INT >= 26) {
            w.setVerticalScrollBarEnabled(true);
            w.setOverScrollMode(View.OVER_SCROLL_IF_CONTENT_SCROLLS);
        }
        // 滚动全部交给 WebView 自己处理（原生跟手 + 原生惯性）。
        // 早期为了绕开「边缘手势吃事件」在壳里用 scrollBy 代滚，结果和 WebView
        // 自身的滚动叠加，表现为抖动、滑不动、方向和手相反 —— 这段已彻底删掉。
        w.setHorizontalScrollBarEnabled(false);
        w.setScrollbarFadingEnabled(true);

        try {
            CookieManager.getInstance().setAcceptCookie(true);
            if (Build.VERSION.SDK_INT >= 21) {
                CookieManager.getInstance().setAcceptThirdPartyCookies(w, true);
            }
        } catch (Throwable ignored) {
        }

        w.setLongClickable(true);
        w.setHapticFeedbackEnabled(false);

        // 跳转拦截：记下用户碰屏幕的时间，用来区分「亲手点的链接」和「网页自己跳」
        w.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent e) {
                if (e.getActionMasked() == MotionEvent.ACTION_DOWN) NavGuard.noteTouch();
                return false;
            }
        });

        w.setWebViewClient(new WebViewClient() {

            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest req) {
                Uri u = req == null ? null : req.getUrl();
                if (u == null) return null;
                // 视频嗅探：所有请求都过一遍，命中 m3u8 / mp4 就记下来（不改请求本身）
                Sniffer.note(u.toString());
                if (!Site.HOST.equals(u.getHost())) return null;
                return Site.response(MainActivity.this, u.getPath());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView v, String url) {
                return v == web && handleUrl(url);
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest req) {
                if (v != web) return false;
                return handleUrl(req == null || req.getUrl() == null ? null : req.getUrl().toString());
            }

            @Override
            public void onPageStarted(WebView v, String url, Bitmap favicon) {
                if (v != web) return;
                hideError();
                // 换页了：上一页被拦下的跳转 / 弹窗都过时了，清掉
                NavGuard.onPageStart(MainActivity.this);
                // 换页了，叠在网页上那个播放器和它的占位块都得撤掉
                if (Sniffer.isEmbedded(v)) {
                    PlayerActivity.closeOverlay();
                    Sniffer.unembed(v);
                }
                // 换页了还停在上一个视频的全屏黑底上，先退出来
                if (fullscreen) exitFullscreen(true);
                if (bar != null) {
                    bar.setVisibility(View.VISIBLE);
                    bar.setProgress(8);
                }
            }

            @Override
            public void onPageFinished(WebView v, String url) {
                if (v == web && expectingHome) {
                    expectingHome = false;
                    ui.removeCallbacks(homeTimeout);
                }
                injectFullscreenFix();
                injectVideoHook();
                // 电脑版：页面多半写了 width=device-width，光换 UA 仍按手机宽度排版，
                // 这里把 viewport 改成 1280，网页才会按桌面断点渲染（再缩放到屏宽）
                if (Prefs.desktop(MainActivity.this)) injectDesktopViewport(v);
                // 视频嗅探：DOM 里的 video/src、以及 performance 资源表里的播放地址
                Sniffer.collect(v);
                // 内置页和在线网页一样处理：主题只换浏览器自己的界面，
                // 不再往网页里注入配色（页面用自己写的样式）
                // 记一条浏览历史（闪电球 → 历史）；隐私模式不记
                if (Config.FEATURE_HISTORY && !Prefs.privacy(MainActivity.this)) {
                    History.record(MainActivity.this, url, v == null ? null : v.getTitle());
                }
                if (v == web && bar != null) {
                    bar.setProgress(100);
                    bar.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            if (bar != null) {
                                bar.setVisibility(View.GONE);
                                bar.setProgress(0);
                            }
                        }
                    }, 220);
                }
            }

            @Override
            public void onReceivedError(WebView v, WebResourceRequest req, WebResourceError err) {
                if (v != web) return;
                if (req == null || !req.isForMainFrame()) return;
                // 首页是在线主站，打不开就先回落到内置页，而不是甩一张错误页
                if (expectingHome && !fellBack) {
                    fallbackToBuiltin("在线站点打不开");
                    return;
                }
                showError("页面打不开", String.valueOf(err == null ? "" : err.getDescription()));
            }

            @Override
            public void onReceivedSslError(WebView v, android.webkit.SslErrorHandler handler,
                                           android.net.http.SslError error) {
                // 默认行为是「静默取消」，用户只会看到一片白，以为卡死了。
                // 这里取消掉并明确告诉用户，同时保持不降级 TLS 校验。
                handler.cancel();
                if (v != web) return;
                // 图片/脚本之类的子资源证书错不该整页判死，只处理主文档
                String bad = error == null ? null : error.getUrl();
                String cur = pageUrl();
                if (!TextUtils.isEmpty(bad) && !TextUtils.isEmpty(cur)
                        && !bad.equals(cur)) {
                    return;
                }
                if (expectingHome && !fellBack) {
                    fallbackToBuiltin("在线站点证书有问题");
                    return;
                }
                showError("这个网站的证书有问题",
                        "为了安全没有继续访问。" + (bad == null ? "" : "\n" + bad));
            }

            @Override
            public boolean onRenderProcessGone(WebView v, android.webkit.RenderProcessGoneDetail d) {
                // 渲染进程挂了之后这个 WebView 就废了，只能重建一个，否则永远白屏
                // 不要在回调栈里直接销毁，丢到下一轮消息再换
                ui.post(new Runnable() {
                    @Override
                    public void run() {
                        if (v == web) rebuildWeb();
                        else FabRegistry.onWebGone(v);
                    }
                });
                return true;
            }

        });

        // 视频自动接管：网页里的 <video> 开始播就通知壳，壳把播放层盖上去
        try {
            w.addJavascriptInterface(new VideoHook(), "vieShell");
        } catch (Throwable ignored) {
        }

        w.setWebChromeClient(new WebChromeClient() {

            @Override
            public void onShowCustomView(View view, WebChromeClient.CustomViewCallback callback) {
                if (w != web) return;
                enterFullscreen(view, ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED, callback);
            }

            @Override
            public void onShowCustomView(View view, int requestedOrientation,
                                         WebChromeClient.CustomViewCallback callback) {
                if (w != web) return;
                enterFullscreen(view, requestedOrientation, callback);
            }

            @Override
            public void onHideCustomView() {
                // 网页自己退全屏：不要再回调 onCustomViewHidden，否则会绕回去
                exitFullscreen(false);
            }

            @Override
            public void onProgressChanged(WebView v, int p) {
                if (v == web && bar != null && bar.getVisibility() == View.VISIBLE) bar.setProgress(p);
            }

            @Override
            public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb,
                                             FileChooserParams params) {
                if (fileCallback != null) {
                    fileCallback.onReceiveValue(null);
                }
                fileCallback = cb;
                try {
                    Intent i = params.createIntent();
                    startActivityForResult(i, REQ_FILE);
                    return true;
                } catch (Throwable t) {
                    fileCallback = null;
                    Ui.toast(MainActivity.this, "打不开文件选择器");
                    return false;
                }
            }

            @Override
            public void onReceivedTitle(WebView v, String title) {
                // 用网页标题，但别盖掉 App 名
                if (v == web && !TextUtils.isEmpty(title) && title.length() < 40) setTitle(title);
            }

            /**
             * 跳转拦截开启时：网页里的 JS 弹窗（alert）按站点决策 ——
             * 白名单直接放行、黑名单悄悄丢弃，其余先扣下来，
             * 用户在网页底部的胶囊按钮里点开后再放行 / 拦截（可记住选择）。
             */
            @Override
            public boolean onJsAlert(WebView v, String url, String message, JsResult result) {
                if (w == web && NavGuard.holdPopup(MainActivity.this, url, message)) {
                    try {
                        result.cancel();
                    } catch (Throwable ignored) {
                    }
                    return true;
                }
                return super.onJsAlert(v, url, message, result);
            }
        });

        w.setDownloadListener(new DownloadListener() {
            @Override
            public void onDownloadStart(String url, String userAgent, String contentDisposition,
                                        String mimetype, long contentLength) {
                downloader.confirm(url, userAgent, contentDisposition, mimetype, contentLength);
            }
        });

        w.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                if (v != web) return false;
                return handleLongPress();
            }
        });
    }

    /**
     * 有些站点的播放器放在 iframe 里，而 iframe 少了 allowfullscreen 属性时
     * requestFullscreen() 会被直接拒绝 —— 表现就是「点全屏没反应」。
     * 这里在内存里给 iframe 补上这个属性（只改运行时 DOM，不动网页文件）。
     */
    /** 网页里的视频开播了 → 壳这边把播放层盖上去（可全屏、可关闭） */
    private class VideoHook {
        @JavascriptInterface
        public void onVideoPlay(final String url) {
            if (TextUtils.isEmpty(url)) return;
            ui.post(new Runnable() {
                @Override
                public void run() {
                    // 已经有一层在播了就不再弹（同一个页面多段视频、进度回调都走这里）
                    if (PlayerActivity.isOverlayOpen()) return;
                    if (fullscreen) return;
                    Sniffer.playInPage(MainActivity.this, url, null);
                }
            });
        }
    }

    /** 页面加载完给视频元素挂「开播上报」钩子（换页会重挂） */
    private void injectVideoHook() {
        if (web == null) return;
        final String js = "(function(){"
                + "if(window.__vieAuto)return;window.__vieAuto=1;"
                + "function hook(v){"
                + "if(!v||v.__vie)return;v.__vie=1;"
                + "v.addEventListener('playing',function(){"
                + "try{var s=v.currentSrc||v.src||'';"
                + "if(!s){var so=v.querySelector('source');if(so)s=so.src||'';}"
                + "if(!s)return;"
                + "if(/^blob:/i.test(s))return;"
                + "window.vieShell.onVideoPlay(String(s));}catch(e){}"
                + "});}"
                + "function scan(){try{var a=document.querySelectorAll('video');"
                + "for(var i=0;i<a.length;i++)hook(a[i]);}catch(e){}}"
                + "scan();"
                + "try{new MutationObserver(function(){setTimeout(scan,200);})"
                + ".observe(document.documentElement,{childList:true,subtree:true});}catch(e){}"
                + "})();";
        try {
            web.evaluateJavascript(js, null);
        } catch (Throwable ignored) {
        }
    }

    private void injectFullscreenFix() {
        if (web == null) return;
        final String js = "(function(){"
                + "function fix(){var a=document.querySelectorAll('iframe');"
                + "for(var i=0;i<a.length;i++){var f=a[i];"
                + "if(!f.hasAttribute('allowfullscreen'))f.setAttribute('allowfullscreen','');"
                + "var v=f.getAttribute('allow')||'';"
                + "if(v.indexOf('fullscreen')<0)f.setAttribute('allow',(v?v+'; ':'')+'fullscreen');}}"
                + "fix();"
                + "if(window.__hjkFs)return;window.__hjkFs=1;"
                + "try{var t=0;new MutationObserver(function(){if(t)return;"
                + "t=setTimeout(function(){t=0;fix();},300);})"
                + ".observe(document.documentElement,{childList:true,subtree:true});}catch(e){}"
                + "})();";
        try {
            web.evaluateJavascript(js, null);
        } catch (Throwable ignored) {
        }
    }

    /**
     * 电脑版页面修正。
     *
     * 只改 UA 是不够的：绝大多数响应式站点靠 CSS 媒体查询（宽度）决定布局，
     * 页面自己又写了 {@code width=device-width}，于是桌面 UA + 手机宽度 =
     * 还是手机版排版。把 viewport 改成固定 1280，媒体查询命中桌面断点，
     * WebView 再按 useWideViewPort + overview 缩到屏宽。
     */
    private void injectDesktopViewport(WebView v) {
        if (v == null) return;
        String js = "(function(){try{"
                + "var m=document.querySelector('meta[name=viewport]');"
                + "if(!m){m=document.createElement('meta');"
                + "m.setAttribute('name','viewport');"
                + "(document.head||document.documentElement).appendChild(m);}"
                + "m.setAttribute('content','width=1280');"
                + "}catch(e){}})();";
        try {
            v.evaluateJavascript(js, null);
        } catch (Throwable ignored) {
        }
    }

    /** 渲染进程崩溃 / WebView 不可用时，换一个新的继续用 */
    private void rebuildWeb() {
        String last = pageUrl();
        QuickMenu.dismissAll();
        exitFullscreen(false);
        hideError();
        try {
            if (web != null) {
                web.setWebChromeClient(null);
                web.setWebViewClient(null);
                try {
                    root.removeView(web);
                } catch (Throwable ignored) {
                }
                web.destroy();
            }
        } catch (Throwable ignored) {
        }

        web = new WebView(this);
        applyPageColor(web);
        root.addView(web, 0, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        setupWeb();
        if (fab != null) fab.bringToFront();

        if (TextUtils.isEmpty(last)) loadStart();
        else web.loadUrl(last);
    }

    /**
     * 页面里的链接全部先过这里。
     * 返回 true = 我们接管了；false = 让 WebView 自己加载。
     */
    private boolean handleUrl(String url) {
        if (TextUtils.isEmpty(url)) return false;

        // 壳自己的虚拟地址
        if (url.startsWith("hjk://")) {
            if (url.startsWith("hjk://reload")) {
                hideError();
                web.reload();
            } else if (url.startsWith("hjk://home")) {
                goHome();
            } else if (url.startsWith("hjk://url")) {
                openUrlDialog();
            } else if (url.startsWith("hjk://scan")) {
                Scan.start(this);
            }
            return true;
        }

        if (Route.isSpecial(url)) return false;

        // 阅读模式（防误触）：网页里的链接点了也不跳，壳内页面（hjk://）不受影响。
        // 防的就是误触到网页隐藏块，一点就跳走的坑。
        if (Prefs.guard(this) && Prefs.read(this)) {
            NavGuard.toastReadBlocked(this);
            return true;
        }

        if (Route.isHttp(url)) {
            // 内部虚拟域名：壳内的页面跳转，正常加载
            if (Site.HOST.equals(Route.hostOf(url))) return false;

            // 网页控制：开启后，没上名单的跳转一律停住 —— 你点的当场问，
            // 网页自己跳的排队等（见 NavGuard）
            if (NavGuard.maybeHold(this, url)) return true;

            // 网页控制开着：这次是「没被拦、直接放行」的跳转。
            // 下面这几种都由壳自己接管（下载确认、转 App 选择），记一笔
            // 「用户点的链接」，误触了可以在底部按钮的「最近处理」里一键加黑名单。
            if (Prefs.guard(this) && NavGuard.userTouched()) {
                String h = GuardLists.normalize(Route.hostOf(url));
                if (Mimes.isDownloadable(url) || Route.isQqLink(url)
                        || Route.isWxLink(url) || Route.isAliLink(url)) {
                    NavGuard.noteUserClickRec(h, url);
                }
            }

            // 点击的是明确的文件（.apk / .zip / .pdf …）→ 先问用户
            if (Mimes.isDownloadable(url)) {
                final String dl = url;
                web.post(new Runnable() {
                    @Override
                    public void run() {
                        downloader.confirm(dl, null, null, null, 0);
                    }
                });
                return true;
            }

            // 腾讯系 / 支付宝域名：可能是加群/加好友/公众号/付款码，
            // 先问用户要不要交给 QQ / 微信 / 支付宝
            if (Route.isQqLink(url) || Route.isWxLink(url) || Route.isAliLink(url)) {
                final String tx = url;
                web.post(new Runnable() {
                    @Override
                    public void run() {
                        Route.choose(MainActivity.this, tx, false);
                    }
                });
                return true;
            }
            // 普通网页链接：留在壳内。进度条先动起来，别等首包
            beginLoading();
            return false;
        }

        // mqq:// weixin:// alipays:// tel: mailto: …：交给系统选择器，由用户挑 App
        final String schemeUrl = url;
        web.post(new Runnable() {
            @Override
            public void run() {
                Route.tapScheme(MainActivity.this, schemeUrl);
            }
        });
        return true;
    }

    // ================================================================ 长按

    private boolean handleLongPress() {
        final long seq = ++pressSeq;

        WebView.HitTestResult r = web.getHitTestResult();
        final int type = r == null ? 0 : r.getType();
        final String extra = r == null || r.getExtra() == null ? "" : r.getExtra();

        final boolean imgType = type == WebView.HitTestResult.IMAGE_TYPE
                || type == WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE
                || type == WebView.HitTestResult.IMAGE_ANCHOR_TYPE;
        final boolean linkType = type == WebView.HitTestResult.SRC_ANCHOR_TYPE
                || type == WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE
                || type == WebView.HitTestResult.IMAGE_ANCHOR_TYPE;

        // 长按的是普通文字/空白 → 还给系统（保留选词复制）
        if (!imgType && !linkType) return false;

        final String fbImg = imgType ? extra : "";
        final String fbLink = (type == WebView.HitTestResult.SRC_ANCHOR_TYPE) ? extra : "";

        final boolean[] done = {false};
        Handler.Callback cb = new Handler.Callback() {
            @Override
            public boolean handleMessage(Message msg) {
                if (done[0] || seq != pressSeq) return true;
                done[0] = true;
                Bundle b = msg.getData();
                String href = b == null ? null : b.getString("url");
                String src = b == null ? null : b.getString("src");
                if (TextUtils.isEmpty(src)) src = fbImg;
                if (TextUtils.isEmpty(href)) href = fbLink;
                showLongPressSheet(src, href);
                return true;
            }
        };

        try {
            Message msg = Message.obtain(new Handler(Looper.getMainLooper(), cb));
            web.requestFocusNodeHref(msg);
        } catch (Throwable ignored) {
        }

        ui.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (done[0] || seq != pressSeq) return;
                done[0] = true;
                showLongPressSheet(fbImg, fbLink);
            }
        }, 280);

        return true;
    }

    private void showLongPressSheet(final String imgUrl, final String href) {
        final boolean hasImg = !TextUtils.isEmpty(imgUrl);
        final boolean hasLink = !TextUtils.isEmpty(href) && !"javascript:void(0)".equals(href);

        if (!hasImg && !hasLink) return;

        long now = System.currentTimeMillis();
        if (now - lastSheetAt < 500) return;   // 防止重复弹
        lastSheetAt = now;

        if (hasImg) {
            // 长按的是图片：先在后台识别一遍有没有二维码，
            // 有 → 弹二维码相关选项；没有 → 只弹普通的图片选项
            final ProgressDialog d = busy("正在识别图片…");
            new Thread(new Runnable() {
                @Override
                public void run() {
                    String qr = null;
                    try {
                        android.graphics.Bitmap b = Img.load(MainActivity.this, imgUrl,
                                pageUrl(), 1600);
                        qr = Scan.decodeBitmap(b);
                        if (b != null) b.recycle();
                    } catch (Throwable ignored) {
                    }
                    final String qrText = qr;
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            dismissBusy(d);
                            if (isFinishing() || isDestroyed()) return;
                            showLongPressSheetInner(imgUrl, href, qrText, hasLink);
                        }
                    });
                }
            }, "img-qr-detect").start();
            return;
        }
        showLongPressSheetInner(null, href, null, hasLink);
    }

    /** 二维码识别完成后真正弹出的面板 */
    private void showLongPressSheetInner(final String imgUrl, final String href,
                                         final String qr, final boolean hasLink) {
        final boolean hasImg = !TextUtils.isEmpty(imgUrl);
        final boolean hasQr = !TextUtils.isEmpty(qr);

        final ArrayList<Integer> icons = new ArrayList<>();
        final ArrayList<String> labels = new ArrayList<>();
        final ArrayList<Integer> acts = new ArrayList<>();

        if (hasImg && hasQr) {
            // 图里识别出了二维码：给二维码相关选项，不给「扫一扫」那一堆
            if (Route.isHttp(qr)) {
                icons.add(R.drawable.ic_q_web);      labels.add("打开二维码里的链接"); acts.add(11);
            }
            icons.add(R.drawable.ic_q_copy);     labels.add("复制二维码内容"); acts.add(12);
            icons.add(R.drawable.ic_q_share);    labels.add("分享二维码内容"); acts.add(13);
            icons.add(R.drawable.ic_q_download); labels.add("保存图片"); acts.add(1);
        } else if (hasImg) {
            // 普通图片：只有图片选项
            icons.add(R.drawable.ic_q_download); labels.add("保存图片"); acts.add(1);
            icons.add(R.drawable.ic_q_share);    labels.add("分享图片"); acts.add(2);
        }
        // 链接：浏览器、复制、收藏、后台 / 新窗口
        if (hasLink) {
            icons.add(R.drawable.ic_q_web);      labels.add("用浏览器打开"); acts.add(3);
            icons.add(R.drawable.ic_q_link);     labels.add("复制链接"); acts.add(4);
            if (Config.ALLOW_USER_BOOKMARKS) {
                icons.add(R.drawable.ic_q_star); labels.add("收藏这个链接"); acts.add(5);
            }
            if (FabRegistry.hasBackground()) {
                icons.add(R.drawable.ic_q_layer); labels.add("后台打开"); acts.add(6);
                icons.add(R.drawable.ic_q_web);   labels.add("新窗口打开"); acts.add(7);
            }
        }

        String title;
        if (hasImg && hasQr) title = "图片 · 检测到二维码";
        else if (hasImg && hasLink) title = null;
        else title = hasImg ? "图片" : "链接";

        int[] iconIds = new int[icons.size()];
        for (int i = 0; i < iconIds.length; i++) iconIds[i] = icons.get(i);
        Sheet.show(this, title, hasImg && hasQr ? qr : null,
                iconIds,
                labels.toArray(new String[0]),
                new String[labels.size()],
                new Sheet.Pick() {
                    @Override
                    public void onPick(int i) {
                        switch (acts.get(i)) {
                            case 1: saveImage(imgUrl); break;
                            case 2: shareImage(imgUrl); break;
                            case 3: Route.browser(MainActivity.this, href); break;
                            case 4: Route.copy(MainActivity.this, href, "链接已复制"); break;
                            case 6: FabRegistry.openInBackground(MainActivity.this, href); break;
                            case 7: FabRegistry.openInNewWindow(MainActivity.this, href); break;
                            case 11: Route.inApp(MainActivity.this, qr); break;
                            case 12: Route.copy(MainActivity.this, qr, "内容已复制"); break;
                            case 13: Route.shareText(MainActivity.this, qr); break;
                            default: bookmarkLink(href); break;
                        }
                    }
                });
    }

    /** 长按链接里的「收藏」：名字、地址都能改 */
    private void bookmarkLink(String url) {
        if (TextUtils.isEmpty(url)) return;
        if (Bookmarks.isPreset(this, url)) {
            Ui.toast(this, "这是内置书签，不用再收藏");
            return;
        }
        final String target = url;
        boolean exists = Bookmarks.has(this, target);
        BookmarkDialog.show(this, exists ? "编辑书签" : "收藏这个链接",
                exists ? nameOfBookmark(target) : Bookmarks.labelOf(target),
                target, exists ? target : null, new BookmarkDialog.Done() {
                    @Override
                    public void onSave(String name, String u) {
                        Bookmarks.save(MainActivity.this, name, u);
                        Ui.toast(MainActivity.this, "已加入书签");
                    }
                });
    }

    private String nameOfBookmark(String url) {
        if (TextUtils.isEmpty(url)) return "";
        for (Bookmarks.Item i : Bookmarks.all(this)) {
            if (i.url != null && i.url.equalsIgnoreCase(url)) return i.name;
        }
        return Bookmarks.labelOf(url);
    }

    // ================================================================ 图片

    private void saveImage(final String src) {
        final ProgressDialog d = busy("正在保存图片…");
        new Thread(new Runnable() {
            @Override
            public void run() {
                String msg;
                try {
                    Bitmap b = Img.load(MainActivity.this, src, pageUrl(), 0);
                    if (b == null) throw new Exception("图片读取失败");
                    String path = Saver.toAlbum(MainActivity.this, b, Saver.nameFromUrl(src));
                    msg = "已保存到 " + path;
                } catch (Throwable t) {
                    msg = "保存失败：" + (t.getMessage() == null ? "未知原因" : t.getMessage());
                }
                final String out = msg;
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        dismissBusy(d);
                        Ui.toast(MainActivity.this, out);
                    }
                });
            }
        }).start();
    }

    private void shareImage(final String src) {
        final ProgressDialog d = busy("正在准备图片…");
        new Thread(new Runnable() {
            @Override
            public void run() {
                final File f;
                String err = null;
                try {
                    Bitmap b = Img.load(MainActivity.this, src, pageUrl(), 0);
                    f = Saver.toCache(MainActivity.this, b, Saver.nameFromUrl(src));
                } catch (Throwable t) {
                    final String why = t.getMessage();
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            dismissBusy(d);
                            Ui.toast(MainActivity.this,
                                    "分享失败：" + (why == null ? "未知原因" : why));
                        }
                    });
                    return;
                }
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        dismissBusy(d);
                        Route.shareFile(MainActivity.this, f, "image/jpeg");
                    }
                });
            }
        }).start();
    }

    // ================================================================ 对外

    /**
     * 用户主动发起加载（点链接 / 刷新 / 输网址）时立刻给个进度反馈：
     * 不等 onPageStarted（那要等 DNS + 首包，慢网下可能好几秒没动静）。
     */
    public void beginLoading() {
        if (bar == null) return;
        bar.setVisibility(View.VISIBLE);
        bar.setProgress(bar.getMax() / 10);
    }

    public void openInside(String url) {
        if (web == null || TextUtils.isEmpty(url)) return;
        cancelHomeExpect();
        beginLoading();
        web.loadUrl(url);
    }

    // ---------------------------------------------------------------- 多窗口（features.background）

    /** 当前后台模块用的：拿当前前台 WebView */
    public WebView currentWeb() {
        return web;
    }

    /**
     * 造一个 WebView 并挂到根布局上（后台页是 GONE 的，不渲染不抢焦点）。
     * foreground=true 直接可见，但「谁在前台」要等 adoptForeground 决定。
     */
    public WebView spawnWebView(boolean foreground) {
        WebView w = new WebView(this);
        applyPageColor(w);
        configureWebView(w);
        // 关键：loadUrl 之前就把 UA / 桌面版 / 字号 / 缓存模式套上。
        // 之前新窗口用默认 UA 加载完才在切前台时补设置，表现就是
        // 「手机/电脑切换、浏览器标识不完全生效」。
        Prefs.applyTo(this, w);
        root.addView(w, 0, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        if (!foreground) w.setVisibility(View.GONE);
        return w;
    }

    /** 把 w 升为前台窗口：旧的前台页隐藏（引用由 Background 放进后台列表） */
    public void adoptForeground(WebView w) {
        if (w == null) return;
        WebView old = web;
        if (w == old) {
            w.setVisibility(View.VISIBLE);
            return;
        }
        if (fullscreen) exitFullscreen(true);
        cancelHomeExpect();
        // 切换窗口：叠在旧窗口上的播放器不能跟着留在这儿
        if (Sniffer.isEmbedded(old)) {
            PlayerActivity.closeOverlay();
            Sniffer.unembed(old);
        }
        if (old != null) old.setVisibility(View.GONE);
        web = w;
        w.setVisibility(View.VISIBLE);
        // 切过来的窗口也要吃当前设置（UA / 字号 / 缓存模式）和当前主题
        Prefs.apply(this);
        applyPageColor(w);
    }

    public String pageUrl() {
        try {
            return web == null ? null : web.getUrl();
        } catch (Throwable t) {
            return null;
        }
    }

    // ---------------------------------------------------------------- 给闪电球菜单用

    public boolean canGoBack() {
        return web != null && web.canGoBack();
    }

    public boolean canGoForward() {
        return web != null && web.canGoForward();
    }

    public void goBackPage() {
        hideError();
        cancelHomeExpect();
        if (web != null && web.canGoBack()) web.goBack();
    }

    public void goForwardPage() {
        hideError();
        cancelHomeExpect();
        if (web != null && web.canGoForward()) web.goForward();
    }

    /** 当前是不是已经停在启动页（内置页，或配了在线站点时的在线主站） */
    public boolean isHome() {
        String u = pageUrl();
        if (TextUtils.isEmpty(u)) return false;
        if (u.startsWith(Site.builtinPath())) return true;
        if (Site.hasOnline()) {
            String home = Config.ONLINE;
            return u.equals(home) || u.startsWith(home + "/") || u.startsWith(home + "?");
        }
        return false;
    }

    /** 回启动页：配了在线站点走在线（失败回落内置），没配直接内置 */
    public void goHome() {
        hideError();
        loadHome();
    }

    public void refreshPage() {
        hideError();
        if (web != null) web.reload();
    }

    /**
     * 收藏用的地址：内置页面各自保留真实虚拟地址（hjk 域名 + 各自的文件名），
     * 这样三个内置页收藏出来是三条不同的书签；只有内置首页归一成 hjk://home，
     * 让它继续跟着「首页」走。
     */
    public String currentBookmarkUrl() {
        String u = pageUrl();
        if (TextUtils.isEmpty(u)) return "";
        if (u.startsWith(Site.ORIGIN)) return normalizeBuiltin(u);
        return u;
    }

    /**
     * 内置地址归一：去掉 ?v= 版本参数；根路径和内置首页文件归一成 hjk://home，
     * 其余（内容一.html / 内容二.html …）原样保留。
     */
    static String normalizeBuiltin(String u) {
        String clean = u;
        int q = clean.indexOf('?');
        if (q >= 0) clean = clean.substring(0, q);
        String path = clean.substring(Site.ORIGIN.length());
        if (path.length() == 0 || "/".equals(path)
                || path.equals("/" + Site.homeFile())) {
            return Bookmarks.HOME;
        }
        return clean;
    }

    public void openBookmark(String url) {
        if (TextUtils.isEmpty(url)) return;
        if (Bookmarks.HOME.equals(url)) {
            goHome();
        } else {
            openInside(url);
        }
    }

    public void bookmarkCurrentPage() {
        final String url = currentBookmarkUrl();
        if (TextUtils.isEmpty(url)) {
            Ui.toast(this, "当前页面还没有地址");
            return;
        }
        if (Bookmarks.isPreset(this, url)) {
            Ui.toast(this, "这是内置书签，不用再收藏");
            return;
        }
        boolean exists = Bookmarks.has(this, url);
        String name;
        if (exists) {
            name = nameOfBookmark(url);
        } else {
            // 直接问当前 WebView 的标题：Activity 的 title 是上一个网页留下的
            //（onReceivedTitle 会把它设进来），当前页没标题时就会误用
            String t = null;
            try {
                t = web == null ? null : web.getTitle();
            } catch (Throwable ignored) {
            }
            name = TextUtils.isEmpty(t) ? Bookmarks.labelOf(url) : t;
        }
        // 展示用：hjk://home 显示成内置首页路径，其余内置页显示各自文件
        String shownUrl = Bookmarks.HOME.equals(url) ? Site.builtinPath() : url;

        BookmarkDialog.show(this, exists ? "编辑书签" : "收藏本页",
                name, shownUrl, exists ? url : null, new BookmarkDialog.Done() {
                    @Override
                    public void onSave(String n, String u) {
                        // 内置地址再走一次归一：首页归 hjk://home，其余保留各自文件
                        String save = u != null && u.startsWith(Site.ORIGIN)
                                ? normalizeBuiltin(u) : u;
                        Bookmarks.save(MainActivity.this, n, save);
                        Ui.toast(MainActivity.this, "已加入书签");
                    }
                });
    }

    /**
     * 书签里存的是虚拟地址（hjk://home），新窗口 / 后台打开时要换成真实网址，
     * 否则 WebView 会去加载一个它不认识的协议，直接白屏。
     */
    public String realUrlOf(String url) {
        if (!Bookmarks.HOME.equals(url)) return url;
        if (!TextUtils.isEmpty(Config.HOME_URL)) return Config.HOME_URL;
        if (Site.hasOnline()) return Config.ONLINE;
        return Site.builtinUrl(this);
    }

    public String userAgent() {
        try {
            return web == null ? null : web.getSettings().getUserAgentString();
        } catch (Throwable t) {
            return null;
        }
    }

    /** 装 APK：没开「安装未知应用」就先引导，回来自动继续 */
    /** 给 Updater 用：更新包走同一套下载器，下完自动拉起安装器 */
    public Downloader downloads() {
        return downloader;
    }

    public void installApk(File f) {
        if (f == null || !f.exists()) {
            Ui.toast(this, "安装包不存在");
            return;
        }
        // 先自己比一遍包名和证书：不一致时系统只会弹「应用未安装」，
        // 用户根本不知道为什么，这里提前说清楚
        final String why = SignCheck.why(this, f);
        if (why != null) {
            final boolean conflict = SignCheck.isSignatureConflict(why);
            // 装不上是个需要用户明确处理的岔路：只认弹窗里的按钮，
            // 点弹窗外面不会悄悄关掉（否则用户以为点过了、其实什么都没做）
            AlertDialog.Builder b = new AlertDialog.Builder(this)
                    .setTitle("无法直接安装")
                    .setMessage(why)
                    .setCancelable(false);
            if (conflict) {
                // 签名冲突只能卸载重装，直接给个「卸载本应用」出口，
                // 省得用户去系统设置里翻（卸载后本机书签/历史会丢，文案里讲明）
                b.setPositiveButton("卸载本应用后手动安装", new android.content.DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(android.content.DialogInterface d, int w) {
                        try {
                            Intent i = new Intent(Intent.ACTION_DELETE,
                                    Uri.parse("package:" + getPackageName()));
                            startActivity(i);
                        } catch (Throwable t) {
                            Ui.toast(MainActivity.this, "打不开卸载页面，请到系统设置里卸载");
                        }
                    }
                });
                b.setNegativeButton("取消", null);
            } else {
                b.setPositiveButton("知道了", null);
            }
            Ui.show(b.create());
            return;
        }
        if (Build.VERSION.SDK_INT >= 26 && !getPackageManager().canRequestPackageInstalls()) {
            pendingApk = f;
            AlertDialog installAsk = new AlertDialog.Builder(this)
                    .setTitle("需要允许安装应用")
                    .setMessage("系统要求先允许「" + getString(R.string.app_name) + "」安装应用。开启后会自动回到这里继续安装。")
                    .setPositiveButton("去开启", new android.content.DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(android.content.DialogInterface d, int w) {
                            try {
                                Intent i = new Intent(
                                        android.provider.Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                                        Uri.parse("package:" + getPackageName()));
                                startActivity(i);
                            } catch (Throwable t) {
                                Ui.toast(MainActivity.this, "打不开设置页，请手动去系统设置里允许");
                            }
                        }
                    })
                    .setNegativeButton("取消", null)
                    .setCancelable(false)
                    .create();
            Ui.show(installAsk);
            return;
        }
        doInstall(f);
    }

    private void doInstall(File f) {
        try {
            Uri uri = LocalFiles.uriFor(this, f);
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setDataAndType(uri, Downloader.APK_MIME);
            i.setClipData(ClipData.newRawUri("", uri));
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (Throwable t) {
            Ui.toast(this, "打不开安装器，请到「下载」目录手动安装");
        }
    }

    // ================================================================ 错误页

    /**
     * 错误页用原生 View 画，不用 WebView。
     * 之前用 WebView 装错误页，hjk:// 的按钮点不动，页面一出错就卡死在那里 —— 这是那个 bug 的根因。
     */
    private void showError(String title, String desc) {
        if (bar != null) bar.setVisibility(View.GONE);
        QuickMenu.dismissAll();
        if (fullscreen) exitFullscreen(true);
        hideError();

        final String safeTitle = TextUtils.isEmpty(title) ? "页面打不开" : title;
        final String safeDesc = TextUtils.isEmpty(desc) ? "" : desc;

        FrameLayout layer = new FrameLayout(this);
        layer.setBackgroundColor(Shell.of(this).panel);
        layer.setClickable(true);          // 吃掉点击，别漏给下面的 WebView

        LinearLayout column = new LinearLayout(this);
        column.setOrientation(LinearLayout.VERTICAL);
        column.setGravity(Gravity.CENTER_HORIZONTAL);

        int w = Math.min(getResources().getDisplayMetrics().widthPixels - Ui.dp(this, 56),
                Ui.dp(this, 340));

        TextView t = new TextView(this);
        t.setText(safeTitle);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f);
        t.setTextColor(Shell.of(this).text);
        t.setGravity(Gravity.CENTER);
        t.getPaint().setFakeBoldText(true);
        column.addView(t, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        if (!TextUtils.isEmpty(safeDesc)) {
            TextView d = new TextView(this);
            d.setText(safeDesc);
            d.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f);
            d.setTextColor(Shell.of(this).sub);
            d.setGravity(Gravity.CENTER);
            d.setLineSpacing(Ui.dp(this, 3), 1f);
            LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            dlp.topMargin = Ui.dp(this, 8);
            column.addView(d, dlp);
        }

        LinearLayout.LayoutParams btnLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        btnLp.topMargin = Ui.dp(this, 10);
        column.addView(flatBtn("重新加载", true, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                refreshPage();
            }
        }), btnLp);

        LinearLayout.LayoutParams btnLp2 = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        btnLp2.topMargin = Ui.dp(this, 10);
        column.addView(flatBtn("返回首页", false, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                goHome();
            }
        }), btnLp2);

        LinearLayout.LayoutParams btnLp3 = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        btnLp3.topMargin = Ui.dp(this, 10);
        column.addView(flatBtn("输入网址访问", false, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openUrlDialog();
            }
        }), btnLp3);

        TextView note = new TextView(this);
        note.setText("也可以点右下角闪电球，在菜单里输入网址");
        note.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f);
        note.setTextColor(0xFFA8B1BF);
        note.setGravity(Gravity.CENTER);
        note.setLineSpacing(Ui.dp(this, 3), 1f);
        LinearLayout.LayoutParams nlp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        nlp.topMargin = Ui.dp(this, 18);
        column.addView(note, nlp);

        FrameLayout.LayoutParams clp = new FrameLayout.LayoutParams(w,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        clp.gravity = Gravity.CENTER;
        layer.addView(column, clp);

        errorView = layer;
        root.addView(errorView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        if (fab != null) fab.bringToFront();
    }

    private TextView flatBtn(String text, boolean primary, View.OnClickListener l) {
        TextView b = new TextView(this);
        b.setText(text);
        b.setGravity(Gravity.CENTER);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14.5f);
        b.setTextColor(primary ? 0xFFFFFFFF : 0xFF3B4655);
        b.setPadding(0, Ui.dp(this, 13), 0, Ui.dp(this, 13));

        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(Ui.dp(this, 12));
        if (primary) {
            bg.setColor(0xFFE64A19);
        } else {
            bg.setColor(0xFFFFFFFF);
            bg.setStroke(Math.max(1, Ui.dp(this, 0.8f)), 0xFFE6E9EE);
        }
        b.setBackground(bg);
        b.setClickable(true);
        b.setOnClickListener(l);
        return b;
    }

    private void hideError() {
        if (errorView != null) {
            final View v = errorView;
            errorView = null;
            try {
                root.removeView(v);
            } catch (Throwable ignored) {
            }
        }
    }

    // ================================================================ 返回键

    @Override
    public void onBackPressed() {
        doBack();
    }

    private void doBack() {
        // 叠在网页上的播放器开着时，返回键先收播放器（和全屏同一优先级）
        if (PlayerActivity.isOverlayOpen()) {
            PlayerActivity.closeOverlay();
            Sniffer.unembed(web);
            return;
        }
        // 视频全屏时，返回键第一优先是退出全屏，而不是退出网页
        if (fullscreen) {
            exitFullscreen(true);
            return;
        }
        // 快捷菜单开着时，返回键先收菜单
        if (QuickMenu.isOpen()) {
            QuickMenu.dismissAll();
            return;
        }
        if (errorView != null) {
            // 有错误页时：先撤掉它，能退就退，退不了回启动页
            hideError();
            if (web != null && web.canGoBack()) web.goBack();
            else if (web != null && !isHome()) goHome();
            return;
        }
        if (web != null && web.canGoBack()) {
            web.goBack();
            return;
        }
        // 已经在首页：再按一次退出
        long now = System.currentTimeMillis();
        if (now - lastBackAt < 1800) {
            finish();
        } else {
            lastBackAt = now;
            Ui.toast(this, "再按一次退出");
        }
    }

    private long lastBackAt = 0;

    // ================================================================ 杂项

    /** 页面查找：菜单里的「页面查找」 */
    public void findInPage() {
        FindBar.show(this);
    }

    /** 分享当前页地址：横向按钮条里的那个分享图标 */
    public void shareCurrentPage() {
        String u = pageUrl();
        if (TextUtils.isEmpty(u) || "about:blank".equals(u)) {
            Ui.toast(this, "当前页面还没有地址");
            return;
        }
        // 内置页分享各自的文件地址（去掉版本参数），不再统一按首页处理
        String shown = u.startsWith(Site.ORIGIN) ? normalizeBuiltin(u) : u;
        Route.shareText(this, shown);
    }

    /** 换 UA / 手机电脑版之后重载当前页，保留滚动位置 */
    public void reloadKeepPosition() {
        if (web == null) return;
        try {
            final int y = web.getScrollY();
            web.reload();
            ui.postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (web != null) web.scrollTo(0, y);
                }
            }, 420);
        } catch (Throwable ignored) {
        }
    }

    /** 输入网址访问：菜单里那一项，以及错误页的按钮都走这里 */
    public void openUrlDialog() {
        final android.widget.EditText input = new android.widget.EditText(this);
        input.setSingleLine(true);
        input.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f);
        input.setHint("输入网址");
        input.setInputType(android.text.InputType.TYPE_TEXT_VARIATION_URI);
        input.setImeOptions(android.view.inputmethod.EditorInfo.IME_ACTION_GO);
        input.setHighlightColor(0x33E64A19);
        // 不预填：打开就是一个空输入框，输什么去什么
        int pad = Ui.dp(this, 20);
        FrameLayout box = new FrameLayout(this);
        box.setPadding(pad, Ui.dp(this, 6), pad, 0);
        box.addView(input, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        AlertDialog.Builder b = new AlertDialog.Builder(this);
        b.setTitle("输入网址访问");
        b.setView(box);
        b.setNegativeButton("取消", null);
        if (FabRegistry.hasBackground()) {
            b.setNeutralButton("后台打开", null);
        }
        // 自己接管「打开」：地址不合法时别把弹窗关掉，让用户就地改
        b.setPositiveButton("打开", null);

        final AlertDialog d = b.create();
        if (d.getWindow() != null) {
            d.getWindow().setSoftInputMode(
                    WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
        }
        d.setOnShowListener(new android.content.DialogInterface.OnShowListener() {
            @Override
            public void onShow(android.content.DialogInterface dialog) {
                d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(
                        new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                if (submitUrl(input)) d.dismiss();
                            }
                        });
                if (FabRegistry.hasBackground()) {
                    d.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(
                            new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    String u = Bookmarks.normalize(
                                            String.valueOf(input.getText()).trim());
                                    if (TextUtils.isEmpty(u)) {
                                        Ui.toast(MainActivity.this, "网址不能为空");
                                        return;
                                    }
                                    if (!Route.isHttp(u)) {
                                        Ui.toast(MainActivity.this, "只支持 http / https 网址");
                                        return;
                                    }
                                    FabRegistry.openInBackground(MainActivity.this, u);
                                    d.dismiss();
                                }
                            });
                }
            }
        });
        input.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == android.view.inputmethod.EditorInfo.IME_ACTION_GO) {
                    if (submitUrl(input)) d.dismiss();
                    return true;
                }
                return false;
            }
        });
        Ui.show(d);
        input.requestFocus();
    }

    private boolean submitUrl(android.widget.EditText input) {
        String u = Bookmarks.normalize(String.valueOf(input.getText()).trim());
        if (TextUtils.isEmpty(u)) {
            Ui.toast(this, "网址不能为空");
            return false;
        }
        if (!Route.isHttp(u)) {
            Ui.toast(this, "只支持 http / https 网址");
            return false;
        }
        openInside(u);
        return true;
    }

    private ProgressDialog busy(String msg) {
        try {
            ProgressDialog d = new ProgressDialog(this);
            d.setMessage(msg);
            d.setCancelable(false);
            d.setIndeterminate(true);
            d.show();
            return d;
        } catch (Throwable t) {
            return null;
        }
    }

    private void dismissBusy(ProgressDialog d) {
        try {
            if (d != null && d.isShowing()) d.dismiss();
        } catch (Throwable ignored) {
        }
    }
}
