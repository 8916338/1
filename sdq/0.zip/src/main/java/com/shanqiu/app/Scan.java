package com.shanqiu.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.text.TextUtils;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.BinaryBitmap;
import com.google.zxing.DecodeHintType;
import com.google.zxing.MultiFormatReader;
import com.google.zxing.PlanarYUVLuminanceSource;
import com.google.zxing.common.HybridBinarizer;

import java.io.InputStream;
import java.util.EnumMap;
import java.util.Map;

/**
 * 扫码入口与结果处理。
 *
 * 交互：点「扫描二维码」直接进入扫码界面（ScanActivity）——
 * 相机取景、边看边扫，界面里自带「相册」和「手电筒」两个按钮，
 * 不再先弹「用相机拍 / 从相册选」的选择框。
 *
 * 解码统一用 ZXing（二维码 + 常见一维码都认）。
 */
public final class Scan {

    public static final int REQ_SCAN = 1004;

    private Scan() {
    }

    /** 直接进入相机扫码界面 */
    public static void start(final MainActivity a) {
        if (a == null || a.isFinishing()) return;
        try {
            a.startActivityForResult(new Intent(a, ScanActivity.class), REQ_SCAN);
        } catch (Throwable t) {
            Ui.toast(a, "打不开扫码界面");
        }
    }

    /** MainActivity.onActivityResult 转发进来；返回 true 表示这个请求被消费了 */
    public static boolean onResult(final MainActivity a, int req, int res, Intent data) {
        if (req != REQ_SCAN) return false;
        if (res != Activity.RESULT_OK || data == null) return true;
        String text = data.getStringExtra("text");
        if (TextUtils.isEmpty(text)) return true;
        handle(a, text);
        return true;
    }

    /**
     * 相册图 / 任意图片 Uri → 二维码内容；解不出来返回 null。
     * ScanActivity 的「相册」按钮和这里共用。
     */
    public static String decodeUri(Context c, Uri uri) {
        Bitmap bmp = null;
        InputStream in = null;
        try {
            BitmapFactory.Options probe = new BitmapFactory.Options();
            probe.inJustDecodeBounds = true;
            in = c.getContentResolver().openInputStream(uri);
            BitmapFactory.decodeStream(in, null, probe);
            close(in);

            int sample = 1;
            int maxSide = Math.max(probe.outWidth, probe.outHeight);
            while (maxSide / sample > 1600) sample *= 2;

            BitmapFactory.Options opt = new BitmapFactory.Options();
            opt.inSampleSize = sample;
            in = c.getContentResolver().openInputStream(uri);
            bmp = BitmapFactory.decodeStream(in, null, opt);
        } catch (Throwable ignored) {
        } finally {
            close(in);
        }
        if (bmp == null) return null;

        try {
            return decodeBitmap(bmp);
        } finally {
            try {
                bmp.recycle();
            } catch (Throwable ignored) {
            }
        }
    }

    private static void close(InputStream in) {
        try {
            if (in != null) in.close();
        } catch (Throwable ignored) {
        }
    }

    /** 解码时最长边压到多少：太大只是慢，二维码解码不需要原分辨率 */
    private static final int MAX_DECODE_SIDE = 1200;

    /**
     * 任意 Bitmap → 二维码 / 条码内容；解不出来返回 null。
     *
     * 转灰度后按 0° / 90° / 180° / 270° 四个方向都试一遍 ——
     * 手机拍的二维码图经常是横躺的（EXIF 旋转不会被 BitmapFactory 应用），
     * 只试正方向就会「怎么都扫不出来」。
     */
    public static String decodeBitmap(Bitmap bmp) {
        if (bmp == null || bmp.isRecycled()) return null;
        Bitmap src = bmp;
        try {
            int w0 = bmp.getWidth();
            int h0 = bmp.getHeight();
            if (w0 <= 0 || h0 <= 0) return null;
            int maxSide = Math.max(w0, h0);
            if (maxSide > MAX_DECODE_SIDE) {
                float s = (float) MAX_DECODE_SIDE / maxSide;
                src = Bitmap.createScaledBitmap(bmp,
                        Math.max(1, Math.round(w0 * s)), Math.max(1, Math.round(h0 * s)), true);
            }
            int w = src.getWidth();
            int h = src.getHeight();
            int[] px = new int[w * h];
            src.getPixels(px, 0, w, 0, 0, w, h);
            byte[] gray = new byte[w * h];
            for (int i = 0; i < px.length; i++) {
                int p = px[i];
                int r = (p >> 16) & 0xFF, g = (p >> 8) & 0xFF, b = p & 0xFF;
                gray[i] = (byte) ((r * 38 + g * 75 + b * 15) >> 7);
            }
            return decodeGray(gray, w, h, hints(true), 0);
        } catch (Throwable t) {
            return null;
        } finally {
            if (src != bmp) {
                try {
                    src.recycle();
                } catch (Throwable ignored) {
                }
            }
        }
    }

    /** 解码提示：二维码 + 常见一维码，反色码也认 */
    static Map<DecodeHintType, Object> hints(boolean allFormats) {
        Map<DecodeHintType, Object> hints = new EnumMap<DecodeHintType, Object>(
                DecodeHintType.class);
        hints.put(DecodeHintType.TRY_HARDER, Boolean.TRUE);
        hints.put(DecodeHintType.CHARACTER_SET, "UTF-8");
        hints.put(DecodeHintType.ALSO_INVERTED, Boolean.TRUE);
        if (allFormats) {
            hints.put(DecodeHintType.POSSIBLE_FORMATS, java.util.Arrays.asList(
                    BarcodeFormat.QR_CODE, BarcodeFormat.DATA_MATRIX, BarcodeFormat.AZTEC,
                    BarcodeFormat.EAN_13, BarcodeFormat.EAN_8, BarcodeFormat.UPC_A,
                    BarcodeFormat.UPC_E, BarcodeFormat.CODE_128, BarcodeFormat.CODE_39,
                    BarcodeFormat.CODE_93, BarcodeFormat.ITF, BarcodeFormat.CODABAR));
        }
        return hints;
    }

    /**
     * 灰度图 → 文本：四个方向依次试，每个方向先整幅、再中心 70%、最后直方图兜底。
     *
     * 为什么要自己转：ZXing 3.5 的 PlanarYUVLuminanceSource 不支持
     * rotateCounterClockwise()（调用直接抛 UnsupportedOperationException），
     * 而相机预览帧在竖屏下是横躺的 —— 旧代码只能试原始方向，等于永远扫不出来。
     *
     * @param firstRot 先试哪个方向（0/1/2/3 = 0°/90°/180°/270°，顺时针）
     */
    static String decodeGray(byte[] gray, int w, int h,
                             Map<DecodeHintType, Object> hints, int firstRot) {
        if (gray == null || w <= 0 || h <= 0) return null;
        stretch(gray);
        for (int k = 0; k < 4; k++) {
            int rot = (((firstRot + k) % 4) + 4) % 4;
            byte[] buf = gray;
            int dw = w;
            int dh = h;
            if (rot != 0) {
                dw = (rot == 2) ? w : h;
                dh = (rot == 2) ? h : w;
                buf = new byte[dw * dh];
                rotateGray(gray, w, h, buf, rot);
            }
            PlanarYUVLuminanceSource full = new PlanarYUVLuminanceSource(
                    buf, dw, dh, 0, 0, dw, dh, false);
            String text = decodeOne(full, hints, true);
            if (text != null) return text;

            int cw = Math.max(1, dw * 7 / 10);
            int ch = Math.max(1, dh * 7 / 10);
            PlanarYUVLuminanceSource center = new PlanarYUVLuminanceSource(
                    buf, dw, dh, (dw - cw) / 2, (dh - ch) / 2, cw, ch, false);
            text = decodeOne(center, hints, true);
            if (text != null) return text;
        }
        // 兜底：反光 / 弱光 / 低对比度下 Hybrid 会失手，换全局直方图再试两个最可能的方向
        for (int k = 0; k < 2; k++) {
            int rot = (((firstRot + k) % 4) + 4) % 4;
            byte[] buf = gray;
            int dw = w;
            int dh = h;
            if (rot != 0) {
                dw = (rot == 2) ? w : h;
                dh = (rot == 2) ? h : w;
                buf = new byte[dw * dh];
                rotateGray(gray, w, h, buf, rot);
            }
            String text = decodeOne(new PlanarYUVLuminanceSource(
                    buf, dw, dh, 0, 0, dw, dh, false), hints, false);
            if (text != null) return text;
        }
        return null;
    }

    /**
     * 灰度拉伸：把 1% / 99% 分位之间映射到 0..255。
     *
     * 弱光、反光、隔着屏幕拍的时候，二维码黑白只差几十级灰度，
     * 直接二值化很容易糊成一片；先拉一次对比度，识别率明显变好。
     * 对比度本来就极低的图（几乎纯色）不硬拉，否则只会把噪点放大。
     */
    private static void stretch(byte[] g) {
        int[] hist = new int[256];
        for (byte b : g) hist[b & 0xFF]++;
        int cut = Math.max(1, g.length / 100);
        int lo = 0, hi = 255, acc = 0;
        for (int i = 0; i < 256; i++) {
            acc += hist[i];
            if (acc >= cut) {
                lo = i;
                break;
            }
        }
        acc = 0;
        for (int i = 255; i >= 0; i--) {
            acc += hist[i];
            if (acc >= cut) {
                hi = i;
                break;
            }
        }
        int span = hi - lo;
        if (span < 24) return;
        for (int i = 0; i < g.length; i++) {
            int v = (g[i] & 0xFF) - lo;
            v = v * 255 / span;
            if (v < 0) v = 0;
            if (v > 255) v = 255;
            g[i] = (byte) v;
        }
    }

    /** 灰度平面顺时针旋转：1=90°（宽高互换）2=180° 3=270°（宽高互换） */
    private static void rotateGray(byte[] src, int w, int h, byte[] dst, int rot) {
        if (rot == 1) {
            for (int y = 0; y < h; y++) {
                int row = y * w;
                for (int x = 0; x < w; x++) {
                    dst[x * h + (h - 1 - y)] = src[row + x];
                }
            }
        } else if (rot == 2) {
            int n = w * h;
            for (int i = 0; i < n; i++) dst[n - 1 - i] = src[i];
        } else {
            for (int y = 0; y < h; y++) {
                int row = y * w;
                for (int x = 0; x < w; x++) {
                    dst[(w - 1 - x) * h + y] = src[row + x];
                }
            }
        }
    }

    private static String decodeOne(com.google.zxing.LuminanceSource src,
                                    Map<DecodeHintType, Object> hints, boolean hybrid) {
        try {
            com.google.zxing.Binarizer binarizer = hybrid
                    ? new HybridBinarizer(src)
                    : new com.google.zxing.common.GlobalHistogramBinarizer(src);
            return new MultiFormatReader().decode(new BinaryBitmap(binarizer), hints).getText();
        } catch (Throwable t) {
            return null;
        }
    }

    private static void handle(final MainActivity a, final String text) {
        final String url = asUrl(text);
        AlertDialog.Builder b = new AlertDialog.Builder(a);
        b.setTitle(url == null ? "扫描结果" : "扫描到网址");
        b.setMessage(url == null ? text : url);
        if (url != null) {
            b.setPositiveButton("打开", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface d, int w) {
                    a.openInside(url);
                }
            });
        }
        b.setNegativeButton("复制", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface d, int w) {
                Route.copy(a, text, "已复制");
            }
        });
        b.setNeutralButton("关闭", null);
        try {
            Ui.show(b.create());
        } catch (Throwable ignored) {
        }
    }

    private static String asUrl(String text) {
        if (TextUtils.isEmpty(text)) return null;
        String t = text.trim();
        if (Route.isHttp(t)) return t;
        if (t.startsWith("www.")) return "https://" + t;
        return null;
    }
}
