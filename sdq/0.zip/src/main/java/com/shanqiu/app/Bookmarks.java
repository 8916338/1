package com.shanqiu.app;

import android.content.Context;
import android.content.SharedPreferences;
import android.text.TextUtils;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

/**
 * 闪电球里的书签。
 *
 * 书签分两类：
 *   1. 内置书签 —— 由工程配置 app-config.json 的 bookmarks 决定，打包进 assets/preset_bookmarks.json，
 *      用户端删不掉、改不了，要改只能重新打包；
 *   2. 自己收藏的 —— 在网页里点「收藏本页」加进来的，存在本地，可以长按删除。
 *
 * 菜单里内置的排在前面，自己收藏的排在后面。
 */
public final class Bookmarks {

    /** 特殊地址：指向启动页（跟着 Config.ONLINE / 内置页走，换站点也不会失效） */
    public static final String HOME = "hjk://home";

    /**
     * 内置网页书签在 assets/preset_bookmarks.json 里的前缀，
     * 例如 bookmark:f15cc76e3.html —— 运行时拼成内置页的真实地址。
     * 构建时由 tools/apply_config.py 写入（混淆版会自动换成改名后的文件名）。
     */
    private static final String FILE_PREFIX = "bookmark:";

    private static final String PREF = "shell_bookmarks";
    private static final String K_LIST = "list";
    /** 数据版本：1 = 带两条预置，2 = 清掉预置，只留用户自己的 */
    private static final String K_VER = "ver";
    private static final int VER = 2;

    public static final class Item {
        public String name;
        public String url;
        public boolean preset;
    }

    /** 内置书签读一次就缓存，assets 里的文件在进程生命周期内不会变 */
    private static List<Item> cachedPresets;

    private Bookmarks() {
    }

    private static SharedPreferences sp(Context c) {
        return c.getApplicationContext().getSharedPreferences(PREF, Context.MODE_PRIVATE);
    }

    // ------------------------------------------------------------ 读

    public static List<Item> all(Context c) {
        migrateIfNeeded(c);
        ArrayList<Item> out = new ArrayList<>(presets(c));
        for (Item i : read(c)) {
            if (indexOf(out, i.url) < 0) out.add(i);
        }
        return out;
    }

    /**
     * 内置书签：来自 assets/preset_bookmarks.json（构建时由 app-config.json 生成）。
     * 读不到就是空列表，不影响自己收藏的书签。
     */
    public static List<Item> presets(Context c) {
        if (cachedPresets != null) return cachedPresets;

        ArrayList<Item> out = new ArrayList<>();
        InputStream in = null;
        try {
            in = c.getAssets().open("preset_bookmarks.json");
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
            JSONArray arr = new JSONArray(new String(bo.toByteArray(), "UTF-8"));
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.optJSONObject(i);
                if (o == null) continue;
                String u = normalize(o.optString("url", ""));
                if (TextUtils.isEmpty(u)) continue;
                Item it = new Item();
                it.url = u;
                String nm = o.optString("name", "").trim();
                // 内置网页书签：bookmark:文件名 → 内置页真实地址
                if (u.startsWith(FILE_PREFIX)) {
                    String file = u.substring(FILE_PREFIX.length());
                    if (TextUtils.isEmpty(file)) continue;
                    it.url = Site.ORIGIN + "/" + file;
                }
                it.name = TextUtils.isEmpty(nm) ? labelOf(it.url) : nm;
                it.preset = true;
                out.add(it);
            }
        } catch (Throwable ignored) {
        } finally {
            try {
                if (in != null) in.close();
            } catch (Throwable ignored) {
            }
        }
        cachedPresets = out;
        return out;
    }

    /** 这条是不是内置书签（内置的删不掉） */
    public static boolean isPreset(Context c, String url) {
        return indexOf(presets(c), url) >= 0;
    }

    private static int indexOf(List<Item> list, String url) {
        for (int i = 0; i < list.size(); i++) {
            if (same(list.get(i).url, url)) return i;
        }
        return -1;
    }

    public static boolean has(Context c, String url) {
        if (TextUtils.isEmpty(url)) return false;
        for (Item i : all(c)) {
            if (same(i.url, url)) return true;
        }
        return false;
    }

    /** 用于「收藏本页」时给个默认名字 */
    public static String labelOf(String url) {
        if (TextUtils.isEmpty(url)) return "未命名";
        if (HOME.equals(url)) return "首页";
        // 内置页面：用文件名（去掉 .html）当名字，比如「内容一」
        if (url.startsWith(Site.ORIGIN)) {
            String path = url.substring(Site.ORIGIN.length());
            int q = path.indexOf('?');
            if (q >= 0) path = path.substring(0, q);
            while (path.startsWith("/")) path = path.substring(1);
            int dot = path.lastIndexOf('.');
            String n = dot > 0 ? path.substring(0, dot) : path;
            return TextUtils.isEmpty(n) ? "内置页面" : n;
        }
        String h = Route.hostOf(url);
        return TextUtils.isEmpty(h) ? url : h;
    }

    // ------------------------------------------------------------ 写

    public static void save(Context c, String name, String url) {
        if (TextUtils.isEmpty(url)) return;
        // 内置书签已经有了，不用在用户列表里再存一份
        if (isPreset(c, url)) return;
        String n = TextUtils.isEmpty(name) ? labelOf(url) : name.trim();

        ArrayList<Item> list = new ArrayList<>(all(c));
        boolean hit = false;
        for (Item i : list) {
            if (same(i.url, url)) {
                i.name = n;
                hit = true;
                break;
            }
        }
        if (!hit) {
            Item it = new Item();
            it.name = n;
            it.url = url;
            list.add(it);
        }
        write(c, list);
    }

    public static void remove(Context c, String url) {
        if (isPreset(c, url)) return;   // 内置书签来自配置，用户端删不掉
        ArrayList<Item> list = new ArrayList<>();
        for (Item i : all(c)) {
            if (!same(i.url, url)) list.add(i);
        }
        write(c, list);
    }

    private static void write(Context c, List<Item> list) {
        JSONArray arr = new JSONArray();
        for (Item i : list) {
            try {
                JSONObject o = new JSONObject();
                o.put("name", i.name);
                o.put("url", i.url);
                o.put("preset", i.preset);
                arr.put(o);
            } catch (Throwable ignored) {
            }
        }
        sp(c).edit().putString(K_LIST, arr.toString()).apply();
    }

    private static boolean same(String a, String b) {
        if (a == null || b == null) return false;
        return a.trim().equalsIgnoreCase(b.trim());
    }

    /**
     * 老版本装过的用户，列表里带着两条 preset（首页 / 备份站点）。
     * 这两项现在由菜单的固定项承担，升级时直接清掉，用户自己收藏的保留。
     */
    private static void migrateIfNeeded(Context c) {
        if (sp(c).getInt(K_VER, 1) >= VER) return;

        ArrayList<Item> keep = new ArrayList<>();
        for (Item i : read(c)) {
            if (i.preset) continue;
            keep.add(i);
        }
        write(c, keep);
        sp(c).edit().putInt(K_VER, VER).apply();
    }

    /** 只读，不触发迁移，避免递归 */
    private static ArrayList<Item> read(Context c) {
        ArrayList<Item> out = new ArrayList<>();
        try {
            JSONArray arr = new JSONArray(sp(c).getString(K_LIST, "[]"));
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.optJSONObject(i);
                if (o == null) continue;
                String u = o.optString("url", "");
                if (TextUtils.isEmpty(u)) continue;
                Item it = new Item();
                it.url = u;
                it.name = o.optString("name", "");
                if (TextUtils.isEmpty(it.name)) it.name = labelOf(u);
                it.preset = o.optBoolean("preset", false);
                out.add(it);
            }
        } catch (Throwable ignored) {
        }
        return out;
    }

    /** 把用户手输的地址补成合法 URL */
    public static String normalize(String url) {
        String u = url == null ? "" : url.trim();
        if (u.length() == 0) return "";
        String low = u.toLowerCase(java.util.Locale.US);
        if (low.startsWith("http://") || low.startsWith("https://")
                || low.startsWith("hjk://") || low.startsWith("bookmark:")) {
            return u;
        }
        return "https://" + u;
    }
}
