package com.shanqiu.app;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

/**
 * 壳内的文件操作：重命名 / 复制 / 剪切 / 移动 / 删除。
 *
 * 为什么要自己做：把用户甩给系统文件管理器，等于让他在另一个 App 里重新找一遍文件，
 * 找到还不一定能改（安卓 11+ 的分区存储把很多目录都挡住了）。这里直接对文件下手，
 * 代价只有一个：需要「所有文件访问权限」。
 *
 * 权限：
 *   Android 11+  → MANAGE_EXTERNAL_STORAGE（设置里手动打开，一次授权长期有效）
 *   Android 6~10 → WRITE_EXTERNAL_STORAGE 运行时权限
 *   更低版本     → 安装时就给了
 */
public final class FileOps {

    private FileOps() {
    }

    public static boolean hasAccess(Context c) {
        if (c == null) return false;
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                return Environment.isExternalStorageManager();
            } catch (Throwable t) {
                return false;
            }
        }
        if (Build.VERSION.SDK_INT >= 23) {
            return c.checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE)
                    == PackageManager.PERMISSION_GRANTED;
        }
        return true;
    }

    /** 没有权限就带用户去开，返回 false 表示当前还不可用 */
    public static boolean ensure(final Activity a) {
        if (a == null) return false;
        if (hasAccess(a)) return true;

        if (Build.VERSION.SDK_INT >= 30) {
            try {
                Intent i = new Intent(android.provider.Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                        Uri.parse("package:" + a.getPackageName()));
                a.startActivity(i);
            } catch (Throwable t) {
                try {
                    a.startActivity(new Intent(
                            android.provider.Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION));
                } catch (Throwable ignored) {
                    Ui.toast(a, "打不开权限设置，请到系统设置里给「所有文件访问权限」");
                    return false;
                }
            }
            Ui.toast(a, "打开「所有文件访问权限」后回来再操作一次");
            return false;
        }

        if (Build.VERSION.SDK_INT >= 23) {
            try {
                a.requestPermissions(
                        new String[]{android.Manifest.permission.WRITE_EXTERNAL_STORAGE}, 0x51);
                Ui.toast(a, "授予存储权限后再操作一次");
            } catch (Throwable ignored) {
                Ui.toast(a, "没有存储权限，改不了文件");
            }
            return false;
        }
        return true;
    }

    // ------------------------------------------------------------ 操作

    /** 重命名（同目录内）。成功返回新文件，失败返回 null */
    public static File rename(File f, String newName) {
        if (f == null || !f.exists() || newName == null) return null;
        String name = Ui.safeName(newName, "");
        if (name == null || name.length() == 0) return null;
        File dst = new File(f.getParentFile(), name);
        if (dst.getAbsolutePath().equals(f.getAbsolutePath())) return f;
        if (dst.exists()) return null;
        try {
            return f.renameTo(dst) ? dst : null;
        } catch (Throwable t) {
            return null;
        }
    }

    /** 复制到目标目录，重名自动加 (1)(2)。成功返回新文件 */
    public static File copyTo(File f, File dir) {
        if (f == null || !f.exists() || dir == null) return null;
        try {
            if (!dir.exists() && !dir.mkdirs()) return null;
            File dst = new File(dir, uniqueName(dir, f.getName()));
            if (!pipe(f, dst)) return null;
            return dst;
        } catch (Throwable t) {
            return null;
        }
    }

    /** 移动到目标目录（先试 rename，跨分区就复制再删原文件） */
    public static File moveTo(File f, File dir) {
        if (f == null || !f.exists() || dir == null) return null;
        try {
            if (!dir.exists() && !dir.mkdirs()) return null;
            File dst = new File(dir, uniqueName(dir, f.getName()));
            if (dst.getAbsolutePath().equals(f.getAbsolutePath())) return f;
            if (f.renameTo(dst)) return dst;
            if (!pipe(f, dst)) return null;
            // 复制成功再删原件；删不掉不算失败（文件已经在新位置）
            //noinspection ResultOfMethodCallIgnored
            f.delete();
            return dst;
        } catch (Throwable t) {
            return null;
        }
    }

    public static boolean delete(File f) {
        if (f == null || !f.exists()) return false;
        try {
            return f.delete();
        } catch (Throwable t) {
            return false;
        }
    }

    /** 目录里不重名的文件名 */
    public static String uniqueName(File dir, String name) {
        String base = name == null ? "file" : name;
        if (!new File(dir, base).exists()) return base;
        String ext = "";
        int dot = base.lastIndexOf('.');
        if (dot > 0) {
            ext = base.substring(dot);
            base = base.substring(0, dot);
        }
        for (int i = 1; i < 500; i++) {
            String n = base + "(" + i + ")" + ext;
            if (!new File(dir, n).exists()) return n;
        }
        return System.currentTimeMillis() + ext;
    }

    private static boolean pipe(File src, File dst) {
        InputStream in = null;
        OutputStream out = null;
        try {
            in = new FileInputStream(src);
            out = new FileOutputStream(dst);
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            out.flush();
            return true;
        } catch (Throwable t) {
            // 复制了一半的文件留着没用，清掉
            try {
                if (dst.exists()) dst.delete();
            } catch (Throwable ignored) {
            }
            return false;
        } finally {
            try {
                if (in != null) in.close();
            } catch (Throwable ignored) {
            }
            try {
                if (out != null) out.close();
            } catch (Throwable ignored) {
            }
        }
    }
}
