package com.shanqiu.app;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/**
 * 底部动作面板（不依赖 AndroidX，纯原生手搓）
 */
public final class Sheet {

    public interface Pick {
        void onPick(int index);
    }

    /** 长按某一项（菜单里用来删书签） */
    public interface LongPick {
        void onLongPick(int index);
    }

    private Sheet() {
    }

    public static Dialog show(Context ctx, String title, String subtitle,
                              String[] icons, String[] labels, String[] subs,
                              final Pick pick) {
        Object[] boxed = new Object[icons == null ? 0 : icons.length];
        for (int i = 0; i < boxed.length; i++) boxed[i] = icons[i];
        return showMixed(ctx, title, subtitle, boxed, labels, subs, pick, null);
    }

    /**
     * 矢量图标版：iconRes 与 labels 一一对应（0 表示这一行不放图标）。
     * 长按链接 / 图片的动作面板用这版 —— 图标风格与闪电球菜单一致（半透明线性）。
     */
    public static Dialog show(Context ctx, String title, String subtitle,
                              int[] iconRes, String[] labels, String[] subs,
                              final Pick pick) {
        return show(ctx, title, subtitle, iconRes, labels, subs, pick, null);
    }

    public static Dialog show(Context ctx, String title, String subtitle,
                              int[] iconRes, String[] labels, String[] subs,
                              final Pick pick, final LongPick longPick) {
        Object[] boxed = new Object[iconRes == null ? 0 : iconRes.length];
        for (int i = 0; i < boxed.length; i++) boxed[i] = iconRes[i];
        return showMixed(ctx, title, subtitle, boxed, labels, subs, pick, longPick);
    }

    /** 图标混排版：icons[i] 是 Integer(资源 id) 或 String(emoji)，其余同上 */
    public static Dialog showMixed(Context ctx, String title, String subtitle,
                                   Object[] icons, String[] labels, String[] subs,
                                   final Pick pick, final LongPick longPick) {
        if (ctx == null || labels == null || labels.length == 0) return null;
        if (ctx instanceof android.app.Activity
                && (((android.app.Activity) ctx).isFinishing()
                || ((android.app.Activity) ctx).isDestroyed())) {
            return null;
        }

        final Dialog dialog = new Dialog(ctx, R.style.SheetTheme);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setCanceledOnTouchOutside(true);

        final int pad = Ui.dp(ctx, 20);
        // 整块面板跟主题同色：面板底色 = 页面底色（同一个颜色），不再分层次
        Theme.Palette pal = Shell.of(ctx);

        LinearLayout root = new LinearLayout(ctx);
        root.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(pal.panel);
        float r = Ui.dp(ctx, 20);
        bg.setCornerRadii(new float[]{r, r, r, r, 0, 0, 0, 0});
        root.setBackground(bg);

        // 顶部小把手
        View grip = new View(ctx);
        GradientDrawable gripBg = new GradientDrawable();
        gripBg.setColor(pal.border);
        gripBg.setCornerRadius(Ui.dp(ctx, 2));
        grip.setBackground(gripBg);
        LinearLayout.LayoutParams gripLp = new LinearLayout.LayoutParams(Ui.dp(ctx, 34), Ui.dp(ctx, 4));
        gripLp.topMargin = Ui.dp(ctx, 9);
        gripLp.gravity = Gravity.CENTER_HORIZONTAL;
        root.addView(grip, gripLp);

        if (!TextUtils.isEmpty(title)) {
            LinearLayout head = new LinearLayout(ctx);
            head.setOrientation(LinearLayout.VERTICAL);
            head.setPadding(pad, Ui.dp(ctx, 14), pad, Ui.dp(ctx, 8));

            TextView t = new TextView(ctx);
            t.setText(title);
            t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f);
            t.setTextColor(pal.text);
            t.getPaint().setFakeBoldText(true);
            head.addView(t);

            if (!TextUtils.isEmpty(subtitle)) {
                TextView s = new TextView(ctx);
                s.setText(subtitle);
                s.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f);
                s.setTextColor(pal.sub);
                s.setMaxLines(2);
                s.setEllipsize(TextUtils.TruncateAt.MIDDLE);
                LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                slp.topMargin = Ui.dp(ctx, 3);
                head.addView(s, slp);
            }
            root.addView(head);
        }

        LinearLayout list = new LinearLayout(ctx);
        list.setOrientation(LinearLayout.VERTICAL);

        for (int i = 0; i < labels.length; i++) {
            if (i > 0) list.addView(divider(ctx, pad + (icons != null ? Ui.dp(ctx, 38) : 0)));
            final int index = i;
            LinearLayout row = new LinearLayout(ctx);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(pad, Ui.dp(ctx, 13), pad, Ui.dp(ctx, 13));
            row.setBackground(rowBackground(ctx));
            row.setClickable(true);
            row.setFocusable(true);

            Object icon = (icons != null && i < icons.length) ? icons[i] : null;
            if (icon instanceof Integer) {
                android.widget.ImageView ic = new android.widget.ImageView(ctx);
                ic.setImageResource((Integer) icon);
                LinearLayout.LayoutParams ilp = new LinearLayout.LayoutParams(
                        Ui.dp(ctx, 22), Ui.dp(ctx, 22));
                ilp.rightMargin = Ui.dp(ctx, 12);
                ic.setAlpha(0.85f);
                row.addView(ic, ilp);
            } else if (icon instanceof android.graphics.drawable.Drawable) {
                // 应用图标（选择「用哪个 App 打开」时用）——原色小圆角，不做灰度
                android.widget.ImageView ic = new android.widget.ImageView(ctx);
                ic.setImageDrawable((android.graphics.drawable.Drawable) icon);
                LinearLayout.LayoutParams ilp = new LinearLayout.LayoutParams(
                        Ui.dp(ctx, 26), Ui.dp(ctx, 26));
                ilp.rightMargin = Ui.dp(ctx, 10);
                row.addView(ic, ilp);
            } else if (icon != null && !TextUtils.isEmpty(String.valueOf(icon))) {
                TextView ic = new TextView(ctx);
                ic.setText(String.valueOf(icon));
                ic.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f);
                ic.setGravity(Gravity.CENTER);
                LinearLayout.LayoutParams ilp = new LinearLayout.LayoutParams(
                        Ui.dp(ctx, 32), Ui.dp(ctx, 32));
                ilp.rightMargin = Ui.dp(ctx, 6);
                row.addView(ic, ilp);
            }

            LinearLayout text = new LinearLayout(ctx);
            text.setOrientation(LinearLayout.VERTICAL);

            TextView label = new TextView(ctx);
            label.setText(labels[i]);
            label.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14.5f);
            label.setTextColor(pal.text);
            text.addView(label);

            String s = (subs != null && i < subs.length) ? subs[i] : null;
            if (!TextUtils.isEmpty(s)) {
                TextView sv = new TextView(ctx);
                sv.setText(s);
                sv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f);
                sv.setTextColor(pal.sub);
                sv.setMaxLines(1);
                sv.setEllipsize(TextUtils.TruncateAt.MIDDLE);
                LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                slp.topMargin = Ui.dp(ctx, 2);
                text.addView(sv, slp);
            }
            row.addView(text, new LinearLayout.LayoutParams(0,
                    ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

            row.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    dialog.dismiss();
                    if (pick != null) pick.onPick(index);
                }
            });

            if (longPick != null) {
                row.setOnLongClickListener(new View.OnLongClickListener() {
                    @Override
                    public boolean onLongClick(View v) {
                        dialog.dismiss();
                        longPick.onLongPick(index);
                        return true;
                    }
                });
            }

            list.addView(row, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        }

        final ScrollView scroller = new ScrollView(ctx);
        scroller.setFillViewport(false);
        scroller.addView(list, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(scroller, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        // 取消
        TextView cancel = new TextView(ctx);
        cancel.setText(R.string.cancel);
        cancel.setGravity(Gravity.CENTER);
        cancel.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14.5f);
        cancel.setTextColor(pal.sub);
        cancel.setPadding(0, Ui.dp(ctx, 14), 0, Ui.dp(ctx, 14));
        GradientDrawable cancelBg = new GradientDrawable();
        cancelBg.setColor(pal.press);
        cancelBg.setCornerRadius(Ui.dp(ctx, 12));
        cancel.setBackground(cancelBg);
        cancel.setClickable(true);
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        clp.leftMargin = pad;
        clp.rightMargin = pad;
        clp.topMargin = Ui.dp(ctx, 8);
        root.addView(cancel, clp);

        View bottom = new View(ctx);
        root.addView(bottom, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(ctx, 12)));

        dialog.setContentView(root);

        Window w = dialog.getWindow();
        if (w != null) {
            w.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            w.setGravity(Gravity.BOTTOM);
            // 不压暗背景：弹窗显示原色，页面保持原来的亮度
            WindowManager.LayoutParams lp = w.getAttributes();
            lp.width = WindowManager.LayoutParams.MATCH_PARENT;
            lp.height = WindowManager.LayoutParams.WRAP_CONTENT;
            lp.dimAmount = 0f;
            w.setAttributes(lp);
        }

        dialog.show();

        if (w != null) {
            w.setLayout(WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.WRAP_CONTENT);
        }

        // 选项一多（图片 + 链接 + 设置能有 10 项）会顶出屏幕，
        // 这里把面板高度卡在屏幕 60%，让列表自己滚，底下留一截页面可以点。
        final Window win = w;
        root.post(new Runnable() {
            @Override
            public void run() {
                if (win == null) return;
                int screenH = ctx.getResources().getDisplayMetrics().heightPixels;
                int maxH = (int) (screenH * 0.6f);
                if (root.getHeight() > maxH) {
                    LinearLayout.LayoutParams lp =
                            (LinearLayout.LayoutParams) scroller.getLayoutParams();
                    lp.height = 0;
                    lp.weight = 1f;
                    scroller.setLayoutParams(lp);
                    win.setLayout(WindowManager.LayoutParams.MATCH_PARENT, maxH);
                }
            }
        });
        return dialog;
    }

    private static View divider(Context ctx, int leftMargin) {
        View v = new View(ctx);
        v.setBackgroundColor(Shell.of(ctx).border);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, Math.max(1, Ui.dp(ctx, 0.7f)));
        lp.leftMargin = leftMargin;
        v.setLayoutParams(lp);
        return v;
    }

    private static StateListDrawable rowBackground(Context ctx) {
        Theme.Palette p = Shell.of(ctx);
        StateListDrawable sl = new StateListDrawable();
        GradientDrawable pressed = new GradientDrawable();
        pressed.setColor(p.press);
        pressed.setCornerRadius(Ui.dp(ctx, 9));
        GradientDrawable normal = new GradientDrawable();
        normal.setColor(Color.TRANSPARENT);
        normal.setCornerRadius(Ui.dp(ctx, 9));
        sl.addState(new int[]{android.R.attr.state_pressed}, pressed);
        sl.addState(new int[]{}, normal);
        return sl;
    }
}
