package com.shanqiu.app;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 插件仓库：安装、解析、启停、删除、按网址匹配。
 *
 * 插件就是一个 .js 文件，头部按通用 userscript 写法声明自己是谁、管哪些站点：
 *
 *   // ==UserScript==
 *   // @name        GitHub 中文化
 *   // @version     1.0.0
 *   // @match       https://github.com/*
 *   // @match       https://gist.github.com/*
 *   // ==/UserScript==
 *
 * 这样第三方开发者按油猴的写法就能写，壳只认这一小撮元数据（@name /
 * @version / @match / @include / @exclude），不用另学一套。
 *
 * 安装时把源码复制进应用私有目录（files/plugins/），元数据存 SharedPreferences。
 * 所以本机原文件删了、来源网址挂了，插件照样能用；卸载 App 才会一起没。
 */
public final class PluginStore {

    /** 一个装好的插件 */
    public static final class Plugin {
        public String id = "";
        public String name = "";
        public String version = "";
        /** 展示用：第一个站点，多个时加「等 N 个」 */
        public String site = "";
        /** 换行分隔的 @match / @include 规则 */
        public String matches = "";
        /** 换行分隔的 @exclude */
        public String excludes = "";
        /** 来源：网址或本地文件名 */
        public String source = "";
        public boolean enabled = true;
        public long installedAt;
        /** 已经给哪些站点弹过「首次进入」提示，逗号分隔 */
        public String hinted = "";
    }

    public interface Callback {
        void done(Plugin p, String error);
    }

    /** 单个插件上限 2MB：正常脚本几十 KB，超过基本是拉错了文件 */
    private static final int MAX_BYTES = 2 * 1024 * 1024;

    private static final String SP = "vie_plugins";
    private static final String K_LIST = "list";

    private PluginStore() {
    }

    // ------------------------------------------------------------ 读写清单

    private static SharedPreferences sp(Context c) {
        return c.getSharedPreferences(SP, Context.MODE_PRIVATE);
    }

    public static List<Plugin> list(Context c) {
        ArrayList<Plugin> out = new ArrayList<>();
        String raw = sp(c).getString(K_LIST, "");
        if (TextUtils.isEmpty(raw)) return out;
        try {
            JSONArray arr = new JSONArray(raw);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.optJSONObject(i);
                if (o == null) continue;
                Plugin p = new Plugin();
                p.id = o.optString("id");
                p.name = o.optString("name");
                p.version = o.optString("version");
                p.site = o.optString("site");
                p.matches = o.optString("matches");
                p.excludes = o.optString("excludes");
                p.source = o.optString("source");
                p.enabled = o.optBoolean("enabled", true);
                p.installedAt = o.optLong("installedAt");
                p.hinted = o.optString("hinted");
                if (!TextUtils.isEmpty(p.id) && new File(codeFile(c, p.id)).exists()) out.add(p);
            }
        } catch (Throwable ignored) {
        }
        return out;
    }

    private static void save(Context c, List<Plugin> items) {
        JSONArray arr = new JSONArray();
        for (Plugin p : items) {
            JSONObject o = new JSONObject();
            try {
                o.put("id", p.id);
                o.put("name", p.name);
                o.put("version", p.version);
                o.put("site", p.site);
                o.put("matches", p.matches);
                o.put("excludes", p.excludes);
                o.put("source", p.source);
                o.put("enabled", p.enabled);
                o.put("installedAt", p.installedAt);
                o.put("hinted", p.hinted);
            } catch (Throwable ignored) {
            }
            arr.put(o);
        }
        sp(c).edit().putString(K_LIST, arr.toString()).apply();
    }

    public static Plugin find(Context c, String id) {
        for (Plugin p : list(c)) if (p.id.equals(id)) return p;
        return null;
    }

    public static boolean hasAny(Context c) {
        return !list(c).isEmpty();
    }

    public static int enabledCount(Context c) {
        int n = 0;
        for (Plugin p : list(c)) if (p.enabled) n++;
        return n;
    }

    public static void setEnabled(Context c, String id, boolean on) {
        List<Plugin> all = list(c);
        for (Plugin p : all) {
            if (p.id.equals(id)) p.enabled = on;
        }
        save(c, all);
    }

    public static void remove(Context c, String id) {
        List<Plugin> all = list(c);
        for (int i = 0; i < all.size(); i++) {
            if (all.get(i).id.equals(id)) {
                all.remove(i);
                break;
            }
        }
        try {
            new File(codeFile(c, id)).delete();
        } catch (Throwable ignored) {
        }
        save(c, all);
    }

    private static File dir(Context c) {
        File d = new File(c.getFilesDir(), "plugins");
        if (!d.exists()) d.mkdirs();
        return d;
    }

    private static String codeFile(Context c, String id) {
        return new File(dir(c), id + ".js").getAbsolutePath();
    }

    /** 读插件源码（注入时用） */
    public static String code(Context c, Plugin p) {
        try {
            return readFile(new File(codeFile(c, p.id)), MAX_BYTES);
        } catch (Throwable t) {
            return "";
        }
    }

    // ------------------------------------------------------------ 安装

    /**
     * 把源码装进来。同名插件再装一次就是升级（保留启用状态和 id）。
     * 解析不出适用站点会抛异常 —— 这种插件装进去也不会生效，不如当场拒绝。
     */
    public static Plugin install(Context c, String code, String source) throws Exception {
        if (TextUtils.isEmpty(code)) throw new Exception("内容是空的");
        if (code.length() > MAX_BYTES) throw new Exception("插件太大（超过 2MB）");
        if (!code.contains("==UserScript==") && !code.contains("@match") && !code.contains("@include")) {
            throw new Exception("不像插件：缺少 ==UserScript== 头或 @match 规则");
        }

        Meta m = parseMeta(code);
        if (TextUtils.isEmpty(m.name)) throw new Exception("插件里没写 @name（名字）");
        if (TextUtils.isEmpty(m.matches)) throw new Exception("插件里没写 @match（适用网站）");

        String id = m.id();
        List<Plugin> all = list(c);

        Plugin p = null;
        for (Plugin e : all) if (e.id.equals(id)) p = e;
        boolean isNew = p == null;
        if (isNew) {
            p = new Plugin();
            p.id = id;
            p.installedAt = System.currentTimeMillis();
            all.add(p);
        }
        p.name = m.name;
        p.version = m.version;
        p.matches = m.matches;
        p.excludes = m.excludes;
        p.site = m.siteLabel();
        p.source = source == null ? "" : source;
        p.enabled = true;

        writeFile(new File(codeFile(c, p.id)), code);
        save(c, all);
        return p;
    }

    /** 从网址装：后台下载，主线程回调 */
    public static void installUrl(final Activity a, final String url, final Callback cb) {
        final Handler ui = new Handler(Looper.getMainLooper());
        new Thread(new Runnable() {
            @Override
            public void run() {
                String err = null;
                String body = null;
                try {
                    body = download(url);
                } catch (Throwable t) {
                    err = friendly(t);
                }
                final String fBody = body;
                final String fErr = err;
                ui.post(new Runnable() {
                    @Override
                    public void run() {
                        if (fErr != null) {
                            cb.done(null, fErr);
                            return;
                        }
                        try {
                            cb.done(install(a, fBody, url), null);
                        } catch (Throwable t) {
                            cb.done(null, t.getMessage());
                        }
                    }
                });
            }
        }, "plugin-dl").start();
    }

    /** 从系统文件选择器拿到的地址装（读成文本再存私有目录，原文件删了也不影响） */
    public static void installUri(final Activity a, final Uri uri, final Callback cb) {
        final Handler ui = new Handler(Looper.getMainLooper());
        new Thread(new Runnable() {
            @Override
            public void run() {
                String err = null;
                String body = null;
                String name = "本地文件";
                try {
                    InputStream in = a.getContentResolver().openInputStream(uri);
                    if (in == null) throw new Exception("读不到这个文件");
                    body = readStream(in, MAX_BYTES);
                    String last = uri.getLastPathSegment();
                    if (!TextUtils.isEmpty(last)) name = last;
                } catch (Throwable t) {
                    err = friendly(t);
                }
                final String fBody = body;
                final String fErr = err;
                final String fName = name;
                ui.post(new Runnable() {
                    @Override
                    public void run() {
                        if (fErr != null) {
                            cb.done(null, fErr);
                            return;
                        }
                        try {
                            cb.done(install(a, fBody, fName), null);
                        } catch (Throwable t) {
                            cb.done(null, t.getMessage());
                        }
                    }
                });
            }
        }, "plugin-file").start();
    }

    private static String download(String url) throws Exception {
        if (TextUtils.isEmpty(url)) throw new Exception("地址是空的");
        if (!url.startsWith("http://") && !url.startsWith("https://")) {
            throw new Exception("只支持 http / https 地址");
        }
        HttpURLConnection conn = null;
        try {
            conn = (HttpURLConnection) new URL(url).openConnection();
            conn.setConnectTimeout(15000);
            conn.setReadTimeout(20000);
            conn.setInstanceFollowRedirects(true);
            // 有些站点对移动 UA 返回不同内容，这里装成桌面浏览器
            conn.setRequestProperty("User-Agent",
                    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                            + "(KHTML, like Gecko) Chrome/120.0 Safari/537.36");
            int code = conn.getResponseCode();
            if (code < 200 || code >= 300) throw new Exception("下载失败：HTTP " + code);
            return readStream(conn.getInputStream(), MAX_BYTES);
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    private static String friendly(Throwable t) {
        String m = t == null ? "" : String.valueOf(t.getMessage());
        if (TextUtils.isEmpty(m)) m = "网络或文件读取失败";
        if (m.contains("Permission")) return "没有网络权限或文件访问被拒";
        if (m.contains("timeout") || m.contains("timed out")) return "连接超时，检查地址或网络";
        return m;
    }

    // ------------------------------------------------------------ 元数据解析

    private static final Pattern META = Pattern.compile("^\\s*//\\s*@([A-Za-z0-9:_-]+)\\s+(.+?)\\s*$");

    private static final class Meta {
        String name = "";
        String zhName = "";
        String version = "";
        String namespace = "";
        String matches = "";
        String excludes = "";
        String firstHost = "";

        String display() {
            return TextUtils.isEmpty(zhName) ? name : zhName;
        }

        String id() {
            String base = (TextUtils.isEmpty(namespace) ? "" : namespace) + "|" + name;
            int h = base.hashCode();
            return "p" + Integer.toHexString(h == Integer.MIN_VALUE ? 1 : Math.abs(h));
        }

        String siteLabel() {
            if (TextUtils.isEmpty(firstHost)) return "";
            int n = matches.split("\n").length;
            return n > 1 ? firstHost + " 等 " + n + " 个站点" : firstHost;
        }
    }

    private static Meta parseMeta(String code) {
        Meta m = new Meta();
        boolean inHead = false;
        for (String line : code.split("\n", 200)) {
            String s = line.trim();
            if (s.contains("==UserScript==")) {
                inHead = true;
                continue;
            }
            if (s.contains("==/UserScript==")) break;
            if (!inHead) continue;
            Matcher mt = META.matcher(line);
            if (!mt.find()) continue;
            String k = mt.group(1);
            String v = mt.group(2).trim();
            if ("name".equals(k)) m.name = v;
            else if ("name:zh-CN".equals(k) || "name:zh".equals(k)) m.zhName = v;
            else if ("version".equals(k)) m.version = v;
            else if ("namespace".equals(k)) m.namespace = v;
            else if ("match".equals(k) || "include".equals(k)) {
                m.matches += (m.matches.isEmpty() ? "" : "\n") + v;
                if (m.firstHost.isEmpty()) m.firstHost = hostOfPattern(v);
            } else if ("exclude".equals(k)) {
                m.excludes += (m.excludes.isEmpty() ? "" : "\n") + v;
            }
        }
        return m;
    }

    private static String hostOfPattern(String pattern) {
        try {
            int i = pattern.indexOf("://");
            String rest = i > 0 ? pattern.substring(i + 3) : pattern;
            int slash = rest.indexOf('/');
            String host = slash >= 0 ? rest.substring(0, slash) : rest;
            if (host.startsWith("*.")) host = host.substring(2);
            return host;
        } catch (Throwable t) {
            return "";
        }
    }

    // ------------------------------------------------------------ 网址匹配

    /** 这个网址要跑哪些插件（只算启用的） */
    public static List<Plugin> matchFor(Context c, String url) {
        ArrayList<Plugin> out = new ArrayList<>();
        if (TextUtils.isEmpty(url)) return out;
        for (Plugin p : list(c)) {
            if (p.enabled && matches(p, url)) out.add(p);
        }
        return out;
    }

    static boolean matches(Plugin p, String url) {
        if (TextUtils.isEmpty(url)) return false;
        Uri u = Uri.parse(url);
        String host = u.getHost();
        if (TextUtils.isEmpty(host)) return false;
        boolean hit = false;
        for (String m : p.matches.split("\n")) {
            if (TextUtils.isEmpty(m)) continue;
            if (matchOne(m, url, host)) {
                hit = true;
                break;
            }
        }
        if (!hit) return false;
        for (String e : p.excludes.split("\n")) {
            if (!TextUtils.isEmpty(e) && matchOne(e, url, host)) return false;
        }
        return true;
    }

    private static boolean matchOne(String pattern, String url, String host) {
        String pat = pattern.trim();
        int i = pat.indexOf("://");
        String scheme = i > 0 ? pat.substring(0, i) : "*";
        String rest = i > 0 ? pat.substring(i + 3) : pat;
        int slash = rest.indexOf('/');
        String phost = slash >= 0 ? rest.substring(0, slash) : rest;
        String ppath = slash >= 0 ? rest.substring(slash) : "/*";

        Uri u = Uri.parse(url);
        String us = u.getScheme() == null ? "" : u.getScheme();
        if (!"*".equals(scheme) && !scheme.equalsIgnoreCase(us)) return false;

        if (!glob(phost, host)) return false;

        String path = u.getPath();
        if (TextUtils.isEmpty(path)) path = "/";
        if (!TextUtils.isEmpty(u.getQuery())) path += "?" + u.getQuery();
        return glob(ppath, path);
    }

    /** 只支持 * 通配，够用了；转成正则逐字符比 */
    private static boolean glob(String pattern, String text) {
        if (pattern.equals("*") || pattern.equals("/*")) return true;
        StringBuilder re = new StringBuilder("^");
        for (int i = 0; i < pattern.length(); i++) {
            char ch = pattern.charAt(i);
            if (ch == '*') re.append(".*");
            else if ("\\.[]{}()+-^$|?".indexOf(ch) >= 0) re.append('\\').append(ch);
            else re.append(ch);
        }
        re.append("$");
        try {
            return text.matches(re.toString());
        } catch (Throwable t) {
            return false;
        }
    }

    // ------------------------------------------------------------ 首次进入提示

    public static boolean hinted(Context c, Plugin p, String host) {
        if (p == null || TextUtils.isEmpty(host)) return true;
        for (String h : p.hinted.split(",")) if (h.equals(host)) return true;
        return false;
    }

    public static void markHinted(Context c, String id, String host) {
        if (TextUtils.isEmpty(host)) return;
        List<Plugin> all = list(c);
        for (Plugin p : all) {
            if (!p.id.equals(id)) continue;
            if (hinted(c, p, host)) return;
            p.hinted = p.hinted.isEmpty() ? host : p.hinted + "," + host;
        }
        save(c, all);
    }

    // ------------------------------------------------------------ 文件

    static String readFile(File f, int max) throws Exception {
        if (!f.exists()) throw new Exception("文件不存在");
        if (f.length() > max) throw new Exception("文件太大");
        return readStream(new java.io.FileInputStream(f), max);
    }

    static String readStream(InputStream in, int max) throws Exception {
        try {
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            int total = 0;
            while ((n = in.read(buf)) > 0) {
                total += n;
                if (total > max) throw new Exception("内容超过 2MB，可能不是插件文件");
                bos.write(buf, 0, n);
            }
            return new String(bos.toByteArray(), "UTF-8");
        } finally {
            try {
                in.close();
            } catch (Throwable ignored) {
            }
        }
    }

    static void writeFile(File f, String text) throws Exception {
        FileOutputStream out = new FileOutputStream(f);
        try {
            out.write(text.getBytes("UTF-8"));
            out.flush();
        } finally {
            out.close();
        }
    }
}
