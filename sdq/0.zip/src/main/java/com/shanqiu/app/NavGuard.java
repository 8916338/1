package com.shanqiu.app;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.drawable.GradientDrawable;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.FrameLayout;
import android.widget.TextView;

import org.json.JSONObject;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;

/**
 * 网页控制（「更多 → 网页控制」里的开关，Prefs.guard）。
 *
 * 核心约定：开关打开后，网页的每一次「跳转」和「弹窗」都不许自己发生，
 * 放不放行由用户点，壳只负责把事件停下来并摆到用户面前。壳不做任何
 * 「这个应该是用户想要的」之类的自动判断。
 *
 * 每次事件只有四种走向：
 *
 *   站点在白名单   → 直接执行，底部按钮浮出 5 秒标语「已按白名单放行 · a.com」
 *   站点在黑名单   → 直接丢弃，底部按钮浮出 5 秒标语「已按黑名单拦截 · a.com」
 *   不在名单 + 用户点的  → 当场弹决策框（放行 / 拦截 / 先放着 + 记住此站点）
 *   不在名单 + 自动发生的 → 进待处理队列，底部按钮常驻「待处理 N 条」
 *
 * 底部按钮是唯一的操作入口：点开有 待处理 / 临时决策 / 阅读模式 /
 * 最近处理 / 名单管理 / 隐藏按钮。临时决策和阅读模式开着时按钮常驻，
 * 随时能点回来关掉。
 *
 * 「是不是用户点的」只用来决定**什么时候问**（当场问还是排队问），
 * 不用于决定放不放行 —— 放不放行永远是用户点出来的。
 */
public final class NavGuard {

    // ------------------------------------------------------------ 数据结构

    /** 一条被拦下的跳转或弹窗 */
    public static final class Item {
        public final String url;
        /** true = JS 弹窗（内容存的是弹窗文案）；false = 页面跳转 */
        public final boolean popup;
        /** 站点主机名：弹窗是来源站点，跳转是目标站点 */
        public final String host;
        public final long at;

        Item(String url, boolean popup, String host) {
            this.url = url;
            this.popup = popup;
            String h = GuardLists.normalize(host);
            this.host = TextUtils.isEmpty(h) ? UNKNOWN_HOST : h;
            this.at = System.currentTimeMillis();
        }
    }

    /** 一条处理记录（「最近处理」里显示，点开可以把站点加进 / 移出名单） */
    public static final class Rec {
        public final String host;
        public final boolean popup;
        /** true = 白/黑名单自动处理；false = 用户手动决定 */
        public final boolean auto;
        public final boolean allowed;
        /** 来源文案：白名单 / 黑名单 / 临时 / 手动 / 点击 */
        public final String mode;
        public final String detail;
        public final long at;

        Rec(String host, boolean popup, boolean auto, boolean allowed, String mode, String detail) {
            this.host = GuardLists.normalize(host);
            this.popup = popup;
            this.auto = auto;
            this.allowed = allowed;
            this.mode = mode;
            this.detail = detail == null ? "" : detail;
            this.at = System.currentTimeMillis();
        }
    }

    /** 拿不到站点名时的占位（about:blank / data: 这类） */
    static final String UNKNOWN_HOST = "未知站点";

    /** 待处理队列（包内可见：GuardLists 决策完要摘条目） */
    static final ArrayList<Item> QUEUE = new ArrayList<>();

    /** 最近处理：自动（白/黑名单命中）、手动决定、用户亲手点的链接，各留 5 条 */
    private static final int HIST_MAX = 5;
    static final ArrayDeque<Rec> AUTO_HIST = new ArrayDeque<>();
    static final ArrayDeque<Rec> MANUAL_HIST = new ArrayDeque<>();
    /** 用户点开过的链接（没被拦、直接加载的）。误触隐藏块就靠这里一键加黑 */
    static final ArrayDeque<Rec> CLICK_HIST = new ArrayDeque<>();

    /** 临时决策：本次使用期间对「全部跳转 + 全部弹窗」统一放行 / 统一拦截 */
    public static final int TEMP_NONE = 0;
    public static final int TEMP_ALLOW = 1;
    public static final int TEMP_BLOCK = 2;
    private static volatile int tempMode = TEMP_NONE;

    private static final int MAX_PENDING = 12;
    /** 点击后多少毫秒内的跳转算「用户点的」—— 只用于决定当场问还是排队问 */
    private static final long TOUCH_WINDOW_MS = 700;
    /** 白/黑名单自动处理时，底部标语停留时长 */
    private static final long FLASH_MS = 5000;
    /**
     * 用户刚点了「放行」之后的一小段时间里，页面自己接着发生的跳转
     * （302 重定向、落地页续跳）算这次放行的延续，不再拦 —— 否则
     * 放行一个短链会立刻被下一条重定向拦下来再问一次，很烦人。
     * 时间窗故意短：2 秒，够页面跑完这一串跳转，又不会把后面的广告放走。
     */
    private static final long FOLLOW_MS = 2000;

    private static volatile long lastTouchAt;
    /** 用户刚放行过，这段时间内的续跳不再拦 */
    private static volatile long bypassUntil;
    /** 正在弹「要打开这个链接吗」的框，避免连跳叠出好几层 */
    private static boolean asking;

    /** 底部那颗胶囊按钮（挂在 MainActivity 的根布局上） */
    private static TextView pill;

    /** 5 秒临时标语（白/黑名单命中、阅读模式拦截） */
    private static String flashText;
    /** 最近一条标语，说明弹窗关掉后要补放一遍 */
    private static String lastFlash;
    private static long flashUntil;
    private static int flashSeq;

    /** 用户主动在面板里把按钮藏了（下一次有事自动冒出来） */
    private static boolean hiddenByUser;

    private NavGuard() {
    }

    // ------------------------------------------------------------ 开关

    public static boolean on(Context c) {
        return c != null && Prefs.guard(c);
    }

    // ------------------------------------------------------------ 拦截点

    /** 用户手指碰到网页（ACTION_DOWN）时记一笔，只用于「当场问 / 排队问」的分流 */
    public static void noteTouch() {
        lastTouchAt = System.currentTimeMillis();
    }

    /** 这次跳转是不是刚被用户点出来的（只用来分「当场问」还是「排队问」） */
    public static boolean userTouched() {
        return System.currentTimeMillis() - lastTouchAt < TOUCH_WINDOW_MS;
    }

    /**
     * 页面跳转拦截点（MainActivity.handleUrl 里调用）。
     * 返回 true = 这次跳转被拦下了，调用方不要再加载它。
     */
    public static boolean maybeHold(MainActivity a, String url) {
        if (a == null || TextUtils.isEmpty(url)) return false;
        if (!on(a)) return false;
        // 刚放行过：这一串续跳是用户点头的延续，别再问一遍
        if (System.currentTimeMillis() < bypassUntil) return false;
        // 壳自己的虚拟地址和特殊协议不拦
        if (url.startsWith("hjk://") || Route.isSpecial(url)) return false;
        // 只拦 http / https
        if (!Route.isHttp(url)) return false;
        // 内置页面之间随便跳，不拦
        if (Site.HOST.equals(Route.hostOf(url))) return false;

        String host = GuardLists.normalize(Route.hostOf(url));

        // 1. 临时决策最优先：用户自己按下的临时开关，对所有站点一视同仁
        if (tempMode == TEMP_ALLOW) {
            noteAutoRec(host, false, true, "临时", url);
            flash(a, "临时放行 · " + shortHost(host));
            return false;
        }
        if (tempMode == TEMP_BLOCK) {
            noteAutoRec(host, false, false, "临时", url);
            flash(a, "临时拦截 · " + shortHost(host));
            return true;
        }

        // 2. 用户亲手维护的名单：直接执行，只在底部按钮上留 5 秒标语
        String d = GuardLists.decision(a, host);
        if (GuardLists.ALLOW.equals(d)) {
            noteAutoRec(host, false, true, "白名单", url);
            flash(a, "已按白名单放行 · " + shortHost(host));
            return false;
        }
        if (GuardLists.BLOCK.equals(d)) {
            noteAutoRec(host, false, false, "黑名单", url);
            flash(a, "已按黑名单拦截 · " + shortHost(host));
            return true;
        }

        // 3. 没名单：网页自己跳的排队等
        if (!userTouched()) {
            hold(a, new Item(url, false, host));
            return true;
        }
        // 用户点的：记进「最近处理」（误触了能一键加黑），再当场问
        noteUserClickRec(host, url);
        if (asking) {
            // 手上已经有一个框（首次说明 / 上一条的决策框）在等用户点，
            // 这条先排队，别叠出两层把屏幕糊住
            enqueue(a, new Item(url, false, host));
        } else {
            askJump(a, url, host);
        }
        return true;
    }

    /**
     * JS 弹窗拦截点（WebChromeClient.onJsAlert 里调用）。
     * 返回 true = 这次别走默认弹窗（拦下 / 丢弃了）。
     *
     * 弹窗一律进队列：它没有「用户点的」这种来源可判断，
     * 与其猜，不如统一排队等用户点开看。
     */
    public static boolean holdPopup(MainActivity a, String pageUrl, String message) {
        if (a == null || TextUtils.isEmpty(message)) return false;
        if (!on(a)) return false;
        // 内置页面的弹窗是自己人，不拦
        if (!TextUtils.isEmpty(pageUrl) && pageUrl.startsWith(Site.ORIGIN)) return false;

        String host = GuardLists.normalize(Route.hostOf(pageUrl));

        if (tempMode == TEMP_ALLOW) {
            noteAutoRec(host, true, true, "临时", message);
            flash(a, "临时放行弹窗 · " + shortHost(host));
            return false;
        }
        if (tempMode == TEMP_BLOCK) {
            noteAutoRec(host, true, false, "临时", message);
            flash(a, "临时拦截弹窗 · " + shortHost(host));
            return true;
        }

        String d = GuardLists.decision(a, host);
        if (GuardLists.ALLOW.equals(d)) {
            noteAutoRec(host, true, true, "白名单", message);
            flash(a, "白名单放行弹窗 · " + shortHost(host));
            return false;
        }
        if (GuardLists.BLOCK.equals(d)) {
            noteAutoRec(host, true, false, "黑名单", message);
            flash(a, "黑名单拦截弹窗 · " + shortHost(host));
            return true;
        }

        hold(a, new Item(message, true, host));
        return true;
    }

    /** 用户点了链接、站点又不在名单里：当场问一句（放行 / 拦截 / 先放着） */
    private static void askJump(final MainActivity a, final String url, final String host) {
        // 第一次用：先讲按钮是干什么的，讲完再问这一条放不放
        if (needIntro(a)) {
            showIntro(a, new Runnable() {
                @Override
                public void run() {
                    askJumpNow(a, url, host);
                }
            });
            return;
        }
        askJumpNow(a, url, host);
    }

    private static void askJumpNow(final MainActivity a, final String url, final String host) {
        asking = true;

        final int pad = Ui.dp(a, 20);
        android.widget.LinearLayout box = new android.widget.LinearLayout(a);
        box.setOrientation(android.widget.LinearLayout.VERTICAL);
        box.setPadding(pad, Ui.dp(a, 10), pad, Ui.dp(a, 2));

        TextView site = new TextView(a);
        site.setText(shortHost(host));
        site.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f);
        site.setTextColor(Shell.of(a).text);
        box.addView(site);

        TextView link = new TextView(a);
        link.setText(url);
        link.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f);
        link.setTextColor(Shell.of(a).sub);
        link.setPadding(0, Ui.dp(a, 4), 0, 0);
        box.addView(link);

        final CheckBox remember = new CheckBox(a);
        remember.setText("记住这个站点，以后都按这次的选择处理");
        remember.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f);
        remember.setTextColor(Shell.of(a).text);
        android.widget.LinearLayout.LayoutParams rlp = new android.widget.LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        rlp.topMargin = Ui.dp(a, 8);
        box.addView(remember, rlp);

        AlertDialog.Builder b = new AlertDialog.Builder(a);
        b.setTitle("这个链接要跳转");
        b.setView(box);
        b.setPositiveButton("放行", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface d, int w) {
                if (remember.isChecked()) {
                    GuardLists.add(a, GuardLists.WHITE, host);
                    Ui.toast(a, "已把 " + shortHost(host) + " 加进白名单");
                }
                noteManualRec(host, false, true, url);
                bypassUntil = System.currentTimeMillis() + FOLLOW_MS;
                a.openInside(url);
            }
        });
        b.setNegativeButton("拦截", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface d, int w) {
                if (remember.isChecked()) {
                    GuardLists.add(a, GuardLists.BLACK, host);
                    Ui.toast(a, "已把 " + shortHost(host) + " 加进黑名单");
                }
                noteManualRec(host, false, false, url);
            }
        });
        b.setNeutralButton("先放着", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface d, int w) {
                hold(a, new Item(url, false, host));
            }
        });
        AlertDialog d = b.create();
        d.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface dlg) {
                asking = false;
                sync(a);
            }
        });
        Ui.show(d);
    }

    /**
     * 拦下一条。第一次用时先把「底部这颗按钮」讲清楚 —— 讲完才入队，
     * 这样用户关掉说明时这条还在，不会出现「说明一关，本条也没了」。
     */
    private static void hold(final MainActivity a, final Item it) {
        if (needIntro(a)) {
            showIntro(a, new Runnable() {
                @Override
                public void run() {
                    enqueue(a, it);
                }
            });
            return;
        }
        enqueue(a, it);
    }

    private static void enqueue(MainActivity a, Item it) {
        // 去重：同一条反复触发只留最新一份，挪到队尾
        for (int i = 0; i < QUEUE.size(); i++) {
            Item p = QUEUE.get(i);
            if (p.popup == it.popup && p.url.equals(it.url)) {
                QUEUE.remove(i);
                break;
            }
        }
        QUEUE.add(it);
        while (QUEUE.size() > MAX_PENDING) QUEUE.remove(0);
        hiddenByUser = false;
        sync(a);
    }

    /** 换页了：上一页拦下的跳转 / 弹窗已经过时，清掉（临时决策和名单不受影响） */
    public static void onPageStart(MainActivity a) {
        if (!QUEUE.isEmpty()) {
            QUEUE.clear();
        }
        sync(a);
    }

    /** 关掉开关时把队列、临时决策、标语一起清掉 */
    public static void clear(MainActivity a) {
        QUEUE.clear();
        tempMode = TEMP_NONE;
        flashText = null;
        lastFlash = null;
        flashUntil = 0;
        hiddenByUser = false;
        bypassUntil = 0;
        AUTO_HIST.clear();
        MANUAL_HIST.clear();
        CLICK_HIST.clear();
        sync(a);
    }

    // ------------------------------------------------------------ 放行 / 拦截

    /**
     * 放行若干条：弹窗内容拼起来当场亮出来，跳转只打开最后一条
     * （一连串跳转互相覆盖，全开会绕圈）。
     */
    static void releaseItems(MainActivity a, List<Item> items) {
        StringBuilder pop = new StringBuilder();
        String jump = null;
        for (Item it : items) {
            if (it.popup) {
                if (pop.length() > 0) pop.append("\n\n―――――\n\n");
                pop.append(it.url);
            } else {
                jump = it.url;
            }
        }
        QUEUE.removeAll(items);
        sync(a);
        if (jump != null) {
            bypassUntil = System.currentTimeMillis() + FOLLOW_MS;
            a.openInside(jump);
        }
        if (pop.length() > 0) showPopupContent(a, pop.toString());
    }

    /** 拦截若干条：网页本来就没跳，摘掉队列 + 记一笔就行 */
    static void blockItems(MainActivity a, List<Item> items) {
        if (items.isEmpty()) return;
        QUEUE.removeAll(items);
        sync(a);
    }

    static void releaseAll(final MainActivity a) {
        if (QUEUE.isEmpty()) return;
        ArrayList<Item> all = new ArrayList<>(QUEUE);
        for (Item it : all) noteManualRec(it.host, it.popup, true, it.url);
        releaseItems(a, all);
    }

    static void blockAll(final MainActivity a) {
        if (QUEUE.isEmpty()) {
            Ui.toast(a, "没有待处理的东西");
            return;
        }
        ArrayList<Item> all = new ArrayList<>(QUEUE);
        for (Item it : all) noteManualRec(it.host, it.popup, false, it.url);
        blockItems(a, all);
        Ui.toast(a, "已拦截 " + all.size() + " 条");
    }

    // ------------------------------------------------------------ 历史

    private static void noteAutoRec(String host, boolean popup, boolean allowed, String mode, String detail) {
        push(AUTO_HIST, new Rec(host, popup, true, allowed, mode, detail));
    }

    /** 用户亲手点开的链接（没被拦、直接加载）：进「最近处理」第三本 */
    static void noteUserClickRec(String host, String url) {
        String h = GuardLists.normalize(host);
        if (TextUtils.isEmpty(h)) h = UNKNOWN_HOST;
        push(CLICK_HIST, new Rec(h, false, false, true, "点击", url));
    }

    static void noteManualRec(String host, boolean popup, boolean allowed, String detail) {
        push(MANUAL_HIST, new Rec(host, popup, false, allowed, "手动", detail));
    }

    private static void push(ArrayDeque<Rec> q, Rec r) {
        // 同站点 + 同类型 + 同结果只留最新的，免得 5 条全是同一个站
        Iterator<Rec> it = q.iterator();
        while (it.hasNext()) {
            Rec e = it.next();
            if (e.host.equals(r.host) && e.popup == r.popup && e.allowed == r.allowed) it.remove();
        }
        q.addFirst(r);
        while (q.size() > HIST_MAX) q.removeLast();
    }

    // ------------------------------------------------------------ 底部胶囊按钮

    /**
     * 创建胶囊按钮（MainActivity.onCreate 里调一次）。
     * 贴网页底部居中，宽度尽量窄；平时藏起来，有事才浮出来。
     */
    public static void attach(final MainActivity a) {
        if (a == null || a.isFinishing() || a.isDestroyed()) return;
        if (pill != null && pill.getParent() == a.overlayRoot()) return;

        TextView p = new TextView(a);
        p.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f);
        p.setTextColor(0xFFFFFFFF);
        p.setGravity(Gravity.CENTER);
        p.setIncludeFontPadding(false);
        p.setSingleLine(true);
        p.setEllipsize(TextUtils.TruncateAt.END);
        p.setPadding(Ui.dp(a, 10), Ui.dp(a, 6), Ui.dp(a, 10), Ui.dp(a, 6));

        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(Ui.dp(a, 14));
        bg.setColor(0xE62196F3);
        bg.setStroke(Math.max(1, Ui.dp(a, 0.8f)), 0x33FFFFFF);
        p.setBackground(bg);
        p.setClickable(true);
        p.setFocusable(true);
        p.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showPanel(a);
            }
        });

        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        // 底部居中；再往下压半行，贴近网页底边，不挡正文
        lp.gravity = Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL;
        lp.bottomMargin = Ui.dp(a, 8);
        // 长文案别一直往右长，左右各给闪电球留出位置
        p.setMaxWidth(a.getResources().getDisplayMetrics().widthPixels
                - Ui.dp(a, 2 * (14 + 48 + 8)));

        pill = p;
        a.overlayRoot().addView(pill, lp);
        pill.setVisibility(View.GONE);
        sync(a);
    }

    /** 队列 / 模式变化就调：更新胶囊按钮的可见性和文字 */
    public static void sync(final MainActivity a) {
        if (a == null || a.isFinishing() || a.isDestroyed()) return;
        a.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                TextView p = pill;
                if (p == null) return;
                String text = label(a);
                if (text == null || hiddenByUser) {
                    p.setVisibility(View.GONE);
                    return;
                }
                p.setText(text);
                p.setVisibility(View.VISIBLE);
                p.bringToFront();
                // 球永远在最上面
                if (a.fab() != null) a.fab().bringToFront();
            }
        });
    }

    /** 按钮当前该显示什么；null = 该藏起来 */
    private static String label(MainActivity a) {
        if (!on(a)) return null;
        if (flashText != null && System.currentTimeMillis() < flashUntil) return flashText;

        int jumps = 0;
        int pops = 0;
        for (Item i : QUEUE) {
            if (i.popup) pops++;
            else jumps++;
        }
        if (jumps + pops > 0) {
            StringBuilder t = new StringBuilder("待处理 ").append(jumps + pops).append(" 条");
            if (jumps > 0) t.append(" · 跳转 ").append(jumps);
            if (pops > 0) t.append(" · 弹窗 ").append(pops);
            t.append(" · 点这里处理");
            return t.toString();
        }
        if (tempMode == TEMP_ALLOW) return "临时放行全部中 · 点这里取消";
        if (tempMode == TEMP_BLOCK) return "临时拦截全部中 · 点这里取消";
        if (Prefs.read(a)) return "阅读模式 · 点这里关闭";
        return null;
    }

    /** 白/黑名单命中、阅读模式拦下：只在按钮上闪一句，不弹框 */
    private static void flash(MainActivity a, String text) {
        flashText = text;
        lastFlash = text;
        flashUntil = System.currentTimeMillis() + FLASH_MS;
        hiddenByUser = false;
        sync(a);

        final TextView p = pill;
        if (p == null) return;
        final int seq = ++flashSeq;
        p.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (seq != flashSeq) return;                  // 又来了一条，让它继续计时
                if (System.currentTimeMillis() < flashUntil) return;
                flashText = null;
                sync(a);
            }
        }, FLASH_MS + 120);
    }

    /** 阅读模式下点了链接：拦下来，标语放按钮上（节流，连点不刷屏） */
    public static void toastReadBlocked(MainActivity a) {
        if (a == null) return;
        long now = System.currentTimeMillis();
        if (now - lastReadAt < 1200) return;
        lastReadAt = now;
        flash(a, "阅读模式：已阻止跳转");
    }

    private static long lastReadAt;

    /** 首次说明讲过了没有 */
    private static boolean needIntro(MainActivity a) {
        return a != null && !Prefs.guardIntro(a) && !introShowing;
    }

    /**
     * 第一次真要处理跳转 / 弹窗时，先把底部按钮讲一遍（点「知道了」才关）。
     * 关掉之后才走 after —— 也就是「用户退出提示之后，才选择是否放行本条」。
     */
    private static void showIntro(final MainActivity a, final Runnable after) {
        if (a == null || a.isFinishing() || a.isDestroyed()) {
            if (after != null) after.run();
            return;
        }
        introShowing = true;
        // 说明占着屏幕，这期间不再弹决策框（后来的事件排队等）
        asking = true;
        try {
            AlertDialog d = new AlertDialog.Builder(a)
                    .setTitle("底部这颗按钮")
                    .setMessage("网页要跳转、或者要弹窗的时候，会被它先拦下来，网页停在原地。\n\n"
                            + "点它就能处理：放行、拦截，或者记住这个站点以后都这么办。\n\n"
                            + "· 处理完它自己会消失，不挡你看网页\n"
                            + "· 它可以收起来，下次有事还会出现\n"
                            + "· 临时决策和阅读模式开着时它会一直留着，随时能点回来关\n"
                            + "· 白名单 / 黑名单命中的，只在它上面闪一句，不打扰你")
                    .setPositiveButton("知道了", null)
                    .create();
            d.setOnDismissListener(new DialogInterface.OnDismissListener() {
                @Override
                public void onDismiss(DialogInterface dlg) {
                    introShowing = false;
                    asking = false;
                    Prefs.setGuardIntro(a);
                    // 说明期间可能正好闪过白/黑名单标语，计时被它吃掉；
                    // 这里补回 5 秒，用户关掉说明后仍然看得见。
                    if (flashText != null) {
                        flashText = null;
                        flash(a, lastFlash);
                    }
                    if (after != null) after.run();
                    sync(a);
                }
            });
            Ui.show(d);
        } catch (Throwable t) {
            introShowing = false;
            asking = false;
            Prefs.setGuardIntro(a);
            if (after != null) after.run();
        }
    }

    private static boolean introShowing;

    /** Activity 销毁时摘掉按钮，别把销毁掉的 View 留在静态变量里 */
    public static void detach(MainActivity a) {
        if (pill != null && a != null && pill.getParent() == a.overlayRoot()) {
            try {
                a.overlayRoot().removeView(pill);
            } catch (Throwable ignored) {
            }
        }
        pill = null;
        QUEUE.clear();
        tempMode = TEMP_NONE;
        flashText = null;
        flashUntil = 0;
        hiddenByUser = false;
        asking = false;
    }

    // ------------------------------------------------------------ 处理面板

    /** 点胶囊按钮呼出的面板 */
    public static void showPanel(final MainActivity a) {
        if (a == null || a.isFinishing() || a.isDestroyed()) return;

        ArrayList<QuickMenu.Row> rows = new ArrayList<>();

        // ① 待处理：按站点归组
        if (QUEUE.isEmpty()) {
            rows.add(new QuickMenu.Row(0, "现在没有待处理的跳转或弹窗",
                    "网页有事的时候会自己冒出来", "guard__h1__header__", null));
        } else {
            rows.add(new QuickMenu.Row(0, "待处理 " + QUEUE.size() + " 条",
                    "点一行看明细，决定放不放", "guard__h1__header__", null));

            LinkedHashMap<String, ArrayList<Item>> byHost = new LinkedHashMap<>();
            for (Item it : QUEUE) {
                ArrayList<Item> g = byHost.get(it.host);
                if (g == null) {
                    g = new ArrayList<>();
                    byHost.put(it.host, g);
                }
                g.add(it);
            }
            for (String host : byHost.keySet()) {
                ArrayList<Item> g = byHost.get(host);
                int j = 0;
                int p2 = 0;
                for (Item it : g) {
                    if (it.popup) p2++;
                    else j++;
                }
                StringBuilder sub = new StringBuilder();
                if (j > 0) sub.append("跳转 ").append(j);
                if (p2 > 0) {
                    if (sub.length() > 0) sub.append(" · ");
                    sub.append("弹窗 ").append(p2);
                }
                sub.append(" · 点击处理");
                rows.add(new QuickMenu.Row(
                        GuardLists.decision(a, host).equals(GuardLists.BLOCK)
                                ? R.drawable.ic_q_delete : R.drawable.ic_q_web,
                        shortHost(host), sub.toString(), "guard_site", host));
            }

            rows.add(new QuickMenu.Row(R.drawable.ic_q_link, "放行当前全部", null,
                    "guard_all_allow", null));
            rows.add(new QuickMenu.Row(R.drawable.ic_q_delete, "拦截当前全部", null,
                    "guard_all_block", null));
        }

        // ② 临时决策
        rows.add(new QuickMenu.Row(0, "临时决策", "本次使用有效，退出 App 自动复位",
                "guard__h2__header__", null));
        rows.add(new QuickMenu.Row(R.drawable.ic_q_play,
                tempMode == TEMP_ALLOW ? "✓ 临时放行全部（点击取消）" : "临时放行全部",
                "跳转和弹窗都不再问，直接过", "guard_temp_allow", null));
        rows.add(new QuickMenu.Row(R.drawable.ic_q_delete,
                tempMode == TEMP_BLOCK ? "✓ 临时拦截全部（点击取消）" : "临时拦截全部",
                "跳转和弹窗都不再问，直接丢", "guard_temp_block", null));

        // ③ 阅读模式
        rows.add(new QuickMenu.Row(0, "阅读模式", "链接点了也不跳，防误触隐藏块",
                "guard__h3__header__", null));
        rows.add(new QuickMenu.Row(R.drawable.ic_q_link,
                Prefs.read(a) ? "✓ 阅读模式（点击关闭）" : "阅读模式（点击开启）",
                Prefs.read(a) ? "已生效：网页里的链接点了不跳" : "开启后网页里的链接点了不跳",
                "guard_read", null));

        // ④ 名单
        rows.add(new QuickMenu.Row(0, "名单", "点进去增删站点",
                "guard__h4__header__", null));
        rows.add(new QuickMenu.Row(R.drawable.ic_q_bookmark,
                "白名单（" + GuardLists.get(a, GuardLists.WHITE).size() + "）",
                "这些站点直接放行", "guard_white", null));
        rows.add(new QuickMenu.Row(R.drawable.ic_q_delete,
                "黑名单（" + GuardLists.get(a, GuardLists.BLACK).size() + "）",
                "这些站点直接丢弃", "guard_black", null));

        // ⑤ 最近处理：名单自动处理 5 条 / 手动决定 5 条 / 你点开的链接 5 条
        if (!AUTO_HIST.isEmpty() || !MANUAL_HIST.isEmpty() || !CLICK_HIST.isEmpty()) {
            rows.add(new QuickMenu.Row(0, "最近处理",
                    "点一条可加进 / 移出名单（误触的链接就在这里拉黑）",
                    "guard__h5__header__", null));
            for (Rec r : AUTO_HIST) {
                rows.add(new QuickMenu.Row(iconOf(r), autoLabel(r),
                        recSub(a, r), "guard_rec", r));
            }
            for (Rec r : MANUAL_HIST) {
                rows.add(new QuickMenu.Row(iconOf(r), manualLabel(r),
                        recSub(a, r), "guard_rec", r));
            }
            for (Rec r : CLICK_HIST) {
                rows.add(new QuickMenu.Row(iconOf(r), clickLabel(r),
                        recSub(a, r), "guard_rec", r));
            }
        }

        // ⑥ 收起
        rows.add(new QuickMenu.Row(R.drawable.ic_q_fold, "收起这颗按钮",
                "不影响拦截，下次有事还会出来", "guard_hide", null));

        QuickMenu.show(a, a.fab(), rows, false, new QuickMenu.Pick() {
            @Override
            public void onPick(String id, Object data) {
                if (id == null) return;

                if ("guard_site".equals(id)) {
                    final String host = String.valueOf(data);
                    ArrayList<Item> items = new ArrayList<>();
                    for (Item it : QUEUE) {
                        if (it.host.equals(host)) items.add(it);
                    }
                    if (items.isEmpty()) return;
                    GuardLists.decideSite(a, host, items);
                    return;
                }
                if ("guard_all_allow".equals(id)) {
                    if (QUEUE.isEmpty()) {
                        Ui.toast(a, "没有待处理的东西");
                    } else {
                        releaseAll(a);
                    }
                    return;
                }
                if ("guard_all_block".equals(id)) {
                    blockAll(a);
                    return;
                }
                if ("guard_temp_allow".equals(id)) {
                    if (tempMode == TEMP_ALLOW) {
                        tempMode = TEMP_NONE;
                        Ui.toast(a, "已取消临时放行");
                    } else {
                        tempMode = TEMP_ALLOW;
                        // 打开临时放行，already 排队的那批也算「不再问」，直接放掉
                        if (!QUEUE.isEmpty()) releaseAll(a);
                        Ui.toast(a, "临时放行全部：跳转和弹窗都直接过，再点一次取消");
                    }
                    sync(a);
                    return;
                }
                if ("guard_temp_block".equals(id)) {
                    if (tempMode == TEMP_BLOCK) {
                        tempMode = TEMP_NONE;
                        Ui.toast(a, "已取消临时拦截");
                    } else {
                        tempMode = TEMP_BLOCK;
                        QUEUE.clear();
                        Ui.toast(a, "临时拦截全部：跳转和弹窗都直接丢，再点一次取消");
                    }
                    sync(a);
                    return;
                }
                if ("guard_read".equals(id)) {
                    Prefs.setRead(a, !Prefs.read(a));
                    sync(a);
                    return;
                }
                if ("guard_rec".equals(id)) {
                    Rec r = (Rec) data;
                    showRec(a, r);
                    return;
                }
                if ("guard_white".equals(id)) {
                    GuardLists.manageList(a, GuardLists.WHITE);
                    return;
                }
                if ("guard_black".equals(id)) {
                    GuardLists.manageList(a, GuardLists.BLACK);
                    return;
                }
                if ("guard_hide".equals(id)) {
                    hiddenByUser = true;
                    flashText = null;
                    flashUntil = 0;
                    sync(a);
                    boolean stillOn = tempMode != TEMP_NONE || Prefs.read(a);
                    Ui.toast(a, "已收起" + (stillOn ? "，临时决策 / 阅读模式还在生效" : "")
                            + "，下次有拦截会自动出来");
                }
            }
        });
    }

    private static int iconOf(Rec r) {
        if (r.popup) return R.drawable.ic_q_layer;
        return R.drawable.ic_q_link;
    }

    private static String autoLabel(Rec r) {
        return r.mode + (r.allowed ? "放行 · " : "拦截 · ") + shortHost(r.host);
    }

    private static String manualLabel(Rec r) {
        return (r.allowed ? "手动放行 · " : "手动拦截 · ") + shortHost(r.host);
    }

    private static String clickLabel(Rec r) {
        return "你点过 · " + shortHost(r.host);
    }

    private static String recSub(MainActivity a, Rec r) {
        String kind = r.popup ? "弹窗" : "跳转";
        String tail = r.detail == null ? "" : r.detail.replace('\n', ' ');
        if (tail.length() > 34) tail = tail.substring(0, 34) + "…";
        if (TextUtils.isEmpty(tail)) return kind + " · 点一条可调名单";
        return kind + " · " + tail;
    }

    /** 点一条历史：加进白/黑名单，或从现有名单里移出来 */
    private static void showRec(final MainActivity a, final Rec r) {
        String inWhite = GuardLists.get(a, GuardLists.WHITE).contains(r.host) ? "（已在白名单）" : "";
        String inBlack = GuardLists.get(a, GuardLists.BLACK).contains(r.host) ? "（已在黑名单）" : "";
        boolean listed = GuardLists.decision(a, r.host) != GuardLists.ASK;

        StringBuilder msg = new StringBuilder();
        msg.append(r.allowed ? "处理：放行" : "处理：拦截");
        if ("点击".equals(r.mode)) msg.append("（你点开的链接）");
        else if (r.auto) msg.append("（" + r.mode + "自动处理）");
        else msg.append("（你手动定的）");
        msg.append("\n类型：").append(r.popup ? "弹窗" : "跳转");
        msg.append("\n站点：").append(r.host);
        if (!TextUtils.isEmpty(r.detail)) {
            String tail = r.detail.replace('\n', ' ');
            if (tail.length() > 120) tail = tail.substring(0, 120) + "…";
            msg.append("\n内容：").append(tail);
        }

        AlertDialog.Builder b = new AlertDialog.Builder(a);
        b.setTitle(("点击".equals(r.mode) ? "你点过的链接" : "最近一次处理") + inWhite + inBlack);
        b.setMessage(msg.toString());
        b.setPositiveButton("加进白名单", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface d, int w) {
                GuardLists.add(a, GuardLists.WHITE, r.host);
                Ui.toast(a, shortHost(r.host) + " → 白名单：以后直接放行");
            }
        });
        b.setNeutralButton("加进黑名单", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface d, int w) {
                GuardLists.add(a, GuardLists.BLACK, r.host);
                Ui.toast(a, shortHost(r.host) + " → 黑名单：以后直接丢弃");
            }
        });
        if (listed) {
            b.setNegativeButton("从名单移出", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface d, int w) {
                    GuardLists.remove(a, GuardLists.WHITE, r.host);
                    GuardLists.remove(a, GuardLists.BLACK, r.host);
                    Ui.toast(a, shortHost(r.host) + " 已移出名单，以后会再问你");
                }
            });
        } else {
            b.setNegativeButton("关闭", null);
        }
        Ui.show(b.create());
    }

    // ------------------------------------------------------------ 小工具

    /** 站点名字太长塞不下，截一下 */
    static String shortHost(String host) {
        if (host == null) return "";
        String h = host;
        if (h.startsWith("www.")) h = h.substring(4);
        if (h.length() > 26) h = h.substring(0, 26) + "…";
        return h;
    }

    /** 放行弹窗：把内容原样亮出来（一条或多条拼好传进来） */
    public static void showPopupContent(MainActivity a, String message) {
        try {
            new AlertDialog.Builder(a)
                    .setTitle("网页弹窗")
                    .setMessage(message)
                    .setPositiveButton("知道了", null)
                    .show();
        } catch (Throwable t) {
            Ui.toast(a, message);
        }
    }

    /** 调试用：把当前队列倒成 JSON（暂未接界面，留作扩展点） */
    public static String dumpJson() {
        try {
            org.json.JSONArray arr = new org.json.JSONArray();
            for (Item i : QUEUE) {
                JSONObject o = new JSONObject();
                o.put("url", i.url);
                o.put("popup", i.popup);
                arr.put(o);
            }
            return arr.toString();
        } catch (Throwable t) {
            return "[]";
        }
    }
}
