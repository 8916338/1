package com.shanqiu.app;

import android.app.DownloadManager;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.ParcelFileDescriptor;
import android.text.TextUtils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.HashMap;

/**
 * 下载：**永远先问用户**。
 *
 * 页面里点了 .apk / .zip 之类的链接，不会静默开下，而是弹一个面板：
 *   下载到手机 / 交给浏览器 / 复制链接
 *
 * 下载走系统 DownloadManager，好处是通知栏有进度、文件落在系统「下载」目录、
 * 文件管理器和系统的「打开方式」都能正常识别类型。
 */
public final class Downloader {

    public static final String APK_MIME = "application/vnd.android.package-archive";

    /** 本地下载台账：系统下载器里的记录可能被清掉、也可能属于旧包名，这里留一份 */
    private static final String PREF = "vie_downloads";
    private static final String KEY = "log";
    private static final int LOG_MAX = 120;

    private final MainActivity act;
    private final DownloadManager dm;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final HashMap<Long, Item> items = new HashMap<>();
    private boolean polling;

    private static final class Item {
        long id;
        String name;
        String mime;
        long startedAt;
        /** 系统下载器记录的真实落盘地址（完成时才有） */
        String localUri;
    }

    public Downloader(MainActivity a) {
        this.act = a;
        this.dm = (DownloadManager) a.getSystemService(Context.DOWNLOAD_SERVICE);
    }

    // ------------------------------------------------------------ 入口

    /** 页面点击 / DownloadListener 都会走到这里：先弹选择面板 */
    public void confirm(final String url, final String ua, final String disposition,
                        final String mime, final long length) {
        if (TextUtils.isEmpty(url)) {
            Ui.toast(act, "下载地址为空");
            return;
        }
        if (url.startsWith("blob:")) {
            Ui.toast(act, "这个文件是网页临时生成的，壳里没法直接保存");
            return;
        }

        final String name = guessName(url, disposition, mime);
        final String m = Mimes.guess(url, mime);
        String sub = name + (length > 0 ? "  ·  " + Ui.humanSize(length) : "");

        Sheet.show(act, "下载文件", sub,
                new String[]{"⬇", "🌐", "📋"},
                new String[]{"下载到手机", "交给浏览器下载", "复制下载链接"},
                new String[]{"存到系统「下载」目录，通知栏有进度",
                        "用浏览器自己的下载功能", null},
                new Sheet.Pick() {
                    @Override
                    public void onPick(int i) {
                        if (i == 0) start(url, ua, name, m);
                        else if (i == 1) Route.browser(act, url);
                        else Route.copy(act, url, "下载链接已复制");
                    }
                });
    }

    /** 真正开始下载 */
    public void start(String url, String ua, String name, String mime) {
        if (dm == null) {
            Ui.toast(act, "系统下载器不可用");
            return;
        }
        try {
            DownloadManager.Request r = new DownloadManager.Request(Uri.parse(url));
            r.setTitle(name);
            r.setDescription("网页下载");
            r.setMimeType(mime);
            r.setNotificationVisibility(
                    DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            r.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name);
            if (Build.VERSION.SDK_INT >= 24) r.setAllowedOverMetered(true);
            r.setAllowedOverRoaming(true);
            String agent = TextUtils.isEmpty(ua) ? act.userAgent() : ua;
            if (!TextUtils.isEmpty(agent)) r.addRequestHeader("User-Agent", agent);
            String ref = act.pageUrl();
            if (!TextUtils.isEmpty(ref)) r.addRequestHeader("Referer", ref);

            long id = dm.enqueue(r);
            Item it = new Item();
            it.id = id;
            it.name = name;
            it.mime = mime;
            it.startedAt = System.currentTimeMillis();
            items.put(id, it);
            remember(act, id, name, url, mime, 0);
            Ui.toast(act, "开始下载：" + name);
            startPolling();
        } catch (Throwable t) {
            Ui.toast(act, "下载失败：" + t.getMessage());
        }
    }

    // ------------------------------------------------------------ 本地台账

    /**
     * 记一条下载台账。
     *
     * 为什么要自己记：DownloadManager 的记录属于「发起下载的那个包」，
     * 换包名重装之后就查不到了；有的 ROM 清理下载任务时也会把记录一起删掉。
     * 自己留一份，面板里至少能看到「下载过什么」。
     */
    public static void remember(Context c, long id, String name, String url,
                                String mime, long size) {
        remember(c, id, name, url, mime, size, null, null);
    }

    public static void remember(Context c, long id, String name, String url,
                                String mime, long size, String local, String cache) {
        if (c == null || TextUtils.isEmpty(name)) return;
        try {
            org.json.JSONArray arr = log(c);
            org.json.JSONObject o = new org.json.JSONObject();
            o.put("id", id);
            o.put("name", name);
            o.put("url", url == null ? "" : url);
            o.put("mime", mime == null ? "" : mime);
            o.put("size", size);
            o.put("time", System.currentTimeMillis());
            if (!TextUtils.isEmpty(local)) o.put("local", local);
            if (!TextUtils.isEmpty(cache)) o.put("cache", cache);
            arr.put(o);

            org.json.JSONArray out = new org.json.JSONArray();
            for (int i = arr.length() - 1; i >= 0 && out.length() < LOG_MAX; i--) {
                org.json.JSONObject one = arr.optJSONObject(i);
                if (one != null) out.put(one);
            }
            c.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit()
                    .putString(KEY, out.toString()).apply();
        } catch (Throwable ignored) {
        }
    }

    /** 读台账（数组顺序：新的在前） */
    public static org.json.JSONArray log(Context c) {
        try {
            String s = c.getSharedPreferences(PREF, Context.MODE_PRIVATE)
                    .getString(KEY, "[]");
            org.json.JSONArray arr = new org.json.JSONArray(s == null ? "[]" : s);
            // 存的时候新的在前，追加时按时间正序更好处理，这里翻一次
            org.json.JSONArray rev = new org.json.JSONArray();
            for (int i = arr.length() - 1; i >= 0; i--) {
                org.json.JSONObject o = arr.optJSONObject(i);
                if (o != null) rev.put(o);
            }
            return rev;
        } catch (Throwable t) {
            return new org.json.JSONArray();
        }
    }

    /**
     * 删掉一条台账记录（面板里的「删除记录」）。
     * id >= 0 按任务 id 匹配，否则按文件名匹配；只动台账，不动文件。
     */
    public static void forget(Context c, long id, String name) {
        if (c == null) return;
        try {
            org.json.JSONArray arr = log(c);   // 新的在前
            org.json.JSONArray out = new org.json.JSONArray();
            for (int i = 0; i < arr.length(); i++) {
                org.json.JSONObject o = arr.optJSONObject(i);
                if (o == null) continue;
                boolean hit = id >= 0
                        ? o.optLong("id", -2) == id
                        : (name != null && name.equals(o.optString("name", "")));
                if (hit) continue;
                out.put(o);
            }
            c.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit()
                    .putString(KEY, out.toString()).apply();
        } catch (Throwable ignored) {
        }
    }

    /**
     * 下载完成（或重试成功）后把路径信息补进台账：
     * local = 系统下载目录里的原件地址；cache = 本应用私有缓存里的副本地址。
     * 只更新对应 id 的那条，找不到就不动。
     */
    public static void attachPaths(Context c, long id, String local, String cache) {
        if (c == null || id < 0) return;
        try {
            org.json.JSONArray arr = log(c);
            boolean changed = false;
            for (int i = 0; i < arr.length(); i++) {
                org.json.JSONObject o = arr.optJSONObject(i);
                if (o == null || o.optLong("id", -2) != id) continue;
                if (!TextUtils.isEmpty(local)) o.put("local", local);
                if (!TextUtils.isEmpty(cache)) o.put("cache", cache);
                changed = true;
                break;
            }
            if (!changed) return;
            org.json.JSONArray out = new org.json.JSONArray();
            for (int i = arr.length() - 1; i >= 0; i--) {
                org.json.JSONObject one = arr.optJSONObject(i);
                if (one != null) out.put(one);
            }
            c.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit()
                    .putString(KEY, out.toString()).apply();
        } catch (Throwable ignored) {
        }
    }

    /**
     * 改名 / 移动之后同步台账。
     *
     * 为什么要单独记 rname：DownloadManager 的标题改不了，下次查出来还是老名字，
     * 面板里就会「改完又变回去」。查询时优先用 rname，才不至于白改一场。
     */
    public static void rename(Context c, long id, String oldName, String newName, String newLocal) {
        if (c == null || TextUtils.isEmpty(newName)) return;
        try {
            org.json.JSONArray arr = log(c);          // 新的在前
            boolean changed = false;
            for (int i = 0; i < arr.length(); i++) {
                org.json.JSONObject o = arr.optJSONObject(i);
                if (o == null) continue;
                boolean hit = id >= 0 ? o.optLong("id", -2) == id
                        : newName.equals(o.optString("name", ""));
                if (!hit) continue;
                o.put("name", newName);
                o.put("rname", newName);
                if (!TextUtils.isEmpty(newLocal)) o.put("local", newLocal);
                changed = true;
                break;
            }
            if (!changed) {
                org.json.JSONObject o = new org.json.JSONObject();
                o.put("id", id);
                o.put("name", newName);
                o.put("rname", newName);
                o.put("url", "");
                o.put("mime", "");
                o.put("size", 0);
                o.put("time", System.currentTimeMillis());
                if (!TextUtils.isEmpty(newLocal)) o.put("local", newLocal);
                arr.put(o);
            }
            org.json.JSONArray out = new org.json.JSONArray();
            for (int i = arr.length() - 1; i >= 0 && out.length() < LOG_MAX; i--) {
                org.json.JSONObject one = arr.optJSONObject(i);
                if (one != null) out.put(one);
            }
            c.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit()
                    .putString(KEY, out.toString()).apply();
        } catch (Throwable ignored) {
        }
    }

    /** 文件名 → 系统「下载」目录里的实际路径 */
    public static File publicFile(String name) {
        return new File(Environment.getExternalStoragePublicDirectory(
                Environment.DIRECTORY_DOWNLOADS), Ui.safeName(name, "download"));
    }

    // ------------------------------------------------------------ 进度

    private void startPolling() {
        if (polling) return;
        polling = true;
        ui.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (items.isEmpty()) {
                    polling = false;
                    return;
                }
                tick();
                ui.postDelayed(this, 800);
            }
        }, 800);
    }

    private void tick() {
        if (items.isEmpty()) return;
        long[] ids = new long[items.size()];
        int k = 0;
        for (Long id : items.keySet()) ids[k++] = id;

        Cursor c = null;
        try {
            c = dm.query(new DownloadManager.Query().setFilterById(ids));
            if (c == null) return;
            while (c.moveToNext()) {
                long id = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_ID));
                int status = c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS));
                Item it = items.get(id);
                if (it == null) continue;

                if (status == DownloadManager.STATUS_SUCCESSFUL) {
                    items.remove(id);
                    int ti = c.getColumnIndex(DownloadManager.COLUMN_TITLE);
                    String title = ti >= 0 ? c.getString(ti) : null;
                    if (!TextUtils.isEmpty(title)) it.name = title;
                    int li = c.getColumnIndex(DownloadManager.COLUMN_LOCAL_URI);
                    if (li >= 0) it.localUri = c.getString(li);
                    onDone(it);
                } else if (status == DownloadManager.STATUS_FAILED) {
                    items.remove(id);
                    int ri = c.getColumnIndex(DownloadManager.COLUMN_REASON);
                    int reason = ri >= 0 ? c.getInt(ri) : 0;
                    Ui.toast(act, "下载失败（" + reasonText(reason) + "）：" + it.name);
                }
            }
        } catch (Throwable ignored) {
        } finally {
            if (c != null) c.close();
        }

        long now = System.currentTimeMillis();
        ArrayList<Long> drop = new ArrayList<>();
        for (Item it : items.values()) {
            if (now - it.startedAt > 10 * 60 * 1000L) drop.add(it.id);
        }
        for (Long id : drop) items.remove(id);
    }

    private static String reasonText(int reason) {
        switch (reason) {
            case DownloadManager.ERROR_INSUFFICIENT_SPACE: return "存储空间不足";
            case DownloadManager.ERROR_FILE_ERROR: return "文件写入失败";
            case DownloadManager.ERROR_HTTP_DATA_ERROR: return "网络中断";
            case DownloadManager.ERROR_TOO_MANY_REDIRECTS: return "重定向过多";
            case DownloadManager.ERROR_UNHANDLED_HTTP_CODE: return "服务器返回异常";
            case DownloadManager.ERROR_CANNOT_RESUME: return "无法断点续传";
            case DownloadManager.ERROR_UNKNOWN: return "未知错误";
            default: return "错误码 " + reason;
        }
    }

    // ------------------------------------------------------------ 完成

    private void onDone(Item it) {
        File f = copyToCache(it);
        // 台账补齐路径信息：local = 系统下载目录里的原件，cache = 私有缓存副本。
        // 面板点击时优先用 cache 打开，不依赖任何存储权限。
        attachPaths(act, it.id, it.localUri,
                f == null ? null : "file://" + f.getAbsolutePath());
        // 网页下载一律是「文件」，.apk 也一样：保存 / 分享 / 打开目录，
        // 走系统的「打开方式」交给用户决定，不替用户拉起安装器。
        // （App 自己的更新包走 UpdateDownload，不进这里、也不进下载记录）
        if (f == null) {
            Ui.toast(act, "已保存到下载目录：" + it.name);
            return;
        }
        openSheet(f, it);
    }

    private void openSheet(final File f, final Item it) {
        String ext = Mimes.ext(it.name).toUpperCase(java.util.Locale.US);
        Sheet.show(act, "下载完成", it.name,
                new String[]{"📂", "📤", "📁"},
                new String[]{"打开文件", "分享文件", "打开下载目录"},
                new String[]{ext.length() > 0 ? ext + " 文件" : null, null, null},
                new Sheet.Pick() {
                    @Override
                    public void onPick(int i) {
                        if (i == 0) openFile(f, it.mime);
                        else if (i == 1) Route.shareFile(act, f, it.mime);
                        else openDownloads(act);
                    }
                });
    }

    public static void openDownloads(Context c) {
        try {
            Intent i = new Intent(DownloadManager.ACTION_VIEW_DOWNLOADS);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            c.startActivity(i);
        } catch (Throwable t) {
            Ui.toast(c, "打不开下载目录");
        }
    }

    private void openFile(File f, String mime) {
        try {
            Uri uri = LocalFiles.uriFor(act, f);
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setDataAndType(uri, TextUtils.isEmpty(mime) ? "application/octet-stream" : mime);
            i.setClipData(android.content.ClipData.newRawUri("", uri));
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
            AppPicker.show(act, i, "用其他应用打开");
        } catch (Throwable t) {
            Ui.toast(act, "没有能打开它的应用");
        }
    }

    /** 把系统下载目录里的文件搬一份到私有缓存，好交给安装器 / 其它 App */
    private File copyToCache(Item it) {
        try {
            ParcelFileDescriptor pfd = dm.openDownloadedFile(it.id);
            if (pfd == null) return null;
            File out = new File(LocalFiles.dir(act), Ui.safeName(it.name, "file"));
            FileInputStream in = new FileInputStream(pfd.getFileDescriptor());
            FileOutputStream fos = new FileOutputStream(out);
            byte[] buf = new byte[64 * 1024];
            int n;
            while ((n = in.read(buf)) > 0) fos.write(buf, 0, n);
            fos.close();
            in.close();
            pfd.close();
            return out.length() > 0 ? out : null;
        } catch (Throwable t) {
            return null;
        }
    }

    // ------------------------------------------------------------ 文件名

    public static String guessName(String url, String disposition, String mime) {
        String name = null;
        if (!TextUtils.isEmpty(disposition)) {
            String lower = disposition.toLowerCase(java.util.Locale.US);
            int i = lower.indexOf("filename*=");
            if (i >= 0) {
                String v = disposition.substring(i + 10);
                int semi = v.indexOf(';');
                if (semi >= 0) v = v.substring(0, semi);
                v = v.trim().replace("\"", "");
                int eq = v.indexOf("''");
                if (eq >= 0) v = v.substring(eq + 2);
                try {
                    name = java.net.URLDecoder.decode(v, "UTF-8");
                } catch (Throwable ignored) {
                    name = v;
                }
            }
            if (TextUtils.isEmpty(name)) {
                i = lower.indexOf("filename=");
                if (i >= 0) {
                    String v = disposition.substring(i + 9);
                    int semi = v.indexOf(';');
                    if (semi >= 0) v = v.substring(0, semi);
                    name = v.trim().replace("\"", "");
                }
            }
        }
        if (TextUtils.isEmpty(name)) {
            name = Uri.decode(url);
            int q = name.indexOf('?');
            if (q >= 0) name = name.substring(0, q);
            int slash = name.lastIndexOf('/');
            name = slash >= 0 ? name.substring(slash + 1) : name;
        }
        if (TextUtils.isEmpty(name)) name = "download_" + System.currentTimeMillis();

        name = Ui.safeName(name, "download_" + System.currentTimeMillis());
        if (!name.contains(".")) {
            String ext = Mimes.ext(url);
            if (ext.length() > 0) {
                name = name + "." + ext;
            } else {
                String m = Mimes.guess(url, mime);
                if (APK_MIME.equals(m)) name = name + ".apk";
                else if ("application/zip".equals(m)) name = name + ".zip";
                else if ("application/pdf".equals(m)) name = name + ".pdf";
            }
        }
        return name;
    }
}
