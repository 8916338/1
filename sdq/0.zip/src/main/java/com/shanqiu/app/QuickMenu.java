package com.shanqiu.app;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.ScrollView;
import android.widget.TextView;

/**
 * 闪电球弹出来的面板。
 *
 * 布局规则（按需求固定）：
 *  1. 面板总高不超过屏幕的一半；
 *  2. 靠近闪电球弹：球在上半边就往下弹（面板顶边贴在球下方），
 *     球在下半边就往上弹（面板底边贴在球上方），两种情况都不遮挡闪电球；
 *  3. 面板贴着球的左/右侧对齐（球在左，面板左对齐；球在右，面板右对齐）；
 *  4. 面板里靠近球的那一侧是一条横向图标按钮（刷新/前进/后退/收藏/主页），
 *     再往外才是列表：输入网址访问 → 书签 → 下载内容 → 历史 → 喝咖啡 → 更多。
 */
public final class QuickMenu {

    public interface Pick {
        void onPick(String id, Object data);
    }

    private static final int PANEL_MAX_W_DP = 300;
    private static final int PAD_DP = 6;
    private static final int ITEM_H_DP = 42;
    private static final int RADIUS_DP = 14;
    private static final int ITEM_RADIUS_DP = 9;
    private static final int ICON_BOX_DP = 20;
    private static final int ICON_DP = 17;
    private static final int GAP_DP = 9;
    /** 面板与球之间留的空隙（不遮挡，也留出手感距离） */
    private static final int NEAR_GAP_DP = 10;

    /** 当前主题（每次 show 时刷新），行内取色都走它 */
    private static Theme.Palette P;

    private static Theme.Palette palette(Context c) {
        if (P == null) P = Shell.of(c);
        return P;
    }

    /** 全局只留一个，免得连点几下叠出好几层 */
    private static PopupWindow open;

    /** 当前面板是往下弹（true）还是往上弹（false） */
    private static boolean droppedDown;

    private QuickMenu() {
    }

    public static boolean isDropDown() {
        return droppedDown;
    }

    // ------------------------------------------------------------ 构建条目

    public static final class Row {
        public int icon;
        public String label;
        public String sub;
        public String id;
        public Object data;
        public boolean dim;
        /** 长按这一行时的动作（书签行用来弹「新窗 / 后台 / 删除」） */
        public Runnable onLong;
        /** 横划删除这一行：设了才接管横向手势，删完行会消失 */
        public Runnable onDelete;
        /** true = 横划直接删，不弹确认（历史 / 书签这类删了不心疼的） */
        public boolean silentDelete;

        public Row(int icon, String label, String sub, String id, Object data) {
            this.icon = icon;
            this.label = label;
            this.sub = sub;
            this.id = id;
            this.data = data;
        }

        public Row longPress(Runnable r) {
            this.onLong = r;
            return this;
        }
    }

    /**
     * 弹出面板。
     *
     * @param rows          列表内容（已按配置排好序）
     * @param showActionBar 是否在靠近球的一侧显示横向图标操作栏
     */
    public static PopupWindow show(final MainActivity a, final Fab anchor,
                                   final java.util.List<Row> rows,
                                   final boolean showActionBar,
                                   final Pick pick) {
        if (a == null || rows == null || rows.isEmpty()) return null;
        if (a.isFinishing() || a.isDestroyed()) return null;

        dismissAll();
        P = Shell.of(a);

        // 闪电球被关掉（fab.enabled=false）时没有球可当锚点，
        // 退化成「居中浮层」：方向按屏幕中线算，不遮挡任何东西。
        View anchorView = anchor;
        if (anchorView == null) {
            anchorView = a.getWindow().getDecorView();
        }
        ViewGroup parent = (ViewGroup) anchorView.getParent();
        if (parent == null) return null;

        int screenW = a.getResources().getDisplayMetrics().widthPixels;
        int panelW = Math.min(Ui.dp(a, PANEL_MAX_W_DP), (int) (screenW * 0.86f));
        int pad = Ui.dp(a, PAD_DP);

        Theme.Palette pal = palette(a);

        LinearLayout list = new LinearLayout(a);
        list.setOrientation(LinearLayout.VERTICAL);
        for (int i = 0; i < rows.size(); i++) {
            list.addView(rowView(a, rows.get(i), pick), rowParams(a, i));
        }

        // 面板壳：白底 + 1px 边框 + 14 圆角 + 6 内边距
        FrameLayout shell = new FrameLayout(a);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(pal.panel);
        bg.setCornerRadius(Ui.dp(a, RADIUS_DP));
        bg.setStroke(Math.max(1, Ui.dp(a, 1)), pal.border);
        shell.setBackground(bg);
        shell.setPadding(pad, pad, pad, pad);

        final ScrollView sv = new ScrollView(a);
        sv.setVerticalScrollBarEnabled(false);
        sv.setFillViewport(false);
        sv.addView(list, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        LinearLayout stack = new LinearLayout(a);
        stack.setOrientation(LinearLayout.VERTICAL);

        // ---- 方向：球在上半边 → 往下弹；球在下半边 → 往上弹 ----
        int[] loc = new int[2];
        anchorView.getLocationOnScreen(loc);
        int screenH = a.getResources().getDisplayMetrics().heightPixels;
        int anchorCY = loc[1] + anchorView.getHeight() / 2;
        boolean drop = anchorCY < screenH / 2;   // 靠上就往下弹
        droppedDown = drop;

        // 靠近球的那一侧放操作栏
        final ActionBar bar = showActionBar ? new ActionBar(a, a, new ActionBar.OnAction() {
            @Override
            public void onAction(String id) {
                // 后退 / 前进可以连着点，点完面板留着；
                // 首页 / 刷新一步到位，点完收面板（见 staysOpen），
                // 要跳走或弹新窗的（更多、历史、下载…）也先收面板，免得两层叠着
                if (!staysOpen(id)) dismissQuietly();
                if (pick != null) pick.onPick(id, null);
            }
        }) : null;
        if (bar != null) {
            LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            if (drop) {          // 往下弹：操作栏在最上面
                blp.bottomMargin = Ui.dp(a, 4);
                stack.addView(bar, blp);
                stack.addView(sv, new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
            } else {             // 往上弹：操作栏在最下面
                blp.topMargin = Ui.dp(a, 4);
                stack.addView(sv, new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
                stack.addView(bar, blp);
            }
        } else {
            stack.addView(sv, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        }

        shell.addView(stack, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        // ---- 高度：不超过半屏，也不超过球到屏幕另一侧的距离 ----
        int screenBottom = screenH - Ui.dp(a, 8);
        int safeTop = statusBarHeight(a) + Ui.dp(a, 8);
        int gap = Ui.dp(a, NEAR_GAP_DP);
        int maxByScreen = (int) (screenH * 0.5f);
        int maxBySide = drop
                ? screenBottom - (loc[1] + anchorView.getHeight() + gap)
                : (loc[1] - gap) - safeTop;
        int maxH = Math.max(Ui.dp(a, 160), Math.min(maxByScreen, maxBySide));

        int innerW = panelW - pad * 2;
        // 操作栏可能是 1 排也可能是 2 排，高度按配置实际算
        int barH = bar == null ? 0 : Ui.dp(a, ActionBar.heightDp(a)) + Ui.dp(a, 4);
        int listMax = Math.max(Ui.dp(a, ITEM_H_DP), maxH - pad * 2 - barH);

        list.measure(View.MeasureSpec.makeMeasureSpec(innerW, View.MeasureSpec.EXACTLY),
                View.MeasureSpec.makeMeasureSpec(listMax, View.MeasureSpec.AT_MOST));
        int listH = Math.min(list.getMeasuredHeight(), listMax);
        int totalH = Math.min(maxH, listH + barH + pad * 2);

        final PopupWindow pw = new PopupWindow(shell, panelW, totalH, true);
        pw.setBackgroundDrawable(new ColorDrawable(0x01000000));
        pw.setOutsideTouchable(true);
        pw.setTouchable(true);
        pw.setClippingEnabled(true);
        pw.setOnDismissListener(new PopupWindow.OnDismissListener() {
            @Override
            public void onDismiss() {
                if (anchor != null) anchor.setOpen(false);
                open = null;
            }
        });

        // ---- 横向：球在左 → 面板左侧对齐球；球在右 → 右侧对齐球 ----
        int safeLeft = Ui.dp(a, 8);
        boolean leftHalf = anchor != null ? anchor.onLeftHalf()
                : (loc[0] + anchorView.getWidth() / 2) < screenW / 2;
        int x = leftHalf ? loc[0] : loc[0] + anchorView.getWidth() - panelW;
        x = Math.max(safeLeft, Math.min(x, screenW - panelW - safeLeft));

        // ---- 纵向：贴球的外侧，绝不压住球 ----
        int y;
        if (drop) {
            y = loc[1] + anchorView.getHeight() + gap;
            if (y + totalH > screenBottom) y = Math.max(safeTop, screenBottom - totalH);
        } else {
            y = loc[1] - gap - totalH;
            if (y < safeTop) y = safeTop;
        }

        // 先设属性再 show，避免出现一帧不透明的闪烁
        shell.setAlpha(0f);
        shell.setTranslationY(Ui.dp(a, drop ? 8 : -8));
        shell.setPivotX(panelW / 2f);
        shell.setPivotY(totalH / 2f);
        shell.setScaleX(0.96f);
        shell.setScaleY(0.96f);

        try {
            pw.showAtLocation(anchorView, Gravity.NO_GRAVITY, x, y);
        } catch (Throwable t) {
            return null;
        }

        shell.animate().alpha(1f).translationY(0f).scaleX(1f).scaleY(1f)
                .setDuration(200)
                .setInterpolator(new DecelerateInterpolator(1.6f))
                .start();

        if (anchor != null) anchor.setOpen(true);
        open = pw;
        return pw;
    }

    private static LinearLayout.LayoutParams rowParams(Context a, int i) {
        LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(a, ITEM_H_DP));
        if (i > 0) rlp.topMargin = Ui.dp(a, 1);
        return rlp;
    }

    private static View rowView(final Context a, final Row r, final Pick pick) {
        final LinearLayout row = new LinearLayout(a);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(Ui.dp(a, 10), 0, Ui.dp(a, 10), 0);
        row.setBackground(rowBackground(a));
        row.setClickable(true);
        row.setFocusable(true);

        FrameLayout box = new FrameLayout(a);
        ImageView ico = new ImageView(a);
        if (r.icon != 0) ico.setImageResource(r.icon);
        ico.setImageTintList(r.dim ? ColorStateList.valueOf(palette(a).dim) : tint(palette(a).icon));
        ico.setImageTintMode(android.graphics.PorterDuff.Mode.SRC_IN);
        ico.setDuplicateParentStateEnabled(true);
        box.addView(ico, new FrameLayout.LayoutParams(
                Ui.dp(a, ICON_DP), Ui.dp(a, ICON_DP), Gravity.CENTER));

        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(
                Ui.dp(a, ICON_BOX_DP), Ui.dp(a, ICON_BOX_DP));
        blp.rightMargin = Ui.dp(a, GAP_DP);
        row.addView(box, blp);

        LinearLayout texts = new LinearLayout(a);
        texts.setOrientation(LinearLayout.VERTICAL);
        texts.setGravity(Gravity.CENTER_VERTICAL);

        TextView label = new TextView(a);
        label.setText(r.label);
        label.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f);
        label.setTextColor(r.dim ? ColorStateList.valueOf(palette(a).dim) : textColors(a));
        label.setDuplicateParentStateEnabled(true);
        label.setSingleLine(true);
        label.setEllipsize(TextUtils.TruncateAt.END);
        label.setIncludeFontPadding(false);
        texts.addView(label, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        if (!TextUtils.isEmpty(r.sub)) {
            TextView sub = new TextView(a);
            sub.setText(r.sub);
            sub.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f);
            sub.setTextColor(palette(a).sub);
            sub.setSingleLine(true);
            sub.setEllipsize(TextUtils.TruncateAt.MIDDLE);
            sub.setIncludeFontPadding(false);
            sub.setDuplicateParentStateEnabled(true);
            texts.addView(sub, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        }
        row.addView(texts, new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        // 分组标题（如「书签」）只是说明，点了不关面板
        final boolean header = r.id != null && r.id.endsWith("__header__");
        row.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (header) return;
                if (!staysOpen(r.id)) dismissQuietly();
                if (pick != null) pick.onPick(r.id, r.data);
            }
        });
        if (r.onDelete != null) {
            SwipeRow.attach(row, new SwipeRow.OnDelete() {
                @Override
                public boolean beforeDelete(View v) {
                    if (r.silentDelete) return true;
                    // 横划不等于确认：先把面板收起，再问一句「删不删」
                    dismissQuietly();
                    Ui.confirm(v.getContext(), "删除这一项？", r.label, "删除",
                            new Runnable() {
                                @Override
                                public void run() {
                                    if (r.onDelete != null) r.onDelete.run();
                                }
                            }, null);
                    return false;
                }

                @Override
                public void onDelete(View v) {
                    if (r.onDelete != null) r.onDelete.run();
                }
            });
        }
        if (r.onLong != null) {
            row.setLongClickable(true);
            row.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {
                    v.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS);
                    r.onLong.run();
                    return true;
                }
            });
        }
        return row;
    }

    /**
     * 点完还要留在面板里的条目。
     *
     * 只有后退 / 前进还留在面板里：用户经常连着点好几下（一路退回去），
     * 每点一下面板就收起、想再退一次还得重新从闪电球里进一遍，太折腾。
     * 首页 / 刷新是「一步到位」的动作，点完这次浏览基本就换了目标，
     * 一直开着面板反而挡页面 —— 所以点完就把面板收掉。
     */
    private static boolean staysOpen(String id) {
        if (id == null) return false;
        switch (id) {
            case "back":
            case "forward":
                return true;
            default:
                return false;
        }
    }

    // ------------------------------------------------------------ 生命周期

    public static boolean isOpen() {
        return open != null && open.isShowing();
    }

    public static void dismissAll() {
        PopupWindow pw = open;
        open = null;
        if (pw != null) {
            try {
                pw.dismiss();
            } catch (Throwable ignored) {
            }
        }
    }

    private static void dismissQuietly() {
        dismissAll();
    }

    private static int statusBarHeight(Context c) {
        try {
            int id = c.getResources().getIdentifier("status_bar_height", "dimen", "android");
            if (id > 0) return c.getResources().getDimensionPixelSize(id);
        } catch (Throwable ignored) {
        }
        return 0;
    }

    /** 按下变橙，松开回灰 */
    private static ColorStateList textColors(Context c) {
        Theme.Palette p = palette(c);
        return new ColorStateList(
                new int[][]{new int[]{android.R.attr.state_pressed}, new int[]{}},
                new int[]{p.accent, p.text});
    }

    private static ColorStateList tint(int normal) {
        Theme.Palette p = P == null ? Shell.of(0) : P;
        return new ColorStateList(
                new int[][]{new int[]{android.R.attr.state_pressed}, new int[]{}},
                new int[]{p.accent, normal});
    }

    /** :active{background:#fff8f5; border-radius:9px} */
    private static StateListDrawable rowBackground(Context c) {
        GradientDrawable pressed = new GradientDrawable();
        pressed.setColor(palette(c).press);
        pressed.setCornerRadius(Ui.dp(c, ITEM_RADIUS_DP));

        GradientDrawable normal = new GradientDrawable();
        normal.setColor(Color.TRANSPARENT);
        normal.setCornerRadius(Ui.dp(c, ITEM_RADIUS_DP));

        StateListDrawable sl = new StateListDrawable();
        sl.addState(new int[]{android.R.attr.state_pressed}, pressed);
        sl.addState(new int[]{}, normal);
        return sl;
    }
}
