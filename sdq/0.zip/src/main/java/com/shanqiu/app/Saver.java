package com.shanqiu.app;

import android.content.ContentValues;
import android.content.Context;
import android.graphics.Bitmap;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.text.TextUtils;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;

/** 图片落盘：存相册 / 存临时目录（给分享用） */
public final class Saver {

    public static final String ALBUM = "网页图片";

    private Saver() {
    }

    /** 存到相册，返回人类可读路径 */
    public static String toAlbum(Context c, Bitmap bmp, String baseName) throws Exception {
        if (bmp == null) throw new Exception("图片读取失败");
        String name = jpgName(baseName);

        if (Build.VERSION.SDK_INT >= 29) {
            ContentValues v = new ContentValues();
            v.put(MediaStore.Images.Media.DISPLAY_NAME, name);
            v.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
            v.put(MediaStore.Images.Media.RELATIVE_PATH,
                    Environment.DIRECTORY_PICTURES + "/" + ALBUM);
            v.put(MediaStore.Images.Media.IS_PENDING, 1);
            Uri uri = c.getContentResolver().insert(
                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v);
            if (uri == null) throw new Exception("相册不可写");
            OutputStream out = c.getContentResolver().openOutputStream(uri);
            if (out == null) throw new Exception("相册不可写");
            bmp.compress(Bitmap.CompressFormat.JPEG, 94, out);
            out.close();
            v.clear();
            v.put(MediaStore.Images.Media.IS_PENDING, 0);
            c.getContentResolver().update(uri, v, null, null);
            return "相册 / Pictures/" + ALBUM + "/" + name;
        }

        File dir = new File(Environment.getExternalStoragePublicDirectory(
                Environment.DIRECTORY_PICTURES), ALBUM);
        if (!dir.exists() && !dir.mkdirs()) throw new Exception("相册目录创建失败");
        File f = new File(dir, name);
        FileOutputStream fos = new FileOutputStream(f);
        bmp.compress(Bitmap.CompressFormat.JPEG, 94, fos);
        fos.close();
        MediaScannerConnection.scanFile(c, new String[]{f.getAbsolutePath()}, null, null);
        return "相册 / Pictures/" + ALBUM + "/" + name;
    }

    /** 存到 cache/dl，给「分享图片」用 */
    public static File toCache(Context c, Bitmap bmp, String baseName) throws Exception {
        if (bmp == null) throw new Exception("图片读取失败");
        String name = jpgName(baseName);
        File f = new File(LocalFiles.dir(c), name);
        FileOutputStream fos = new FileOutputStream(f);
        bmp.compress(Bitmap.CompressFormat.JPEG, 94, fos);
        fos.close();
        return f;
    }

    /** 存的一律是 JPEG，扩展名也要跟着改，否则相册/别的 App 会认错 */
    private static String jpgName(String baseName) {
        String n = Ui.safeName(baseName, "img_" + System.currentTimeMillis());
        int dot = n.lastIndexOf('.');
        if (dot > 0) n = n.substring(0, dot);
        return n + ".jpg";
    }

    /** 从图片地址猜个好听的文件名 */
    public static String nameFromUrl(String url) {
        if (TextUtils.isEmpty(url)) return "image.jpg";
        if (url.startsWith("data:")) return "qrcode.png";
        String s = url;
        int q = s.indexOf('?');
        if (q >= 0) s = s.substring(0, q);
        int slash = s.lastIndexOf('/');
        String last = slash >= 0 ? s.substring(slash + 1) : s;
        if (last.length() == 0 || !last.contains(".")) {
            String ext = Mimes.ext(url);
            last = "image_" + System.currentTimeMillis() + (ext.isEmpty() ? ".jpg" : "." + ext);
        }
        return last;
    }
}
