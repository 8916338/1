package com.shanqiu.app;

/**
 * 由 tools/apply_config.py 根据 app-config.json 生成，不要手改（下次构建会覆盖）。
 */
public final class Config {

    public static final String APP_NAME = "闪电球";
    public static final String VERSION_NAME = "1.0.6";
    public static final int VERSION_CODE = 24;
    public static final String ONLINE = "";
    public static final String FAB_TEXT = "";

    // ---------------------------------------------------------------- 赞助码
    // 写死在壳里，不依赖 assets/data.json —— 网页数据被替换、被改版都不影响。
    /** 赞赏码图片地址（http/https 或 assets 里的相对路径），空 = 菜单里不出现这一项 */
    public static final String COFFEE_QR = "https://0.wudaozhe.net/vip/zsm.jpg";
    /** QQ 号，空 = 不显示那一行 */
    public static final String COFFEE_QQ = "1480570637";
    /** 二维码下面的说明文案，空 = 用默认文案 */
    public static final String COFFEE_TIP = "微信扫码•长按二维码可保存到相册";

    /** 允不允许用户自己加书签（false = 书签完全由打包决定） */
    public static final boolean ALLOW_USER_BOOKMARKS = true;

    /** 悬浮球总开关（fab.enabled） */
    public static final boolean FAB_ENABLED = true;

    /** 悬浮球菜单项（fab.sections，按数组顺序排列，enabled 控制是否显示） */
    public static final String FAB_ITEMS_JSON = "[{\"id\":\"openurl\",\"title\":\"输入网址访问\",\"enabled\":true},{\"id\":\"bookmark\",\"title\":\"收藏本页\",\"enabled\":true},{\"id\":\"bookmarks\",\"title\":\"书签\",\"enabled\":true},{\"id\":\"pages\",\"title\":\"更多页面\",\"enabled\":true},{\"id\":\"downloads\",\"title\":\"下载\",\"enabled\":true},{\"id\":\"history\",\"title\":\"历史\",\"enabled\":true},{\"id\":\"find\",\"title\":\"页面查找\",\"enabled\":true},{\"id\":\"coffee\",\"title\":\"赞助\",\"enabled\":true},{\"id\":\"more\",\"title\":\"更多\",\"enabled\":true}]";

    /** 弹窗靠球那一侧的横向图标条（fab.toolbar）：顺序 + 开关 + 标题 */
    public static final String FAB_TOOLBAR_JSON = "[{\"id\":\"refresh\",\"title\":\"刷新\",\"enabled\":true,\"row\":2},{\"id\":\"forward\",\"title\":\"前进\",\"enabled\":true,\"row\":2},{\"id\":\"history\",\"title\":\"历史\",\"enabled\":true,\"row\":2},{\"id\":\"downloads\",\"title\":\"下载\",\"enabled\":true,\"row\":2},{\"id\":\"background\",\"title\":\"后台\",\"enabled\":true,\"row\":2},{\"id\":\"bookmark\",\"title\":\"收藏\",\"enabled\":true,\"row\":2},{\"id\":\"home\",\"title\":\"首页\",\"enabled\":true,\"row\":1},{\"id\":\"back\",\"title\":\"后退\",\"enabled\":true,\"row\":1},{\"id\":\"find\",\"title\":\"查找\",\"enabled\":true,\"row\":1},{\"id\":\"scan\",\"title\":\"扫描\",\"enabled\":true,\"row\":1},{\"id\":\"share\",\"title\":\"分享\",\"enabled\":true,\"row\":1},{\"id\":\"more\",\"title\":\"更多\",\"enabled\":true,\"row\":1}]";

    /**
     * 构建期功能开关（features.*）。
     * 为 false 时 tools/apply_config.py 会生成不带该分支的 FabRegistry，
     * build.sh 同时把对应源码排除在编译之外 —— 功能真的不进包，不是运行时隐藏。
     */
    public static final boolean FEATURE_DOWNLOADS = true;

    /** 浏览历史模块是否打包进来（features.history） */
    public static final boolean FEATURE_HISTORY = true;

    /** 检测更新模块是否打包进来（features.update） */
    public static final boolean FEATURE_UPDATE = true;

    /** 后台 / 多窗口模块是否打包进来（features.background） */
    public static final boolean FEATURE_BACKGROUND = true;

    // ---------------------------------------------------------------- 内置插件
    /** 随包内置插件：file = assets 里的 .js 路径，enabled = 默认开关 */
    public static final String BUILTIN_PLUGINS_JSON = "[{\"file\":\"plugins/github-zh.user.js\",\"enabled\":true}]";
    public static final boolean BUILTIN_PLUGINS_ENABLED = true;

    /** 悬浮球弹窗板块（fab.sections）：顺序 + 开关；数组顺序即由近到远 */
    public static final String FAB_SECTIONS_JSON = "[{\"id\":\"openurl\",\"title\":\"转到网址\",\"enabled\":true},{\"id\":\"bookmarks\",\"title\":\"书签\",\"enabled\":true},{\"id\":\"bookmark\",\"title\":\"收藏本页\",\"enabled\":false},{\"id\":\"pages\",\"title\":\"更多页面\",\"enabled\":false},{\"id\":\"downloads\",\"title\":\"下载内容\",\"enabled\":false},{\"id\":\"history\",\"title\":\"历史\",\"enabled\":false},{\"id\":\"find\",\"title\":\"页面查找\",\"enabled\":false},{\"id\":\"coffee\",\"title\":\"赞助\",\"enabled\":false},{\"id\":\"more\",\"title\":\"更多\",\"enabled\":false}]";

    /** 「更多」面板项目（fab.more）：update + 7 个浏览设置，全部可配 */
    public static final String FAB_MORE_JSON = "[{\"id\":\"update\",\"title\":\"检查更新\",\"enabled\":true},{\"id\":\"privacy\",\"title\":\"隐私模式\",\"enabled\":true},{\"id\":\"guard\",\"title\":\"网页拦截\",\"enabled\":true},{\"id\":\"plugin\",\"title\":\"插件\",\"enabled\":true},{\"id\":\"desktop\",\"title\":\"网页版本\",\"enabled\":true},{\"id\":\"ua\",\"title\":\"浏览器标识\",\"enabled\":true},{\"id\":\"orient\",\"title\":\"屏幕方向\",\"enabled\":true},{\"id\":\"font\",\"title\":\"字体大小\",\"enabled\":true},{\"id\":\"theme\",\"title\":\"主题\",\"enabled\":true},{\"id\":\"start\",\"title\":\"初始页\",\"enabled\":true},{\"id\":\"coffee\",\"title\":\"赞助\",\"enabled\":true}]";

    // ---------------------------------------------------------------- 多内置网页
    /** 页面列表：title + file（内置）/ url（在线）+ home（首页按钮用）+ start（初始页） */
    public static final String PAGES_JSON = "[{\"title\":\"首页\",\"file\":\"index.html\",\"url\":\"\",\"home\":true,\"start\":true},{\"title\":\"接口大全本地版\",\"file\":\"api.html\",\"url\":\"\",\"home\":false,\"start\":false}]";
    /** 初始页候选：name + url / file，供「更多 → 初始页」直接列出 */
    public static final String START_PAGES_JSON = "[{\"name\":\"首页\",\"url\":\"\",\"file\":\"index.html\"},{\"name\":\"接口大全本地版\",\"url\":\"\",\"file\":\"api.html\"},{\"name\":\"接口大全在线版\",\"url\":\"https://0.wudaozhe.net\",\"file\":\"\"}]";
    /** 首页（首页按钮的目标）是内置文件时，这个文件名（默认 index.html） */
    public static final String HOME_FILE = "index.html";
    /** 首页是在线地址时，那个地址（为空表示首页不是在线页） */
    public static final String HOME_URL = "";
    /** 初始页（打开 App 时加载）是内置文件时，这个文件名（空 = 跟首页一致） */
    public static final String START_FILE = "index.html";
    /** 初始页是在线地址时，那个地址（空 = 跟首页一致） */
    public static final String START_URL = "";

    /** pages 数组；配置损坏时返回空数组，调用处不用判空 */
    public static org.json.JSONArray pages() {
        try {
            return new org.json.JSONArray(PAGES_JSON);
        } catch (Throwable t) {
            return new org.json.JSONArray();
        }
    }

    /** 第 i 个页面的打开地址：file 转成内置虚拟域名，url 原样返回 */
    public static String pageUrl(int i) {
        org.json.JSONObject o = pages().optJSONObject(i);
        if (o == null) return "";
        String u = o.optString("url", "");
        if (u != null && u.trim().length() > 0) return u.trim();
        String f = o.optString("file", "");
        if (f == null || f.trim().length() == 0) return "";
        return Site.ORIGIN + "/" + f.trim();
    }

    /** 初始页候选；配置损坏时返回空数组 */
    public static org.json.JSONArray startPages() {
        try {
            return new org.json.JSONArray(START_PAGES_JSON);
        } catch (Throwable t) {
            return new org.json.JSONArray();
        }
    }

    // ---------------------------------------------------------------- 检测更新
    /** 更新校验链接（JSON 地址），为空则不做自动检测 */
    public static final String UPDATE_URL = "https://0.wudaozhe.net/sdq/update.json";
    /** 是否在启动时自动检测更新 */
    public static final boolean UPDATE_ENABLED = true;
    /** 启动后延迟多少秒检测 */
    public static final int UPDATE_DELAY_SECONDS = 6;
    /** 忽略本版后，同一版本多少天内不再提示 */
    public static final int UPDATE_IGNORE_DAYS = 7;
    /** 下载新版安装包的提示文案 */
    public static final String UPDATE_HINT = "";

    private Config() {
    }
}
