package com.shanqiu.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Locale;

/**
 * 检测更新。
 *
 * 更新信息来自 app-config.json → update.url（一个返回 JSON 的地址，模板见
 * tools/update-template.json），打包时改这一项即可，不用动代码。
 *
 * JSON 字段（除 versionCode 外都可选）：
 * {
 *   "versionCode": 3,                       // 必填，整数，比当前新才提示
 *   "versionName": "1.0.3",
 *   "minVersionCode": 2,                    // 低于它的用户强制更新（不给「忽略」）
 *   "url": "https://.../app-1.0.3.apk",     // 新版下载地址（.apk 直接装，其它交给浏览器）
 *   "apkSha256": "...",                     // 可选，下载后校验
 *   "size": 8388608,                        // 可选，字节
 *   "notes": "1. 修复滑动\n2. 新增历史",
 *   "force": false                          // 可选，等价于 minVersionCode 生效
 * }
 *
 * 弹窗三个选择：立即更新 / 忽略本版（该版本不再提示，直到下个版本）/ 不再提示（永久关掉）
 * 所有状态都存本机，不发任何上报。
 *
 * 下载走 {@link UpdateDownload}（App 更新专用通道）：
 *   - 落私有缓存，不进系统「下载」目录，也不出现在「下载内容」面板里；
 *   - 下完先问「是否马上更新」，选「稍后」就把安装包留着；
 *   - 下次点「检查更新」或弹窗里的「立即安装」，直接用这个文件装，不再重下。
 */
public final class Updater {

    private static final String PREF = "shell_update";
    private static final String K_IGNORE_CODE = "ignoreCode";
    private static final String K_IGNORE_AT = "ignoreAt";
    private static final String K_MUTE = "mute";
    private static final String K_LAST_CHECK = "lastCheck";

    /** 已下好、还没装的新版安装包（下载选「稍后」时留着，下次直接装它） */
    private static final String K_APK_PATH = "apkPath";
    private static final String K_APK_CODE = "apkCode";
    private static final String K_APK_NAME = "apkName";

    private Updater() {
    }

    // ------------------------------------------------------------ 入口

    /** 启动时自动检测（延迟到界面稳定后） */
    public static void autoCheck(final Activity a) {
        if (a == null) return;
        // 启动时顺手清一遍：装完更新后缓存里那份安装包已经没用了，
        // 版本号追上了就会被 pendingApk() 删掉，不用一直占着几十兆
        try {
            pendingApk(a);
        } catch (Throwable ignored) {
        }
        if (!Config.UPDATE_ENABLED) return;
        if (TextUtils.isEmpty(Config.UPDATE_URL)) return;
        SharedPreferences sp = a.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        if (sp.getBoolean(K_MUTE, false)) return;

        a.getWindow().getDecorView().postDelayed(new Runnable() {
            @Override
            public void run() {
                check(a, false);
            }
        }, Math.max(1, Config.UPDATE_DELAY_SECONDS) * 1000L);
    }

    /** 「更多 → 检查更新」：用户主动点，忽略记录也照样查，但会告知当前版本 */
    public static void checkManually(final Activity a) {
        if (a == null) return;
        // 上次下载完选了「稍后」：这次点「检查更新」直接把已经下好的包装上，
        // 不再重新下一遍（用户要的就是「我点了更新就能更新」）
        File pending = pendingApk(a);
        if (pending != null) {
            Ui.toast(a, "正在安装已下载的新版本…");
            install(a, pending);
            return;
        }
        if (TextUtils.isEmpty(Config.UPDATE_URL)) {
            AlertDialog noUrl = new AlertDialog.Builder(a)
                    .setTitle("检查更新")
                    .setMessage("这个版本没有配置更新校验链接（app-config.json → update.url），"
                            + "所以无法自动检测。\n\n当前版本：v" + Config.VERSION_NAME)
                    .setNegativeButton("知道了", null)
                    .create();
            Ui.show(noUrl);
            return;
        }
        Ui.toast(a, "正在检查更新…");
        check(a, true);
    }

    // ------------------------------------------------------------ 已下载待安装

    /**
     * 已经下好、还没装的新版安装包。
     *
     * 下载完用户选了「稍后」时留着它：下次点「检查更新」或者更新弹窗里的
     * 「立即安装」，都直接拿这个文件进安装流程，不再重新下载一遍。
     *
     * 文件不存在 / 是空的 / 当前版本已经追上了（说明装过了）→ 顺手清掉，返回 null。
     */
    public static File pendingApk(Context c) {
        if (c == null) return null;
        SharedPreferences sp = c.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        String path = sp.getString(K_APK_PATH, "");
        if (TextUtils.isEmpty(path)) return null;
        File f = new File(path);
        int code = sp.getInt(K_APK_CODE, 0);
        boolean dead = !f.exists() || f.length() <= 0
                || (code > 0 && code <= selfCode(c));
        if (dead) {
            clearPending(c, true);
            return null;
        }
        return f;
    }

    /** 记下「这个版本已经下好了」 */
    static void savePending(Context c, File f, int code, String name) {
        if (c == null || f == null) return;
        c.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit()
                .putString(K_APK_PATH, f.getAbsolutePath())
                .putInt(K_APK_CODE, code)
                .putString(K_APK_NAME, name == null ? "" : name)
                .apply();
    }

    /** 忘掉待安装包；deleteFile=true 时连文件一起删 */
    static void clearPending(Context c, boolean deleteFile) {
        if (c == null) return;
        SharedPreferences sp = c.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        String path = sp.getString(K_APK_PATH, "");
        sp.edit().remove(K_APK_PATH).remove(K_APK_CODE).remove(K_APK_NAME).apply();
        if (deleteFile && !TextUtils.isEmpty(path)) {
            try {
                File f = new File(path);
                if (f.exists()) {
                    //noinspection ResultOfMethodCallIgnored
                    f.delete();
                }
            } catch (Throwable ignored) {
            }
        }
    }

    /** 交给系统安装器：优先用壳自己的预检（签名 / 安装权限） */
    static void install(Activity a, File f) {
        if (f == null || !f.exists()) {
            Ui.toast(a, "安装包不存在");
            return;
        }
        if (a instanceof MainActivity) {
            ((MainActivity) a).installApk(f);
            return;
        }
        try {
            Uri uri = LocalFiles.uriFor(a, f);
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setDataAndType(uri, Downloader.APK_MIME);
            i.setClipData(android.content.ClipData.newRawUri("", uri));
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
            a.startActivity(i);
        } catch (Throwable t) {
            Ui.toast(a, "打不开安装器");
        }
    }

    // ------------------------------------------------------------ 网络

    private static void check(final Activity a, final boolean manual) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                String err = null;
                JSONObject info = null;
                try {
                    info = fetch(new URL(Config.UPDATE_URL));
                } catch (Throwable t) {
                    err = t.getMessage() == null ? "网络异常" : t.getMessage();
                }
                final JSONObject fin = info;
                final String ferr = err;
                a.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (a.isFinishing()) return;
                        if (fin == null) {
                            if (manual) {
                                Ui.show(new AlertDialog.Builder(a)
                                        .setTitle("检查更新失败")
                                        .setMessage("没能读到更新信息：\n" + ferr
                                                + "\n\n可以稍后再试。")
                                        .setNegativeButton("知道了", null)
                                        .create());
                            }
                            return;
                        }
                        a.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit()
                                .putLong(K_LAST_CHECK, System.currentTimeMillis()).apply();
                        handle(a, fin, manual);
                    }
                });
            }
        }, "update-check").start();
    }

    private static JSONObject fetch(URL url) throws Exception {
        HttpURLConnection c = (HttpURLConnection) url.openConnection();
        c.setConnectTimeout(8000);
        c.setReadTimeout(8000);
        c.setRequestProperty("Cache-Control", "no-cache");
        c.setRequestProperty("Accept", "application/json");
        c.setInstanceFollowRedirects(true);
        int code = c.getResponseCode();
        if (code < 200 || code >= 300) {
            throw new Exception("服务器返回 " + code);
        }
        InputStream in = c.getInputStream();
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[16 * 1024];
        int n;
        while ((n = in.read(buf)) > 0) {
            out.write(buf, 0, n);
            if (out.size() > 512 * 1024) break;
        }
        in.close();
        c.disconnect();
        return new JSONObject(new String(out.toByteArray(), "UTF-8"));
    }

    // ------------------------------------------------------------ 判定

    private static int selfCode(Context c) {
        try {
            return c.getPackageManager().getPackageInfo(c.getPackageName(), 0).versionCode;
        } catch (Throwable t) {
            return 0;
        }
    }

    /** 依次尝试多个字段名，返回第一个非空值。 */
    private static String pick(JSONObject o, String... keys) {
        for (String k : keys) {
            String v = o.optString(k, "");
            if (v != null && v.trim().length() > 0) return v.trim();
        }
        return "";
    }

    private static void handle(final Activity a, JSONObject info, boolean manual) {
        int latest = info.optInt("versionCode", 0);
        int self = selfCode(a);
        final int ignoreCode = a.getSharedPreferences(PREF, Context.MODE_PRIVATE)
                .getInt(K_IGNORE_CODE, 0);
        long ignoreAt = a.getSharedPreferences(PREF, Context.MODE_PRIVATE)
                .getLong(K_IGNORE_AT, 0);
        long days = Math.max(0, Config.UPDATE_IGNORE_DAYS) * 24L * 3600L * 1000L;

        if (latest <= 0) {
            if (manual) {
                Ui.show(new AlertDialog.Builder(a).setTitle("检查更新")
                        .setMessage("更新信息格式不对（缺少 versionCode）。")
                        .setNegativeButton("知道了", null).create());
            }
            return;
        }

        if (latest <= self) {
            if (manual) {
                Ui.show(new AlertDialog.Builder(a).setTitle("已是最新版本")
                        .setMessage("当前 v" + Config.VERSION_NAME
                                + "（" + self + "）已是最新。")
                        .setNegativeButton("好", null).create());
            }
            return;
        }

        boolean forced = info.optBoolean("force", false)
                || latest >= info.optInt("minVersionCode", 0)
                && info.has("minVersionCode")
                && self < info.optInt("minVersionCode", 0);

        // 「忽略本版」在有效期内不再自动提示；手动检查仍然提示
        if (!manual && !forced && latest == ignoreCode
                && System.currentTimeMillis() - ignoreAt < days) {
            return;
        }

        showDialog(a, info, latest, forced, manual);
    }

    private static void showDialog(final Activity a, final JSONObject info, final int latest,
                                   final boolean forced, final boolean manual) {
        final String vname = info.optString("versionName", String.valueOf(latest));
        // 兼容两种写法：notes/downloadUrl（旧）与 changelog/downloadUrl（模板）
        final String notes = pick(info, "notes", "changelog", "releaseNotes", "desc");
        final String apk = pick(info, "url", "downloadUrl", "apk", "download");
        // 上次下好了没装：这次直接装它，按钮也换成「立即安装」
        final File pending = pendingApk(a);
        final String hint = pending != null
                ? "安装包已经下载完成，点「立即安装」就能覆盖更新，不影响已有书签和历史。"
                : TextUtils.isEmpty(Config.UPDATE_HINT)
                    ? "下载完成后会直接问你要不要马上更新，不影响已有书签和历史。"
                    : Config.UPDATE_HINT;

        LinearLayout box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(Ui.dp(a, 20), Ui.dp(a, 6), Ui.dp(a, 20), 0);

        TextView ver = new TextView(a);
        ver.setText("新版本 v" + vname + "（" + latest + "）");
        ver.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f);
        ver.setTextColor(0xFF111827);
        ver.getPaint().setFakeBoldText(true);
        box.addView(ver);

        TextView now = new TextView(a);
        now.setText("当前版本 v" + Config.VERSION_NAME);
        now.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f);
        now.setTextColor(0xFF9AA3B2);
        now.setPadding(0, Ui.dp(a, 2), 0, 0);
        box.addView(now);

        TextView body = new TextView(a);
        body.setText(TextUtils.isEmpty(notes) ? "本次更新包含问题修复与体验优化。" : notes);
        body.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13.5f);
        body.setTextColor(0xFF3B4655);
        body.setPadding(0, Ui.dp(a, 12), 0, Ui.dp(a, 6));
        ScrollView sv = new ScrollView(a);
        sv.addView(body);
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f);
        box.addView(sv, slp);

        TextView tip = new TextView(a);
        tip.setText(hint);
        tip.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f);
        tip.setTextColor(0xFF8B96A5);
        GradientDrawable tipBg = new GradientDrawable();
        tipBg.setColor(0xFFF7F8FA);
        tipBg.setCornerRadius(Ui.dp(a, 10));
        tip.setBackground(tipBg);
        tip.setPadding(Ui.dp(a, 10), Ui.dp(a, 8), Ui.dp(a, 10), Ui.dp(a, 8));
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        tlp.topMargin = Ui.dp(a, 6);
        tlp.bottomMargin = Ui.dp(a, 4);
        box.addView(tip, tlp);

        AlertDialog.Builder b = new AlertDialog.Builder(a)
                .setTitle(forced ? "必须更新" : "发现新版本")
                .setView(box)
                // 只认弹窗里的按钮：点外部 / 返回键都不会把它带走了
                .setCancelable(false);

        b.setPositiveButton(pending != null ? "立即安装"
                        : (TextUtils.isEmpty(apk) ? "去下载" : "立即更新"),
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        // 上次已经下好了：直接进安装流程，别再下一遍
                        if (pending != null) {
                            install(a, pending);
                            return;
                        }
                        if (TextUtils.isEmpty(apk)) {
                            Ui.toast(a, "更新信息里没有下载地址，请联系开发者");
                            return;
                        }
                        startUpdate(a, apk, vname, latest);
                    }
                });

        if (!forced) {
            b.setNegativeButton("忽略本版", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface d, int w) {
                    a.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit()
                            .putInt(K_IGNORE_CODE, latest)
                            .putLong(K_IGNORE_AT, System.currentTimeMillis())
                            .apply();
                    Ui.toast(a, "下个版本发布前不再提醒");
                }
            });
            b.setNeutralButton("不再提示更新", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface d, int w) {
                    Ui.show(new AlertDialog.Builder(a)
                            .setTitle("不再提示更新")
                            .setMessage("以后启动都不会自动检测更新。\n"
                                    + "需要时可以在「闪电球 → 更多 → 检查更新」里手动检查。")
                            .setNegativeButton("取消", null)
                            .setPositiveButton("确定关闭", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dd, int ww) {
                                    a.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit()
                                            .putBoolean(K_MUTE, true).apply();
                                    Ui.toast(a, "已关闭自动更新提示");
                                }
                            })
                            .create());
                }
            });
        } else {
            b.setNegativeButton("稍后", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface d, int w) {
                    a.finish();
                }
            });
        }
        Ui.show(b.create());
    }

    /**
     * 走「更新专用」通道下载新版：私有目录、不进下载记录、进度用壳自己的弹窗。
     * 网页里点的 .apk 下载完全不受影响，还是走「下载内容」那套。
     */
    private static void startUpdate(final Activity a, final String url, final String vname,
                                    final int versionCode) {
        String u = url == null ? "" : url.toLowerCase(Locale.US);
        if (!u.endsWith(".apk") && !u.contains(".apk?")) {
            // 网盘 / 发布页之类的地址交给浏览器
            Route.browser(a, url);
            return;
        }
        String name = Ui.safeName("update-" + vname + ".apk", "update.apk");
        UpdateDownload.start(a, url, name, new UpdateDownload.Callback() {
            @Override
            public void onFinish(File apk, String error) {
                if (apk != null) {
                    // 先记下来：就算这会儿界面已经退了，下次进 App 也能直接装
                    savePending(a, apk, versionCode, "v" + vname);
                    if (!a.isFinishing()) askInstall(a, apk, vname);
                    return;
                }
                if (error == null) return;   // 已有下载在跑，前面已经提示过
                if (a.isFinishing()) return;
                if ("已取消下载".equals(error)) {
                    Ui.toast(a, "已取消下载");
                    return;
                }
                Ui.show(new AlertDialog.Builder(a)
                        .setTitle("更新包下载失败")
                        .setMessage(error + "\n\n可以稍后再试，或者到浏览器里手动下载。")
                        .setPositiveButton("用浏览器下载", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface d, int w) {
                                Route.browser(a, url);
                            }
                        })
                        .setNegativeButton("知道了", null)
                        .create());
            }
        });
    }

    /** 更新包下完：问一句「是否马上更新」，两个出口都只认弹窗里的按钮 */
    private static void askInstall(final Activity a, final File apk, final String vname) {
        AlertDialog d = new AlertDialog.Builder(a)
                .setTitle("下载完成")
                .setMessage("新版本 v" + vname + "（" + Ui.humanSize(apk.length())
                        + "）已下载完成，是否马上更新？\n\n"
                        + "选「稍后再说」也不白下：下次点「检查更新」会直接用这个安装包。")
                .setPositiveButton("立即更新", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dlg, int w) {
                        install(a, apk);
                    }
                })
                .setNegativeButton("稍后再说", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dlg, int w) {
                        Ui.toast(a, "安装包已保留，下次点「检查更新」可直接更新");
                    }
                })
                .setCancelable(false)
                .create();
        Ui.show(d);
    }

    /** 供设置页显示：上次检查时间 */
    public static String lastCheckText(Context c) {
        long t = c.getSharedPreferences(PREF, Context.MODE_PRIVATE).getLong(K_LAST_CHECK, 0);
        if (t <= 0) return "从未检查";
        return new java.text.SimpleDateFormat("MM-dd HH:mm", Locale.CHINA)
                .format(new java.util.Date(t));
    }

    /** 「更多」里需要知道自动提示是否被关掉了 */
    public static boolean muted(Context c) {
        return c.getSharedPreferences(PREF, Context.MODE_PRIVATE).getBoolean(K_MUTE, false);
    }

    /** 恢复自动提示（给将来设置面板用） */
    public static void unmute(Context c) {
        c.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit()
                .putBoolean(K_MUTE, false).remove(K_IGNORE_CODE).apply();
    }
}
