package com.shanqiu.app;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.text.TextUtils;
import android.util.Base64;

import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/** 把页面里的图片地址变成 Bitmap：data: / http(s) / file: / content: 都吃 */
public final class Img {

    private static final int MAX_BYTES = 16 * 1024 * 1024;

    private Img() {
    }

    public static Bitmap load(Context c, String src, String referer, int maxPx) throws Exception {
        if (TextUtils.isEmpty(src)) return null;
        byte[] data;
        if (src.startsWith("data:")) {
            data = decodeDataUri(src);
        } else if (src.startsWith("file://")) {
            data = readAll(new FileInputStream(new java.io.File(Uri.parse(src).getPath())));
        } else if (src.startsWith("content://")) {
            InputStream in = c.getContentResolver().openInputStream(Uri.parse(src));
            if (in == null) return null;
            data = readAll(in);
        } else {
            data = http(src, referer);
        }
        if (data == null || data.length == 0) return null;
        return decode(data, maxPx);
    }

    private static Bitmap decode(byte[] data, int maxPx) {
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inJustDecodeBounds = true;
        BitmapFactory.decodeByteArray(data, 0, data.length, o);
        int w = o.outWidth, h = o.outHeight;
        int cap = maxPx > 0 ? maxPx : 3000;   // 长按保存也要有个上限
        int sample = 1;
        while (sample < 16 && (w / sample > cap || h / sample > cap)) sample *= 2;
        BitmapFactory.Options d = new BitmapFactory.Options();
        d.inSampleSize = sample;
        d.inPreferredConfig = Bitmap.Config.ARGB_8888;
        try {
            return BitmapFactory.decodeByteArray(data, 0, data.length, d);
        } catch (OutOfMemoryError e) {
            return null;
        }
    }

    private static byte[] decodeDataUri(String uri) {
        int comma = uri.indexOf(',');
        if (comma < 0) return null;
        String head = uri.substring(5, comma);
        String body = uri.substring(comma + 1);
        if (head.contains("base64")) {
            return Base64.decode(body, Base64.DEFAULT);
        }
        try {
            return Uri.decode(body).getBytes("UTF-8");
        } catch (Throwable t) {
            return null;
        }
    }

    private static byte[] http(String url, String referer) throws Exception {
        HttpURLConnection conn = null;
        try {
            conn = (HttpURLConnection) new URL(url).openConnection();
            conn.setConnectTimeout(12000);
            conn.setReadTimeout(20000);
            conn.setInstanceFollowRedirects(true);
            conn.setRequestProperty("User-Agent",
                    "Mozilla/5.0 (Linux; Android 12) AppleWebKit/537.36 "
                            + "(KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36");
            if (!TextUtils.isEmpty(referer)) conn.setRequestProperty("Referer", referer);
            conn.connect();
            int code = conn.getResponseCode();
            if (code < 200 || code >= 300) return null;
            String type = conn.getContentType();
            if (type != null && type.startsWith("text/")) return null;
            InputStream in = conn.getInputStream();
            byte[] out = readAll(in);
            return out;
        } finally {
            if (conn != null) {
                try { conn.disconnect(); } catch (Throwable ignored) { }
            }
        }
    }

    private static byte[] readAll(InputStream in) throws Exception {
        try {
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            byte[] buf = new byte[32 * 1024];
            int n;
            long total = 0;
            while ((n = in.read(buf)) > 0) {
                total += n;
                if (total > MAX_BYTES) throw new IllegalStateException("图片太大");
                bos.write(buf, 0, n);
            }
            return bos.toByteArray();
        } finally {
            try { in.close(); } catch (Throwable ignored) { }
        }
    }
}
