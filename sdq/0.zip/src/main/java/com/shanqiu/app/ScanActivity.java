package com.shanqiu.app;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.hardware.Camera;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.Surface;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

/**
 * 扫码界面：进来直接是相机取景，中央一个取景框，边看边扫。
 *
 * 底部两个按钮：
 *   相册 —— 从相册挑一张二维码图解码（截图、别人发来的图都能扫）；
 *   手电筒 —— 环境暗时补光（只有机器有闪光灯时才显示）。
 *
 * 解码用 ZXing：预览帧（NV21）转亮度图，后台线程逐帧试，
 * 识别成功震动一下就把结果传回 MainActivity。
 *
 * 相机用老的 android.hardware.Camera 而不是 Camera2：
 * 预览回调一条 API 就能拿到帧，国产 ROM 上预览尺寸 / 对焦行为最稳定。
 * API 已标记 deprecated，但 minSdk 21 的壳里它仍是兼容面最大的选择。
 */
public class ScanActivity extends Activity implements SurfaceHolder.Callback {

    private static final int REQ_PICK = 2001;
    private static final int REQ_PERM = 2002;

    private SurfaceView surface;
    private Camera camera;
    private Camera.Size previewSize;
    private BottomBtn torchBtn;
    /** 预览画面相对自然方向的旋转角度（0/90/180/270），解码时优先按它转 */
    private int displayOrientation;

    private final Object busy = new Object();
    private volatile boolean decoding;
    private long lastDecodeAt;
    private boolean torchOn;
    private boolean needPeriodicFocus;

    // ================================================================ 生命周期

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setBackgroundDrawableResource(android.R.color.black);

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);

        surface = new SurfaceView(this);
        surface.getHolder().addCallback(this);
        surface.getHolder().setKeepScreenOn(true);
        root.addView(surface, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        // 取景框遮罩
        root.addView(new MaskView(this), new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        TextView tip = new TextView(this);
        tip.setText("对准二维码，识别成功会自动打开");
        tip.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f);
        tip.setTextColor(0xCCFFFFFF);
        tip.setGravity(Gravity.CENTER);
        FrameLayout.LayoutParams tlp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        tlp.topMargin = Ui.dp(this, 64);
        root.addView(tip, tlp);

        // 底部按钮：相册 + 手电筒
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER);
        bar.setPadding(0, Ui.dp(this, 10), 0, Ui.dp(this, 10));

        BottomBtn album = new BottomBtn(this, "相册", R.drawable.ic_scan_album);
        album.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pickImage();
            }
        });
        bar.addView(album, barParams());

        torchBtn = new BottomBtn(this, "手电筒", R.drawable.ic_scan_torch);
        torchBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toggleTorch();
            }
        });
        bar.addView(torchBtn, barParams());

        FrameLayout.LayoutParams blp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM);
        blp.bottomMargin = Ui.dp(this, 24);
        root.addView(bar, blp);

        setContentView(root);

        if (checkSelfPermission(android.Manifest.permission.CAMERA)
                == PackageManager.PERMISSION_GRANTED) {
            // surfaceCreated 之后才会真正 open
        } else {
            requestPermissions(new String[]{android.Manifest.permission.CAMERA}, REQ_PERM);
        }
    }

    private LinearLayout.LayoutParams barParams() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                Ui.dp(this, 108), Ui.dp(this, 56));
        lp.leftMargin = Ui.dp(this, 14);
        lp.rightMargin = Ui.dp(this, 14);
        return lp;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions,
                                           int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_PERM) {
            if (grantResults == null || grantResults.length == 0
                    || grantResults[0] != PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "没有相机权限，扫不了码", Toast.LENGTH_SHORT).show();
                finish();
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (surface.getHolder().getSurface() != null
                && surface.getHolder().getSurface().isValid()
                && checkSelfPermission(android.Manifest.permission.CAMERA)
                == PackageManager.PERMISSION_GRANTED) {
            openCamera();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        stopCamera();
    }

    @Override
    public void onBackPressed() {
        setResult(Activity.RESULT_CANCELED);
        super.onBackPressed();
    }

    // ================================================================ SurfaceHolder

    @Override
    public void surfaceCreated(SurfaceHolder holder) {
        if (checkSelfPermission(android.Manifest.permission.CAMERA)
                == PackageManager.PERMISSION_GRANTED) {
            openCamera();
        }
    }

    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
        // openCamera 里按 holder 尺寸选了预览尺寸；这里不再重复开
    }

    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {
        stopCamera();
    }

    // ================================================================ 相机

    private void openCamera() {
        if (camera != null) return;
        try {
            camera = Camera.open(Camera.CameraInfo.CAMERA_FACING_BACK);
            Camera.Parameters p = camera.getParameters();

            // 选预览尺寸：
            //  - 比例要贴近 Surface（否则画面被拉伸/留黑）；
            //  - 分辨率不能太小 —— 旧逻辑按「比例差 + 宽度/4000」打分，结果 4:3 屏上
            //    总挑到 320x240，二维码在帧里只有几十像素，怎么都对不上；
            //  - 也不能太大，解码每帧都在后台跑，1600 以上纯属拖慢。
            SurfaceHolder h = surface.getHolder();
            int sw = h.getSurfaceFrame().width();
            int sh = h.getSurfaceFrame().height();
            if (sw <= 0) {
                sw = getResources().getDisplayMetrics().widthPixels;
                sh = getResources().getDisplayMetrics().heightPixels;
            }
            float target = (float) Math.max(sw, sh) / Math.min(sw, sh);
            List<Camera.Size> sizes = p.getSupportedPreviewSizes();
            Camera.Size best = null;
            if (sizes != null) {
                int bestScore = Integer.MAX_VALUE;
                for (Camera.Size s : sizes) {
                    int side = Math.max(s.width, s.height);
                    if (side > 1600) continue;
                    if (Math.min(s.width, s.height) < 480) continue;
                    float ratio = (float) side / Math.min(s.width, s.height);
                    float ratioDiff = Math.abs(ratio - target);
                    if (ratioDiff > 0.35f) continue;
                    // 比例差为主，'距离 1200 像素' 为辅：既不选最小的，也不选最大的
                    int score = Math.round(ratioDiff * 1000) + Math.abs(side - 1200);
                    if (score < bestScore) {
                        bestScore = score;
                        best = s;
                    }
                }
                if (best == null) {
                    // 没有合适的：退而求其次，挑最长边不超过 1600 里最大的那个
                    for (Camera.Size s : sizes) {
                        int side = Math.max(s.width, s.height);
                        if (side > 1600) continue;
                        if (best == null || side > Math.max(best.width, best.height)) best = s;
                    }
                }
                if (best == null) best = sizes.get(0);
            }
            previewSize = best;
            if (previewSize != null) p.setPreviewSize(previewSize.width, previewSize.height);

            // 对焦：连续对焦最优；不支持就退 AUTO，并定时主动触发，
            // 否则近距离二维码一直是虚的，怎么对都扫不出来。
            List<String> focuss = p.getSupportedFocusModes();
            boolean continuous = false;
            if (focuss != null) {
                if (focuss.contains(Camera.Parameters.FOCUS_MODE_CONTINUOUS_PICTURE)) {
                    p.setFocusMode(Camera.Parameters.FOCUS_MODE_CONTINUOUS_PICTURE);
                    continuous = true;
                } else if (focuss.contains(Camera.Parameters.FOCUS_MODE_CONTINUOUS_VIDEO)) {
                    p.setFocusMode(Camera.Parameters.FOCUS_MODE_CONTINUOUS_VIDEO);
                    continuous = true;
                } else if (focuss.contains(Camera.Parameters.FOCUS_MODE_AUTO)) {
                    p.setFocusMode(Camera.Parameters.FOCUS_MODE_AUTO);
                }
            }
            needPeriodicFocus = !continuous;

            // 竖屏显示要把预览转 90°
            setDisplayOrientation();

            // 手电筒按钮：只有真的带闪光灯才显示
            List<String> flashes = p.getSupportedFlashModes();
            boolean hasTorch = flashes != null
                    && flashes.contains(Camera.Parameters.FLASH_MODE_TORCH);
            torchBtn.setVisibility(hasTorch ? View.VISIBLE : View.GONE);
            torchOn = false;
            torchBtn.setOn(torchOn);
            if (!hasTorch) {
                torchBtn.setAlpha(0.4f);
            }

            camera.setParameters(p);
            camera.setPreviewDisplay(h);
            if (needPeriodicFocus) scheduleFocus();

            // 预览帧 → 解码。
            // 用 setPreviewCallback 而不是 setPreviewCallbackWithBuffer：
            // 后者要自己按 previewSize 分配 callback buffer，个别机型实际帧大小
            // 和 setPreviewSize 不一致，addCallbackBuffer 会对不上，回调直接不触发
            // （表现就是「相机能预览、但永远扫不出东西」）。这里让系统给缓冲，最稳。
            camera.setPreviewCallback(previewCb);
            camera.startPreview();
        } catch (Throwable t) {
            Toast.makeText(this, "相机打开失败：" + t.getMessage(), Toast.LENGTH_SHORT).show();
            finish();
        }
    }

    private void setDisplayOrientation() {
        try {
            Camera.CameraInfo info = new Camera.CameraInfo();
            int n = Camera.getNumberOfCameras();
            for (int i = 0; i < n; i++) {
                Camera.getCameraInfo(i, info);
                if (info.facing == Camera.CameraInfo.CAMERA_FACING_BACK) {
                    int rotation = getWindowManager().getDefaultDisplay().getRotation();
                    int degrees = rotation == Surface.ROTATION_90 ? 90
                            : rotation == Surface.ROTATION_180 ? 180
                            : rotation == Surface.ROTATION_270 ? 270 : 0;
                    // 后置相机标准公式：(info.orientation - degrees + 360) % 360。
                    // 旧代码写成 360 - (orientation + degrees)，竖屏 90° 相机算出 270°，
                    // 预览画面上下颠倒，取景时根本对不准码。
                    int deg = (info.orientation - degrees + 360) % 360;
                    camera.setDisplayOrientation(deg);
                    displayOrientation = deg;
                    return;
                }
            }
        } catch (Throwable ignored) {
        }
    }

    private void stopCamera() {
        synchronized (busy) {
            try {
                if (camera != null) {
                    camera.setPreviewCallback(null);
                    camera.stopPreview();
                    camera.release();
                }
            } catch (Throwable ignored) {
            }
            camera = null;
            torchOn = false;
        }
    }

    private final Camera.PreviewCallback previewCb = new Camera.PreviewCallback() {
        @Override
        public void onPreviewFrame(byte[] data, Camera cam) {
            if (data == null || previewSize == null) return;
            // 个别机型实际帧比 setPreviewSize 小，直接算下去会越界，跳过这一帧
            if (data.length < previewSize.width * previewSize.height) return;
            long now = System.currentTimeMillis();
            boolean skip = decoding || now - lastDecodeAt < 120;
            if (!skip) {
                lastDecodeAt = now;
                decoding = true;
                final byte[] frame = data.clone();   // 系统会复用这块缓冲，先拷一份
                final int w = previewSize.width;
                final int h = previewSize.height;
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        String text = decodeFrame(frame, w, h);
                        decoding = false;
                        if (text != null) onDecoded(text);
                    }
                }).start();
            }
        }
    };

    /** 不支持连续对焦的机型：每 1.2 秒主动对一次焦 */
    private void scheduleFocus() {
        if (surface == null) return;
        surface.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (camera == null || !needPeriodicFocus) return;
                try {
                    camera.autoFocus(null);
                } catch (Throwable ignored) {
                }
                scheduleFocus();
            }
        }, 1200);
    }

    // ================================================================ 解码

    /**
     * 预览帧（NV21）→ 文本。
     *
     * 先按 step 采样成一份灰度图（最长边约 800，纯粹为了速度；二维码识别
     * 不需要原分辨率，1080 以上每帧解码会慢到「看起来扫不动」），
     * 再交给 Scan.decodeGray 按四个方向试 —— 竖屏时相机帧是横躺的，
     * 必须旋转才能认出来；ZXing 的 rotateCounterClockwise() 在 3.5 直接抛异常，
     * 所以旋转在这里自己做。
     */
    private String decodeFrame(byte[] nv21, int width, int height) {
        if (nv21 == null || width <= 0 || height <= 0) return null;
        try {
            int step = 1;
            while (Math.max(width, height) / step > 800) step++;
            int w = width / step;
            int h = height / step;
            if (w <= 0 || h <= 0) return null;

            byte[] gray = new byte[w * h];
            for (int y = 0; y < h; y++) {
                int row = y * step * width;
                int dst = y * w;
                for (int x = 0; x < w; x++) {
                    gray[dst + x] = nv21[row + x * step];
                }
            }
            // 先试屏幕方向对应的那一个（90° 就优先转 90°），常见情况第一下就中
            int first = (displayOrientation / 90) % 4;
            return Scan.decodeGray(gray, w, h, Scan.hints(true), first);
        } catch (Throwable t) {
            return null;
        }
    }

    private void onDecoded(final String text) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (TextUtils.isEmpty(text)) return;
                try {
                    android.os.Vibrator v = (android.os.Vibrator)
                            getSystemService(VIBRATOR_SERVICE);
                    if (v != null) v.vibrate(60);
                } catch (Throwable ignored) {
                }
                stopCamera();
                Intent out = new Intent();
                out.putExtra("text", text);
                setResult(Activity.RESULT_OK, out);
                finish();
            }
        });
    }

    // ================================================================ 手电筒

    private void toggleTorch() {
        try {
            if (camera == null) return;
            Camera.Parameters p = camera.getParameters();
            torchOn = !torchOn;
            p.setFlashMode(torchOn
                    ? Camera.Parameters.FLASH_MODE_TORCH
                    : Camera.Parameters.FLASH_MODE_OFF);
            camera.setParameters(p);
            torchBtn.setOn(torchOn);
        } catch (Throwable t) {
            Toast.makeText(this, "手电筒不可用", Toast.LENGTH_SHORT).show();
        }
    }

    // ================================================================ 相册

    private void pickImage() {
        try {
            Intent i = new Intent(Intent.ACTION_GET_CONTENT);
            i.setType("image/*");
            i.addCategory(Intent.CATEGORY_OPENABLE);
            startActivityForResult(Intent.createChooser(i, "选择图片"), REQ_PICK);
        } catch (Throwable t) {
            Toast.makeText(this, "打不开相册", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_PICK || resultCode != Activity.RESULT_OK
                || data == null || data.getData() == null) {
            return;
        }
        final Uri uri = data.getData();
        new Thread(new Runnable() {
            @Override
            public void run() {
                final String text = Scan.decodeUri(ScanActivity.this, uri);
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (TextUtils.isEmpty(text)) {
                            Toast.makeText(ScanActivity.this,
                                    "没识别出二维码，换张清晰的图试试", Toast.LENGTH_SHORT).show();
                        } else {
                            onDecoded(text);
                        }
                    }
                });
            }
        }).start();
    }

    // ================================================================ 内部 View

    /** 取景框：四周压暗，中央留一块方形亮区 + 四个白色角标 */
    private static final class MaskView extends View {
        private final Paint mask = new Paint();
        private final Paint corner = new Paint();

        MaskView(android.content.Context c) {
            super(c);
            mask.setColor(0x88000000);
            mask.setStyle(Paint.Style.FILL);
            corner.setColor(Color.WHITE);
            corner.setStrokeWidth(Ui.dp(c, 2.5f));
            corner.setStyle(Paint.Style.STROKE);
            corner.setAntiAlias(true);
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            int w = getWidth();
            int h = getHeight();
            int side = Math.min(w, h) * 62 / 100;
            Rect box = new Rect((w - side) / 2, (h - side) / 2 - Ui.dp(getContext(), 40),
                    (w + side) / 2, (h + side) / 2 - Ui.dp(getContext(), 40));
            canvas.save();
            canvas.clipRect(0, 0, w, h);
            // 四块压暗区（中挖方孔）
            canvas.drawRect(0, 0, w, box.top, mask);
            canvas.drawRect(0, box.bottom, w, h, mask);
            canvas.drawRect(0, box.top, box.left, box.bottom, mask);
            canvas.drawRect(box.right, box.top, w, box.bottom, mask);
            // 四角
            int len = Ui.dp(getContext(), 22);
            canvas.drawLine(box.left, box.top + len, box.left, box.top, corner);
            canvas.drawLine(box.left, box.top, box.left + len, box.top, corner);
            canvas.drawLine(box.right - len, box.top, box.right, box.top, corner);
            canvas.drawLine(box.right, box.top, box.right, box.top + len, corner);
            canvas.drawLine(box.right, box.bottom - len, box.right, box.bottom, corner);
            canvas.drawLine(box.right, box.bottom, box.right - len, box.bottom, corner);
            canvas.drawLine(box.left + len, box.bottom, box.left, box.bottom, corner);
            canvas.drawLine(box.left, box.bottom, box.left, box.bottom - len, corner);
            canvas.restore();
        }
    }

    /** 底部按钮：白色线性图标 + 文字，圆角半透明底（照扫码页截图重做） */
    private static final class BottomBtn extends FrameLayout {
        private final android.widget.ImageView icon;
        private final TextView label;

        BottomBtn(android.content.Context c, String text, int iconRes) {
            super(c);
            android.graphics.drawable.GradientDrawable bg =
                    new android.graphics.drawable.GradientDrawable();
            bg.setColor(0x2EFFFFFF);
            bg.setCornerRadius(Ui.dp(c, 16));
            setBackground(bg);
            setClickable(true);

            LinearLayout col = new LinearLayout(c);
            col.setOrientation(LinearLayout.VERTICAL);
            col.setGravity(Gravity.CENTER);

            icon = new android.widget.ImageView(c);
            icon.setImageResource(iconRes);
            LinearLayout.LayoutParams ilp = new LinearLayout.LayoutParams(
                    Ui.dp(c, 24), Ui.dp(c, 24));
            icon.setLayoutParams(ilp);
            col.addView(icon);

            label = new TextView(c);
            label.setText(text);
            label.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f);
            label.setTextColor(0xEEFFFFFF);
            label.setGravity(Gravity.CENTER);
            LinearLayout.LayoutParams llp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            llp.topMargin = Ui.dp(c, 5);
            col.addView(label, llp);

            addView(col, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                    Gravity.CENTER));
        }

        void setOn(boolean on) {
            label.setText(on ? "关闭" : "手电筒");
            icon.setImageResource(on ? R.drawable.ic_scan_torch_on : R.drawable.ic_scan_torch);
        }

        @Override
        public void setPressed(boolean pressed) {
            super.setPressed(pressed);
            setAlpha(pressed ? 0.7f : 1f);
        }
    }
}
