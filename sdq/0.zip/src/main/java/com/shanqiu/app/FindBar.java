package com.shanqiu.app;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.graphics.drawable.GradientDrawable;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

/**
 * 页面内查找（Ctrl+F 那种）。
 *
 * 设计原则（用户明确要求）：
 *   - 不压暗网页 —— 背后页面保持原亮度，随时能对照着看；
 *   - 不要「关闭」按钮 —— 点查找条以外的地方自然关闭；
 *   - 不要标题栏 —— 就是一根贴着屏幕顶端的查找条。
 *
 * 输入即查：每敲一个字让 WebView 重新 findAllAsync，
 * 结果数通过 WebView.FindListener 回调到右侧的「3/12」。
 * 关闭（dismiss）时 clearMatches 把高亮撤掉。
 */
public final class FindBar {

    private static TextView countView;
    private static AlertDialog dialog;

    private FindBar() {
    }

    public static void show(final MainActivity a) {
        if (a == null) return;
        if (dialog != null && dialog.isShowing()) {
            try {
                dialog.dismiss();
            } catch (Throwable ignored) {
            }
            dialog = null;
        }
        if (a.currentWeb() == null) {
            Ui.toast(a, "页面还没准备好");
            return;
        }

        Theme.Palette p = Shell.of(a);

        LinearLayout box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(Ui.dp(a, 16), Ui.dp(a, 10), Ui.dp(a, 16), Ui.dp(a, 10));

        LinearLayout row = new LinearLayout(a);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);

        final EditText input = new EditText(a);
        input.setSingleLine(true);
        input.setHint("在页面中查找");
        input.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f);
        input.setInputType(android.text.InputType.TYPE_CLASS_TEXT);
        input.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
        input.setHighlightColor(0x33E64A19);
        input.setBackground(null);
        input.setPadding(0, 0, 0, 0);
        row.addView(input, new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        countView = new TextView(a);
        countView.setText("");
        countView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f);
        countView.setTextColor(p.sub);
        countView.setPadding(Ui.dp(a, 8), 0, 0, 0);
        row.addView(countView);

        box.addView(row, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        // 上一个 / 下一个：细描边胶囊按钮，不再有关闭
        LinearLayout ops = new LinearLayout(a);
        ops.setOrientation(LinearLayout.HORIZONTAL);
        ops.setGravity(Gravity.END);
        ops.setPadding(0, Ui.dp(a, 8), 0, 0);

        ops.addView(chip(a, "上一个", p, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    a.currentWeb().findNext(false);
                } catch (Throwable ignored) {
                }
            }
        }));
        ops.addView(chip(a, "下一个", p, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    a.currentWeb().findNext(true);
                } catch (Throwable ignored) {
                }
            }
        }));
        box.addView(ops, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        final AlertDialog d = new AlertDialog.Builder(a)
                .setView(box)
                .create();
        dialog = d;

        d.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface dlg) {
                countView = null;
                dialog = null;
                try {
                    a.currentWeb().clearMatches();
                } catch (Throwable ignored) {
                }
            }
        });

        input.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int a1, int b, int c) {
            }

            @Override
            public void onTextChanged(CharSequence s, int a1, int b, int c) {
            }

            @Override
            public void afterTextChanged(Editable e) {
                String t = e == null ? "" : e.toString();
                try {
                    if (t.length() == 0) {
                        a.currentWeb().clearMatches();
                        onResult(0, 0);
                    } else {
                        a.currentWeb().findAllAsync(t);
                    }
                } catch (Throwable ignored) {
                }
            }
        });

        input.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, android.view.KeyEvent ev) {
                if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                    try {
                        a.currentWeb().findNext(true);
                    } catch (Throwable ignored) {
                    }
                    return true;
                }
                return false;
            }
        });

        // 顶部悬浮条：不压暗网页、宽度留边、点外部自然关闭（AlertDialog 默认行为）
        try {
            d.show();
        } catch (Throwable t) {
            dialog = null;
            Toast.makeText(a, "打不开查找框", Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            WindowManager.LayoutParams lp = d.getWindow().getAttributes();
            lp.gravity = Gravity.TOP;
            lp.width = WindowManager.LayoutParams.MATCH_PARENT;
            lp.horizontalMargin = 0.03f;   // 左右各留 3% 屏宽
            lp.verticalMargin = 0.04f;     // 顶部留 4%，避开状态栏下的进度条
            lp.dimAmount = 0f;             // 关键：不调暗背后的网页
            lp.flags &= ~WindowManager.LayoutParams.FLAG_DIM_BEHIND;
            d.getWindow().setAttributes(lp);
        } catch (Throwable ignored) {
        }
        input.requestFocus();
    }

    /** WebView.FindListener 回调转进来 */
    public static void onResult(int index, int total) {
        TextView v = countView;
        if (v == null) return;
        try {
            if (total <= 0) v.setText("无结果");
            else v.setText(index + 1 + "/" + total);
        } catch (Throwable ignored) {
        }
    }

    private static TextView chip(MainActivity a, String text, Theme.Palette p,
                                 View.OnClickListener l) {
        TextView t = new TextView(a);
        t.setText(text);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f);
        t.setTextColor(p.accent);
        t.setGravity(Gravity.CENTER);
        t.setPadding(Ui.dp(a, 14), Ui.dp(a, 7), Ui.dp(a, 14), Ui.dp(a, 7));

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(p.press);
        bg.setCornerRadius(Ui.dp(a, 999));
        t.setBackground(bg);
        t.setClickable(true);
        t.setOnClickListener(l);

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.leftMargin = Ui.dp(a, 8);
        t.setLayoutParams(lp);
        return t;
    }
}
