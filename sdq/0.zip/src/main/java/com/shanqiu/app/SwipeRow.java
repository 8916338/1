package com.shanqiu.app;

import android.content.Context;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewParent;

/**
 * 列表行「横划删除」。
 *
 * 手势约定，和后台窗口列表保持一致：
 *   横向拖动      → 行跟着手走，松开超过阈值就滑出删除；
 *   纵向拖动      → 完全不接管，交给外层 ScrollView 正常滚；
 *   原地点一下    → 返回 false，点击 / 长按照常触发。
 *
 * 判定的关键是「第一次超过 touchSlop 的方向」：一旦认成横向就
 * requestDisallowInterceptTouchEvent(true)，把外层滚动锁住，避免拖着拖着
 * 列表跟着上下抖。
 */
public final class SwipeRow {

    public interface OnDelete {
        /**
         * 手势已经达成，先问一句要不要真删（弹「删除 / 取消」）。
         * 返回 true → 立刻滑出并回调 onDelete；返回 false → 行回弹，什么都不动。
         * 想自己弹对话框的，就在这里弹，并返回 false（对话框里再删数据）。
         */
        boolean beforeDelete(View row);

        /** row 已经从父容器里移除，这里只负责删数据 */
        void onDelete(View row);
    }

    private SwipeRow() {
    }

    public static void attach(final View row, final OnDelete del) {
        final Context c = row.getContext();
        final int slop = ViewConfiguration.get(c).getScaledTouchSlop();
        final int trigger = Ui.dp(c, 64);

        row.setOnTouchListener(new View.OnTouchListener() {
            private float downX;
            private float downY;
            private int mode;   // 0 未定 / 1 横向 / 2 纵向
            private boolean removed;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        downX = e.getX();
                        downY = e.getY();
                        mode = 0;
                        removed = false;
                        v.animate().cancel();
                        v.setTranslationX(0f);
                        v.setAlpha(1f);
                        return false;   // 不吃 DOWN，点击和长按照常

                    case MotionEvent.ACTION_MOVE: {
                        float dx = e.getX() - downX;
                        float dy = e.getY() - downY;
                        if (mode == 0) {
                            if (Math.abs(dx) > slop && Math.abs(dx) > Math.abs(dy) * 1.2f) {
                                mode = 1;
                                ViewParent p = v.getParent();
                                if (p != null) p.requestDisallowInterceptTouchEvent(true);
                            } else if (Math.abs(dy) > slop) {
                                mode = 2;
                            }
                        }
                        if (mode == 1) {
                            v.setTranslationX(dx);
                            // 拉得越远越淡，给个「要删了」的暗示
                            float k = Math.min(1f, Math.abs(dx) / (float) trigger);
                            v.setAlpha(1f - 0.45f * k);
                            return true;
                        }
                        return false;
                    }

                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL: {
                        if (mode != 1) return false;
                        float dx = e.getX() - downX;
                        boolean go = !removed && Math.abs(dx) > trigger
                                && (del == null || del.beforeDelete(row));
                        if (go) {
                            removed = true;
                            swipeOut(row, dx > 0, del);
                        } else {
                            // 取消（或没到阈值）：回弹，不删
                            row.animate().translationX(0f).alpha(1f).setDuration(130).start();
                        }
                        mode = 0;
                        return true;   // 已经滑过就别再触发点击
                    }

                    default:
                        return false;
                }
            }
        });
    }

    private static void swipeOut(final View row, boolean toRight, final OnDelete del) {
        float to = toRight
                ? row.getWidth() + Ui.dp(row.getContext(), 40)
                : -row.getWidth() - Ui.dp(row.getContext(), 40);
        row.animate().translationX(to).alpha(0f).setDuration(150)
                .withEndAction(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            ViewParent p = row.getParent();
                            if (p instanceof android.view.ViewGroup) {
                                ((android.view.ViewGroup) p).removeView(row);
                            }
                        } catch (Throwable ignored) {
                        }
                        try {
                            if (del != null) del.onDelete(row);
                        } catch (Throwable ignored) {
                        }
                    }
                }).start();
    }
}
