package com.shanqiu.app;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.text.TextUtils;
import android.webkit.WebResourceResponse;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

/**
 * 首页地址与 APP 自带的那一份网页（assets/index.html）。
 *
 * 这是一个通用壳：网页可以完全离线跑内置的，也可以指定一个在线站点。
 * 只改下面两个常量就够了：
 *
 *   app-config.json 里的 online 为空 → 只用内置页面（离线可用，当前默认）
 *   app-config.json 里的 online 非空 → 优先加载在线站点，打不开自动回落内置页面
 *
 * 内置页面通过虚拟域名 https://appassets.androidplatform.net/ 提供，
 * 目的是让页面里的 fetch('data.json') 属于同源请求，不会像 file:// 那样被跨域拦掉。
 */
public final class Site {

    public static final String HOST = "appassets.androidplatform.net";
    public static final String ORIGIN = "https://" + HOST;

    private Site() {
    }

    /** 有没有配在线站点（值来自 app-config.json → Config.ONLINE） */
    public static boolean hasOnline() {
        return !TextUtils.isEmpty(Config.ONLINE);
    }

    /** 启动页：配了在线站点走在线，没配直接用内置页 */
    public static String startUrl(Context c) {
        return hasOnline() ? Config.ONLINE : builtinUrl(c);
    }

    /** 内置首页的文件名（app-config.json 的 pages 里 home:true 那一项，默认 index.html） */
    public static String homeFile() {
        String f = Config.HOME_FILE;
        return TextUtils.isEmpty(f) ? "index.html" : f;
    }

    /** 内置页面地址。带版本号，升级安装后不会被 WebView 的旧缓存顶掉 */
    public static String builtinUrl(Context c) {
        return ORIGIN + "/" + homeFile() + "?v=" + versionCode(c);
    }

    /** 内置页面的干净地址（不带 cache 参数），用于 isHome 之类的比对 */
    public static String builtinPath() {
        return ORIGIN + "/" + homeFile();
    }

    private static int versionCode(Context c) {
        try {
            PackageInfo pi = c.getPackageManager().getPackageInfo(c.getPackageName(), 0);
            return pi.versionCode;
        } catch (Throwable t) {
            return 1;
        }
    }

    // ---------------------------------------------------------------- 资源

    public static WebResourceResponse response(Context c, String path) {
        if (TextUtils.isEmpty(path) || "/".equals(path)) path = "/" + homeFile();
        while (path.startsWith("/")) path = path.substring(1);
        if (path.contains("..") || path.contains("\\")) return notFound();

        InputStream in = null;
        try {
            in = c.getAssets().open(path);
        } catch (Throwable ignored) {
        }
        if (in == null) return notFound();

        String mime = Mimes.forPath(path);
        Map<String, String> headers = new HashMap<>();
        headers.put("Cache-Control", "no-store");
        headers.put("Access-Control-Allow-Origin", "*");
        return new WebResourceResponse(mime, Mimes.isText(mime) ? "utf-8" : null,
                200, "OK", headers, in);
    }

    private static WebResourceResponse notFound() {
        Map<String, String> h = new HashMap<>();
        h.put("Cache-Control", "no-store");
        return new WebResourceResponse("text/plain", "utf-8", 404, "Not Found", h,
                new ByteArrayInputStream(new byte[0]));
    }
}
