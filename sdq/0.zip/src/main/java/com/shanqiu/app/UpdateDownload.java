package com.shanqiu.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * 应用更新专用下载通道（和网页下载的 {@link Downloader} 完全分开）。
 *
 * 为什么要单独一条：
 *   网页里点的下载，不管是不是 .apk，都该走「下载内容」那套 ——
 *   落系统「下载」目录、进下载台账、下完弹「打开 / 分享 / 打开目录」。
 *   更新包不能这样：它属于 App 自己的事，不该污染用户的下载记录，
 *   也不该让用户去通知栏里找文件。
 *
 * 这条通道的行为：
 *   1. 落盘在应用私有缓存（可以经 content:// 交给系统安装器）；
 *   2. 不写下载台账、不走系统 DownloadManager → 「下载内容」面板里看不到；
 *   3. 进度用壳自己的弹窗显示，可随时取消（取消不留半截文件）；
 *   4. 下完交给 {@link Updater} 弹「是否马上更新」，选「稍后」也保留文件，
 *      下次点「检查更新」直接拿它装，不再重下。
 */
public final class UpdateDownload {

    /** 正在下载时，其它入口不要再起一条 */
    private static volatile boolean running;

    private static volatile boolean canceled;

    private static final String TMP = "update.tmp";

    private static final String ERR_CANCELED = "已取消下载";

    public interface Callback {
        /**
         * @param apk   下载好的安装包；失败或被取消时为 null
         * @param error 失败原因；成功为 null
         */
        void onFinish(File apk, String error);
    }

    private UpdateDownload() {
    }

    public static boolean isRunning() {
        return running;
    }

    /**
     * 开始下载更新包。
     *
     * @param name 落盘文件名（如 update-1.0.5.apk），要求以 .apk 结尾
     */
    public static boolean start(final Activity act, final String url, final String name,
                                final Callback cb) {
        if (act == null || TextUtils.isEmpty(url)) {
            if (cb != null) cb.onFinish(null, "下载地址为空");
            return false;
        }
        if (running) {
            Ui.toast(act, "更新包正在下载，请稍候");
            return false;
        }
        running = true;
        canceled = false;

        final File dir = LocalFiles.dir(act);
        final File tmp = new File(dir, TMP);
        final File out = new File(dir, Ui.safeName(name, "update.apk"));

        final Handler ui = new Handler(Looper.getMainLooper());
        final Theme.Palette p = Shell.of(act);

        // ---- 进度弹窗 ----
        final TextView msg = new TextView(act);
        msg.setText("正在连接服务器…");
        msg.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f);
        msg.setTextColor(p.sub);

        final ProgressBar bar = new ProgressBar(act, null,
                android.R.attr.progressBarStyleHorizontal);
        bar.setMax(1000);
        bar.setProgress(0);

        LinearLayout box = new LinearLayout(act);
        box.setOrientation(LinearLayout.VERTICAL);
        int pad = Ui.dp(act, 20);
        box.setPadding(pad, Ui.dp(act, 10), pad, Ui.dp(act, 2));
        box.addView(msg, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        blp.topMargin = Ui.dp(act, 12);
        box.addView(bar, blp);

        final AlertDialog dlg = new AlertDialog.Builder(act)
                .setTitle("正在下载新版本")
                .setView(box)
                .setNegativeButton("取消", null)
                // 只认弹窗里的按钮：点外面 / 返回键都别把进度框带走
                .setCancelable(false)
                .create();

        // 「取消」不直接关窗，先置标记，等线程把半截文件删掉再关
        dlg.setOnShowListener(new DialogInterface.OnShowListener() {
            @Override
            public void onShow(DialogInterface d) {
                ((AlertDialog) d).getButton(AlertDialog.BUTTON_NEGATIVE)
                        .setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                canceled = true;
                                msg.setText("正在取消…");
                            }
                        });
            }
        });
        Ui.show(dlg);

        new Thread(new Runnable() {
            @Override
            public void run() {
                String err = null;
                File result = null;
                HttpURLConnection conn = null;
                InputStream in = null;
                FileOutputStream fos = null;
                long done = 0;
                long total = -1;
                long lastPost = 0;

                try {
                    conn = open(url);
                    int code = conn.getResponseCode();
                    if (code < 200 || code >= 300) {
                        throw new Exception("服务器返回 " + code);
                    }
                    total = conn.getContentLength();
                    in = conn.getInputStream();
                    fos = new FileOutputStream(tmp);

                    final long fTotal = total;
                    byte[] buf = new byte[64 * 1024];
                    int n;
                    while ((n = in.read(buf)) > 0) {
                        if (canceled) {
                            err = ERR_CANCELED;
                            break;
                        }
                        fos.write(buf, 0, n);
                        done += n;

                        long now = System.currentTimeMillis();
                        if (now - lastPost > 200) {
                            lastPost = now;
                            final long fDone = done;
                            ui.post(new Runnable() {
                                @Override
                                public void run() {
                                    if (fTotal > 0) {
                                        int pct = (int) Math.min(1000, fDone * 1000 / fTotal);
                                        bar.setProgress(pct);
                                        msg.setText("已下载 " + (pct / 10) + "%  ·  "
                                                + Ui.humanSize(fDone) + " / "
                                                + Ui.humanSize(fTotal));
                                    } else {
                                        msg.setText("已下载 " + Ui.humanSize(fDone));
                                    }
                                }
                            });
                        }
                    }
                    fos.flush();
                    fos.close();
                    fos = null;
                    in.close();
                    in = null;

                    if (err == null) {
                        if (tmp.length() <= 0) throw new Exception("下载到的文件是空的");
                        // 覆盖上一次的同名包
                        if (out.exists() && !out.delete()) {
                            throw new Exception("旧的安装包删不掉");
                        }
                        if (!tmp.renameTo(out)) {
                            copy(tmp, out);
                            //noinspection ResultOfMethodCallIgnored
                            tmp.delete();
                        }
                        result = out;
                    }
                } catch (Throwable t) {
                    err = t.getMessage() == null ? "下载失败" : t.getMessage();
                } finally {
                    close(fos);
                    close(in);
                    closeQuietly(conn);
                    if (result == null) {
                        // 失败 / 取消：不留半截文件
                        //noinspection ResultOfMethodCallIgnored
                        tmp.delete();
                    }
                }

                running = false;
                final File fin = result;
                final String ferr = err;
                ui.post(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            if (dlg.isShowing()) dlg.dismiss();
                        } catch (Throwable ignored) {
                        }
                        if (cb != null) cb.onFinish(fin, ferr);
                    }
                });
            }
        }, "update-download").start();
        return true;
    }

    /** 下载连接：自己跟跳转，http → https 也能跟 */
    private static HttpURLConnection open(String url) throws Exception {
        String cur = url;
        for (int i = 0; i < 6; i++) {
            HttpURLConnection c = (HttpURLConnection) new URL(cur).openConnection();
            c.setConnectTimeout(15000);
            c.setReadTimeout(20000);
            c.setInstanceFollowRedirects(false);
            c.setRequestProperty("User-Agent",
                    "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 "
                            + "(KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36");
            c.setRequestProperty("Accept", "*/*");
            int code = c.getResponseCode();
            if (code == 301 || code == 302 || code == 303 || code == 307 || code == 308) {
                String loc = c.getHeaderField("Location");
                c.disconnect();
                if (TextUtils.isEmpty(loc)) throw new Exception("跳转地址为空");
                cur = new URL(new URL(cur), loc).toString();
                continue;
            }
            return c;
        }
        throw new Exception("跳转次数过多");
    }

    private static void copy(File from, File to) throws Exception {
        FileInputStream in = new FileInputStream(from);
        FileOutputStream out = new FileOutputStream(to);
        try {
            byte[] buf = new byte[64 * 1024];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            out.flush();
        } finally {
            close(in);
            close(out);
        }
    }

    private static void close(java.io.Closeable c) {
        if (c == null) return;
        try {
            c.close();
        } catch (Throwable ignored) {
        }
    }

    private static void closeQuietly(HttpURLConnection c) {
        if (c == null) return;
        try {
            c.disconnect();
        } catch (Throwable ignored) {
        }
    }
}
