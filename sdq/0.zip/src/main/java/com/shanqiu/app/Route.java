package com.shanqiu.app;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.text.TextUtils;

import java.io.File;
import java.util.List;
import java.util.Locale;

/**
 * 所有「要去别处」的动作都从这里走。
 *
 * 核心原则：**任何跳转都不自动执行**。
 *  - 页面里点 http 链接 → 在壳内打开（不经过这里）
 *  - 页面里点自定义 scheme（mqq:// weixin:// …）→ 弹系统选择器
 *  - 长按链接 / 扫码结果 → 弹底部面板，用户自己选
 */
public final class Route {

    public static final String QQ_PKG = "com.tencent.mobileqq";
    public static final String WX_PKG = "com.tencent.mm";
    public static final String ALI_PKG = "com.eg.android.AlipayGphone";

    private Route() {
    }

    // ------------------------------------------------------------ 基础判断

    public static boolean isHttp(String url) {
        if (url == null) return false;
        String u = url.toLowerCase(Locale.US);
        return u.startsWith("http://") || u.startsWith("https://");
    }

    public static boolean isSpecial(String url) {
        if (url == null) return false;
        String u = url.toLowerCase(Locale.US);
        return u.startsWith("javascript:") || u.startsWith("about:")
                || u.startsWith("data:") || u.startsWith("blob:");
    }

    public static String hostOf(String url) {
        try {
            String h = Uri.parse(url).getHost();
            return h == null ? "" : h.toLowerCase(Locale.US);
        } catch (Throwable t) {
            return "";
        }
    }

    public static boolean isQqLink(String url) {
        String h = hostOf(url);
        return h.endsWith("qq.com") && !h.contains("weixin");
    }

    public static boolean isWxLink(String url) {
        String h = hostOf(url);
        // u.wechat.com（加好友）/ mp.weixin.qq.com（公众号）/ weixin.qq.com …
        return h.contains("weixin") || h.contains("wechat");
    }

    public static boolean isAliLink(String url) {
        // qr.alipay.com（付款码）/ render.alipay.com（跳转页）/ alipayobjects.com …
        return hostOf(url).contains("alipay");
    }

    public static boolean installed(Context c, String pkg) {
        try {
            c.getPackageManager().getPackageInfo(pkg, 0);
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    // ------------------------------------------------------------ 页面里点了链接

    /**
     * 页面里点了一个非 http(s) 的链接（mqq://、weixin://、alipays://、tel: …）。
     * 这里**一定**让用户选，不会直接跳。
     */
    public static void tapScheme(final Activity a, final String url) {
        if (a == null || TextUtils.isEmpty(url)) return;

        Intent intent = toIntent(url);
        if (intent == null) {
            unknown(a, url);
            return;
        }
        int n = count(a, intent);
        if (n <= 0) {
            unknown(a, url);
            return;
        }
        // 自绘面板列应用（系统 chooser 样式老气，和闪电球不搭）
        AppPicker.show(a, intent, "选择要打开的应用");
    }

    /** 没有 App 能处理：给个可操作的出口 */
    private static void unknown(final Activity a, final String url) {
        Sheet.show(a, "没有找到能打开它的应用", shortUrl(url),
                new String[]{"📋", "🌐", "↗"},
                new String[]{"复制内容", "试着用浏览器打开", "分享到其他应用"},
                new String[]{null, null, null},
                new Sheet.Pick() {
                    @Override
                    public void onPick(int i) {
                        if (i == 0) copy(a, url, "已复制");
                        else if (i == 1) browser(a, url);
                        else shareText(a, url);
                    }
                });
    }

    // ------------------------------------------------------------ 统一的「打开方式」面板

    /**
     * 打开一个地址，但把选择权交给用户。
     *
     * @param scanned 是不是扫码/识别出来的（标题文案会不一样）
     */
    public static void choose(final Activity a, final String url, final boolean scanned) {
        if (a == null || TextUtils.isEmpty(url)) return;

        if (!isHttp(url)) {
            // 自定义 scheme：直接走系统应用选择
            tapScheme(a, url);
            return;
        }

        // 链接指向哪家就只给哪家：qm.qq.com → QQ，weixin.qq.com → 微信，
        // alipay.com → 支付宝；都不是就只给通用选项，不把三家全糊上去
        final boolean qq = isQqLink(url) && installed(a, QQ_PKG);
        final boolean wx = isWxLink(url) && installed(a, WX_PKG);
        final boolean ali = isAliLink(url) && installed(a, ALI_PKG);

        java.util.ArrayList<Integer> icons = new java.util.ArrayList<>();
        java.util.ArrayList<String> labels = new java.util.ArrayList<>();
        java.util.ArrayList<String> subs = new java.util.ArrayList<>();
        final java.util.ArrayList<Integer> acts = new java.util.ArrayList<>();

        // 图标用和长按面板同一套矢量描边图形（QQ / 支付宝为应用图标同款圆形底）
        if (qq) {
            icons.add(R.drawable.ic_q_qq); labels.add("用 QQ 打开"); subs.add("把链接交给手机 QQ"); acts.add(1);
        }
        if (wx) {
            icons.add(R.drawable.ic_q_wechat); labels.add("用微信打开"); subs.add("复制链接并打开微信"); acts.add(2);
        }
        if (ali) {
            icons.add(R.drawable.ic_q_alipay); labels.add("用支付宝打开"); subs.add("把链接交给支付宝"); acts.add(8);
        }
        icons.add(R.drawable.ic_q_home); labels.add("在应用内打开"); subs.add("就在当前壳里看"); acts.add(3);
        icons.add(R.drawable.ic_q_web); labels.add("用浏览器打开"); subs.add("交给系统浏览器"); acts.add(4);
        icons.add(R.drawable.ic_q_more); labels.add("用其他应用打开"); subs.add("选一个 App 处理这个链接"); acts.add(5);
        icons.add(R.drawable.ic_q_copy); labels.add("复制链接"); subs.add(null); acts.add(6);
        icons.add(R.drawable.ic_q_share); labels.add("分享链接"); subs.add(null); acts.add(7);

        int[] iconIds = new int[icons.size()];
        for (int i = 0; i < iconIds.length; i++) iconIds[i] = icons.get(i);

        String title = scanned ? "识别到的链接" : "打开这个链接";
        Sheet.show(a, title, url,
                iconIds,
                labels.toArray(new String[0]),
                subs.toArray(new String[0]),
                new Sheet.Pick() {
                    @Override
                    public void onPick(int i) {
                        int act = acts.get(i);
                        switch (act) {
                            case 1: openQq(a, url); break;
                            case 2: openWx(a, url); break;
                            case 3: inApp(a, url); break;
                            case 4: browser(a, url); break;
                            case 5: external(a, url); break;
                            case 6: copy(a, url, "链接已复制"); break;
                            case 8: launchApp(a, ALI_PKG); break;
                            default: shareText(a, url); break;
                        }
                    }
                });
    }

    // ------------------------------------------------------------ 具体动作

    public static void inApp(Activity a, String url) {
        if (a instanceof MainActivity) {
            ((MainActivity) a).openInside(url);
        } else if (a != null) {
            Intent i = new Intent(a, MainActivity.class);
            i.putExtra(MainActivity.EXTRA_URL, url);
            a.startActivity(i);
        }
    }

    /**
     * 用系统「打开方式」打开一个本地文件（下载面板用）。
     * 私有缓存里的文件走 LocalFiles 的 content://，避免暴露 file://。
     */
    public static void openFile(final Activity a, final File f) {
        if (a == null || f == null || !f.exists()) {
            Ui.toast(a, "文件不存在");
            return;
        }
        String mime = Mimes.fromName(f.getName());
        if (TextUtils.isEmpty(mime)) mime = "application/octet-stream";
        try {
            // 缓存目录走 dl/，下载目录走 down/；都给 content://（file:// 在
            // Android 7+ 会抛 FileUriExposedException，表现为「点开没反应」）
            Uri uri = null;
            if (f.getAbsolutePath().startsWith(a.getCacheDir().getAbsolutePath())) {
                uri = LocalFiles.uriFor(a, f);
            } else {
                uri = LocalFiles.uriForPath(f);
            }
            if (uri == null) uri = Uri.fromFile(f);
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setDataAndType(uri, mime);
            i.setClipData(ClipData.newRawUri("", uri));
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
            AppPicker.show(a, i, "打开方式");
        } catch (Throwable t) {
            Ui.toast(a, "没有能打开这个文件的应用");
        }
    }


    // ------------------------------------------------------------ 三方 App 扫一扫

    /**
     * 调起微信 / QQ / 支付宝的「扫一扫」。
     * 这些都是非公开协议，各家版本可能失效：打不开就明说，并提示改用壳自带扫码。
     */
    public static void openAppScan(Activity a, String which) {
        if (a == null) return;
        String app = "wechat".equals(which) ? "微信" : "qq".equals(which) ? "QQ" : "支付宝";
        String uri = "wechat".equals(which) ? "weixin://dl/scan"
                : "qq".equals(which) ? "mqqapi://qrcode/scan_qrcode?src_type=internal"
                : "alipay://platformapi/startapp?appId=10000007";
        try {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(uri));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            a.startActivity(i);
        } catch (Throwable t) {
            Ui.toast(a, "调不起" + app + "的扫一扫，已改用自带扫码");
            if (a instanceof MainActivity) {
                try {
                    Scan.start((MainActivity) a);
                } catch (Throwable ignored) {
                }
            }
        }
    }

    /** 复制一段文字到剪贴板（嗅探结果、视频直链都用它） */
    public static void copyText(Context c, String text) {
        if (c == null || TextUtils.isEmpty(text)) return;
        try {
            ClipboardManager cm = (ClipboardManager) c.getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm == null) return;
            cm.setPrimaryClip(ClipData.newPlainText("", text));
            Ui.toast(c, "已复制");
        } catch (Throwable t) {
            Ui.toast(c, "复制失败");
        }
    }

    public static void browser(Activity a, String url) {
        try {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            i.addCategory(Intent.CATEGORY_BROWSABLE);
            AppPicker.show(a, i, "选择浏览器");
        } catch (Throwable t) {
            Ui.toast(a, "没有可用的浏览器");
        }
    }

    public static void external(Activity a, String url) {
        try {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            AppPicker.show(a, i, "用其他应用打开");
        } catch (Throwable t) {
            Ui.toast(a, "没有找到能打开的应用");
        }
    }

    /** 用 QQ 打开网页：走 QQ 的 forward/url 协议 */
    public static void openQq(Activity a, String url) {
        try {
            String b64 = android.util.Base64.encodeToString(url.getBytes("UTF-8"),
                    android.util.Base64.NO_WRAP | android.util.Base64.URL_SAFE);
            String scheme = "mqqapi://forward/url?url_prefix=" + b64 + "&version=1&src_type=web";
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(scheme));
            i.setPackage(QQ_PKG);
            a.startActivity(i);
        } catch (Throwable t) {
            copy(a, url, "已复制，去 QQ 里粘贴");
            launchApp(a, QQ_PKG);
        }
    }

    /** 微信没有开放「打开指定网页」的协议，只能复制 + 唤起 */
    public static void openWx(Activity a, String url) {
        copy(a, url, "链接已复制，去微信里粘贴");
        launchApp(a, WX_PKG);
    }

    public static void launchApp(Activity a, String pkg) {
        try {
            Intent i = a.getPackageManager().getLaunchIntentForPackage(pkg);
            if (i != null) {
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                a.startActivity(i);
            } else {
                Ui.toast(a, "没有安装这个应用");
            }
        } catch (Throwable t) {
            Ui.toast(a, "启动失败");
        }
    }

    /** 加 QQ 好友（二维码/文本里读出来的号） */
    public static void addQqFriend(Activity a, String uin) {
        try {
            Intent i = new Intent(Intent.ACTION_VIEW,
                    Uri.parse("mqqwpa://im/chat?chat_type=wpa&uin=" + uin + "&version=1&src_type=web"));
            i.setPackage(QQ_PKG);
            a.startActivity(i);
        } catch (Throwable t) {
            copy(a, uin, "已复制 QQ 号，去 QQ 里搜");
        }
    }

    /** 用 QQ 群号搜群（QQ 没开放「直接进群」，只能到搜索页） */
    public static void joinQqGroup(Activity a, String uin) {
        try {
            Intent i = new Intent(Intent.ACTION_VIEW,
                    Uri.parse("mqqapi://card/show_pslcard?src_type=internal&source=sharecard&uin="
                            + uin + "&card_type=group"));
            i.setPackage(QQ_PKG);
            a.startActivity(i);
        } catch (Throwable t) {
            copy(a, uin, "已复制群号，去 QQ 里搜");
        }
    }

    public static void search(Activity a, String text) {
        try {
            String q = java.net.URLEncoder.encode(text, "UTF-8");
            browser(a, "https://www.baidu.com/s?wd=" + q);
        } catch (Throwable t) {
            Ui.toast(a, "搜索失败");
        }
    }

    public static void copy(Context c, String text, String tip) {
        if (TextUtils.isEmpty(text)) return;
        try {
            ClipboardManager cm = (ClipboardManager) c.getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("网页链接", text));
            if (tip != null) Ui.toast(c, tip);
        } catch (Throwable t) {
            Ui.toast(c, "复制失败");
        }
    }

    public static void shareText(Activity a, String text) {
        try {
            Intent i = new Intent(Intent.ACTION_SEND);
            i.setType("text/plain");
            i.putExtra(Intent.EXTRA_TEXT, text);
            AppPicker.show(a, i, "分享到");
        } catch (Throwable t) {
            Ui.toast(a, "分享失败");
        }
    }

    public static void shareFile(Activity a, File f, String mime) {
        try {
            Uri u = LocalFiles.uriFor(a, f);
            Intent i = new Intent(Intent.ACTION_SEND);
            i.setType(TextUtils.isEmpty(mime) ? "application/octet-stream" : mime);
            i.putExtra(Intent.EXTRA_STREAM, u);
            i.setClipData(ClipData.newRawUri("", u));
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            AppPicker.show(a, i, "分享到");
        } catch (Throwable t) {
            Ui.toast(a, "分享失败");
        }
    }

    // ------------------------------------------------------------ intent://

    private static Intent toIntent(String url) {
        try {
            if (url.toLowerCase(Locale.US).startsWith("intent:")) {
                Intent i = Intent.parseUri(url, Intent.URI_INTENT_SCHEME);
                i.addCategory(Intent.CATEGORY_BROWSABLE);
                i.setComponent(null);
                i.setSelector(null);
                return i;
            }
            return new Intent(Intent.ACTION_VIEW, Uri.parse(url));
        } catch (Throwable t) {
            return null;
        }
    }

    private static int count(Context c, Intent i) {
        try {
            List<ResolveInfo> list = c.getPackageManager()
                    .queryIntentActivities(i, PackageManager.MATCH_DEFAULT_ONLY);
            return list == null ? 0 : list.size();
        } catch (Throwable t) {
            return 0;
        }
    }

    static String shortUrl(String url) {
        if (url == null) return "";
        return url.length() > 90 ? url.substring(0, 88) + "…" : url;
    }
}
