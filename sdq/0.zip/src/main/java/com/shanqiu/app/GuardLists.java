package com.shanqiu.app;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;

import org.json.JSONArray;

import java.util.ArrayList;
import java.util.List;

/**
 * 网页控制的站点白名单 / 黑名单。
 *
 * 存储在本机 SharedPreferences（JSON 数组），站点一律按主机名归一化
 * （小写、去掉协议和路径），example.com 和 https://www.Example.com/a
 * 算同一个站点。一个站点只能待在一张名单里，加进一边会自动从另一边挪走。
 *
 * 决策（NavGuard 的跳转 / 弹窗拦截点都用它）：
 *   白名单 → 直接执行（跳转照常加载、弹窗照常显示），只在底部按钮上闪一句
 *   黑名单 → 直接丢弃，同样只在底部按钮上闪一句
 *   都不在 → 交给用户：点的当场问，自动的排队等
 *
 * 名单只由用户自己维护 —— 要么在决策框里勾「记住这个站点」，要么在
 * 「最近处理」里点一条历史加进去，要么在名单页手动添加。壳不会自己往里写。
 */
public final class GuardLists {

    public static final int WHITE = 0;
    public static final int BLACK = 1;

    private static final String PREF = "guard_lists";
    private static final String K_WHITE = "whitelist";
    private static final String K_BLACK = "blacklist";

    /** 决策值 */
    public static final String ALLOW = "allow";
    public static final String BLOCK = "block";
    public static final String ASK = "ask";

    private GuardLists() {
    }

    private static android.content.SharedPreferences sp(Context c) {
        return c.getSharedPreferences(PREF, Context.MODE_PRIVATE);
    }

    private static String keyOf(int which) {
        return which == WHITE ? K_WHITE : K_BLACK;
    }

    /** 主机名归一化：小写、去协议、去路径、去端口后缀不处理（保持原样） */
    public static String normalize(String h) {
        if (h == null) return "";
        h = h.trim().toLowerCase();
        if (h.startsWith("https://")) h = h.substring(8);
        else if (h.startsWith("http://")) h = h.substring(7);
        int i = h.indexOf('/');
        if (i > 0) h = h.substring(0, i);
        return h.trim();
    }

    // ------------------------------------------------------------ 读写

    public static ArrayList<String> get(Context c, int which) {
        ArrayList<String> out = new ArrayList<>();
        try {
            JSONArray arr = new JSONArray(sp(c).getString(keyOf(which), "[]"));
            for (int i = 0; i < arr.length(); i++) {
                String s = arr.optString(i, "").trim();
                if (!TextUtils.isEmpty(s)) out.add(s);
            }
        } catch (Throwable ignored) {
        }
        return out;
    }

    /** 加进一张名单，同时从另一张里挪走（一个站点只能在一侧） */
    public static void add(Context c, int which, String host) {
        host = normalize(host);
        if (TextUtils.isEmpty(host)) return;
        ArrayList<String> cur = get(c, which);
        cur.remove(host);
        cur.add(0, host);   // 新加的放最前，方便马上看到
        save(c, which, cur);
        ArrayList<String> other = get(c, which == WHITE ? BLACK : WHITE);
        if (other.remove(host)) save(c, which == WHITE ? BLACK : WHITE, other);
    }

    public static void remove(Context c, int which, String host) {
        host = normalize(host);
        ArrayList<String> cur = get(c, which);
        if (cur.remove(host)) save(c, which, cur);
    }

    private static void save(Context c, int which, ArrayList<String> list) {
        try {
            JSONArray arr = new JSONArray();
            for (String s : list) arr.put(s);
            sp(c).edit().putString(keyOf(which), arr.toString()).apply();
        } catch (Throwable ignored) {
        }
    }

    /** 这个站点的弹窗该怎么办：allow / block / ask */
    public static String decision(Context c, String host) {
        host = normalize(host);
        if (TextUtils.isEmpty(host)) return ASK;
        if (get(c, WHITE).contains(host)) return ALLOW;
        if (get(c, BLACK).contains(host)) return BLOCK;
        return ASK;
    }

    // ------------------------------------------------------------ 站点决策对话框

    /**
     * 一个站点攒下的待处理条目（跳转 + 弹窗混在一起），点开后由用户决定：
     * 放行 / 拦截 / 先放着。
     *
     * 勾选「记住这个站点」就把站点写进对应名单，以后该站的跳转和弹窗
     * 都按这次的选择直接处理（只留一句底部标语，不再问）。
     *
     * 注意：这里只负责问和记，真正执行交给 NavGuard.releaseItems /
     * blockItems —— 放行弹窗是显示原文，放行跳转是加载页面。
     */
    public static void decideSite(final MainActivity a, final String host,
                                  final List<NavGuard.Item> items) {
        if (a == null || a.isFinishing() || a.isDestroyed() || items.isEmpty()) return;

        final int pad = Ui.dp(a, 20);
        LinearLayout box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(pad, Ui.dp(a, 10), pad, Ui.dp(a, 2));

        // 明细：跳转给网址，弹窗给原文
        StringBuilder msg = new StringBuilder();
        for (int i = 0; i < items.size(); i++) {
            if (i > 0) msg.append("\n\n―――――\n\n");
            msg.append(items.get(i).popup ? "【弹窗】\n" : "【跳转】\n");
            msg.append(items.get(i).url);
        }
        TextView body = new TextView(a);
        body.setText(msg.toString());
        body.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13.5f);
        body.setTextColor(Shell.of(a).text);
        body.setTextIsSelectable(true);
        ScrollView sv = new ScrollView(a);
        sv.addView(body, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(a, 190));
        box.addView(sv, slp);

        TextView site = new TextView(a);
        site.setText("来自站点：" + host + "（" + items.size() + " 条）");
        site.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f);
        site.setTextColor(Shell.of(a).sub);
        LinearLayout.LayoutParams sitelp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        sitelp.topMargin = Ui.dp(a, 8);
        box.addView(site, sitelp);

        final CheckBox remember = new CheckBox(a);
        remember.setText("记住这个站点，以后都按这次的选择处理");
        remember.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f);
        remember.setTextColor(Shell.of(a).text);
        LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        rlp.topMargin = Ui.dp(a, 6);
        box.addView(remember, rlp);

        AlertDialog.Builder b = new AlertDialog.Builder(a);
        b.setTitle(NavGuard.shortHost(host));
        b.setView(box);
        b.setPositiveButton("放行", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface d, int w) {
                if (remember.isChecked()) {
                    GuardLists.add(a, WHITE, host);
                    Ui.toast(a, NavGuard.shortHost(host) + " → 白名单，以后直接放行");
                }
                for (NavGuard.Item it : items) {
                    NavGuard.noteManualRec(host, it.popup, true, it.url);
                }
                NavGuard.releaseItems(a, items);
            }
        });
        b.setNegativeButton("拦截", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface d, int w) {
                if (remember.isChecked()) {
                    GuardLists.add(a, BLACK, host);
                    Ui.toast(a, NavGuard.shortHost(host) + " → 黑名单，以后直接丢弃");
                }
                for (NavGuard.Item it : items) {
                    NavGuard.noteManualRec(host, it.popup, false, it.url);
                }
                NavGuard.blockItems(a, items);
                Ui.toast(a, "已拦截 " + items.size() + " 条");
            }
        });
        b.setNeutralButton("先放着", null);
        Ui.show(b.create());
    }

    // ------------------------------------------------------------ 管理面板

    /** 「更多 → 跳转拦截」点开的主面板：开关 + 两张名单的入口 */
    public static void manage(final MainActivity a) {
        if (a == null || a.isFinishing() || a.isDestroyed()) return;

        final int pad = Ui.dp(a, 20);
        LinearLayout box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(pad, Ui.dp(a, 10), pad, Ui.dp(a, 4));

        // 开关行：拦截弹窗与自动跳转
        LinearLayout swRow = new LinearLayout(a);
        swRow.setOrientation(LinearLayout.HORIZONTAL);
        swRow.setGravity(Gravity.CENTER_VERTICAL);
        TextView swLabel = new TextView(a);
        swLabel.setText("拦截网页跳转与弹窗");
        swLabel.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f);
        swLabel.setTextColor(Shell.of(a).text);
        swRow.addView(swLabel, new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        final Switch sw = new Switch(a);
        sw.setChecked(Prefs.guard(a));
        swRow.addView(sw, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        box.addView(swRow, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView swSub = new TextView(a);
        swSub.setText(Prefs.guard(a)
                ? "已开启：网页的跳转和弹窗先停下来，由你点底部按钮决定"
                : "已关闭：网页照常跳转、照常弹窗");
        swSub.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f);
        swSub.setTextColor(Shell.of(a).sub);
        LinearLayout.LayoutParams swSubLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        swSubLp.topMargin = Ui.dp(a, 2);
        box.addView(swSub, swSubLp);

        // 阅读模式搬到网页底部那颗按钮的面板里了（临时性的东西都在那边）
        TextView tip = new TextView(a);
        tip.setText("其余的临时操作（放行 / 拦截当前全部、临时放行、阅读模式）"
                + "都在网页底部那颗按钮里，网页有事时它会自己浮出来。");
        tip.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f);
        tip.setTextColor(Shell.of(a).sub);
        tip.setLineSpacing(0, 1.18f);
        LinearLayout.LayoutParams tipLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        tipLp.topMargin = Ui.dp(a, 14);
        box.addView(tip, tipLp);

        // 名单入口行
        box.addView(listEntry(a, "白名单",
                "这些站点的跳转和弹窗直接放行（" + get(a, WHITE).size() + " 个站点）",
                new Runnable() {
                    @Override
                    public void run() {
                        manageList(a, WHITE);
                    }
                }));
        box.addView(listEntry(a, "黑名单",
                "这些站点的跳转和弹窗直接丢弃（" + get(a, BLACK).size() + " 个站点）",
                new Runnable() {
                    @Override
                    public void run() {
                        manageList(a, BLACK);
                    }
                }));

        AlertDialog.Builder b = new AlertDialog.Builder(a);
        b.setTitle("网页控制");
        b.setView(box);
        b.setNegativeButton("完成", null);
        final AlertDialog d = b.create();

        // 开关直接生效；关掉顺手把队列和临时决策清了
        sw.setOnCheckedChangeListener(new android.widget.CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(android.widget.CompoundButton btn, boolean checked) {
                if (checked == Prefs.guard(a)) return;
                Prefs.toggleGuard(a);
            }
        });

        Ui.show(d);
    }

    private static View listEntry(Context a, String title, String sub, final Runnable open) {
        LinearLayout row = new LinearLayout(a);
        row.setOrientation(LinearLayout.VERTICAL);
        row.setClickable(true);
        row.setFocusable(true);
        row.setBackground(Ui.pressBackground(a));
        int pad = Ui.dp(a, 8);
        row.setPadding(pad, pad * 3 / 2, pad, pad * 3 / 2);

        TextView t = new TextView(a);
        t.setText(title);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14.5f);
        t.setTextColor(Shell.of(a).text);
        row.addView(t);

        TextView s = new TextView(a);
        s.setText(sub);
        s.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f);
        s.setTextColor(Shell.of(a).sub);
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        slp.topMargin = Ui.dp(a, 2);
        row.addView(s, slp);

        row.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                open.run();
            }
        });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = Ui.dp(a, 10);
        // 行与行之间画一条细分割线
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.TRANSPARENT);
        LinearLayout wrap = new LinearLayout(a);
        wrap.setOrientation(LinearLayout.VERTICAL);
        wrap.setBackground(divider(a));
        wrap.setPadding(0, Ui.dp(a, 1), 0, 0);
        wrap.addView(row, lp);
        return wrap;
    }

    private static android.graphics.drawable.Drawable divider(Context a) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(0x1F888888);
        d.setSize(ViewGroup.LayoutParams.MATCH_PARENT, Math.max(1, Ui.dp(a, 1)));
        return d;
    }

    // ------------------------------------------------------------ 名单编辑

    /** 单张名单的编辑页：列出站点（点一个删一个），顶部「添加站点」 */
    public static void manageList(final MainActivity a, final int which) {
        if (a == null || a.isFinishing() || a.isDestroyed()) return;

        final int pad = Ui.dp(a, 12);
        LinearLayout box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);

        View add = addRow(a, which);
        box.addView(add, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        ScrollView sv = new ScrollView(a);
        sv.setVerticalScrollBarEnabled(false);
        LinearLayout list = new LinearLayout(a);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(pad, Ui.dp(a, 2), pad, Ui.dp(a, 6));

        ArrayList<String> hosts = get(a, which);
        if (hosts.isEmpty()) {
            TextView empty = new TextView(a);
            empty.setText(which == WHITE ? "还没有放行站点" : "还没有拦截站点");
            empty.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f);
            empty.setTextColor(Shell.of(a).sub);
            empty.setGravity(Gravity.CENTER);
            empty.setPadding(0, Ui.dp(a, 18), 0, Ui.dp(a, 10));
            list.addView(empty);
        } else {
            for (final String h : hosts) {
                list.addView(hostRow(a, h, which));
            }
        }
        sv.addView(list, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        box.addView(sv, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(a, 300)));

        AlertDialog.Builder b = new AlertDialog.Builder(a);
        b.setTitle(which == WHITE ? "白名单" : "黑名单");
        b.setView(box);
        b.setNegativeButton("完成", null);
        Ui.show(b.create());
    }

    private static View hostRow(final MainActivity a, final String host, final int which) {
        TextView t = new TextView(a);
        t.setText(host);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f);
        t.setTextColor(Shell.of(a).text);
        t.setSingleLine(true);
        t.setEllipsize(TextUtils.TruncateAt.MIDDLE);
        int pad = Ui.dp(a, 10);
        t.setPadding(pad, pad, pad, pad);
        t.setClickable(true);
        t.setFocusable(true);
        t.setBackground(Ui.pressBackground(a));
        t.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Ui.confirm(a, "从名单移除？", host,
                        which == WHITE ? "移出白名单" : "移出黑名单",
                        new Runnable() {
                            @Override
                            public void run() {
                                remove(a, which, host);
                                Ui.toast(a, "已移除 " + host);
                                manageList(a, which);   // 重建刷新
                            }
                        }, null);
            }
        });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = Ui.dp(a, 1);
        LinearLayout wrap = new LinearLayout(a);
        wrap.setOrientation(LinearLayout.VERTICAL);
        wrap.setBackground(divider(a));
        wrap.addView(t, lp);
        return wrap;
    }

    private static View addRow(final MainActivity a, final int which) {
        TextView t = new TextView(a);
        t.setText("＋ 添加站点");
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f);
        t.setTextColor(Shell.of(a).accent);
        t.setGravity(Gravity.CENTER);
        int pad = Ui.dp(a, 10);
        t.setPadding(0, pad, 0, pad);
        t.setClickable(true);
        t.setFocusable(true);
        t.setBackground(Ui.pressBackground(a));
        t.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                inputHost(a, which);
            }
        });
        LinearLayout wrap = new LinearLayout(a);
        wrap.setOrientation(LinearLayout.VERTICAL);
        wrap.setBackground(divider(a));
        wrap.addView(t, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return wrap;
    }

    private static void inputHost(final MainActivity a, final int which) {
        final int pad = Ui.dp(a, 20);
        LinearLayout box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(pad, Ui.dp(a, 6), pad, Ui.dp(a, 2));

        final EditText et = new EditText(a);
        et.setSingleLine(true);
        et.setHint("例如 example.com 或 https://a.example.com/page");
        et.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f);
        et.setInputType(android.text.InputType.TYPE_TEXT_VARIATION_URI);
        box.addView(et);

        AlertDialog.Builder b = new AlertDialog.Builder(a);
        b.setTitle(which == WHITE ? "添加到白名单" : "添加到黑名单");
        b.setView(box);
        b.setNegativeButton("取消", null);
        b.setPositiveButton("添加", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface d, int w) {
                String h = normalize(String.valueOf(et.getText()));
                if (TextUtils.isEmpty(h)) {
                    Ui.toast(a, "站点不能为空");
                    return;
                }
                add(a, which, h);
                Ui.toast(a, "已添加 " + h + " 到"
                        + (which == WHITE ? "白名单" : "黑名单"));
                manageList(a, which);   // 重建刷新
            }
        });
        AlertDialog d = b.create();
        Ui.show(d);
        et.requestFocus();
    }
}
