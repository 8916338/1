package com.shanqiu.app;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * 浏览历史面板。
 *
 * 每行：标题（主文字）/ 地址（次要文字，过长中间省略）/ 时间（更淡）。
 *   点一下   → 在当前壳里打开
 *   长按     → 新窗口打开 / 后台打开 / 删除
 *   左右划   → 直接删掉这一条（行跟着滑出消失）
 * 顶部「清空」一次删光。
 *
 * 操作逻辑和书签行完全一致：长按三个选项，横划直接删。
 */
public final class HistoryDialog {

    private HistoryDialog() {
    }

    public static void show(final MainActivity a) {
        if (a == null) return;
        final List<History.Item> items = History.load(a);

        if (items.isEmpty()) {
            Ui.show(new AlertDialog.Builder(a)
                    .setTitle("历史")
                    .setMessage("还没有浏览记录。")
                    .setNegativeButton("关闭", null)
                    .create());
            return;
        }

        final AlertDialog dlg = new AlertDialog.Builder(a)
                .setTitle("历史 · " + items.size() + " 条")
                .setNegativeButton("关闭", null)
                .setNeutralButton("清空", null)
                .create();

        final LinearLayout root = new LinearLayout(a);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(Ui.dp(a, 4), Ui.dp(a, 8), Ui.dp(a, 4), Ui.dp(a, 8));

        SimpleDateFormat fmt = new SimpleDateFormat("MM-dd HH:mm", Locale.CHINA);
        for (final History.Item it : items) {
            root.addView(row(a, it, fmt, dlg, root), rowParams(a));
        }

        ScrollView sv = new ScrollView(a);
        sv.setFillViewport(false);
        sv.addView(root, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        dlg.setView(sv);

        if (!a.isFinishing()) {
            Ui.show(dlg);
            dlg.getButton(DialogInterface.BUTTON_NEUTRAL).setOnClickListener(
                    new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            AlertDialog confirm = new AlertDialog.Builder(a)
                                    .setTitle("清空历史")
                                    .setMessage("把所有浏览记录删掉？此操作不可恢复。")
                                    .setNegativeButton("取消", null)
                                    .setPositiveButton("清空", new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface d, int w) {
                                            History.clear(a);
                                            dlg.dismiss();
                                            Ui.toast(a, "历史已清空");
                                        }
                                    })
                                    .create();
                            Ui.show(confirm);
                        }
                    });
        }
    }

    private static LinearLayout.LayoutParams rowParams(Context a) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = Ui.dp(a, 1);
        return lp;
    }

    private static View row(final MainActivity a, final History.Item it,
                            SimpleDateFormat fmt, final AlertDialog dlg,
                            final ViewGroup list) {
        Theme.Palette p = Shell.of(a);

        final LinearLayout row = new LinearLayout(a);
        row.setOrientation(LinearLayout.VERTICAL);
        row.setPadding(Ui.dp(a, 14), Ui.dp(a, 10), Ui.dp(a, 14), Ui.dp(a, 10));
        row.setBackground(rowBg(a, p));

        final String title = TextUtils.isEmpty(it.title)
                ? Bookmarks.labelOf(it.url) : it.title;

        TextView t = new TextView(a);
        t.setText(title);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14.5f);
        t.setTextColor(p.text);
        t.getPaint().setFakeBoldText(true);
        t.setSingleLine(true);
        t.setEllipsize(TextUtils.TruncateAt.END);
        row.addView(t);

        TextView u = new TextView(a);
        u.setText(it.url);
        u.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f);
        u.setTextColor(p.sub);
        u.setSingleLine(true);
        u.setEllipsize(TextUtils.TruncateAt.MIDDLE);
        LinearLayout.LayoutParams ulp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        ulp.topMargin = Ui.dp(a, 2);
        row.addView(u, ulp);

        TextView time = new TextView(a);
        time.setText(fmt.format(new Date(it.time)));
        time.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10.5f);
        time.setTextColor(p.icon);
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        tlp.topMargin = Ui.dp(a, 2);
        row.addView(time, tlp);

        row.setClickable(true);
        row.setFocusable(true);
        row.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dlg.dismiss();
                a.openInside(it.url);
            }
        });
        row.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                v.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS);
                dlg.dismiss();
                RowAction.show(a, title, it.url, new Runnable() {
                    @Override
                    public void run() {
                        History.remove(a, it.url);
                        Ui.toast(a, "已删除这条历史");
                    }
                });
                return true;
            }
        });

        // 横划删除：不问，直接删（行滑出、记录移除）
        SwipeRow.attach(row, new SwipeRow.OnDelete() {
            @Override
            public boolean beforeDelete(View v) {
                return true;
            }

            @Override
            public void onDelete(View v) {
                History.remove(a, it.url);
                Ui.toast(a, "已删除这条历史");
                if (list != null) {
                    list.removeView(row);
                    if (list.getChildCount() == 0 && dlg.isShowing()) dlg.dismiss();
                }
            }
        });
        return row;
    }

    private static StateListDrawable rowBg(Context c, Theme.Palette p) {
        GradientDrawable pressed = new GradientDrawable();
        pressed.setColor(p.press);
        pressed.setCornerRadius(Ui.dp(c, 10));

        GradientDrawable normal = new GradientDrawable();
        normal.setColor(0x00000000);
        normal.setCornerRadius(Ui.dp(c, 10));

        StateListDrawable sl = new StateListDrawable();
        sl.addState(new int[]{android.R.attr.state_pressed}, pressed);
        sl.addState(new int[]{}, normal);
        return sl;
    }
}
