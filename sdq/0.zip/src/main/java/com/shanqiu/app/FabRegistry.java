package com.shanqiu.app;

/**
 * 由 tools/apply_config.py 生成，不要手改。
 * 只登记 features 中开启的悬浮球功能模块；关闭的模块连类名都不会出现。
 *
 * 注意：其它类（MainActivity / MoreMenu）一律通过本类间接调用可裁剪模块，
 * 不要直接写 Updater.xxx / DownloadsDialog.xxx，否则关掉开关就编译不过。
 */
public final class FabRegistry {

    private FabRegistry() {
    }

    /** 处理由功能模块负责的菜单项；返回 true 表示已消费。 */
    public static boolean handle(MainActivity a, String id) {
        if ("downloads".equals(id)) { DownloadsDialog.show(a); return true; }
        if ("history".equals(id)) { HistoryDialog.show(a); return true; }
        if ("update".equals(id)) { Updater.checkManually(a); return true; }
        return false;
    }

    /** 启动时的自动检测更新（模块被裁掉时是空实现）。 */
    public static void autoUpdateCheck(MainActivity a) {
        Updater.autoCheck(a);
    }

    /** 后台 / 多窗口模块是否打包进来（features.background） */
    public static boolean hasBackground() {
        return true;
    }

    /** 书签列表末尾的「后台」项：打开后台窗口管理 */
    public static void openBackgroundPanel(MainActivity a) {
        Background.show(a);
    }

    /** 后台打开（预加载，不打断当前页） */
    public static void openInBackground(MainActivity a, String url) {
        Background.openBackground(a, url);
    }

    /** 新窗口打开（当前页转入后台列表） */
    public static void openInNewWindow(MainActivity a, String url) {
        Background.openNewWindow(a, url);
    }

    /** 长按书签 / 链接时弹的二选一 */
    public static void chooseWindow(MainActivity a, String url) {
        Background.chooseWindow(a, url);
    }

    /** 新建窗口：直接加载初始页 */
    public static void openNewStartWindow(MainActivity a) {
        Background.newStartWindow(a);
    }

    /** 后台页的渲染进程挂了：清掉 */
    public static void onWebGone(android.webkit.WebView v) {
        Background.onWebGone(v);
    }

    /** 退出时清理所有后台页 */
    public static void destroyBackgrounds() {
        Background.destroyAll();
    }

}
