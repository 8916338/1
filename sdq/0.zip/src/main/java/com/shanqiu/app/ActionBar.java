package com.shanqiu.app;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * 闪电球弹窗靠球那一侧的横向图标条。
 *
 * 内容、顺序、开关、分排全部来自 app-config.json 的 fab.toolbar：
 *
 *   "toolbar": [
 *     { "id": "refresh", "title": "刷新", "enabled": true, "row": 1 },
 *     { "id": "home",    "title": "首页", "enabled": true, "row": 2 }
 *   ]
 *
 * 可用 id：refresh / home / forward / back / scan / share / history /
 *          downloads / background / bookmark / find / more / sniff。
 *
 * row = 第几排（1 是靠近列表的那一排，2 是再往内一排）。
 * 同一排按数组顺序从左到右、等宽均分；enabled=false 的项不出现；
 * 全关掉时整条不占位。
 */
public final class ActionBar extends LinearLayout {

    public interface OnAction {
        void onAction(String id);
    }

    private static final int BTN_H_DP = 34;
    private static final int ROW_GAP_DP = 3;

    public ActionBar(Context c, final MainActivity a, final OnAction cb) {
        super(c);
        setOrientation(VERTICAL);
        setPadding(Ui.dp(c, 5), Ui.dp(c, 5), Ui.dp(c, 5), Ui.dp(c, 5));

        final Theme.Palette p = Shell.of(c);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(p.press);
        bg.setCornerRadius(Ui.dp(c, 12));
        setBackground(bg);

        JSONArray items = items();
        // 按 row 分组，保持配置顺序
        List<List<JSONObject>> rows = new ArrayList<>();
        int maxRow = 0;
        for (int i = 0; i < items.length(); i++) {
            JSONObject o = items.optJSONObject(i);
            if (o == null) continue;
            if (!o.optBoolean("enabled", true)) continue;
            final String tid0 = o.optString("id", "");
            if (tid0.length() == 0) continue;
            // 功能没打包 / 没数据（比如没配赞赏码、关掉下载模块）就别留个死按钮
            if (!Menu.available(a, tid0)) continue;
            int r = Math.max(1, o.optInt("row", 1)) - 1;
            while (rows.size() <= r) rows.add(new ArrayList<JSONObject>());
            rows.get(r).add(o);
            maxRow = Math.max(maxRow, r);
        }

        int added = 0;
        for (int r = 0; r <= maxRow; r++) {
            if (r >= rows.size()) continue;
            List<JSONObject> row = rows.get(r);
            if (row.isEmpty()) continue;

            LinearLayout line = new LinearLayout(c);
            line.setOrientation(HORIZONTAL);
            line.setGravity(Gravity.CENTER_VERTICAL);

            for (int i = 0; i < row.size(); i++) {
                JSONObject o = row.get(i);
                final String id = o.optString("id", "");
                String title = o.optString("title", "");
                if (title == null || title.length() == 0) title = titleOf(id);

                ImageView btn = new ImageView(c);
                btn.setImageResource(iconOf(id));
                btn.setContentDescription(title);
                btn.setScaleType(ImageView.ScaleType.FIT_CENTER);
                btn.setPadding(Ui.dp(c, 8), Ui.dp(c, 8), Ui.dp(c, 8), Ui.dp(c, 8));
                btn.setBackground(rowBackground(c, 8, p));
                btn.setClickable(true);
                btn.setImageTintList(tint(p.icon, p.accent));
                btn.setImageTintMode(android.graphics.PorterDuff.Mode.SRC_IN);
                btn.setTag(id);
                btn.setOnClickListener(new OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (cb != null) cb.onAction(id);
                    }
                });

                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0,
                        Ui.dp(c, BTN_H_DP), 1f);
                lp.setMargins(Ui.dp(c, 1), 0, Ui.dp(c, 1), 0);
                line.addView(btn, lp);
                added++;
            }

            LinearLayout.LayoutParams rowLp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, Ui.dp(c, BTN_H_DP));
            if (r > 0) rowLp.topMargin = Ui.dp(c, ROW_GAP_DP);
            addView(line, rowLp);
        }

        // 全被关掉时不占空间，弹窗把位置让给列表
        if (added == 0) setVisibility(GONE);
    }

    /** 缩略高度（不测量时给 QuickMenu 算总高用） */
    public static int heightDp(Context c) {
        JSONArray items = items();
        int maxRow = 0;
        int added = 0;
        for (int i = 0; i < items.length(); i++) {
            JSONObject o = items.optJSONObject(i);
            if (o == null) continue;
            if (!o.optBoolean("enabled", true)) continue;
            if (o.optString("id", "").length() == 0) continue;
            maxRow = Math.max(maxRow, Math.max(1, o.optInt("row", 1)));
            added++;
        }
        if (added == 0) return 0;
        return maxRow * BTN_H_DP + Math.max(0, maxRow - 1) * ROW_GAP_DP + 10;
    }

    /** 配置损坏时返回空数组，弹窗只显示列表 */
    private static JSONArray items() {
        try {
            return new JSONArray(Config.FAB_TOOLBAR_JSON);
        } catch (Throwable t) {
            return new JSONArray();
        }
    }

    private static int iconOf(String id) {
        switch (id) {
            case "refresh": return R.drawable.ic_q_refresh;
            case "home": return R.drawable.ic_q_home;
            case "forward": return R.drawable.ic_q_next;
            case "back": return R.drawable.ic_q_prev;
            case "scan": return R.drawable.ic_q_scan;
            case "share": return R.drawable.ic_q_share;
            case "history": return R.drawable.ic_q_history;
            case "downloads": return R.drawable.ic_q_download;
            case "background": return R.drawable.ic_q_layer;
            case "bookmark": return R.drawable.ic_q_star;
            case "find": return R.drawable.ic_q_search;
            case "more": return R.drawable.ic_q_more;
            case "sniff": return R.drawable.ic_q_download;
            case "play": return R.drawable.ic_q_play;
            default: return R.drawable.ic_q_web;
        }
    }

    private static String titleOf(String id) {
        switch (id) {
            case "refresh": return "刷新";
            case "home": return "回到首页";
            case "forward": return "前进";
            case "back": return "后退";
            case "scan": return "扫描二维码";
            case "share": return "分享本页网址";
            case "history": return "历史";
            case "downloads": return "下载内容";
            case "background": return "后台";
            case "bookmark": return "收藏本页";
            case "find": return "页面查找";
            case "more": return "更多";
            case "sniff": return "视频嗅探";
            default: return id;
        }
    }

    private static ColorStateList tint(int normal, int pressed) {
        return new ColorStateList(
                new int[][]{new int[]{android.R.attr.state_pressed}, new int[]{}},
                new int[]{pressed, normal});
    }

    private static StateListDrawable rowBackground(Context c, int radiusDp, Theme.Palette p) {
        GradientDrawable pressed = new GradientDrawable();
        pressed.setColor(0x1A000000);
        pressed.setCornerRadius(Ui.dp(c, radiusDp));

        GradientDrawable normal = new GradientDrawable();
        normal.setColor(0x00000000);
        normal.setCornerRadius(Ui.dp(c, radiusDp));

        StateListDrawable sl = new StateListDrawable();
        sl.addState(new int[]{android.R.attr.state_pressed}, pressed);
        sl.addState(new int[]{}, normal);
        return sl;
    }
}
