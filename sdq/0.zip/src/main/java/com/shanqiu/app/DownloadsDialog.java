package com.shanqiu.app;

import android.app.AlertDialog;
import android.app.DownloadManager;
import android.content.Context;
import android.content.Intent;
import android.content.DialogInterface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

/**
 * 闪电球「下载」：查看并管理本应用发起过的下载。
 *
 * 卡片（默认只显示两行，点一下展开）：

 *   上排：文件名
 *   下排：大小 · 时间 · 状态
 *   下载中：状态行额外显示「百分比 · 网速 · 已下 / 总量」
 *
 * 交互：
 *   点卡片    → 展开 / 收起功能区（打开 / 重命名 / 复制 / 剪切 / 移动 / 删除）
 *   左右横划  → 问一句「删记录还是连文件一起删」，有取消
 *
 * 文件操作全部在壳内完成（FileOps），不再跳系统文件管理器。
 * 本类属于可裁剪功能：features.downloads=false 时不编译进包。
 */
public final class DownloadsDialog {

    private static final int MAX_ROWS = 200;

    private static final int C_DONE = 0xFF16A34A;
    private static final int C_RUN = 0xFFD97706;
    private static final int C_FAIL = 0xFFDC2626;
    private static final int C_DIM = 0xFF6B7280;

    private DownloadsDialog() {
    }

    public static final class Rec {
        long id;
        String name;
        String url;
        String localUri;
        /** 本应用私有缓存里的副本地址（下载完成时记下的，永远可读） */
        String cache;
        String mime;
        long size;
        long done;
        long time;
        int status;
        int reason;
    }

    /** 一张卡片需要被定时刷新的部件 */
    private static final class Card {
        Rec r;
        TextView status;
        TextView detail;
        View ops;
        long lastDone;
        long lastTs;
    }

    public static void show(final MainActivity a) {
        final DownloadManager dm = (DownloadManager) a.getSystemService(Context.DOWNLOAD_SERVICE);
        if (dm == null) {
            Ui.toast(a, "系统下载器不可用");
            return;
        }

        final List<Rec> recs = query(a, dm);

        final AlertDialog dlg = new AlertDialog.Builder(a)
                .setTitle("下载内容")
                .setNegativeButton("关闭", null)
                .create();

        LinearLayout root = new LinearLayout(a);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(Ui.dp(a, 4), Ui.dp(a, 6), Ui.dp(a, 4), Ui.dp(a, 6));

        TextView hint = new TextView(a);
        hint.setText("点条目展开操作 · 左右滑动删除记录");
        hint.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f);
        hint.setTextColor(Shell.of(a).sub);
        hint.setPadding(Ui.dp(a, 10), 0, Ui.dp(a, 10), Ui.dp(a, 8));
        root.addView(hint, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        final List<Card> cards = new ArrayList<>();

        if (recs.isEmpty()) {
            root.addView(emptyView(a), new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        } else {
            SimpleDateFormat fmt = new SimpleDateFormat("MM-dd HH:mm", Locale.CHINA);
            for (int i = 0; i < recs.size(); i++) {
                final Rec r = recs.get(i);
                LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                rlp.bottomMargin = Ui.dp(a, 7);
                Card card = new Card();
                card.r = r;
                root.addView(cardView(a, dlg, card, fmt, cards), rlp);
                cards.add(card);
            }
        }

        ScrollView sv = new ScrollView(a);
        sv.setFillViewport(false);
        sv.addView(root, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        dlg.setView(sv);
        Ui.show(dlg);

        // 下载中的卡片每秒刷一次：百分比、网速、已下 / 总量
        final Handler ui = new Handler(Looper.getMainLooper());
        final Runnable tick = new Runnable() {
            @Override
            public void run() {
                if (!dlg.isShowing()) return;
                tickRunning(dm, cards);
                ui.postDelayed(this, 1000);
            }
        };
        ui.postDelayed(tick, 1000);
        dlg.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface d) {
                ui.removeCallbacksAndMessages(null);
            }
        });
    }

    /** 空态：和有记录时同一套面板壳，只是列表位置放一段提示 */
    private static View emptyView(Context a) {
        LinearLayout box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        box.setPadding(Ui.dp(a, 30), Ui.dp(a, 44), Ui.dp(a, 30), Ui.dp(a, 44));

        TextView ico = new TextView(a);
        ico.setText("\u2B07");
        ico.setTextSize(TypedValue.COMPLEX_UNIT_SP, 34f);
        ico.setGravity(Gravity.CENTER);
        box.addView(ico);

        TextView t = new TextView(a);
        t.setText("还没有下载记录");
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f);
        t.setTextColor(Shell.of(a).text);
        t.getPaint().setFakeBoldText(true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(0, Ui.dp(a, 12), 0, 0);
        box.addView(t);

        TextView tip = new TextView(a);
        tip.setText("在网页里点下载链接、选「下载到手机」，\n文件会出现在这里。");
        tip.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f);
        tip.setTextColor(Shell.of(a).sub);
        tip.setGravity(Gravity.CENTER);
        tip.setLineSpacing(Ui.dp(a, 3), 1f);
        tip.setPadding(0, Ui.dp(a, 8), 0, 0);
        box.addView(tip);
        return box;
    }

    // ------------------------------------------------------------ 单张卡片

    private static View cardView(final MainActivity a, final AlertDialog dlg,
                                 final Card card, SimpleDateFormat fmt,
                                 final List<Card> all) {
        final Rec r = card.r;
        final Theme.Palette p = Shell.of(a);

        final LinearLayout box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(Ui.dp(a, 13), Ui.dp(a, 10), Ui.dp(a, 13), Ui.dp(a, 10));

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(p.panel);
        bg.setCornerRadius(Ui.dp(a, 12));
        bg.setStroke(Math.max(1, Ui.dp(a, 0.8f)), p.border);
        box.setBackground(bg);
        box.setClickable(true);
        box.setFocusable(true);

        // ---- 第一排：文件名 ----
        TextView name = new TextView(a);
        name.setText(r.name);
        name.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14.5f);
        name.setTextColor(p.text);
        name.getPaint().setFakeBoldText(true);
        name.setSingleLine(true);
        name.setEllipsize(TextUtils.TruncateAt.MIDDLE);
        box.addView(name);

        // ---- 第二排：大小 · 时间 · 状态 ----
        LinearLayout meta = new LinearLayout(a);
        meta.setOrientation(LinearLayout.HORIZONTAL);
        meta.setGravity(Gravity.CENTER_VERTICAL);
        meta.addView(chip(a, sizeText(r), p.accent, p.press));
        meta.addView(chip(a, fmt.format(new Date(r.time)), p.sub, p.press));
        int[] sc = statusColors(r.status);
        card.status = chip(a, statusText(r.status, r.done, r.size), sc[0],
                Theme.blend(sc[0], p.page, 0.14f));
        meta.addView(card.status);

        LinearLayout.LayoutParams mlp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        mlp.topMargin = Ui.dp(a, 5);
        box.addView(meta, mlp);

        // ---- 下载中才有的一行：百分比 · 网速 · 已下 / 总量 ----
        card.detail = new TextView(a);
        card.detail.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f);
        card.detail.setTextColor(p.sub);
        card.detail.setSingleLine(true);
        card.detail.setEllipsize(TextUtils.TruncateAt.END);
        LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        dlp.topMargin = Ui.dp(a, 4);
        card.detail.setLayoutParams(dlp);
        card.detail.setText(detailText(r, 0));
        card.detail.setVisibility(isRunning(r.status) ? View.VISIBLE : View.GONE);
        box.addView(card.detail);

        // ---- 功能区（点卡片才展开）----
        LinearLayout ops = new LinearLayout(a);
        ops.setOrientation(LinearLayout.VERTICAL);
        ops.setVisibility(View.GONE);
        card.ops = ops;

        LinearLayout r1 = new LinearLayout(a);
        r1.setOrientation(LinearLayout.HORIZONTAL);
        r1.addView(op(a, R.drawable.ic_q_web, "打开", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openFile(a, r, dlg);
            }
        }), opLp(a));
        r1.addView(op(a, R.drawable.ic_q_font, "重命名", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                doRename(a, card, all);
            }
        }), opLp(a));
        r1.addView(op(a, R.drawable.ic_q_layer, "复制", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                doTransfer(a, card, false, all);
            }
        }), opLp(a));

        LinearLayout r2 = new LinearLayout(a);
        r2.setOrientation(LinearLayout.HORIZONTAL);
        r2.addView(op(a, R.drawable.ic_q_next, "剪切", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                doTransfer(a, card, true, all);
            }
        }), opLp(a));
        r2.addView(op(a, R.drawable.ic_q_retry, "移动", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                doTransfer(a, card, true, all);
            }
        }), opLp(a));
        r2.addView(op(a, R.drawable.ic_q_delete, "删除", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                askDelete(a, card, box, dlg, all);
            }
        }), opLp(a));

        LinearLayout.LayoutParams olp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        olp.topMargin = Ui.dp(a, 8);
        ops.addView(r1, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        LinearLayout.LayoutParams r2lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        r2lp.topMargin = Ui.dp(a, 6);
        ops.addView(r2, r2lp);
        box.addView(ops, olp);

        // 点卡片：展开 / 收起功能区
        box.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean open = ops.getVisibility() == View.VISIBLE;
                ops.setVisibility(open ? View.GONE : View.VISIBLE);
                if (!open) ops.setAlpha(0f);
                if (!open) ops.animate().alpha(1f).setDuration(140).start();
            }
        });

        // 横划：问一句再删（记录删掉，文件可选）
        SwipeRow.attach(box, new SwipeRow.OnDelete() {
            @Override
            public boolean beforeDelete(View v) {
                askDelete(a, card, box, dlg, all);
                return false;
            }

            @Override
            public void onDelete(View v) {
                // 确认框里处理，这里不用做事
            }
        });

        return box;
    }

    private static LinearLayout.LayoutParams opLp(Context c) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        lp.rightMargin = Ui.dp(c, 6);
        return lp;
    }

    private static View op(Context c, int icon, String label, View.OnClickListener l) {
        Theme.Palette pal = Shell.of(c);
        LinearLayout b = new LinearLayout(c);
        b.setOrientation(LinearLayout.HORIZONTAL);
        b.setGravity(Gravity.CENTER);
        GradientDrawable d = new GradientDrawable();
        d.setColor(pal.press);
        d.setCornerRadius(Ui.dp(c, 9));
        b.setBackground(d);
        b.setPadding(Ui.dp(c, 6), Ui.dp(c, 7), Ui.dp(c, 6), Ui.dp(c, 7));
        b.setClickable(true);

        ImageView iv = new ImageView(c);
        iv.setImageResource(icon);
        iv.setImageTintList(android.content.res.ColorStateList.valueOf(pal.icon));
        LinearLayout.LayoutParams ilp = new LinearLayout.LayoutParams(Ui.dp(c, 13), Ui.dp(c, 13));
        ilp.rightMargin = Ui.dp(c, 4);
        b.addView(iv, ilp);

        TextView t = new TextView(c);
        t.setText(label);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f);
        t.setTextColor(pal.text);
        b.addView(t);

        b.setOnClickListener(l);
        return b;
    }

    private static TextView chip(Context c, String text, int fg, int bg) {
        TextView t = new TextView(c);
        t.setText(text);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f);
        t.setTextColor(fg);
        GradientDrawable d = new GradientDrawable();
        d.setColor(bg);
        d.setCornerRadius(Ui.dp(c, 6));
        t.setBackground(d);
        t.setPadding(Ui.dp(c, 6), Ui.dp(c, 2), Ui.dp(c, 6), Ui.dp(c, 2));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.rightMargin = Ui.dp(c, 6);
        t.setLayoutParams(lp);
        return t;
    }

    // ------------------------------------------------------------ 文件位置

    private static boolean isRunning(int status) {
        return status == DownloadManager.STATUS_RUNNING
                || status == DownloadManager.STATUS_PENDING
                || status == DownloadManager.STATUS_PAUSED;
    }

    /** 记录对应的文件：私有缓存副本优先（永远可读），其次下载目录 */
    private static File fileOf(Context c, Rec r) {
        try {
            if (!TextUtils.isEmpty(r.cache) && r.cache.startsWith("file://")) {
                File f = new File(Uri.parse(r.cache).getPath());
                if (f.exists()) return f;
            }
        } catch (Throwable ignored) {
        }
        try {
            if (!TextUtils.isEmpty(r.localUri) && r.localUri.startsWith("file://")) {
                File f = new File(Uri.parse(r.localUri).getPath());
                if (f.exists()) return f;
            }
        } catch (Throwable ignored) {
        }
        return new File(downloadDir(), Ui.safeName(r.name, "file_" + r.id));
    }

    /** 真正可读的那份（缓存副本 → 下载目录原件），都没有返回 null */
    private static File readable(Rec r) {
        try {
            if (!TextUtils.isEmpty(r.cache) && r.cache.startsWith("file://")) {
                File f = new File(Uri.parse(r.cache).getPath());
                if (f.exists() && f.length() > 0) return f;
            }
        } catch (Throwable ignored) {
        }
        File f = fileOf(null, r);
        return f != null && f.exists() && f.length() > 0 ? f : null;
    }

    static File downloadDir() {
        return Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
    }

    // ------------------------------------------------------------ 打开

    private static void openFile(final MainActivity a, final Rec r, final AlertDialog dlg) {
        File f = readable(r);
        if (f == null) {
            if (r.id >= 0 && r.status == DownloadManager.STATUS_SUCCESSFUL) {
                if (dlg != null) dlg.dismiss();
                openInDownloads(a);
                return;
            }
            Ui.toast(a, "文件还没下载完成：" + statusText(r.status, r.done, r.size));
            return;
        }
        Route.openFile(a, f);
    }

    static void openInDownloads(final MainActivity a) {
        try {
            Uri dirUri = android.provider.DocumentsContract.buildDocumentUri(
                    "com.android.externalstorage.documents", "primary:Download");
            android.content.Intent i = new android.content.Intent(android.content.Intent.ACTION_VIEW);
            i.setDataAndType(dirUri,
                    android.provider.DocumentsContract.Document.MIME_TYPE_DIR);
            i.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK);
            a.startActivity(i);
        } catch (Throwable t) {
            Ui.toast(a, "打不开下载目录，请到文件管理器里查看");
        }
    }

    // ------------------------------------------------------------ 重命名

    private static void doRename(final MainActivity a, final Card card, final List<Card> all) {
        if (!FileOps.ensure(a)) return;
        final Rec r = card.r;
        final File f = readable(r);
        if (f == null) {
            Ui.toast(a, "文件不在手机上，改不了名字");
            return;
        }

        final EditText input = new EditText(a);
        input.setSingleLine(true);
        input.setText(f.getName());
        input.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f);
        try {
            input.setSelection(0, f.getName().lastIndexOf('.') > 0
                    ? f.getName().lastIndexOf('.') : f.getName().length());
        } catch (Throwable ignored) {
        }

        int pad = Ui.dp(a, 20);
        LinearLayout wrap = new LinearLayout(a);
        wrap.setPadding(pad, Ui.dp(a, 8), pad, 0);
        wrap.addView(input, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        final AlertDialog d = new AlertDialog.Builder(a)
                .setTitle("重命名")
                .setView(wrap)
                .setNegativeButton("取消", null)
                .setPositiveButton("确定", null)
                .create();
        d.setOnShowListener(new DialogInterface.OnShowListener() {
            @Override
            public void onShow(DialogInterface di) {
                d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String name = String.valueOf(input.getText()).trim();
                        if (TextUtils.isEmpty(name)) {
                            Ui.toast(a, "名字不能为空");
                            return;
                        }
                        File dst = FileOps.rename(f, name);
                        if (dst == null) {
                            Ui.toast(a, "改名失败（同名文件已存在，或没有权限）");
                            return;
                        }
                        String old = r.name;
                        r.name = dst.getName();
                        r.localUri = "file://" + dst.getAbsolutePath();
                        if (!TextUtils.isEmpty(r.cache)) {
                            r.cache = "file://" + dst.getAbsolutePath();
                        }
                        Downloader.rename(a, r.id, old, r.name, "file://" + dst.getAbsolutePath());
                        d.dismiss();
                        Ui.toast(a, "已改名为 " + r.name);
                        refreshCards(a, card, all);
                    }
                });
            }
        });
        Ui.show(d);
    }

    // ------------------------------------------------------------ 复制 / 剪切 / 移动

    // ------------------------------------------------------------ 复制 / 剪切 / 移动（系统文件管理器选目录）

    public static final int REQ_TREE = 7101;

    /** 待执行的转移：树目录选择回来后接着做 */
    private static File pendingFile;
    private static boolean pendingMove;
    private static Card pendingCard;
    private static List<Card> pendingAll;

    /**
     * 复制 / 剪切 / 移动：弹**系统文件管理器**选目标文件夹（SAF），
     * 不再让用户手输绝对路径 —— 那玩意没人记得住。
     */
    private static void doTransfer(final MainActivity a, final Card card,
                                   final boolean move, final List<Card> all) {
        if (!FileOps.ensure(a)) return;
        final Rec r = card.r;
        final File f = readable(r);
        if (f == null) {
            Ui.toast(a, "文件不在手机上，动不了");
            return;
        }

        pendingFile = f;
        pendingMove = move;
        pendingCard = card;
        pendingAll = all;

        try {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION
                    | Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                    | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
            a.startActivityForResult(Intent.createChooser(i,
                    move ? "移动到（选目标文件夹）" : "复制到（选目标文件夹）"), REQ_TREE);
        } catch (Throwable t) {
            pendingFile = null;
            Ui.toast(a, "打不开系统文件管理器");
        }
    }

    /** MainActivity.onActivityResult 转发进来：用户选好了目标文件夹 */
    public static void onTreeResult(MainActivity a, int requestCode, int resultCode, Intent data) {
        if (requestCode != REQ_TREE) return;
        final File f = pendingFile;
        final boolean move = pendingMove;
        final Card card = pendingCard;
        final List<Card> all = pendingAll;
        pendingFile = null;
        pendingCard = null;
        pendingAll = null;
        if (f == null) return;
        if (resultCode != android.app.Activity.RESULT_OK || data == null
                || data.getData() == null) {
            return; // 用户取消了，什么都不做
        }
        final Uri tree = data.getData();

        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                final String result = transferToTree(a, f, tree, move);
                a.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (result == null) {
                            Ui.toast(a, move ? "移动失败（目标文件夹不让写入）" : "复制失败");
                            return;
                        }
                        if (move) {
                            if (card != null && card.r != null) {
                                card.r.localUri = null;
                            }
                            Ui.toast(a, "已移动到所选文件夹");
                            if (card != null) refreshCards(a, card, all);
                        } else {
                            Ui.toast(a, "已复制到所选文件夹");
                        }
                    }
                });
            }
        }, "vie-transfer");
        t.setPriority(Thread.MIN_PRIORITY + 1);
        t.start();
    }

    /**
     * 真正的搬文件：在 SAF 树里 createDocument 建同名文件，再把字节泵过去。
     * 移动 = 复制成功后删源文件。返回提示语，失败返回 null。
     */
    private static String transferToTree(MainActivity a, File src, Uri tree, boolean move) {
        try {
            android.content.ContentResolver cr = a.getContentResolver();
            Uri doc = android.provider.DocumentsContract.buildDocumentUriUsingTree(tree,
                    android.provider.DocumentsContract.getTreeDocumentId(tree));

            String mime = Mimes.fromName(src.getName());
            if (TextUtils.isEmpty(mime)) mime = "application/octet-stream";

            Uri out = null;
            String name = src.getName();
            for (int attempt = 0; attempt < 2 && out == null; attempt++) {
                try {
                    out = android.provider.DocumentsContract.createDocument(cr, doc, mime, name);
                } catch (Throwable t) {
                    // 有些目录只让建特定类型，换 octet-stream 再试一次
                    mime = "application/octet-stream";
                }
            }
            if (out == null) return null;

            java.io.InputStream in = null;
            java.io.OutputStream os = null;
            try {
                in = new java.io.FileInputStream(src);
                os = cr.openOutputStream(out, "w");
                if (os == null) throw new java.io.IOException("no stream");
                byte[] buf = new byte[64 * 1024];
                long total = 0;
                int n;
                while ((n = in.read(buf)) > 0) {
                    os.write(buf, 0, n);
                    total += n;
                }
                os.flush();
                if (total <= 0 && src.length() > 0) throw new java.io.IOException("empty");
            } finally {
                try {
                    if (in != null) in.close();
                } catch (Throwable ignored) {
                }
                try {
                    if (os != null) os.close();
                } catch (Throwable ignored) {
                }
            }

            if (move) {
                FileOps.delete(src);
            }
            return move ? "moved" : "copied";
        } catch (Throwable t) {
            return null;
        }
    }

    // ------------------------------------------------------------ 删除

    /** 删记录 / 连文件一起删 —— 自定义视图：两个明确选项 + 「确认删除」 */
    private static void askDelete(final MainActivity a, final Card card,
                                  final View box, final AlertDialog dlg, final List<Card> all) {
        final Rec r = card.r;
        final File f = readable(r);

        Theme.Palette p = Shell.of(a);
        LinearLayout wrap = new LinearLayout(a);
        wrap.setOrientation(LinearLayout.VERTICAL);
        int pad = Ui.dp(a, 22);
        wrap.setPadding(pad, Ui.dp(a, 8), pad, Ui.dp(a, 4));

        TextView msg = new TextView(a);
        msg.setText(f == null
                ? "文件已经不在手机上了，只会删掉记录"
                : "文件：" + f.getName() + "\n选择要删到什么程度：");
        msg.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f);
        msg.setTextColor(p.sub);
        wrap.addView(msg);

        // 两个选项（自绘单选，不依赖系统的 setItems / setSingleChoiceItems）
        final int[] sel = {0};   // 0 = 只删记录，1 = 连文件一起删
        final TextView[] optViews = new TextView[2];
        String[] texts = {"只删除记录（文件保留在手机上）",
                "删除记录和文件（文件会彻底删除）"};

        View.OnClickListener pick = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sel[0] = v.getId() == 101 ? 0 : 1;
                for (int i = 0; i < optViews.length; i++) {
                    boolean on = sel[0] == i;
                    Theme.Palette pp = Shell.of(a);
                    GradientDrawable bg = new GradientDrawable();
                    bg.setColor(on ? pp.press : pp.panel);
                    bg.setCornerRadius(Ui.dp(a, 12));
                    bg.setStroke(Math.max(1, Ui.dp(a, 1.2f)),
                            on ? pp.accent : pp.border);
                    optViews[i].setBackground(bg);
                    optViews[i].setTextColor(on ? pp.accent : pp.text);
                }
            }
        };

        for (int i = 0; i < 2; i++) {
            TextView o = new TextView(a);
            o.setText(texts[i]);
            o.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13.5f);
            o.setPadding(Ui.dp(a, 14), Ui.dp(a, 12), Ui.dp(a, 14), Ui.dp(a, 12));
            o.setId(i == 0 ? 101 : 102);
            o.setClickable(true);
            o.setOnClickListener(pick);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.topMargin = Ui.dp(a, 10);
            wrap.addView(o, lp);
            optViews[i] = o;
        }
        // 默认选中「只删除记录」
        optViews[0].performClick();

        // 确认 / 取消
        LinearLayout btns = new LinearLayout(a);
        btns.setOrientation(LinearLayout.HORIZONTAL);
        btns.setGravity(Gravity.END);
        TextView cancel = new TextView(a);
        cancel.setText("取消");
        styleBtn(cancel, a, p);
        TextView ok = new TextView(a);
        ok.setText("确认删除");
        styleBtn(ok, a, p);
        ok.getPaint().setFakeBoldText(true);
        LinearLayout.LayoutParams blp1 = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        blp1.leftMargin = Ui.dp(a, 10);
        btns.addView(cancel);
        btns.addView(ok, blp1);
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        blp.topMargin = Ui.dp(a, 14);
        wrap.addView(btns, blp);

        final AlertDialog[] holder = new AlertDialog[1];
        AlertDialog d = new AlertDialog.Builder(a)
                .setTitle("删除「" + r.name + "」")
                .setView(wrap)
                .create();

        ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (holder[0] != null) holder[0].dismiss();
                if (sel[0] == 0) {
                    removeRecord(a, r, box, dlg);
                    Ui.toast(a, "已删除记录，文件还在手机里");
                    return;
                }
                boolean okDel = f != null && FileOps.delete(f);
                removeRecord(a, r, box, dlg);
                Ui.toast(a, okDel ? "已删除记录和文件"
                        : "记录已删除（文件没删掉，可能没权限）");
            }
        });
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (holder[0] != null) holder[0].dismiss();
            }
        });

        holder[0] = d;
        Ui.show(d);
    }

    /** 弹窗按钮统一胶囊样式（和 Ui.styleActionButton 一致） */
    private static void styleBtn(TextView t, Context c, Theme.Palette p) {
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f);
        t.setTextColor(p.accent);
        t.setPadding(Ui.dp(c, 16), Ui.dp(c, 8), Ui.dp(c, 16), Ui.dp(c, 8));
        t.setBackground(Ui.chipBackground(c, p));
        t.setClickable(true);
    }

    /** 只清记录：台账 + 系统下载器里的任务，不动文件 */
    private static void removeRecord(final MainActivity a, final Rec r,
                                     final View box, final AlertDialog dlg) {
        Downloader.forget(a, r.id, r.name);
        if (r.id >= 0) {
            try {
                DownloadManager dm =
                        (DownloadManager) a.getSystemService(Context.DOWNLOAD_SERVICE);
                if (dm != null) dm.remove(r.id);
            } catch (Throwable ignored) {
            }
        }
        try {
            ViewGroup parent = (ViewGroup) box.getParent();
            if (parent != null) parent.removeView(box);
        } catch (Throwable ignored) {
        }
    }

    /** 改名 / 移动之后，把这张卡片上的文字就地更新 */
    private static void refreshCards(MainActivity a, Card card, List<Card> all) {
        if (card == null) return;
        try {
            View parent = (View) card.ops.getParent();
            if (parent instanceof LinearLayout) {
                LinearLayout box = (LinearLayout) parent;
                TextView name = (TextView) box.getChildAt(0);
                name.setText(card.r.name);
            }
        } catch (Throwable ignored) {
        }
    }

    // ------------------------------------------------------------ 定时刷新

    private static void tickRunning(DownloadManager dm, List<Card> cards) {
        if (dm == null || cards == null) return;
        long now = System.currentTimeMillis();
        for (Card c : cards) {
            if (c == null || c.r == null || !isRunning(c.r.status)) continue;
            long done = c.r.done;
            long total = c.r.size;
            int status = c.r.status;
            android.database.Cursor cur = null;
            try {
                cur = dm.query(new DownloadManager.Query().setFilterById(c.r.id));
                if (cur != null && cur.moveToFirst()) {
                    status = (int) getLong(cur, DownloadManager.COLUMN_STATUS, status);
                    done = getLong(cur, DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR, done);
                    long t = getLong(cur, DownloadManager.COLUMN_TOTAL_SIZE_BYTES, total);
                    if (t > 0) total = t;
                }
            } catch (Throwable ignored) {
            } finally {
                if (cur != null) cur.close();
            }

            long speed = 0;
            if (c.lastTs > 0 && now > c.lastTs && done >= c.lastDone) {
                speed = (done - c.lastDone) * 1000L / Math.max(1L, now - c.lastTs);
            }
            c.lastDone = done;
            c.lastTs = now;

            c.r.done = done;
            if (total > 0) c.r.size = total;
            c.r.status = status;

            if (c.status != null) {
                c.status.setText(statusText(status, done, total));
                int[] col = statusColors(status);
                GradientDrawable bg = new GradientDrawable();
                bg.setColor(Theme.blend(col[0], Shell.of(c.status.getContext()).page, 0.14f));
                bg.setCornerRadius(Ui.dp(c.status.getContext(), 6));
                c.status.setBackground(bg);
                c.status.setTextColor(col[0]);
            }
            if (c.detail != null) {
                c.detail.setText(detailText(c.r, speed));
                c.detail.setVisibility(isRunning(status) ? View.VISIBLE : View.GONE);
            }
        }
    }

    // ------------------------------------------------------------ 查询与文案

    public static List<Rec> query(MainActivity a, DownloadManager dm) {
        List<Rec> recs = new ArrayList<>();
        HashMap<Long, org.json.JSONObject> logs = new HashMap<>();
        org.json.JSONArray logArr = Downloader.log(a);
        for (int i = 0; i < logArr.length(); i++) {
            org.json.JSONObject o = logArr.optJSONObject(i);
            if (o == null) continue;
            logs.put(o.optLong("id", -1), o);
        }

        android.database.Cursor c = null;
        try {
            c = dm.query(new DownloadManager.Query());
            if (c != null) {
                while (c.moveToNext()) {
                    Rec r = new Rec();
                    r.id = getLong(c, DownloadManager.COLUMN_ID, -1);
                    if (r.id < 0) continue;
                    r.status = (int) getLong(c, DownloadManager.COLUMN_STATUS, 0);
                    r.size = getLong(c, DownloadManager.COLUMN_TOTAL_SIZE_BYTES, -1);
                    r.done = getLong(c, DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR, 0);
                    if (r.size <= 0) r.size = r.done;
                    r.time = getLong(c, DownloadManager.COLUMN_LAST_MODIFIED_TIMESTAMP, 0);
                    if (r.time <= 0) r.time = getLong(c, "timestamp", 0);
                    r.reason = (int) getLong(c, DownloadManager.COLUMN_REASON, 0);
                    r.url = getString(c, DownloadManager.COLUMN_URI);
                    r.localUri = getString(c, DownloadManager.COLUMN_LOCAL_URI);
                    r.mime = getString(c, DownloadManager.COLUMN_MEDIA_TYPE);

                    String title = getString(c, DownloadManager.COLUMN_TITLE);
                    String name = !TextUtils.isEmpty(title)
                            ? title : nameFrom(r.localUri, r.url);
                    r.name = TextUtils.isEmpty(name) ? ("下载 #" + r.id) : name;
                    if (r.time <= 0) r.time = System.currentTimeMillis();

                    // 改过名 / 移过位置：以台账为准，否则重启后又被系统标题盖回去
                    org.json.JSONObject log = logs.get(r.id);
                    if (log != null) {
                        String rn = log.optString("rname", "");
                        if (!TextUtils.isEmpty(rn)) r.name = rn;
                        String local = log.optString("local", "");
                        if (!TextUtils.isEmpty(local)) r.localUri = local;
                        String cache = log.optString("cache", "");
                        if (!TextUtils.isEmpty(cache)) r.cache = cache;
                    }
                    recs.add(r);
                }
            }
        } catch (Throwable ignored) {
        } finally {
            if (c != null) c.close();
        }

        // 系统下载器里查不到的老记录（换包名重装、ROM 清理任务列表），用本地台账补上
        java.util.HashSet<Long> seen = new java.util.HashSet<>();
        for (Rec r : recs) seen.add(r.id);

        for (int i = 0; i < logArr.length(); i++) {
            org.json.JSONObject o = logArr.optJSONObject(i);
            if (o == null) continue;
            long id = o.optLong("id", -1);
            if (id >= 0 && seen.contains(id)) continue;

            Rec r = new Rec();
            r.id = id;
            r.name = o.optString("name", "");
            r.url = o.optString("url", "");
            r.mime = o.optString("mime", "");
            r.time = o.optLong("time", 0);
            r.size = o.optLong("size", 0);
            r.localUri = o.optString("local", "");
            r.cache = o.optString("cache", "");
            String rn = o.optString("rname", "");
            if (!TextUtils.isEmpty(rn)) r.name = rn;

            File f = fileOf(a, r);
            if (f.exists() && f.length() > 0) {
                r.status = DownloadManager.STATUS_SUCCESSFUL;
                r.size = f.length();
                r.done = f.length();
            } else if (!TextUtils.isEmpty(r.cache)
                    && new File(Uri.parse(r.cache).getPath()).exists()) {
                r.status = DownloadManager.STATUS_SUCCESSFUL;
                File c2 = new File(Uri.parse(r.cache).getPath());
                r.size = c2.length();
                r.done = c2.length();
            } else if (r.id >= 0) {
                r.status = DownloadManager.STATUS_SUCCESSFUL;
            } else {
                r.status = -1;
            }
            if (TextUtils.isEmpty(r.name)) continue;
            if (id >= 0) seen.add(id);
            recs.add(r);
        }

        Collections.sort(recs, new Comparator<Rec>() {
            @Override
            public int compare(Rec x, Rec y) {
                return Long.compare(y.time, x.time);
            }
        });
        if (recs.size() > MAX_ROWS) recs.subList(MAX_ROWS, recs.size()).clear();
        return recs;
    }

    private static String sizeText(Rec r) {
        if (r.size <= 0) return "大小未知";
        return Ui.humanSize(r.size);
    }

    /** 下载中：45% · 1.2 MB/s · 12.3 MB / 27.4 MB */
    private static String detailText(Rec r, long speed) {
        if (!isRunning(r.status)) return "";
        StringBuilder sb = new StringBuilder();
        if (r.size > 0) {
            sb.append(r.done * 100 / r.size).append('%');
        } else {
            sb.append("—");
        }
        sb.append(" · ");
        sb.append(speed > 0 ? Ui.humanSize(speed) + "/s" : "…");
        if (r.size > 0) {
            sb.append(" · ").append(Ui.humanSize(r.done)).append(" / ").append(Ui.humanSize(r.size));
        }
        return sb.toString();
    }

    private static int[] statusColors(int status) {
        switch (status) {
            case DownloadManager.STATUS_SUCCESSFUL: return new int[]{C_DONE, C_DONE};
            case DownloadManager.STATUS_RUNNING:
            case DownloadManager.STATUS_PENDING:
            case DownloadManager.STATUS_PAUSED: return new int[]{C_RUN, C_RUN};
            case DownloadManager.STATUS_FAILED: return new int[]{C_FAIL, C_FAIL};
            default: return new int[]{C_DIM, C_DIM};
        }
    }

    public static String statusText(int status, long done, long total) {
        switch (status) {
            case DownloadManager.STATUS_SUCCESSFUL: return "已完成";
            case DownloadManager.STATUS_RUNNING:
                if (total > 0) return "下载中 " + (done * 100 / total) + "%";
                return "下载中";
            case DownloadManager.STATUS_PAUSED: return "已暂停";
            case DownloadManager.STATUS_PENDING: return "等待中";
            case DownloadManager.STATUS_FAILED: return "失败";
            case -1: return "记录已失效";
            default: return "未知";
        }
    }

    private static long getLong(android.database.Cursor c, String col, long def) {
        int i = c.getColumnIndex(col);
        if (i < 0) return def;
        try {
            return c.getLong(i);
        } catch (Throwable t) {
            return def;
        }
    }

    private static String getString(android.database.Cursor c, String col) {
        int i = c.getColumnIndex(col);
        if (i < 0) return null;
        try {
            return c.getString(i);
        } catch (Throwable t) {
            return null;
        }
    }

    private static String nameFrom(String localUri, String uri) {
        String s = !TextUtils.isEmpty(localUri) ? localUri : uri;
        if (TextUtils.isEmpty(s)) return null;
        s = Uri.decode(s);
        int q = s.indexOf('?');
        if (q >= 0) s = s.substring(0, q);
        int slash = s.lastIndexOf('/');
        return slash >= 0 ? s.substring(slash + 1) : s;
    }
}
