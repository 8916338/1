package com.shanqiu.app;

import android.text.TextUtils;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

/**
 * 「更多」面板。
 *
 * 面板里有什么、按什么顺序、叫什么名字，全部来自 app-config.json 的 fab.more：
 *
 *   "more": [
 *     { "id": "update",  "title": "检查更新", "enabled": true },
 *     { "id": "privacy", "title": "隐私模式", "enabled": true },
 *     { "id": "desktop", "title": "网页版本", "enabled": true },
 *     { "id": "ua",      "title": "浏览器标识", "enabled": true },
 *     { "id": "orient",  "title": "屏幕方向", "enabled": true },
 *     { "id": "font",    "title": "字体大小", "enabled": true },
 *     { "id": "theme",   "title": "主题", "enabled": true },
 *     { "id": "start",   "title": "初始页", "enabled": true },
 *     { "id": "coffee",  "title": "赞助", "enabled": true },
 *     { "id": "sniff",   "title": "视频嗅探", "enabled": true },
 *     { "id": "play",    "title": "在网页里看视频", "enabled": true }
 *   ]
 *
 * 每一项都显示当前状态（副行），点一下就切 / 弹选择框。
 * 可裁剪模块（更新）仍然经 FabRegistry 间接调用，关掉开关不会编译不过。
 */
public final class MoreMenu {

    private MoreMenu() {
    }

    public static void show(final MainActivity a) {
        if (a == null) return;

        JSONArray items;
        try {
            items = new JSONArray(Config.FAB_MORE_JSON);
        } catch (Throwable t) {
            items = new JSONArray();
        }

        ArrayList<QuickMenu.Row> rows = new ArrayList<>();

        for (int i = 0; i < items.length(); i++) {
            JSONObject o = items.optJSONObject(i);
            if (o == null) continue;
            String id = o.optString("id", "");
            if (TextUtils.isEmpty(id)) continue;
            if (!o.optBoolean("enabled", true)) continue;
            if ("update".equals(id) && !Config.FEATURE_UPDATE) continue;

            String title = o.optString("title", "");
            if (TextUtils.isEmpty(title)) title = defaultTitle(id);

            rows.add(new QuickMenu.Row(iconOf(id), title, subOf(a, id), id, null));
        }

        if (rows.isEmpty()) {
            Ui.toast(a, "「更多」里没有可用的项目");
            return;
        }

        QuickMenu.show(a, a.fab(), rows, false, new QuickMenu.Pick() {
            @Override
            public void onPick(String id, Object data) {
                if (id == null) return;
                switch (id) {
                    case "privacy":
                        Prefs.togglePrivacy(a);
                        break;
                    case "guard":
                        // 这里只管开关和两张名单；临时操作都在底部按钮的面板里
                        GuardLists.manage(a);
                        break;
                    case "plugin":
                        PluginMenu.show(a);
                        break;
                    case "desktop":
                        Prefs.toggleDesktop(a);
                        break;
                    case "ua":
                        Prefs.chooseUa(a);
                        break;
                    case "orient":
                        Prefs.chooseOrientation(a);
                        break;
                    case "font":
                        Prefs.chooseFont(a);
                        break;
                    case "theme":
                        // 不弹选择框：点一下换下一套，界面、网页、面板立即跟着换色
                        Prefs.cycleTheme(a);
                        break;
                    case "start":
                        Prefs.chooseStart(a);
                        break;
                    case "coffee":
                        Coffee.show(a);
                        break;
                    case "sniff":
                        Sniffer.show(a);
                        break;
                    case "play":
                        Sniffer.watch(a);
                        break;
                    default:
                        // 统一交给 FabRegistry：features.update=false 时这里不会有 Updater 的引用
                        FabRegistry.handle(a, id);
                        break;
                }
            }
        });
    }

    /** 副行：显示这一项的当前状态 */
    private static String subOf(MainActivity a, String id) {
        switch (id) {
            case "update":
                return "v" + Config.VERSION_NAME;
            case "privacy":
                return Prefs.privacy(a) ? "已开启 · 不记录历史" : "已关闭";
            case "guard":
                if (!Prefs.guard(a)) return "已关闭 · 网页照常跳转";
                return "已开启 · 白名单 " + GuardLists.get(a, GuardLists.WHITE).size()
                        + " · 黑名单 " + GuardLists.get(a, GuardLists.BLACK).size()
                        + "（点击管理）";
            case "plugin": {
                int all = PluginStore.list(a).size();
                if (all == 0) return "装一个 .js 插件，按它声明的网站自动生效";
                return "已装 " + all + " 个 · 启用 " + PluginStore.enabledCount(a) + " 个（点击管理）";
            }
            case "desktop":
                return Prefs.desktop(a) ? "电脑版" : "手机版";
            case "ua":
                return Prefs.uaName(a);
            case "orient":
                return Prefs.ORIENT_NAMES[Prefs.orientationIndex(a)];
            case "font":
                return Prefs.fontPercent(a) + "%";
            case "theme":
                return Theme.nameOf(Prefs.themeIndex(a)) + "（点击换下一套）";
            case "start":
                return Prefs.startName(a);
            case "sniff":
                return "抓取当前页的视频地址";
            case "play":
                return "原地全屏，不跳走";
            case "coffee":
                return "赞赏支持";
            default:
                return null;
        }
    }

    private static int iconOf(String id) {
        switch (id) {
            case "update": return R.drawable.ic_q_refresh;
            case "privacy": return R.drawable.ic_q_incognito;
            case "guard": return R.drawable.ic_q_web;
            case "plugin": return R.drawable.ic_q_layer;
            case "desktop": return R.drawable.ic_q_desktop;
            case "ua": return R.drawable.ic_q_ua;
            case "orient": return R.drawable.ic_q_rotate;
            case "font": return R.drawable.ic_q_font;
            case "theme": return R.drawable.ic_q_theme;
            case "start": return R.drawable.ic_q_home;
            case "sniff": return R.drawable.ic_q_download;
            case "play": return R.drawable.ic_q_play;
            case "coffee": return R.drawable.ic_q_coffee;
            default: return R.drawable.ic_q_more;
        }
    }

    private static String defaultTitle(String id) {
        switch (id) {
            case "update": return "检查更新";
            case "privacy": return "隐私模式";
            case "guard": return "网页控制";
            case "plugin": return "插件";
            case "desktop": return "网页版本";
            case "ua": return "浏览器标识";
            case "orient": return "屏幕方向";
            case "font": return "字体大小";
            case "theme": return "主题";
            case "start": return "初始页";
            case "sniff": return "视频嗅探";
            case "play": return "在网页里看视频";
            case "coffee": return "赞助";
            default: return id;
        }
    }
}
