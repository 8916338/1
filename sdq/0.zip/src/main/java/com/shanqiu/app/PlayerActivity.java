package com.shanqiu.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.VideoView;

/**
 * 视频播放器。两种出场方式：
 *
 *   play()  —— 独立全屏 Activity（黑底 + 系统 MediaController），
 *               适合 mp4 这类「抓到就能直接播」的地址。
 *   embed() —— 叠在网页上原位播（由 Sniffer.playInPage 调）：
 *               页面里那块视频的位置被一个黑块占住，我们把播放器盖在上面，
 *               底下一层网页还在（不动页面 DOM 坐标），关掉就恢复原样。
 *
 * 为什么要有 embed：
 *   网页播放器的全屏按钮走的是「请求浏览器宿主全屏」，而 WebView 默认
 *   不理会这个请求（第三方 iframe 更是完全不认）—— 这就是「点了没反应」。
 *   我们不请求了，直接当宿主自己画全屏：播放器本身就是全屏的，只是位置对齐。
 *
 * 全屏手势：双击画面进 / 出全屏（最常见的习惯），右上角也有按钮。
 */
public final class PlayerActivity extends Activity {

    private static final String EXTRA_URL = "url";
    private static final String EXTRA_TITLE = "title";

    /** 独立播放 */
    public static void play(Context c, String url, String title) {
        if (c == null || TextUtils.isEmpty(url)) return;
        try {
            Intent i = new Intent(c, PlayerActivity.class);
            i.putExtra(EXTRA_URL, url);
            i.putExtra(EXTRA_TITLE, title == null ? "" : title);
            if (!(c instanceof Activity)) i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            c.startActivity(i);
        } catch (Throwable t) {
            Ui.toast(c, "打不开播放器");
        }
    }

    // ================================================================ 叠在网页上播

    /** 当前那层播放器（同一时间只留一个，换视频先收掉旧的） */
    private static View overlay;
    private static VideoView overlayVv;

    /**
     * @param anchor 目标区域的屏幕坐标 {x, y, w, h}（由页面里的占位块量出来）
     */
    public static void embed(final MainActivity a, final String url,
                             final String title, final int[] anchor) {
        if (a == null || TextUtils.isEmpty(url)) return;
        ViewGroup root = a.overlayRoot();
        closeOverlay();

        // 根布局带系统栏内边距，子 View 的坐标是相对内沿的：
        // 宽高不传（=0）就表示「铺满可用区域」，交给 placeOverlay 去算。
        final int[] rect = anchor == null || anchor.length < 4
                ? new int[]{0, 0, 0, 0} : anchor;

        FrameLayout layer = new FrameLayout(a);
        layer.setBackgroundColor(Color.BLACK);

        final VideoView vv = new VideoView(a);
        layer.addView(vv, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        // 顶部：文件名 + 关闭
        LinearLayout top = new LinearLayout(a);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(Ui.dp(a, 14), Ui.dp(a, 8), Ui.dp(a, 8), Ui.dp(a, 8));

        TextView name = new TextView(a);
        name.setText(TextUtils.isEmpty(title) ? url : title);
        name.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f);
        name.setTextColor(0xE6FFFFFF);
        name.setSingleLine(true);
        name.setEllipsize(TextUtils.TruncateAt.MIDDLE);
        top.addView(name, new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        final TextView full = glass(a, "全屏");
        top.addView(full);

        TextView close = glass(a, "关闭");
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        clp.leftMargin = Ui.dp(a, 8);
        top.addView(close, clp);

        FrameLayout.LayoutParams tlp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        tlp.gravity = Gravity.TOP;
        // 半透明渐变压一层，免得白字压在亮画面上看不见
        GradientDrawable scrim = new GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{0xCC000000, 0x00000000});
        top.setBackground(scrim);
        layer.addView(top, tlp);

        // 底部：进度条 + 时间 + 播放暂停
        LinearLayout bottom = new LinearLayout(a);
        bottom.setOrientation(LinearLayout.HORIZONTAL);
        bottom.setGravity(Gravity.CENTER_VERTICAL);
        bottom.setPadding(Ui.dp(a, 12), Ui.dp(a, 6), Ui.dp(a, 12), Ui.dp(a, 8));

        final TextView playBtn = glass(a, "暂停");
        bottom.addView(playBtn);

        final SeekBar sb = new SeekBar(a);
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        slp.leftMargin = Ui.dp(a, 10);
        slp.rightMargin = Ui.dp(a, 10);
        bottom.addView(sb, slp);

        final TextView clock = new TextView(a);
        clock.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f);
        clock.setTextColor(0xCCFFFFFF);
        clock.setText("00:00 / 00:00");
        bottom.addView(clock);

        FrameLayout.LayoutParams blp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        blp.gravity = Gravity.BOTTOM;
        GradientDrawable scrim2 = new GradientDrawable(
                GradientDrawable.Orientation.BOTTOM_TOP,
                new int[]{0xCC000000, 0x00000000});
        bottom.setBackground(scrim2);
        layer.addView(bottom, blp);

        // 加载中的转圈
        final ProgressBar spin = new ProgressBar(a);
        spin.setIndeterminate(true);
        FrameLayout.LayoutParams plp = new FrameLayout.LayoutParams(
                Ui.dp(a, 40), Ui.dp(a, 40));
        plp.gravity = Gravity.CENTER;
        layer.addView(spin, plp);

        // 顶部/底部控件点一下才显示，平时让画面干净
        final View[] bars = {top, bottom};
        final boolean[] showing = {true};
        // 单击显隐控件，双击全屏 / 还原
        vv.setOnTouchListener(new View.OnTouchListener() {
            private long last;
            private float lx, ly;
            private boolean dbl;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                if (e.getAction() == MotionEvent.ACTION_DOWN) {
                    long now = System.currentTimeMillis();
                    if (now - last < 300) {
                        dbl = true;
                        doToggleFull(a, rect, layer);
                    }
                    last = now;
                    lx = e.getX();
                    ly = e.getY();
                } else if (e.getAction() == MotionEvent.ACTION_UP) {
                    boolean tap = Math.abs(e.getX() - lx) < Ui.dp(a, 14)
                            && Math.abs(e.getY() - ly) < Ui.dp(a, 14);
                    if (dbl) {
                        dbl = false;
                        return true;
                    }
                    if (tap && vv.isPlaying()) {
                        showing[0] = !showing[0];
                        for (View b : bars) b.setVisibility(showing[0] ? View.VISIBLE : View.GONE);
                    }
                }
                return false;
            }
        });

        overlay = layer;
        overlayVv = vv;

        placeOverlay(layer, rect, root);
        root.addView(layer);

        full.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                doToggleFull(a, rect, layer);
            }
        });
        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                closeAll(a);
            }
        });

        // 播放器自身
        try {
            vv.setVideoURI(Uri.parse(url));
            vv.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                @Override
                public void onPrepared(MediaPlayer mp) {
                    spin.setVisibility(View.GONE);
                    mp.setLooping(false);
                    sb.setMax(mp.getDuration());
                    vv.start();
                    playBtn.setText("暂停");
                }
            });
            vv.setOnInfoListener(new MediaPlayer.OnInfoListener() {
                @Override
                public boolean onInfo(MediaPlayer mp, int what, int extra) {
                    if (what == MediaPlayer.MEDIA_INFO_BUFFERING_START) spin.setVisibility(View.VISIBLE);
                    else if (what == MediaPlayer.MEDIA_INFO_BUFFERING_END) spin.setVisibility(View.GONE);
                    return false;
                }
            });
            vv.setOnErrorListener(new MediaPlayer.OnErrorListener() {
                @Override
                public boolean onError(MediaPlayer mp, int what, int extra) {
                    spin.setVisibility(View.GONE);
                    embedFail(a, url, title);
                    return true;
                }
            });
            vv.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer mp) {
                    playBtn.setText("重播");
                }
            });
        } catch (Throwable t) {
            spin.setVisibility(View.GONE);
            embedFail(a, url, title);
        }

        playBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    if (vv.isPlaying()) {
                        vv.pause();
                        playBtn.setText("播放");
                    } else {
                        vv.start();
                        playBtn.setText("暂停");
                    }
                } catch (Throwable ignored) {
                }
            }
        });

        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar s, int p, boolean fromUser) {
                if (fromUser) {
                    try {
                        vv.seekTo(p);
                    } catch (Throwable ignored) {
                    }
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar s) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar s) {
            }
        });

        final Runnable tick = new Runnable() {
            @Override
            public void run() {
                if (overlay != layer) return;
                try {
                    int cur = vv.getCurrentPosition();
                    int dur = vv.getDuration();
                    if (dur > 0 && sb.getMax() != dur) sb.setMax(dur);
                    sb.setProgress(cur);
                    clock.setText(clockOf(cur) + " / " + clockOf(dur));
                } catch (Throwable ignored) {
                }
                layer.postDelayed(this, 500);
            }
        };
        layer.postDelayed(tick, 500);
    }

    /** 把播放器层贴到目标区域上；宽或高为 0 表示铺满可用区域 */
    private static void placeOverlay(View layer, int[] rect, ViewGroup root) {
        FrameLayout.LayoutParams f;
        ViewGroup.LayoutParams lp = layer.getLayoutParams();
        if (lp instanceof FrameLayout.LayoutParams) {
            f = (FrameLayout.LayoutParams) lp;
        } else {
            f = new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        }
        int availW = 0, availH = 0;
        if (root != null) {
            availW = root.getWidth() - root.getPaddingLeft() - root.getPaddingRight();
            availH = root.getHeight() - root.getPaddingTop() - root.getPaddingBottom();
        }
        f.width = rect[2] > 0 ? rect[2] : availW;
        f.height = rect[3] > 0 ? rect[3] : availH;
        f.leftMargin = rect[0];
        f.topMargin = rect[1];
        f.gravity = Gravity.TOP | Gravity.START;
        layer.setLayoutParams(f);
        layer.requestLayout();
    }

    private static void doToggleFull(final Activity a, final int[] rect, View layer) {
        final ViewGroup root = (ViewGroup) layer.getParent();
        if (root == null) return;
        boolean isFull = layer.getTag() != null && Boolean.TRUE.equals(layer.getTag());
        FrameLayout.LayoutParams f = (FrameLayout.LayoutParams) layer.getLayoutParams();
        if (isFull) {
            layer.setTag(null);
            placeOverlay(layer, rect, root);
            try {
                a.getWindow().getDecorView().setSystemUiVisibility(
                        View.SYSTEM_UI_FLAG_VISIBLE);
                a.setRequestedOrientation(android.content.pm.ActivityInfo
                        .SCREEN_ORIENTATION_UNSPECIFIED);
            } catch (Throwable ignored) {
            }
        } else {
            layer.setTag(Boolean.TRUE);
            f.width = ViewGroup.LayoutParams.MATCH_PARENT;
            f.height = ViewGroup.LayoutParams.MATCH_PARENT;
            f.leftMargin = 0;
            f.topMargin = 0;
            layer.setLayoutParams(f);
            try {
                a.getWindow().getDecorView().setSystemUiVisibility(
                        View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                                | View.SYSTEM_UI_FLAG_FULLSCREEN);
                a.setRequestedOrientation(android.content.pm.ActivityInfo
                        .SCREEN_ORIENTATION_SENSOR);
            } catch (Throwable ignored) {
            }
        }
        layer.bringToFront();
    }

    /** 网页原位播不了：给个明确的出口，别让用户对着黑屏发呆 */
    private static void embedFail(final Activity a, final String url, final String title) {
        AlertDialog d = new AlertDialog.Builder(a)
                .setTitle("这个地址播不了")
                .setMessage("可能是加密流（地址对，但播放时要加解密参数），"
                        + "也可能是格式不支持。\n\n换一种方式试试？")
                .setNegativeButton("复制链接", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dlg, int w) {
                        Route.copyText(a, url);
                    }
                })
                .setNeutralButton("独立播放器", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dlg, int w) {
                        closeOverlay();
                        play(a, url, title);
                    }
                })
                .setPositiveButton("收起", null)
                .create();
        Ui.show(d);
    }

    /** 叠层是不是还开着（返回键要先收它） */
    public static boolean isOverlayOpen() {
        return overlay != null;
    }

    /** 叫停网页里的播放器并撤掉那层 */
    public static void closeOverlay() {
        View v = overlay;
        overlay = null;
        if (overlayVv != null) {
            try {
                overlayVv.stopPlayback();
            } catch (Throwable ignored) {
            }
            overlayVv = null;
        }
        if (v != null && v.getParent() instanceof ViewGroup) {
            try {
                ((ViewGroup) v.getParent()).removeView(v);
            } catch (Throwable ignored) {
            }
        }
    }

    /** 网页换页 / 窗口切换时整体收回：撤播放器 + 撤占位块 */
    public static void closeAll(Activity a) {
        closeOverlay();
        if (a instanceof MainActivity) {
            try {
                Sniffer.unembed(((MainActivity) a).currentWeb());
            } catch (Throwable ignored) {
            }
        }
    }

    private static String clockOf(int ms) {
        if (ms < 0) ms = 0;
        int s = ms / 1000;
        return String.format(java.util.Locale.US, "%02d:%02d", s / 60, s % 60);
    }

    /** 半透明玻璃胶囊（播放器界面用，不走主题色：黑底上必须够亮） */
    private static TextView glass(Context c, String text) {
        TextView t = new TextView(c);
        t.setText(text);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f);
        t.setTextColor(0xFFFFFFFF);
        t.setGravity(Gravity.CENTER);
        t.setPadding(Ui.dp(c, 12), Ui.dp(c, 6), Ui.dp(c, 12), Ui.dp(c, 6));
        GradientDrawable d = new GradientDrawable();
        d.setColor(0x33FFFFFF);
        d.setCornerRadius(Ui.dp(c, 999));
        t.setBackground(d);
        t.setClickable(true);
        return t;
    }
    // ================================================================ 独立播放（Activity）

    private VideoView vv;
    private String url;
    private String title;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        url = getIntent() == null ? null : getIntent().getStringExtra(EXTRA_URL);
        title = getIntent() == null ? "" : getIntent().getStringExtra(EXTRA_TITLE);
        if (TextUtils.isEmpty(url)) {
            finish();
            return;
        }

        // 全屏：状态栏 / 导航栏都收起
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        if (Build.VERSION.SDK_INT >= 21) {
            getWindow().setStatusBarColor(Color.BLACK);
            getWindow().setNavigationBarColor(Color.BLACK);
        }
        hideBars();

        FrameLayout pageRoot = new FrameLayout(this);
        pageRoot.setBackgroundColor(Color.BLACK);

        vv = new VideoView(this);
        android.widget.MediaController mc = new android.widget.MediaController(this);
        mc.setAnchorView(vv);
        vv.setMediaController(mc);
        pageRoot.addView(vv, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        // 顶部：文件名 + 关闭
        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(Ui.dp(this, 14), Ui.dp(this, 10), Ui.dp(this, 10), Ui.dp(this, 10));

        TextView name = new TextView(this);
        name.setText(TextUtils.isEmpty(title) ? url : title);
        name.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f);
        name.setTextColor(0xCCFFFFFF);
        name.setSingleLine(true);
        name.setEllipsize(TextUtils.TruncateAt.MIDDLE);
        top.addView(name, new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView close = glass(this, "关闭");
        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        top.addView(close);

        FrameLayout.LayoutParams tlp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        tlp.gravity = Gravity.TOP;
        pageRoot.addView(top, tlp);

        setContentView(pageRoot);

        try {
            vv.setVideoURI(Uri.parse(url));
            vv.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                @Override
                public void onPrepared(MediaPlayer mp) {
                    mp.setLooping(false);
                    vv.start();
                }
            });
            vv.setOnErrorListener(new MediaPlayer.OnErrorListener() {
                @Override
                public boolean onError(MediaPlayer mp, int what, int extra) {
                    fail();
                    return true;
                }
            });
            vv.requestFocus();
        } catch (Throwable t) {
            fail();
        }
    }

    /** 播不了：不装作没事，给两条能走的路 */
    private void fail() {
        Ui.toast(this, "这个地址内置播放器播不了，可以复制链接用别的播放器打开");

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        box.setPadding(Ui.dp(this, 24), Ui.dp(this, 24), Ui.dp(this, 24), Ui.dp(this, 24));

        TextView tip = new TextView(this);
        tip.setText("播放失败\n可能是加密流、需要网页携带的鉴权头，或格式不支持");
        tip.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f);
        tip.setTextColor(0xCCFFFFFF);
        tip.setGravity(Gravity.CENTER);
        box.addView(tip);

        TextView copy = glass(this, "复制链接");
        copy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Route.copyText(PlayerActivity.this, url);
            }
        });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = Ui.dp(this, 14);
        box.addView(copy, lp);

        TextView ext = glass(this, "用其他应用打开");
        ext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                    AppPicker.show(PlayerActivity.this, i, "用其他应用打开");
                } catch (Throwable t) {
                    Ui.toast(PlayerActivity.this, "没有能打开这个地址的应用");
                }
            }
        });
        LinearLayout.LayoutParams lp2 = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp2.topMargin = Ui.dp(this, 10);
        box.addView(ext, lp2);

        addContentView(box, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    private void hideBars() {
        try {
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        } catch (Throwable ignored) {
        }
    }

    @Override
    public void onBackPressed() {
        finish();
    }

    @Override
    protected void onPause() {
        super.onPause();
        try {
            if (vv != null && vv.isPlaying()) vv.pause();
        } catch (Throwable ignored) {
        }
    }

    @Override
    protected void onDestroy() {
        try {
            if (vv != null) {
                vv.stopPlayback();
                vv = null;
            }
        } catch (Throwable ignored) {
        }
        closeOverlay();
        super.onDestroy();
    }
}
