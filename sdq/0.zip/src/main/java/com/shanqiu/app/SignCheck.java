package com.shanqiu.app;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.os.Build;

import java.io.File;
import java.security.MessageDigest;

/**
 * 安装包预检。
 *
 * 系统装 APK 只认一件事：新包的签名必须和已装版本完全一致，
 * 否则直接弹「应用未安装 / 与已有软件包冲突」，且不告诉你原因。
 * 这里在拉起安装器之前先自己比一遍包名和证书，把话说清楚：
 *   - 包名不同 → 不是同一个应用
 *   - 证书不同 → 不同电脑/不同密钥打的包，必须先卸载旧版
 */
public final class SignCheck {

    private SignCheck() {
    }

    /**
     * @return null 表示可以装；否则是给人看的原因
     */
    public static String why(Context c, File apk) {
        if (c == null || apk == null || !apk.isFile()) return "安装包不存在";
        try {
            PackageManager pm = c.getPackageManager();
            int flags = Build.VERSION.SDK_INT >= 28
                    ? PackageManager.GET_SIGNING_CERTIFICATES
                    : PackageManager.GET_SIGNATURES;
            PackageInfo mine = pm.getPackageInfo(c.getPackageName(), flags);
            PackageInfo theirs = pm.getPackageArchiveInfo(apk.getAbsolutePath(), flags);
            if (theirs == null) return "安装包解析失败，可能下载不完整";

            if (!c.getPackageName().equals(theirs.packageName)) {
                return "包名不一致（" + theirs.packageName + "），不是同一个应用";
            }
            String a = digest(mine);
            String b = digest(theirs);
            if (a == null || b == null) return null;   // 取不到就交给系统判断
            if (!a.equals(b)) {
                return "安装包签名与已装版本不一致。\n\n"
                        + "这通常是用了另一份证书打包（例如没配签名密钥的 CI 自签名包）。\n"
                        + "系统会拒绝覆盖安装，只能先卸载旧版再装 —— 卸载会清空书签、历史等本机数据。";
            }
            return null;
        } catch (Throwable t) {
            return null;   // 预检失败不挡路，交给系统
        }
    }

    /** 这条原因是不是「签名冲突」（需要卸载重装才能装） */
    public static boolean isSignatureConflict(String why) {
        return why != null && why.contains("签名");
    }

    /** 取第一个签名证书的 SHA-256 */
    private static String digest(PackageInfo info) {
        try {
            Signature[] sigs = null;
            if (Build.VERSION.SDK_INT >= 28 && info.signingInfo != null) {
                sigs = info.signingInfo.getApkContentsSigners();
            } else {
                sigs = info.signatures;
            }
            if (sigs == null || sigs.length == 0) return null;
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hash = md.digest(sigs[0].toByteArray());
            StringBuilder sb = new StringBuilder();
            for (byte x : hash) sb.append(String.format("%02x", x));
            return sb.toString();
        } catch (Throwable t) {
            return null;
        }
    }
}
