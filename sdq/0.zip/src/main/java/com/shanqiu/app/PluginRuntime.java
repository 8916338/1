package com.shanqiu.app;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.ValueCallback;
import android.webkit.WebView;
import android.widget.FrameLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/**
 * 插件运行时：页面加载完成后把匹配的插件注入进去，并在底部浮一颗按钮告诉用户
 * 「这个站的插件生效了」，点开可以禁用 / 删除 / 换一份。
 *
 * 注入用的是 evaluateJavascript 直接执行源码，而不是插 <script src>：
 * GitHub 这类站点 CSP 很严，外链脚本会被拦下，只有原生注入这一条路走得通。
 *
 * 注入时机是 onPageFinished（DOM 已就绪）。GitHub 用 Turbo 做站内跳转，
 * 换页不会重新加载文档，所以插件自己要在页面里监听 turbo:load / pjax:end，
 * 这部分由插件负责，壳只保证「每个文档注入一次」。
 */
public final class PluginRuntime {

    /** 底部提示按钮（和网页控制的按钮同款，位置高一行，避免叠在一起） */
    private static TextView pill;
    /** 当前页面生效的插件名 */
    private static final ArrayList<String> ACTIVE = new ArrayList<>();
    private static String currentUrl;
    /** 本页 URL，点胶囊时用它回到管理界面 */
    private static String curUrl;
    private static MainActivity actRef;
    private static List<PluginStore.Plugin> pendingHint;
    private static boolean hintShown;
    private static int failCount;

    private PluginRuntime() {
    }

    // ------------------------------------------------------------ 注入

    /**
     * onPageFinished 时调。返回注入成功的插件数量。
     */
    public static int apply(final MainActivity a, final WebView v, final String url) {
        if (a == null || v == null || TextUtils.isEmpty(url)) return 0;
        // 内置首页不注入：那是壳自己的页面
        if (Site.HOST.equals(Uri.parse(url).getHost())) {
            hide(a);
            return 0;
        }

        List<PluginStore.Plugin> hit = PluginStore.matchFor(a, url);
        ACTIVE.clear();
        if (hit.isEmpty()) {
            hide(a);
            return 0;
        }

        currentUrl = url;
        curUrl = url;
        actRef = a;
        failCount = 0;
        hintShown = false;
        pendingHint = hit;
        // 注入是异步的，先把按钮藏起来；回调里注入成功再露出来
        if (pill != null) pill.setVisibility(View.GONE);
        for (final PluginStore.Plugin p : hit) {
            final String name = p.name;
            String code = PluginStore.code(a, p);
            if (TextUtils.isEmpty(code)) continue;
            // 以前的兜底只看「有没有语法错」，React 页面没有 CSP，所以这里能拿到真结果：
            // 有错就别再显示「已生效」，直接把第一行抛给用户看
            v.evaluateJavascript("(function(){try{\n" + code + "\n;return '';}catch(e){return String((e&&e.message)||e);}})();",
                    new ValueCallback<String>() {
                        @Override
                        public void onReceiveValue(String v2) {
                            if (v2 == null || "null".equals(v2) || "\"\"".equals(v2) || v2.isEmpty()) {
                                ACTIVE.add(name);
                                afterInject();
                                return;
                            }
                            String msg = v2;
                            if (msg.length() > 1 && msg.startsWith("\"")) {
                                try {
                                    msg = new org.json.JSONArray("[" + msg + "]").optString(0);
                                } catch (Throwable ignored) {
                                }
                            }
                            fail(a, name, msg);
                        }
                    });
        }
        // 注入是异步的，先记下这次要提示的站点，回调里再决定要不要弹按钮
        return ACTIVE.size();
    }

    /** 所有插件都注入完（成功）后：弹胶囊、首次提示 */
    private static void afterInject() {
        MainActivity a = actRef;
        if (a == null) return;
        if (ACTIVE.isEmpty()) {
            // 全失败了，交给 fail 去显示错误胶囊
            if (failCount == 0) hide(a);
            return;
        }
        showPill(a);
        if (!hintShown && pendingHint != null) {
            hintShown = true;
            maybeHint(a, pendingHint, curUrl);
        }
    }

    private static void fail(MainActivity a, String name, String msg) {
        failCount++;
        lastError = name + "：" + (TextUtils.isEmpty(msg) ? "运行出错" : msg);
        if (ACTIVE.isEmpty()) {
            showErrorPill(a);
        }
    }

    private static void showErrorPill(final MainActivity a) {
        ensurePill(a);
        final TextView p = pill;
        if (p == null) return;
        p.setText("插件运行出错 · 点这里查看");
        p.setVisibility(View.VISIBLE);
        p.bringToFront();
        if (a.fab() != null) a.fab().bringToFront();
        // 出错属于「待用户处理」，常驻不自动藏；只有点开看过的那一刻才让开。
        p.removeCallbacks(hideRunnable);
    }

    /**
     * 是否像一份能执行的脚本。
     *
     * 以前这里只看安装时有没有 ==UserScript== 头，结果一份「下载页面另存成 .js」的
     * HTML、或者被转义的 JSON，也能装进去，然后每打开一次网页就报一次
     * Uncaught SyntaxError，看着就是「插件不能适配浏览器」。安装时当场拦住更好。
     */
    public static String syntaxProblem(String code) {
        String s = code == null ? "" : code.trim();
        if (s.length() < 12) return "内容是空的";
        String low = s.toLowerCase();
        if (low.startsWith("<!doctype") || low.startsWith("<html") || low.startsWith("<head")
                || low.startsWith("<body") || low.startsWith("<?xml")) {
            return "这是一份网页（HTML），不是脚本。多半是下载后存成了 .js.html，请直接安装 .js 原始文件";
        }
        if (low.startsWith("{") && low.endsWith("}") && !low.contains("function") && !low.contains("=>")) {
            return "这是一段 JSON 数据，不是脚本";
        }
        int paren = 0, brace = 0, bracket = 0;
        boolean str = false, esc = false, line = false, block = false, re = false;
        int lineNo = 1;
        boolean prevSymbol = false;
        for (int i = 0; i < s.length(); i++) {
            char ch = s.charAt(i);
            char nx = i + 1 < s.length() ? s.charAt(i + 1) : 0;
            if (ch == '\n') {
                lineNo++;
                line = false;
                if (!re) prevSymbol = false;
                continue;
            }
            if (line) continue;
            if (block) {
                if (ch == '*' && nx == '/') {
                    block = false;
                    i++;
                }
                continue;
            }
            if (str) {
                if (esc) esc = false;
                else if (ch == '\\') esc = true;
                else if (ch == '"' || ch == '\'') str = false;
                continue;
            }
            if (re) {
                if (esc) esc = false;
                else if (ch == '\\') esc = true;
                else if (ch == '/') re = false;
                continue;
            }
            if (ch == '/' && nx == '/') {
                line = true;
                i++;
                continue;
            }
            if (ch == '/' && nx == '*') {
                block = true;
                i++;
                continue;
            }
            if (ch == '"' || ch == '\'') {
                str = true;
                prevSymbol = false;
                continue;
            }
            if (ch == '/') {
                if (!prevSymbol) re = true;
                prevSymbol = false;
                continue;
            }
            if (ch == '(') paren++;
            else if (ch == ')') paren--;
            else if (ch == '{') brace++;
            else if (ch == '}') brace--;
            else if (ch == '[') bracket++;
            else if (ch == ']') bracket--;
            else if (!Character.isWhitespace(ch)) {
                prevSymbol = true;
                continue;
            }
            if (paren < 0 || brace < 0 || bracket < 0) {
                return "括号不匹配（第 " + lineNo + " 行多了一个 " + ch + "）";
            }
        }
        if (str && !block) return "字符串没有闭合，文件可能被截断了";
        if (paren != 0 || brace != 0 || bracket != 0) {
            return "括号不匹配，文件可能没下载完整（可重新下载一次再装）";
        }
        return null;
    }

    /** 包一层，插件自己抛错不至于把页面脚本带崩 */
    private static String wrap(String code) {
        return "(function(){try{\n" + code + "\n}catch(e){"
                + "try{window.__viePluginErr=String((e&&e.message)||e);"
                + "if(window.__viePluginErrBridged)window.__viePluginErrBridged(window.__viePluginErr);"
                + "console.error('[plugin]',e);}catch(_){}}})();";
    }

    // ------------------------------------------------------------ 底部按钮

    private static void ensurePill(final MainActivity a) {
        if (a == null || a.isFinishing() || a.isDestroyed()) return;
        if (pill != null && pill.getParent() == a.overlayRoot()) return;

        TextView p = new TextView(a);
        // 样式对齐网页控制那颗胶囊：14sp、蓝底、圆角、居中、窄一点、位置下移半行
        p.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f);
        p.setTextColor(0xFFFFFFFF);
        p.setTypeface(Typeface.DEFAULT_BOLD);
        p.setGravity(Gravity.CENTER);
        p.setIncludeFontPadding(false);
        p.setSingleLine(true);
        p.setMaxWidth((int) (a.getResources().getDisplayMetrics().widthPixels * 0.62f));
        p.setEllipsize(TextUtils.TruncateAt.END);
        p.setPadding(Ui.dp(a, 9), Ui.dp(a, 5), Ui.dp(a, 9), Ui.dp(a, 5));

        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.RECTANGLE);
        bg.setCornerRadius(Ui.dp(a, 18));
        bg.setColor(0xF52196F3);
        bg.setStroke(Math.max(1, Ui.dp(a, 0.8f)), 0x40FFFFFF);
        p.setBackground(bg);
        p.setClickable(true);
        p.setFocusable(true);
        p.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 点开即视为「已看到」，错误胶囊让开（不再常驻挡页面）
                if (failCount > 0 && ACTIVE.isEmpty()) {
                    if (pill != null) pill.setVisibility(View.GONE);
                    new AlertDialog.Builder(a)
                            .setTitle("插件没能在这个网站运行")
                            .setMessage("「" + lastError + "」\n\n"
                                    + "· 删掉后在「更多 → 插件」里重装一次\n"
                                    + "· 或者直接换一份别的插件")
                            .setPositiveButton("去管理", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface d, int w) {
                                    PluginMenu.manageFor(a, curUrl);
                                }
                            })
                            .setNegativeButton("关闭", null)
                            .show();
                    return;
                }
                PluginMenu.manageFor(a, currentUrl);
            }
        });

        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.gravity = Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL;
        // 网页控制的胶囊贴在最下面，插件这颗压在上方一行，两颗同时在也不打架
        lp.bottomMargin = Ui.dp(a, 58);

        pill = p;
        a.overlayRoot().addView(pill, lp);
        pill.setVisibility(View.GONE);
    }

    private static void showPill(final MainActivity a) {
        ensurePill(a);
        final TextView p = pill;
        if (p == null) return;
        String text = ACTIVE.size() == 1
                ? ACTIVE.get(0) + " 已生效 · 点这里管理"
                : ACTIVE.size() + " 个插件已生效 · 点这里管理";
        p.setText(text);
        p.setVisibility(View.VISIBLE);
        p.bringToFront();
        if (a.fab() != null) a.fab().bringToFront();

        // 每次打开页面提示一下，5 秒后自己让开（和拦截按钮一个节奏）
        p.removeCallbacks(hideRunnable);
        p.postDelayed(hideRunnable, 5000);
    }

    // ------------------------------------------------------------ 运行报错

    /** 最近一次页面里插件抛出的异常，点胶囊时给用户看 */
    static String lastError = "";

    private static final Runnable hideRunnable = new Runnable() {
        @Override
        public void run() {
            if (pill != null) pill.setVisibility(View.GONE);
        }
    };

    private static void hide(MainActivity a) {
        ACTIVE.clear();
        currentUrl = null;
        if (pill != null) {
            pill.removeCallbacks(hideRunnable);
            pill.setVisibility(View.GONE);
        }
    }

    /**
     * 网页首次载入插件时的说明。走统一教程闸门：一生只弹一次，
     * 且 10 秒内只放一个教程出来（和网页控制说明、装插件说明合并）。
     */
    private static void maybeHint(final MainActivity a, List<PluginStore.Plugin> hit, String url) {
        final PluginStore.Plugin first = hit.get(0);
        String host = Uri.parse(url).getHost();
        if (PluginStore.hinted(a, first, host)) return;
        if (!Prefs.tutorialOnce(a, Prefs.TUT_PLUGIN_PAGE)) return;

        final String fHost = host;
        final String fId = first.id;
        if (pill == null) return;
        pill.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (a.isFinishing() || a.isDestroyed()) return;
                PluginStore.markHinted(a, fId, fHost);
                try {
                    new AlertDialog.Builder(a)
                            .setTitle("插件在这个网站生效了")
                            .setMessage("「" + first.name + "」已经自动加载到 " + fHost + "。\n\n"
                                    + "· 页面底部的青色按钮就是它，点开可以禁用或删除\n"
                                    + "· 每次打开页面它会露一下，5 秒后自己让开，不挡你看网页\n"
                                    + "· 插件只改页面显示，不会动你的账号和密码")
                            .setPositiveButton("知道了", null)
                            .show();
                } catch (Throwable ignored) {
                }
            }
        }, 900);
    }

    // ------------------------------------------------------------ 生命周期

    public static void detach(MainActivity a) {
        if (pill != null && a != null && pill.getParent() == a.overlayRoot()) {
            try {
                a.overlayRoot().removeView(pill);
            } catch (Throwable ignored) {
            }
        }
        pill = null;
        ACTIVE.clear();
        currentUrl = null;
    }
}
