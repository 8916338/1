package com.shanqiu.app;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.widget.FrameLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/**
 * 插件运行时：页面加载完成后把匹配的插件注入进去，并在底部浮一颗按钮告诉用户
 * 「这个站的插件生效了」，点开可以禁用 / 删除 / 换一份。
 *
 * 注入用的是 evaluateJavascript 直接执行源码，而不是插 <script src>：
 * GitHub 这类站点 CSP 很严，外链脚本会被拦下，只有原生注入这一条路走得通。
 *
 * 注入时机是 onPageFinished（DOM 已就绪）。GitHub 用 Turbo 做站内跳转，
 * 换页不会重新加载文档，所以插件自己要在页面里监听 turbo:load / pjax:end，
 * 这部分由插件负责，壳只保证「每个文档注入一次」。
 */
public final class PluginRuntime {

    /** 底部提示按钮（和网页控制的按钮同款，位置高一行，避免叠在一起） */
    private static TextView pill;
    /** 当前页面生效的插件名 */
    private static final ArrayList<String> ACTIVE = new ArrayList<>();
    private static String currentUrl;

    private PluginRuntime() {
    }

    // ------------------------------------------------------------ 注入

    /**
     * onPageFinished 时调。返回注入成功的插件数量。
     */
    public static int apply(final MainActivity a, final WebView v, final String url) {
        if (a == null || v == null || TextUtils.isEmpty(url)) return 0;
        // 内置首页不注入：那是壳自己的页面
        if (Site.HOST.equals(Uri.parse(url).getHost())) {
            hide(a);
            return 0;
        }

        List<PluginStore.Plugin> hit = PluginStore.matchFor(a, url);
        ACTIVE.clear();
        if (hit.isEmpty()) {
            hide(a);
            return 0;
        }

        currentUrl = url;
        for (PluginStore.Plugin p : hit) {
            String code = PluginStore.code(a, p);
            if (TextUtils.isEmpty(code)) continue;
            try {
                v.evaluateJavascript(wrap(code), null);
                ACTIVE.add(p.name);
            } catch (Throwable ignored) {
            }
        }
        if (ACTIVE.isEmpty()) {
            hide(a);
            return 0;
        }

        showPill(a);
        maybeHint(a, hit, url);
        return ACTIVE.size();
    }

    /** 包一层，插件自己抛错不至于把页面脚本带崩 */
    private static String wrap(String code) {
        return "(function(){try{\n" + code + "\n}catch(e){try{console.error('[vie-plugin]',e)}catch(_){}}})();";
    }

    // ------------------------------------------------------------ 底部按钮

    private static void ensurePill(final MainActivity a) {
        if (a == null || a.isFinishing() || a.isDestroyed()) return;
        if (pill != null && pill.getParent() == a.overlayRoot()) return;

        TextView p = new TextView(a);
        p.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f);
        p.setTextColor(0xFFFFFFFF);
        p.setGravity(Gravity.CENTER);
        p.setIncludeFontPadding(false);
        p.setSingleLine(true);
        p.setEllipsize(TextUtils.TruncateAt.END);
        p.setPadding(Ui.dp(a, 10), Ui.dp(a, 6), Ui.dp(a, 10), Ui.dp(a, 6));

        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(Ui.dp(a, 14));
        // 和网页控制的按钮区分开：青色
        bg.setColor(0xE6008A8A);
        bg.setStroke(Math.max(1, Ui.dp(a, 0.8f)), 0x33FFFFFF);
        p.setBackground(bg);
        p.setClickable(true);
        p.setFocusable(true);
        p.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                PluginMenu.manageFor(a, currentUrl);
            }
        });

        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.gravity = Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL;
        // 比网页控制那颗高一行，两颗同时在也不打架
        lp.bottomMargin = Ui.dp(a, 44);
        p.setMaxWidth(a.getResources().getDisplayMetrics().widthPixels
                - Ui.dp(a, 2 * (14 + 48 + 8)));

        pill = p;
        a.overlayRoot().addView(pill, lp);
        pill.setVisibility(View.GONE);
    }

    private static void showPill(final MainActivity a) {
        ensurePill(a);
        final TextView p = pill;
        if (p == null) return;
        String text = ACTIVE.size() == 1
                ? ACTIVE.get(0) + " 已生效 · 点这里管理"
                : ACTIVE.size() + " 个插件已生效 · 点这里管理";
        p.setText(text);
        p.setVisibility(View.VISIBLE);
        p.bringToFront();
        if (a.fab() != null) a.fab().bringToFront();

        // 每次打开页面提示一下，5 秒后自己让开（和拦截按钮一个节奏）
        p.removeCallbacks(hideRunnable);
        p.postDelayed(hideRunnable, 5000);
    }

    private static final Runnable hideRunnable = new Runnable() {
        @Override
        public void run() {
            if (pill != null) pill.setVisibility(View.GONE);
        }
    };

    private static void hide(MainActivity a) {
        ACTIVE.clear();
        currentUrl = null;
        if (pill != null) {
            pill.removeCallbacks(hideRunnable);
            pill.setVisibility(View.GONE);
        }
    }

    /** 首次在这个网站跑某个插件：讲一次它是什么、怎么关 */
    private static void maybeHint(final MainActivity a, List<PluginStore.Plugin> hit, String url) {
        final PluginStore.Plugin first = hit.get(0);
        String host = Uri.parse(url).getHost();
        if (PluginStore.hinted(a, first, host)) return;

        final String fHost = host;
        final String fId = first.id;
        if (pill == null) return;
        pill.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (a.isFinishing() || a.isDestroyed()) return;
                PluginStore.markHinted(a, fId, fHost);
                try {
                    new AlertDialog.Builder(a)
                            .setTitle("插件在这个网站生效了")
                            .setMessage("「" + first.name + "」已经自动加载到 " + fHost + "。\n\n"
                                    + "· 页面底部的青色按钮就是它，点开可以禁用、换一份或删除\n"
                                    + "· 每次打开页面它会露一下，5 秒后自己让开，不挡你看网页\n"
                                    + "· 插件只改页面显示，不会动你的账号和密码")
                            .setPositiveButton("知道了", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface d, int w) {
                                }
                            })
                            .show();
                } catch (Throwable ignored) {
                }
            }
        }, 900);
    }

    // ------------------------------------------------------------ 生命周期

    public static void detach(MainActivity a) {
        if (pill != null && a != null && pill.getParent() == a.overlayRoot()) {
            try {
                a.overlayRoot().removeView(pill);
            } catch (Throwable ignored) {
            }
        }
        pill = null;
        ACTIVE.clear();
        currentUrl = null;
    }
}
