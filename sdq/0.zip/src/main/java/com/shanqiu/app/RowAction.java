package com.shanqiu.app;

import android.app.AlertDialog;
import android.content.DialogInterface;

/**
 * 书签行 / 历史行长按弹出的操作单。
 *
 * 三项，和后台窗口面板的操作逻辑保持一致：
 *   新窗口打开 —— 当前页转入后台
 *   后台打开   —— 不离开当前页
 *   删除       —— 删掉这条书签 / 这条历史
 *
 * features.background=false 时只剩「删除」（不会引用到 Background 类，
 * 关掉后台功能照样能编译）。
 */
public final class RowAction {

    private RowAction() {
    }

    public static void show(final MainActivity a, final String title, final String url,
                            final Runnable onDelete) {
        if (a == null) return;

        final boolean bg = FabRegistry.hasBackground();

        // 图标 + 文字的动作面板（与闪电球菜单同一套半透明线性图标）
        java.util.ArrayList<Integer> icons = new java.util.ArrayList<>();
        java.util.ArrayList<String> labels = new java.util.ArrayList<>();
        java.util.ArrayList<Runnable> runs = new java.util.ArrayList<>();

        if (bg) {
            icons.add(R.drawable.ic_q_web);
            labels.add("新窗口打开");
            runs.add(new Runnable() {
                @Override
                public void run() {
                    FabRegistry.openInNewWindow(a, a.realUrlOf(url));
                }
            });
            icons.add(R.drawable.ic_q_layer);
            labels.add("后台打开");
            runs.add(new Runnable() {
                @Override
                public void run() {
                    FabRegistry.openInBackground(a, a.realUrlOf(url));
                }
            });
        }
        icons.add(R.drawable.ic_q_delete);
        labels.add("删除");
        runs.add(onDelete);

        int[] ids = new int[icons.size()];
        for (int i = 0; i < ids.length; i++) ids[i] = icons.get(i);

        try {
            Sheet.show(a, title, null, ids,
                    labels.toArray(new String[0]), new String[labels.size()],
                    new Sheet.Pick() {
                        @Override
                        public void onPick(int index) {
                            Runnable r = runs.get(index);
                            if (r != null) r.run();
                        }
                    });
        } catch (Throwable ignored) {
        }
    }
}
