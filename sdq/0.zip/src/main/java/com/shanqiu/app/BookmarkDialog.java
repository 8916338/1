package com.shanqiu.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.graphics.Color;
import android.text.InputType;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * 收藏 / 编辑书签：名字 + 网址，都可以改。
 * 只负责编辑，落库交给调用方（同一个地址可能来自内置页面，需要归一化）。
 */
public final class BookmarkDialog {

    public interface Done {
        void onSave(String name, String url);
    }

    private BookmarkDialog() {
    }

    /**
     * @param deleteUrl 不为空时，多给一个「删除」按钮（说明这条已经在书签里了）
     */
    public static void show(final Activity a, String headTitle,
                            String name, String url, final String deleteUrl,
                            final Done done) {
        show(a, headTitle, name, url, deleteUrl, done, null);
    }

    /**
     * @param afterDelete 删除成功后的回调，书签管理页用它重新渲染列表
     */
    public static void show(final Activity a, String headTitle,
                            String name, String url, final String deleteUrl,
                            final Done done, final Runnable afterDelete) {
        if (a == null) return;

        final int pad = Ui.dp(a, 20);

        LinearLayout box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(pad, Ui.dp(a, 6), pad, Ui.dp(a, 2));

        box.addView(tag(a, "名称"));
        final EditText etName = input(a, "给这个页面起个名字", name, false);
        box.addView(etName);

        box.addView(tag(a, "网址"));
        final EditText etUrl = input(a, "https://", url, true);
        box.addView(etUrl);
        etUrl.setSelection(etUrl.getText().length());

        AlertDialog.Builder b = new AlertDialog.Builder(a);
        b.setTitle(TextUtils.isEmpty(headTitle) ? "加入书签" : headTitle);
        b.setView(box);
        b.setPositiveButton("保存", null);
        b.setNegativeButton("取消", null);
        if (!TextUtils.isEmpty(deleteUrl)) b.setNeutralButton("删除", null);

        final AlertDialog d = b.create();
        d.setOnShowListener(new DialogInterface.OnShowListener() {
            @Override
            public void onShow(DialogInterface di) {
                d.getButton(AlertDialog.BUTTON_POSITIVE)
                        .setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                String u = Bookmarks.normalize(etUrl.getText().toString());
                                if (TextUtils.isEmpty(u)) {
                                    Ui.toast(a, "网址不能为空");
                                    return;
                                }
                                String n = etName.getText().toString().trim();
                                if (TextUtils.isEmpty(n)) n = Bookmarks.labelOf(u);
                                d.dismiss();
                                if (done != null) done.onSave(n, u);
                            }
                        });

                if (!TextUtils.isEmpty(deleteUrl)) {
                    d.getButton(AlertDialog.BUTTON_NEUTRAL)
                            .setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    Bookmarks.remove(a, deleteUrl);
                                    d.dismiss();
                                    Ui.toast(a, "已从书签删除");
                                    if (afterDelete != null) afterDelete.run();
                                }
                            });
                }
            }
        });
        try {
            Ui.show(d);
        } catch (Throwable t) {
            Ui.toast(a, "打不开编辑框");
        }
    }

    private static TextView tag(Activity a, String text) {
        TextView t = new TextView(a);
        t.setText(text);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f);
        t.setTextColor(0xFF8B96A5);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = Ui.dp(a, 10);
        lp.bottomMargin = Ui.dp(a, 3);
        t.setLayoutParams(lp);
        return t;
    }

    private static EditText input(Activity a, String hint, String value, boolean url) {
        EditText e = new EditText(a);
        e.setHint(hint);
        e.setText(value == null ? "" : value);
        e.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f);
        e.setTextColor(0xFF0A1A2B);
        e.setHintTextColor(0xFFB9C1CD);
        e.setBackgroundColor(Color.TRANSPARENT);
        e.setSingleLine(true);
        e.setPadding(0, Ui.dp(a, 8), 0, Ui.dp(a, 8));
        e.setInputType(InputType.TYPE_CLASS_TEXT
                | (url ? InputType.TYPE_TEXT_VARIATION_URI : 0));
        return e;
    }
}
