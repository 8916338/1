package com.shanqiu.app;

import android.text.TextUtils;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * 闪电球菜单。
 *
 * 板块与顺序全部来自 app-config.json 的 fab.sections：
 *
 *   "fab": {
 *     "enabled": true,
 *     "sections": [
 *       { "id": "openurl",   "title": "输入网址访问", "enabled": true },
 *       { "id": "bookmarks", "title": "书签",         "enabled": true },
 *       { "id": "pages",     "title": "更多页面",     "enabled": true },
 *       { "id": "downloads", "title": "下载内容",     "enabled": true },
 *       { "id": "history",   "title": "历史",         "enabled": true },
 *       { "id": "coffee",    "title": "请开发者喝咖啡","enabled": true },
 *       { "id": "more",      "title": "更多",         "enabled": true }
 *     ],
 *     "more": [
 *       { "id": "update", "title": "检查更新", "enabled": true }
 *     ]
 *   }
 *
 * 特殊 id：
 *   pages      —— 展开 app-config.json 的 pages 数组（跳过首页那一项）；
 *   page:<n>   —— 只展开 pages 里的第 n 项（从 0 开始）。
 *
 * 面板靠球那一侧固定是横向图标按钮（刷新/首页/前进/后退/扫码/分享）。
 * 书签列表结束后固定追加一行「后台」（features.background 开启时），
 * 长按书签行可以「后台打开 / 新窗口打开」。
 *
 * 由功能模块实现、可在打包时整体裁掉的项（下载 / 历史 / 更新 / 后台多窗），
 * 统一交给 FabRegistry 分发 —— 功能关掉时连类都不会进包。
 */
public final class Menu {

    /* 图标：全部照抄网页里那套 24×24 描边图形 */
    private static final int I_REFRESH = R.drawable.ic_q_refresh;
    private static final int I_STAR = R.drawable.ic_q_star;
    private static final int I_NEXT = R.drawable.ic_q_next;
    private static final int I_PREV = R.drawable.ic_q_prev;
    private static final int I_HOME = R.drawable.ic_q_home;
    private static final int I_WEB = R.drawable.ic_q_web;
    private static final int I_BOOKMARK = R.drawable.ic_q_bookmark;
    private static final int I_LINK = R.drawable.ic_q_link;
    private static final int I_COFFEE = R.drawable.ic_q_coffee;
    private static final int I_DOWNLOAD = R.drawable.ic_q_download;
    private static final int I_HISTORY = R.drawable.ic_q_history;
    private static final int I_MORE = R.drawable.ic_q_more;
    private static final int I_LAYER = R.drawable.ic_q_layer;
    private static final int I_SEARCH = R.drawable.ic_q_search;
    private static final int I_SCAN = R.drawable.ic_q_scan;
    private static final int I_SHARE = R.drawable.ic_q_share;
    private static final int I_PLAY = R.drawable.ic_q_play;

    /** 书签行的 id 会拼成 bookmark:<url>，方便统一处理 */
    public static final String ID_BOOKMARK_ROW = "bookmark:";
    public static final String BOOKMARK_HEADER_ID = ID_BOOKMARK_ROW + "__header__";
    public static final String ID_PAGE_ROW = "page:";

    private Menu() {
    }

    private static int iconOf(String id) {
        switch (id) {
            case "refresh": return I_REFRESH;
            case "bookmark": return I_STAR;
            case "forward": return I_NEXT;
            case "back": return I_PREV;
            case "home": return I_HOME;
            case "openurl": return I_LINK;
            case "bookmarks": return I_BOOKMARK;
            case "downloads": return I_DOWNLOAD;
            case "history": return I_HISTORY;
            case "coffee": return I_COFFEE;
            case "more": return I_MORE;
            case "background": return I_LAYER;
            case "pages": return I_WEB;
            case "find": return I_SEARCH;
            case "scan": return I_SCAN;
            case "share": return I_SHARE;
            case "sniff": return I_DOWNLOAD;
            case "play": return I_PLAY;
            default:
                if (id.startsWith(ID_PAGE_ROW)) return I_WEB;
                return 0;
        }
    }

    /** 该项此刻是否真的可用（依赖配置 / 数据 / 开关）；横向按钮条也用它过滤 */
    public static boolean available(MainActivity a, String id) {
        switch (id) {
            case "bookmark":
                return Config.ALLOW_USER_BOOKMARKS;
            case "coffee":
                return Coffee.hasSponsor(a);
            case "downloads":
                return Config.FEATURE_DOWNLOADS;
            case "background":
            case "pages":
                return true;
            default:
                if (id.startsWith(ID_PAGE_ROW)) {
                    return pageIndex(id) >= 0;
                }
                return true;
        }
    }

    private static int pageIndex(String id) {
        try {
            return Integer.parseInt(id.substring(ID_PAGE_ROW.length()));
        } catch (Throwable t) {
            return -1;
        }
    }

    public static void show(final MainActivity a) {
        if (a == null) return;

        final List<Bookmarks.Item> marks = Bookmarks.all(a);
        final ArrayList<QuickMenu.Row> rows = new ArrayList<>();

        JSONArray sections;
        try {
            sections = new JSONArray(Config.FAB_SECTIONS_JSON);
        } catch (Throwable t) {
            sections = new JSONArray();
        }

        for (int i = 0; i < sections.length(); i++) {
            JSONObject o = sections.optJSONObject(i);
            if (o == null) continue;
            String id = o.optString("id", "");
            if (TextUtils.isEmpty(id)) continue;
            if (!o.optBoolean("enabled", true)) continue;
            if (!available(a, id)) continue;

            String title = o.optString("title", "");
            if (TextUtils.isEmpty(title)) title = defaultTitle(id);

            // 「收藏本页」是一个独立板块：可以在 fab.sections 里单独排序、隐藏、改名，
            // 不再跟书签列表绑在一起
            if ("bookmark".equals(id)) {
                if (Config.ALLOW_USER_BOOKMARKS) {
                    rows.add(new QuickMenu.Row(I_STAR, title, null, "bookmark", null));
                }
                continue;
            }

            if ("bookmarks".equals(id)) {
                // 书签板块：只列书签，结尾按需追加「后台」
                if (!marks.isEmpty()) {
                    for (final Bookmarks.Item m : marks) {
                        final String url = m.url;
                        final String label = TextUtils.isEmpty(m.name)
                                ? Bookmarks.labelOf(m.url) : m.name;

                        QuickMenu.Row r = new QuickMenu.Row(I_BOOKMARK, label,
                                null, ID_BOOKMARK_ROW + m.url, m.url);

                        // 横划直接删（不问，面板里这一行跟着消失）
                        r.silentDelete = true;
                        r.onDelete = new Runnable() {
                            @Override
                            public void run() {
                                deleteBookmark(a, url);
                            }
                        };
                        // 长按：新窗口 / 后台 / 删除，三项和后台面板一致
                        r.longPress(new Runnable() {
                            @Override
                            public void run() {
                                QuickMenu.dismissAll();
                                RowAction.show(a, label, url, new Runnable() {
                                    @Override
                                    public void run() {
                                        deleteBookmark(a, url);
                                    }
                                });
                            }
                        });
                        rows.add(r);
                    }
                }
                if (FabRegistry.hasBackground()) {
                    rows.add(new QuickMenu.Row(I_LAYER, "后台", null, "background", null));
                }
                continue;
            }

            if ("pages".equals(id)) {
                boolean any = false;
                JSONArray pages = Config.pages();
                for (int p = 0; p < pages.length(); p++) {
                    JSONObject pg = pages.optJSONObject(p);
                    if (pg == null || pg.optBoolean("home", false)) continue;
                    rows.add(new QuickMenu.Row(I_WEB,
                            TextUtils.isEmpty(pg.optString("title")) ? "页面" : pg.optString("title"),
                            null, ID_PAGE_ROW + p, p));
                    any = true;
                }
                // 页面都由 pages 展开，板块本身不再单独出行
                continue;
            }

            if (id.startsWith(ID_PAGE_ROW)) {
                int idx = pageIndex(id);
                JSONArray pages = Config.pages();
                JSONObject pg = idx >= 0 && idx < pages.length()
                        ? pages.optJSONObject(idx) : null;
                if (pg == null) continue;
                rows.add(new QuickMenu.Row(I_WEB,
                        TextUtils.isEmpty(title) || defaultTitle(id).equals(title)
                                ? (TextUtils.isEmpty(pg.optString("title")) ? "页面" : pg.optString("title"))
                                : title,
                        null, id, idx));
                continue;
            }

            rows.add(new QuickMenu.Row(iconOf(id), title, null, id, null));
        }

        if (rows.isEmpty()) {
            Ui.toast(a, "没有可用的菜单项");
            return;
        }

        // 闪电球被配置关掉时，用页面顶部区域兜底作为锚点
        Fab anchor = a.fab();

        QuickMenu.show(a, anchor, rows, true, new QuickMenu.Pick() {
            @Override
            public void onPick(String id, Object data) {
                if (id == null) return;

                // 书签分组行只是说明，点了不做任何事（面板保持打开）
                if (BOOKMARK_HEADER_ID.equals(id)) return;
                if (id.startsWith(ID_BOOKMARK_ROW)) {
                    a.openBookmark(String.valueOf(data));
                    return;
                }
                if (id.startsWith(ID_PAGE_ROW)) {
                    String target = Config.pageUrl((Integer) data);
                    if (!TextUtils.isEmpty(target)) a.openInside(target);
                    return;
                }
                switch (id) {
                    case "refresh":
                        a.refreshPage();
                        break;
                    case "bookmark":
                        a.bookmarkCurrentPage();
                        break;
                    case "forward":
                        if (a.canGoForward()) a.goForwardPage();
                        else Ui.toast(a, "已经在最后一页");
                        break;
                    case "back":
                        if (a.canGoBack()) a.goBackPage();
                        else Ui.toast(a, "已经是第一页");
                        break;
                    case "home":
                        a.goHome();
                        break;
                    case "find":
                        a.findInPage();
                        break;
                    case "scan":
                        Scan.start(a);
                        break;
                    case "share":
                        a.shareCurrentPage();
                        break;
                    case "openurl":
                        a.openUrlDialog();
                        break;
                    case "coffee":
                        Coffee.show(a);
                        break;
                    case "background":
                        FabRegistry.openBackgroundPanel(a);
                        break;
                    case "more":
                        MoreMenu.show(a);
                        break;
                    case "sniff":
                        Sniffer.show(a);
                        break;
                    case "play":
                        Sniffer.watch(a);
                        break;
                    default:
                        // 功能模块（下载 / 历史 / 更新…）自己处理
                        FabRegistry.handle(a, id);
                        break;
                }
            }
        });
    }

    /** 删一条书签；内置书签来自打包配置，用户端删不掉 */
    private static void deleteBookmark(MainActivity a, String url) {
        if (Bookmarks.isPreset(a, url)) {
            Ui.toast(a, "内置书签删不掉，要改请改打包配置");
            return;
        }
        Bookmarks.remove(a, url);
        Ui.toast(a, "已删除书签");
    }

    public static String defaultTitle(String id) {
        switch (id) {
            case "refresh": return "刷新本页";
            case "bookmark": return "收藏本页";
            case "forward": return "前进";
            case "back": return "后退";
            case "home": return "返回首页";
            case "openurl": return "输入网址访问";
            case "bookmarks": return "书签";
            case "downloads": return "下载内容";
            case "history": return "历史";
            case "coffee": return "赞助";
            case "more": return "更多";
            case "background": return "后台";
            case "pages": return "更多页面";
            case "find": return "页面查找";
            case "scan": return "扫描二维码";
            case "share": return "分享本页网址";
            case "sniff": return "视频嗅探";
            case "play": return "在网页里看视频";
            default:
                if (id.startsWith(ID_PAGE_ROW)) return "页面";
                return id;
        }
    }
}
