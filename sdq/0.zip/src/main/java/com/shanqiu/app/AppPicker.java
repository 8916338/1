package com.shanqiu.app;

import android.app.Activity;
import android.app.Dialog;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.drawable.Drawable;
import android.text.TextUtils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * 自绘「选择应用」面板。
 *
 * 系统 {@code Intent.createChooser} 的样式由 ROM 决定，和闪电球的半透明面板
 * 完全两个风格。这里改成自己查 PackageManager、自己排版：
 *   - 应用图标原色显示，名称 + 包名两行
 *   - 点击后按显式 ComponentName 启动，等于「用户在系统选择器里点了那一个」
 *   - 列表为空或查询失败时退回系统选择器，不会出现「点了没反应」
 */
public final class AppPicker {

    private AppPicker() {
    }

    /** 面板最多列出的应用数，超出部分不显示（系统选择器也很少超过这个数） */
    private static final int MAX_ITEMS = 12;

    /**
     * @param target 已经设置好 action / data / type 的 Intent
     * @param title  面板标题，如「选择要打开的应用」
     */
    public static Dialog show(final Activity a, final Intent target, final String title) {
        if (a == null || target == null) return null;

        final PackageManager pm = a.getPackageManager();
        List<ResolveInfo> resolved = null;
        try {
            resolved = pm.queryIntentActivities(target, 0);
        } catch (Throwable ignored) {
        }
        if (resolved == null || resolved.isEmpty()) {
            return systemChooser(a, target, title);
        }

        final ArrayList<ResolveInfo> apps = new ArrayList<ResolveInfo>();
        for (ResolveInfo ri : resolved) {
            if (ri == null || ri.activityInfo == null) continue;
            // 自己的 Activity 不列（否则会「用闪电球打开闪电球」）
            if (a.getPackageName().equals(ri.activityInfo.packageName)) continue;
            apps.add(ri);
        }
        if (apps.isEmpty()) {
            return systemChooser(a, target, title);
        }

        // 按显示名称排序，找起来快
        try {
            Collections.sort(apps, new Comparator<ResolveInfo>() {
                @Override
                public int compare(ResolveInfo x, ResolveInfo y) {
                    String sx = String.valueOf(x.loadLabel(pm));
                    String sy = String.valueOf(y.loadLabel(pm));
                    return sx.compareToIgnoreCase(sy);
                }
            });
        } catch (Throwable ignored) {
        }

        int n = Math.min(apps.size(), MAX_ITEMS);
        Object[] icons = new Object[n];
        String[] labels = new String[n];
        String[] subs = new String[n];
        for (int i = 0; i < n; i++) {
            ResolveInfo ri = apps.get(i);
            Drawable icon = null;
            try {
                icon = ri.loadIcon(pm);
            } catch (Throwable ignored) {
            }
            icons[i] = icon;
            String label = null;
            try {
                label = String.valueOf(ri.loadLabel(pm));
            } catch (Throwable ignored) {
            }
            labels[i] = TextUtils.isEmpty(label) ? ri.activityInfo.packageName : label;
            subs[i] = ri.activityInfo.packageName;
        }

        final List<ResolveInfo> list = apps;
        return Sheet.showMixed(a, TextUtils.isEmpty(title) ? "选择应用" : title,
                null, icons, labels, subs, new Sheet.Pick() {
                    @Override
                    public void onPick(int index) {
                        if (index < 0 || index >= list.size()) return;
                        ResolveInfo ri = list.get(index);
                        Intent i = new Intent(target);
                        i.setComponent(new ComponentName(
                                ri.activityInfo.packageName, ri.activityInfo.name));
                        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        try {
                            a.startActivity(i);
                        } catch (Throwable t) {
                            Ui.toast(a, "打不开这个应用");
                        }
                    }
                }, null);
    }

    /** 兜底：查询不到或全被过滤时，用系统的，保证功能不丢 */
    private static Dialog systemChooser(Activity a, Intent target, String title) {
        try {
            Intent chooser = Intent.createChooser(target,
                    TextUtils.isEmpty(title) ? "选择要打开的应用" : title);
            chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            a.startActivity(chooser);
        } catch (Throwable t) {
            Ui.toast(a, "没有能找到的应用");
        }
        return null;
    }
}
