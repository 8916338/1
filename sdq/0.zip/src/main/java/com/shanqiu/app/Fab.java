package com.shanqiu.app;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.TextView;

/**
 * 闪电球，参数与网页里那颗 ⚡ 完全对齐：
 *
 *   .gq-quick-fab{
 *     width:48px; height:48px; border-radius:50%;
 *     background:linear-gradient(135deg,#2b3340,#171a1f);
 *     color:#fff; font-size:19px; line-height:1;
 *     box-shadow:0 10px 26px -10px rgba(0,0,0,.7);
 *     transition:transform .18s;
 *   }
 *   .gq-quick-fab:active{transform:scale(.94)}
 *   .gq-quick-fab[aria-expanded="true"]{background:linear-gradient(135deg,#ff7043,#e64a19)}
 *
 *   .gq-quick{position:fixed;right:14px;bottom:14px}
 *
 * 所以：48dp 圆、深色渐变、白色 ⚡ 19sp、按下缩到 0.94、展开时变橙色渐变、默认贴右下 14dp。
 * 仍然可以拖动，松手贴边并记住位置。
 */
public class Fab extends FrameLayout {

    public interface Tap {
        void onTap();
    }

    private static final String PREF = "shell_fab";
    private static final String K_X = "x";
    private static final String K_Y = "y";
    /** 位置规则变了就升这个号，老位置作废、回到默认 */
    private static final String K_VER = "ver";
    private static final int VER = 3;

    /** 网页：width/height 48px */
    private static final int SIZE_DP = 48;
    /** 网页：right:14px; bottom:14px */
    private static final int EDGE_DP = 14;
    /**
     * 默认位置比网页那颗球再往上抬一点：网页底部左下角会浮出「网页拦截」的
     * 按钮，同一排容易互相压住。抬一排的距离，两边都点得着。
     * 用户自己拖走之后就按他记的位置来，挡不挡随他。
     */
    private static final int LIFT_DP = 46;

    private static final int[] BG_IDLE = {0xFF2B3340, 0xFF171A1F};
    private static final int[] BG_OPEN = {0xFFFF7043, 0xFFE64A19};

    private Tap tap;

    private float downRawX, downRawY;
    private int startLeft, startTop;
    private boolean dragging;
    private boolean downInFab;
    private long downAt;

    private final int size;
    private final int edge;
    private final int slop;
    private final TextView glyph;
    private GradientDrawable bg;

    public Fab(Context c) {
        super(c);
        size = Ui.dp(c, SIZE_DP);
        edge = Ui.dp(c, EDGE_DP);
        slop = ViewConfiguration.get(c).getScaledTouchSlop();

        setClickable(true);
        setFocusable(false);
        setClipChildren(false);

        bg = new GradientDrawable(GradientDrawable.Orientation.TL_BR, BG_IDLE);
        bg.setShape(GradientDrawable.OVAL);
        setBackground(bg);

        // 网页那条 0 10px 26px -10px 的黑影，用 elevation 近似
        if (android.os.Build.VERSION.SDK_INT >= 21) {
            setElevation(Ui.dp(c, 10));
        }

        // 默认还是网页那颗 ⚡，文字可由工程配置 fabText 覆盖（见 Config）
        glyph = new TextView(c);
        glyph.setText("⚡");
        glyph.setTextSize(TypedValue.COMPLEX_UNIT_SP, 19);
        glyph.setTextColor(Color.WHITE);
        glyph.setGravity(Gravity.CENTER);
        glyph.setIncludeFontPadding(false);
        addView(glyph, new LayoutParams(
                LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT, Gravity.CENTER));

        migrateOldPosition(c);
        applyGlyph();

        setOnTouchListener(new OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        downRawX = e.getRawX();
                        downRawY = e.getRawY();
                        FrameLayout.LayoutParams lp = lp();
                        startLeft = lp == null ? 0 : lp.leftMargin;
                        startTop = lp == null ? 0 : lp.topMargin;
                        dragging = false;
                        downInFab = true;
                        downAt = System.currentTimeMillis();
                        press(true);
                        ViewGroup parent = (ViewGroup) getParent();
                        if (parent != null) parent.requestDisallowInterceptTouchEvent(true);
                        return true;

                    case MotionEvent.ACTION_MOVE:
                        float dx = e.getRawX() - downRawX;
                        float dy = e.getRawY() - downRawY;
                        if (!dragging && (Math.abs(dx) > slop || Math.abs(dy) > slop)) {
                            dragging = true;
                            press(false);
                            QuickMenu.dismissAll();   // 拖球时把菜单收起来
                        }
                        if (dragging) moveTo((int) (startLeft + dx), (int) (startTop + dy));
                        return true;

                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        ViewGroup p = (ViewGroup) getParent();
                        if (p != null) p.requestDisallowInterceptTouchEvent(false);
                        press(false);
                        if (!dragging && System.currentTimeMillis() - downAt < 600) {
                            if (tap != null) tap.onTap();
                        } else if (dragging) {
                            snapToEdge();
                        }
                        dragging = false;
                        return true;
                    default:
                        return false;
                }
            }
        });
    }

    /**
     * 早期版本把球默认放在屏幕中上方（38% 高度），这一版改成网页那颗球的位置（右下 14dp）。
     * 装过旧版的用户手里存着老坐标，这里清一次，让他们也回到右下角。
     */
    private static void migrateOldPosition(Context c) {
        SharedPreferences sp = c.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        if (sp.getInt(K_VER, 0) != VER) {
            sp.edit().remove(K_X).remove(K_Y).putInt(K_VER, VER).apply();
        }
    }

    public void setTap(Tap t) {
        tap = t;
    }

    // ------------------------------------------------------------ 球里的文字

    /**
     * 球里显示的文字，来自工程配置 app-config.json 的 fabText。
     * 留空 = 默认的 ⚡，改配置重新打包才能变。
     */
    public void applyGlyph() {
        String t = Config.FAB_TEXT;
        if (t.length() == 0) {
            glyph.setText("⚡");
            glyph.setTextSize(TypedValue.COMPLEX_UNIT_SP, 19);
        } else {
            glyph.setText(t);
            int cp = t.codePointCount(0, t.length());
            float sp = cp <= 1 ? 20f : cp == 2 ? 15f : cp == 3 ? 12.5f : 10.5f;
            glyph.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        }
    }

    /** 网页 :active{transform:scale(.94)} */
    private void press(boolean on) {
        animate().cancel();
        animate().scaleX(on ? 0.94f : 1f).scaleY(on ? 0.94f : 1f)
                .setDuration(on ? 90 : 160).start();
    }

    /** 展开 / 收起时换背景：网页 aria-expanded=true 时走橙色渐变 */
    public void setOpen(boolean open) {
        bg = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                open ? BG_OPEN : BG_IDLE);
        bg.setShape(GradientDrawable.OVAL);
        setBackground(bg);
    }

    public FrameLayout.LayoutParams params() {
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(size, size);
        lp.gravity = Gravity.TOP | Gravity.START;
        lp.leftMargin = edge;
        lp.topMargin = edge;
        return lp;
    }

    private FrameLayout.LayoutParams lp() {
        ViewGroup.LayoutParams p = getLayoutParams();
        return p instanceof FrameLayout.LayoutParams ? (FrameLayout.LayoutParams) p : null;
    }

    private void moveTo(int left, int top) {
        FrameLayout.LayoutParams lp = lp();
        if (lp == null) return;
        ViewGroup p = (ViewGroup) getParent();
        int maxL = Math.max(0, contentW(p) - getWidth());
        int maxT = Math.max(0, contentH(p) - getHeight());
        lp.leftMargin = Math.max(0, Math.min(left, maxL));
        lp.topMargin = Math.max(0, Math.min(top, maxT));
        setLayoutParams(lp);
    }

    /**
     * 可用区域要减掉根布局的 padding。
     * Android 15 起 targetSdk ≥ 35 会被强制 edge-to-edge，我们在 root 上补了
     * 状态栏/手势条高度的 padding；子 View 的 leftMargin/topMargin 是相对
     * padding 内沿的，若还拿 getWidth()/getHeight()（含 padding）算，
     * 球会被推到屏幕外——表现就是「闪电球不见了」。
     */
    private static int contentW(ViewGroup p) {
        return Math.max(0, p.getWidth() - p.getPaddingLeft() - p.getPaddingRight());
    }

    private static int contentH(ViewGroup p) {
        return Math.max(0, p.getHeight() - p.getPaddingTop() - p.getPaddingBottom());
    }

    /** 松手贴到左右最近的一边，并记住位置 */
    private void snapToEdge() {
        FrameLayout.LayoutParams lp = lp();
        ViewGroup p = (ViewGroup) getParent();
        if (lp == null || p == null) return;
        int pw = contentW(p);
        int target = (lp.leftMargin + getWidth() / 2f) < pw / 2f
                ? edge
                : Math.max(edge, pw - getWidth() - edge);
        lp.leftMargin = target;
        setLayoutParams(lp);
        remember();
    }

    private void remember() {
        FrameLayout.LayoutParams lp = lp();
        ViewGroup p = (ViewGroup) getParent();
        if (lp == null || p == null) return;
        int pw = Math.max(1, contentW(p) - getWidth());
        int ph = Math.max(1, contentH(p) - getHeight());
        SharedPreferences sp = getContext().getSharedPreferences(PREF, Context.MODE_PRIVATE);
        sp.edit()
                .putFloat(K_X, lp.leftMargin / (float) pw)
                .putFloat(K_Y, lp.topMargin / (float) ph)
                .apply();
    }

    /**
     * 恢复位置。没有任何记录时，摆在网页那颗球的位置：贴右下角，右 14dp / 下 14dp。
     * 拖过一次之后就按记住的位置来。
     */
    public void restorePosition() {
        post(new Runnable() {
            private int tries = 0;

            @Override
            public void run() {
                ViewGroup p = (ViewGroup) getParent();
                FrameLayout.LayoutParams lp = lp();
                if (p == null || lp == null) return;
                // 刚 addView 时还没量过，等布局出来再摆
                if (p.getWidth() == 0 && tries++ < 20) {
                    postDelayed(this, 50);
                    return;
                }
                if (p.getWidth() == 0) return;

                SharedPreferences sp = getContext().getSharedPreferences(PREF, Context.MODE_PRIVATE);
                if (sp.contains(K_X)) {
                    int pw = Math.max(0, contentW(p) - getWidth());
                    int ph = Math.max(0, contentH(p) - getHeight());
                    lp.leftMargin = Math.max(0, Math.min(
                            (int) (sp.getFloat(K_X, 1f) * pw), pw));
                    lp.topMargin = Math.max(0, Math.min(
                            (int) (sp.getFloat(K_Y, 1f) * ph), ph));
                    setLayoutParams(lp);
                } else {
                    placeBottomRight(p, lp);
                }
            }
        });
    }

    /** 复位到网页球的位置（右下 14dp），菜单里「复位闪电球」用得上 */

    private void placeBottomRight(ViewGroup p, FrameLayout.LayoutParams lp) {
        lp.leftMargin = Math.max(edge, contentW(p) - getWidth() - edge);
        lp.topMargin = Math.max(edge, contentH(p) - getHeight() - edge - Ui.dp(getContext(), LIFT_DP));
        setLayoutParams(lp);
    }

    /**
     * 系统栏边距变化后（比如转屏、进出全屏、首次拿到 inset），
     * 把已经摆好的球重新夹回可视区域内，避免它落在 padding 之外被裁掉。
     */
    public void clampIntoView() {
        FrameLayout.LayoutParams lp = lp();
        ViewGroup p = (ViewGroup) getParent();
        if (lp == null || p == null || p.getWidth() == 0) return;
        int maxL = Math.max(0, contentW(p) - getWidth());
        int maxT = Math.max(0, contentH(p) - getHeight());
        int l = Math.max(0, Math.min(lp.leftMargin, maxL));
        int t = Math.max(0, Math.min(lp.topMargin, maxT));
        if (l != lp.leftMargin || t != lp.topMargin) {
            lp.leftMargin = l;
            lp.topMargin = t;
            setLayoutParams(lp);
        }
    }

    /**
     * 闪电球当前在屏幕左侧还是右侧（按球心判断）。
     * 弹窗横向对齐、动作栏的贴边方向都按它来。
     */
    public boolean onLeftHalf() {
        ViewGroup p = (ViewGroup) getParent();
        FrameLayout.LayoutParams lp = lp();
        if (p == null || lp == null) return false;
        int pw = contentW(p);
        return (lp.leftMargin + getWidth() / 2f) < pw / 2f;
    }

    /** 球底边在父容器内的 y 坐标（弹窗避让用） */
    public int bottomIn(ViewGroup parent) {
        return getTop() + getHeight() + parent.getPaddingTop();
    }

    /** 球顶边在父容器内的 y 坐标 */
    public int topIn(ViewGroup parent) {
        return getTop() + parent.getPaddingTop();
    }

    public void resetToDefault() {
        ViewGroup p = (ViewGroup) getParent();
        FrameLayout.LayoutParams lp = lp();
        if (p == null || lp == null) return;
        placeBottomRight(p, lp);
        getContext().getSharedPreferences(PREF, Context.MODE_PRIVATE)
                .edit().remove(K_X).remove(K_Y).apply();
    }
}
