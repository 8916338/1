package com.shanqiu.app;

import android.webkit.MimeTypeMap;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

/** 文件类型判断：给下载器 / 安装器 / 系统「打开方式」用 */
public final class Mimes {

    /** 一打开就应该走「下载」的扩展名 */
    private static final Set<String> DOWNLOADABLE = new HashSet<>(Arrays.asList(
            "apk", "apks", "xapk", "apkm", "zip", "rar", "7z", "tar", "gz", "tgz", "bz2", "xz",
            "zst", "iso", "exe", "msi", "dmg", "deb", "rpm", "bin", "img", "jar",
            "pdf", "epub", "mobi", "azw3", "doc", "docx", "xls", "xlsx", "ppt", "pptx",
            "mp3", "m4a", "flac", "wav", "mp4", "mkv", "avi", "mov", "webm", "ts", "m3u8",
            "ttf", "otf", "woff", "woff2", "db", "sqlite", "torrent"
    ));

    private static final String[][] EXTRA = {
            {"apk", "application/vnd.android.package-archive"},
            {"apks", "application/vnd.android.package-archive"},
            {"xapk", "application/vnd.android.package-archive"},
            {"apkm", "application/vnd.android.package-archive"},
            {"zip", "application/zip"},
            {"rar", "application/x-rar-compressed"},
            {"7z", "application/x-7z-compressed"},
            {"tar", "application/x-tar"},
            {"gz", "application/gzip"},
            {"tgz", "application/gzip"},
            {"bz2", "application/x-bzip2"},
            {"xz", "application/x-xz"},
            {"zst", "application/zstd"},
            {"iso", "application/x-iso9660-image"},
            {"exe", "application/vnd.microsoft.portable-executable"},
            {"msi", "application/x-msi"},
            {"dmg", "application/x-apple-diskimage"},
            {"deb", "application/vnd.debian.binary-package"},
            {"rpm", "application/x-rpm"},
            {"epub", "application/epub+zip"},
            {"mobi", "application/x-mobipocket-ebook"},
            {"azw3", "application/vnd.amazon.ebook"},
            {"mkv", "video/x-matroska"},
            {"flac", "audio/flac"},
            {"m3u8", "application/vnd.apple.mpegurl"},
            {"torrent", "application/x-bittorrent"},
            {"sqlite", "application/x-sqlite3"},
            {"db", "application/x-sqlite3"},
            {"ttf", "font/ttf"},
            {"otf", "font/otf"},
            {"woff", "font/woff"},
            {"woff2", "font/woff2"}
    };

    private Mimes() {
    }

    public static String ext(String urlOrName) {
        if (urlOrName == null) return "";
        String s = urlOrName;
        int q = s.indexOf('?');
        if (q >= 0) s = s.substring(0, q);
        int h = s.indexOf('#');
        if (h >= 0) s = s.substring(0, h);
        int slash = s.lastIndexOf('/');
        String last = slash >= 0 ? s.substring(slash + 1) : s;
        int dot = last.lastIndexOf('.');
        if (dot < 0 || dot == last.length() - 1) return "";
        String e = last.substring(dot + 1).toLowerCase(Locale.US);
        return e.length() > 8 ? "" : e;
    }

    public static String fromName(String name) {
        String e = ext(name);
        if (e.length() == 0) return null;
        for (String[] kv : EXTRA) {
            if (kv[0].equals(e)) return kv[1];
        }
        String m = MimeTypeMap.getSingleton().getMimeTypeFromExtension(e);
        return m;
    }

    /** 猜 MIME：优先用服务器给的，其次看扩展名 */
    public static String guess(String url, String serverMime) {
        String byExt = fromName(url);
        if (byExt != null) return byExt;
        if (serverMime != null && serverMime.length() > 0
                && !serverMime.startsWith("text/plain")
                && !serverMime.equals("application/octet-stream")) {
            return serverMime;
        }
        if (serverMime != null && serverMime.length() > 0) return serverMime;
        return "application/octet-stream";
    }

    public static boolean isDownloadable(String url) {
        return DOWNLOADABLE.contains(ext(url));
    }

    /** 按文件路径给 MIME（本地站点资源用） */
    public static String forPath(String path) {
        if (path == null) return "application/octet-stream";
        String p = path.toLowerCase(Locale.US);
        if (p.endsWith(".html") || p.endsWith(".htm")) return "text/html";
        if (p.endsWith(".json")) return "application/json";
        if (p.endsWith(".css")) return "text/css";
        if (p.endsWith(".js") || p.endsWith(".mjs")) return "application/javascript";
        if (p.endsWith(".svg")) return "image/svg+xml";
        if (p.endsWith(".png")) return "image/png";
        if (p.endsWith(".jpg") || p.endsWith(".jpeg")) return "image/jpeg";
        if (p.endsWith(".gif")) return "image/gif";
        if (p.endsWith(".webp")) return "image/webp";
        if (p.endsWith(".ico")) return "image/x-icon";
        if (p.endsWith(".bmp")) return "image/bmp";
        if (p.endsWith(".woff2")) return "font/woff2";
        if (p.endsWith(".woff")) return "font/woff";
        if (p.endsWith(".ttf")) return "font/ttf";
        if (p.endsWith(".otf")) return "font/otf";
        if (p.endsWith(".txt")) return "text/plain";
        if (p.endsWith(".xml")) return "text/xml";
        if (p.endsWith(".mp4")) return "video/mp4";
        if (p.endsWith(".webm")) return "video/webm";
        if (p.endsWith(".mp3")) return "audio/mpeg";
        if (p.endsWith(".m4a")) return "audio/mp4";
        if (p.endsWith(".wav")) return "audio/wav";
        if (p.endsWith(".m3u8")) return "application/vnd.apple.mpegurl";
        if (p.endsWith(".pdf")) return "application/pdf";
        return "application/octet-stream";
    }

    /** 文本类资源需要显式给 utf-8，否则中文会乱码 */
    public static boolean isText(String mime) {
        if (mime == null) return false;
        return mime.startsWith("text/") || mime.contains("json")
                || mime.contains("javascript") || mime.contains("xml")
                || mime.contains("svg");
    }

    public static boolean isApk(String urlOrName, String mime) {
        String e = ext(urlOrName);
        if (e.equals("apk") || e.equals("apks") || e.equals("xapk") || e.equals("apkm")) return true;
        return "application/vnd.android.package-archive".equals(mime);
    }
}
