package com.shanqiu.app;

import android.app.AlertDialog;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * 后台 / 多窗口（features.background，可裁剪模块）。
 *
 * 能力：
 *   1. openBackground(url)  —— 在一个隐藏的 WebView 里预加载页面，不打断当前浏览；
 *   2. openInNewWindow(url) —— 立即切到新窗口，当前页面转入后台列表；
 *   3. 面板                —— 列出所有后台页，点击切换、可新建窗口、可逐个关闭。
 *
 * 窗口模型：MainActivity 只有一个「前台」WebView（MainActivity.web），
 * 后台页是同一个 FrameLayout 里 visibility=GONE 的额外 WebView。
 * 切换 = 交换可见性并让 MainActivity 把引用指向新的前台 WebView，
 * 所以前进/后退/刷新/收藏等行为对切换后的窗口一律生效。
 *
 * 本类属于可裁剪功能：features.background=false 时不会编译进包，
 * 所有入口都经 FabRegistry 间接调用。
 */
public final class Background {

    private static final int MAX_TABS = 6;

    static final class Tab {
        WebView v;
        String url;
    }

    /** 后台页列表（含被切下来的前窗口），进程内共享 */
    private static final ArrayList<Tab> TABS = new ArrayList<>();

    private Background() {
    }

    // ------------------------------------------------------------ 入口

    /** 后台打开：预加载但不切换。同地址已在后台就不再重复开。 */
    public static void openBackground(MainActivity a, String url) {
        open(a, url, false);
    }

    /** 新窗口打开：新 WebView 立即到前台，当前页转入后台列表。 */
    public static void openNewWindow(MainActivity a, String url) {
        open(a, url, true);
    }

    /**
     * 新建一个窗口，直接加载「初始页」（更多 → 初始页 里设的那个；
     * 没设就用打包预设，再没有就内置首页），不再弹输入网址的框。
     */
    public static void newStartWindow(MainActivity a) {
        if (a == null) return;
        WebView w = a.spawnWebView(true);
        String url = Prefs.startTarget(a);
        if (TextUtils.isEmpty(url)) url = Site.builtinUrl(a);
        w.loadUrl(url);

        WebView old = a.currentWeb();
        if (old != null) putAside(a, old);
        a.adoptForeground(w);
        Ui.toast(a, "已新建窗口（初始页）");
    }

    /** 长按书签 / 链接时弹的二选一：后台打开 / 新窗口打开 */
    public static void chooseWindow(final MainActivity a, final String url) {
        if (a == null || TextUtils.isEmpty(url)) return;
        if (Bookmarks.HOME.equals(url)) {
            Ui.toast(a, "首页不用开后台");
            return;
        }
        AlertDialog.Builder b = new AlertDialog.Builder(a);
        b.setItems(new String[]{"后台打开（不离开当前页）", "新窗口打开（当前页转入后台）"},
                new android.content.DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(android.content.DialogInterface d, int w) {
                        if (w == 0) openBackground(a, url);
                        else openNewWindow(a, url);
                    }
                });
        b.setNegativeButton("取消", null);
        try {
            Ui.showList(b.create());
        } catch (Throwable ignored) {
        }
    }

    // ------------------------------------------------------------ 核心

    private static void open(MainActivity a, String url, boolean foreground) {
        if (a == null || TextUtils.isEmpty(url)) return;
        if (!Bookmarks.HOME.equals(url) && !Route.isHttp(url)
                && !url.startsWith(Site.ORIGIN)) {
            Ui.toast(a, "只支持 http / https 网址");
            return;
        }

        // 同地址已在后台：后台打开就提示；新窗口就切换过去
        for (Tab t : TABS) {
            if (url.equals(t.url)) {
                if (foreground) switchTo(a, t);
                else Ui.toast(a, "这个页面已经在后台打开了");
                return;
            }
        }

        if (foreground) {
            WebView w = a.spawnWebView(true);
            w.loadUrl(url);
            WebView old = a.currentWeb();
            if (old != null) putAside(a, old);
            a.adoptForeground(w);
            Ui.toast(a, "已在新窗口打开");
            return;
        }

        if (TABS.size() >= MAX_TABS) {
            Ui.toast(a, "后台页最多 " + MAX_TABS + " 个，请先去「后台」里关掉几个");
            return;
        }
        WebView w = a.spawnWebView(false);
        w.loadUrl(url);
        Tab t = new Tab();
        t.v = w;
        t.url = url;
        TABS.add(t);
        Ui.toast(a, "已在后台打开，去「书签 → 后台」查看");
    }

    /** 把一个 WebView 转入后台列表 */
    private static void putAside(MainActivity a, WebView w) {
        if (w == null) return;
        String u = null;
        try {
            u = w.getUrl();
        } catch (Throwable ignored) {
        }
        Tab t = new Tab();
        t.v = w;
        t.url = TextUtils.isEmpty(u) ? "(空白页)" : u;
        TABS.add(t);
        trim();
    }

    /** 切换到某个后台页：它升为前台，原前台页转入列表 */
    public static void switchTo(MainActivity a, Tab t) {
        if (a == null || t == null || t.v == null) return;
        TABS.remove(t);
        WebView old = a.currentWeb();
        t.v.setVisibility(View.VISIBLE);
        a.adoptForeground(t.v);
        putAside(a, old);
        Ui.toast(a, "已切换窗口");
    }

    private static void trim() {
        while (TABS.size() > MAX_TABS) {
            Tab t = TABS.remove(0);
            destroy(t);
        }
    }

    private static void destroy(Tab t) {
        if (t == null || t.v == null) return;
        try {
            ViewGroup p = (ViewGroup) t.v.getParent();
            if (p != null) p.removeView(t.v);
        } catch (Throwable ignored) {
        }
        try {
            t.v.destroy();
        } catch (Throwable ignored) {
        }
        t.v = null;
    }

    /** 渲染进程挂掉的后台页：直接清掉（MainActivity 的 client 会回调这里） */
    public static void onWebGone(WebView v) {
        for (int i = TABS.size() - 1; i >= 0; i--) {
            if (TABS.get(i).v == v) {
                destroy(TABS.remove(i));
            }
        }
    }

    /** 退出时清理所有后台页 */
    public static void destroyAll() {
        for (Tab t : TABS) destroy(t);
        TABS.clear();
    }

    // ------------------------------------------------------------ 面板

    public static void show(final MainActivity a) {
        if (a == null) return;

        final AlertDialog[] holder = new AlertDialog[1];

        LinearLayout root = new LinearLayout(a);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(Ui.dp(a, 6), Ui.dp(a, 8), Ui.dp(a, 6), Ui.dp(a, 8));

        if (TABS.isEmpty()) {
            TextView empty = new TextView(a);
            empty.setText("没有后台页。\n\n长按链接或书签选「后台打开」，\n或点下面「新建窗口」直接开初始页。");
            empty.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 13f);
            empty.setTextColor(0xFF6B7280);
            empty.setGravity(Gravity.CENTER);
            empty.setLineSpacing(Ui.dp(a, 3), 1f);
            empty.setPadding(0, Ui.dp(a, 30), 0, Ui.dp(a, 30));
            root.addView(empty, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        } else {
            TextView tip = new TextView(a);
            tip.setText("点一下切换，左右滑动删除");
            tip.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 11.5f);
            tip.setTextColor(0xFF9AA3B2);
            tip.setGravity(Gravity.CENTER);
            tip.setPadding(0, 0, 0, Ui.dp(a, 6));
            root.addView(tip, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        }

        ScrollView sv = new ScrollView(a);
        sv.setVerticalScrollBarEnabled(false);

        for (int i = 0; i < TABS.size(); i++) {
            final Tab t = TABS.get(i);
            root.addView(tabRow(a, t, root, holder), new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            if (i < TABS.size() - 1) {
                View line = new View(a);
                line.setBackgroundColor(0xFFF1F3F6);
                root.addView(line, new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, Math.max(1, Ui.dp(a, 1) / 2)));
            }
        }

        TextView add = new TextView(a);
        add.setText("＋ 新建窗口（初始页）");
        add.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 13.5f);
        add.setTextColor(Shell.of(a).accent);
        add.setGravity(Gravity.CENTER);
        add.setPadding(0, Ui.dp(a, 12), 0, Ui.dp(a, 4));
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (holder[0] != null) holder[0].dismiss();
                // 直接建一个初始页窗口，不再问网址
                newStartWindow(a);
            }
        });
        root.addView(add, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        sv.setFillViewport(false);
        sv.addView(root, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        AlertDialog.Builder b = new AlertDialog.Builder(a);
        b.setTitle("后台（" + TABS.size() + "/" + MAX_TABS + "）");
        b.setView(sv);
        b.setNegativeButton("关闭", null);
        try {
            AlertDialog d = b.create();
            holder[0] = d;
            Ui.show(d);
        } catch (Throwable ignored) {
        }
    }

    /**
     * 一行后台页：
     *   点一下  → 切过去，并关掉面板
     *   左右划  → 直接关掉这一页（不需要再点「关闭」按钮）
     *   上下划  → 交给外层列表滚动，不抢手势
     */
    private static View tabRow(final MainActivity a, final Tab t,
                               final ViewGroup listRoot, final AlertDialog[] holder) {
        String title = t.v == null ? "" : t.v.getTitle();
        if (TextUtils.isEmpty(title)) title = Bookmarks.labelOf(t.url);

        final LinearLayout row = new LinearLayout(a);
        row.setOrientation(LinearLayout.VERTICAL);
        row.setPadding(Ui.dp(a, 14), Ui.dp(a, 11), Ui.dp(a, 14), Ui.dp(a, 11));
        row.setBackground(Ui.pressBackground(a));

        TextView name = new TextView(a);
        name.setText(title);
        name.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 14f);
        name.setTextColor(0xFF111827);
        name.getPaint().setFakeBoldText(true);
        name.setSingleLine(true);
        name.setEllipsize(TextUtils.TruncateAt.MIDDLE);
        row.addView(name);

        TextView url = new TextView(a);
        url.setText(t.url);
        url.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 11.5f);
        url.setTextColor(0xFF8B96A5);
        url.setSingleLine(true);
        url.setEllipsize(TextUtils.TruncateAt.MIDDLE);
        url.setPadding(0, Ui.dp(a, 3), 0, 0);
        row.addView(url);

        final int slop = Ui.dp(a, 8);
        final int delAt = Ui.dp(a, 56);

        row.setOnTouchListener(new View.OnTouchListener() {
            private float downX;
            private float downY;
            private float lastY;
            private int mode;
            private long downAt;

            @Override
            public boolean onTouch(View v, android.view.MotionEvent e) {
                switch (e.getActionMasked()) {
                    case android.view.MotionEvent.ACTION_DOWN:
                        downX = e.getX();
                        downY = e.getY();
                        lastY = downY;
                        mode = 0;
                        downAt = System.currentTimeMillis();
                        return true;

                    case android.view.MotionEvent.ACTION_MOVE: {
                        float dx = e.getX() - downX;
                        float dy = e.getY() - downY;
                        if (mode == 0) {
                            if (Math.abs(dx) > slop && Math.abs(dx) > Math.abs(dy)) mode = 1;
                            else if (Math.abs(dy) > slop) mode = 2;
                        }
                        if (mode == 1) {
                            row.setTranslationX(dx);
                            return true;
                        }
                        if (mode == 2 && listRoot.getParent() instanceof ScrollView) {
                            ((ScrollView) listRoot.getParent())
                                    .scrollBy(0, (int) (lastY - e.getY()));
                            lastY = e.getY();
                            return true;
                        }
                        return true;
                    }

                    case android.view.MotionEvent.ACTION_UP:
                    case android.view.MotionEvent.ACTION_CANCEL: {
                        float dx = e.getX() - downX;
                        if (mode == 1 && Math.abs(dx) > delAt) {
                            swipeOut(a, row, listRoot, t, holder);
                            return true;
                        }
                        row.animate().translationX(0f).setDuration(120).start();
                        // 没划动、且按得不久 → 当成点击：切过去并关面板
                        boolean tap = Math.abs(dx) < slop
                                && Math.abs(e.getY() - downY) < slop
                                && System.currentTimeMillis() - downAt < 600;
                        if (tap) {
                            if (holder[0] != null) holder[0].dismiss();
                            switchTo(a, t);
                        }
                        return true;
                    }

                    default:
                        return true;
                }
            }
        });
        return row;
    }

    /** 划走：先动画，再从列表和窗口栈里清掉 */
    private static void swipeOut(final MainActivity a, final View row,
                                 final ViewGroup listRoot, final Tab t,
                                 final AlertDialog[] holder) {
        if (t == null) return;
        float to = row.getTranslationX() > 0
                ? row.getWidth() + Ui.dp(a, 40) : -row.getWidth() - Ui.dp(a, 40);
        row.animate().translationX(to).alpha(0f).setDuration(160)
                .withEndAction(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            listRoot.removeView(row);
                        } catch (Throwable ignored) {
                        }
                        TABS.remove(t);
                        destroy(t);
                        Ui.toast(a, "已关闭这个后台页");
                        if (TABS.isEmpty() && holder[0] != null) {
                            holder[0].dismiss();
                        }
                    }
                }).start();
    }
}
