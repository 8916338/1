package com.shanqiu.app;

import android.content.Context;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.webkit.MimeTypeMap;

import java.io.File;
import java.io.FileNotFoundException;

/**
 * 极简版 FileProvider：把 App 缓存目录和「下载」目录里的文件以 content:// 暴露出去，
 * 用于把安装包交给系统安装器、把视频等文件交给其它 App 打开。
 *
 * 为什么不直接 file://：Android 7 起，把 file:// 传给别的应用会直接抛
 * FileUriExposedException（表现就是「打开文件没反应」），必须走 content://。
 */
public class LocalFiles extends android.content.ContentProvider {

    public static final String AUTHORITY = "com.shanqiu.app.files";
    public static final String DIR = "dl";

    public static File dir(Context c) {
        File d = new File(c.getCacheDir(), DIR);
        if (!d.exists()) //noinspection ResultOfMethodCallIgnored
            d.mkdirs();
        return d;
    }

    public static Uri uriFor(Context c, File f) {
        return new Uri.Builder()
                .scheme("content")
                .authority(AUTHORITY)
                .appendPath(DIR)
                .appendPath(f.getName())
                .build();
    }

    /** 下载目录的公共根（对外只暴露这一棵树） */
    public static File downloadRoot() {
        return android.os.Environment
                .getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DOWNLOADS);
    }

    /**
     * 任意文件（目前支持下载目录树）转 content://。
     * 转不了返回 null，调用方自行兜底。
     */
    public static Uri uriForPath(File f) {
        try {
            String base = downloadRoot().getCanonicalPath();
            String path = f.getCanonicalPath();
            if (!path.startsWith(base + File.separator)) return null;
            String rel = path.substring(base.length() + 1);
            return Uri.parse("content://" + AUTHORITY + "/down/" + Uri.encode(rel, "/"));
        } catch (Throwable t) {
            return null;
        }
    }

    public static File fileFor(Context c, String name) {
        return new File(dir(c), name);
    }

    @Override
    public boolean onCreate() {
        return true;
    }

    @Override
    public ParcelFileDescriptor openFile(Uri uri, String mode) throws FileNotFoundException {
        File f = resolve(uri);
        if (f == null) throw new FileNotFoundException(String.valueOf(uri));

        boolean write = mode != null && mode.indexOf('w') >= 0;
        if (write) {
            // 扫码拍照时相机把自己的照片写进来，这时文件还不存在
            File parent = f.getParentFile();
            if (parent != null && !parent.exists()) //noinspection ResultOfMethodCallIgnored
                parent.mkdirs();
            if (!f.exists()) {
                try {
                    if (!f.createNewFile()) throw new FileNotFoundException(String.valueOf(uri));
                } catch (java.io.IOException e) {
                    throw new FileNotFoundException(String.valueOf(uri));
                }
            }
            return ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_WRITE);
        }

        if (!f.exists() || f.length() == 0) {
            throw new FileNotFoundException(String.valueOf(uri));
        }
        return ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY);
    }

    private File resolve(Uri uri) {
        if (getContext() == null) return null;
        java.util.List<String> seg = uri.getPathSegments();
        if (seg == null || seg.isEmpty()) return null;
        try {
            // content://…/dl/<文件名>：缓存目录
            if (DIR.equals(seg.get(0))) {
                String name = seg.get(seg.size() - 1);
                name = name.replace("/", "").replace("..", "");
                File base = new File(getContext().getCacheDir(), DIR);
                File f = new File(base, name);
                String basePath = base.getCanonicalPath();
                if (!f.getCanonicalPath().startsWith(basePath + File.separator)) return null;
                return f;
            }
            // content://…/down/<相对路径>：公共下载目录
            if ("down".equals(seg.get(0))) {
                StringBuilder rel = new StringBuilder();
                for (int i = 1; i < seg.size(); i++) {
                    if (rel.length() > 0) rel.append('/');
                    rel.append(seg.get(i));
                }
                if (rel.length() == 0) return null;
                File base = downloadRoot();
                File f = new File(base, rel.toString());
                String basePath = base.getCanonicalPath();
                if (!f.getCanonicalPath().startsWith(basePath + File.separator)) return null;
                return f;
            }
            return null;
        } catch (Exception e) {
            return null;
        }
    }

    @Override
    public String getType(Uri uri) {
        String name = uri.getLastPathSegment();
        String mime = Mimes.fromName(name);
        return mime == null ? "application/octet-stream" : mime;
    }

    @Override
    public android.database.Cursor query(Uri uri, String[] projection, String selection,
                                         String[] selectionArgs, String sortOrder) {
        return null;
    }

    @Override
    public Uri insert(Uri uri, android.content.ContentValues values) {
        return null;
    }

    @Override
    public int delete(Uri uri, String selection, String[] selectionArgs) {
        return 0;
    }

    @Override
    public int update(Uri uri, android.content.ContentValues values, String selection,
                      String[] selectionArgs) {
        return 0;
    }
}
