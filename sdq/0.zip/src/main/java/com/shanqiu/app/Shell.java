package com.shanqiu.app;

import android.content.Context;

/**
 * 壳（闪电球 / 横向按钮条 / 面板 / 各类弹窗）专用配色 —— 与网页彻底解耦。
 *
 * 分工：
 *   Theme = 网页侧：内置页 CSS 变量、WebView 底色、深色策略
 *   Shell = 浏览器本体：所有看得见的按钮、面板、弹窗、文字
 *
 * 两边预设同源（同一组 id），但取色与派生各走各的：
 *   壳的颜色永远不会写进网页（不再靠主题色去染 WebView / 注入第三方页），
 *   网页自己的配色也不会反过来影响壳。
 *
 * 壳这边额外有一道「浅色安全」校正：按压底色 / 边框色都以面板底色为底、
 * 只混入少量强调色或文字色，并且限制最大亮度差。这样任何一套预设下，
 * 按钮只会是「同一色调的浅色块」，不会再出现整条按钮发黑的情况。
 */
public final class Shell {

    /** 壳面板/按钮允许的最大亮度差（0~1），超过就往底色回拉 */
    private static final float MAX_PRESS_DIFF = 0.10f;
    private static final float MAX_BORDER_DIFF = 0.13f;

    private Shell() {
    }

    /** 当前生效的壳配色 */
    public static Theme.Palette of(Context c) {
        return of(Prefs.themeIndex(c));
    }

    public static Theme.Palette of(int index) {
        Theme.Palette s = Theme.of(index);
        int page = s.page;
        int panel = page;                                   // 面板与页面同一底色
        int press = soften(page, s.accent, 0.09f, MAX_PRESS_DIFF);
        int border = soften(page, s.text, 0.13f, MAX_BORDER_DIFF);
        int dim = Theme.blend(s.sub, page, 0.45f);          // 禁用态：更淡
        return new Theme.Palette(s.id, s.name, s.accent, press, panel, border,
                s.text, s.sub, s.icon, dim, page, s.ok, s.warn, s.dark);
    }

    /**
     * 以 base 为底混入 ink，并保证结果与 base 的亮度差不超过 maxDiff。
     * 超出就按比例回拉，最多尝试 5 次；仍不合格则取极轻的一层。
     */
    private static int soften(int base, int ink, float ratio, float maxDiff) {
        float r = ratio;
        for (int i = 0; i < 5; i++) {
            int c = Theme.blend(ink, base, r);
            if (Math.abs(lum(c) - lum(base)) <= maxDiff) return c;
            r *= 0.55f;
        }
        return Theme.blend(ink, base, 0.03f);
    }

    private static float lum(int c) {
        int r = (c >> 16) & 0xFF;
        int g = (c >> 8) & 0xFF;
        int b = c & 0xFF;
        return (0.299f * r + 0.587f * g + 0.114f * b) / 255f;
    }
}
