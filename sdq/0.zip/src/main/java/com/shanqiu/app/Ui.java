package com.shanqiu.app;

import android.app.AlertDialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

/** 一些零碎的小工具 */
public final class Ui {

    private Ui() {
    }

    public static int dp(Context c, float v) {
        return (int) (TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v,
                c.getResources().getDisplayMetrics()) + 0.5f);
    }

    public static int sp(Context c, float v) {
        return (int) (TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, v,
                c.getResources().getDisplayMetrics()) + 0.5f);
    }

    /** 列表行通用按压背景：平时透明，按下淡橙圆角 */
    public static StateListDrawable pressBackground(Context c) {
        GradientDrawable pressed = new GradientDrawable();
        pressed.setColor(0xFFFFF8F5);
        pressed.setCornerRadius(dp(c, 9));
        GradientDrawable normal = new GradientDrawable();
        normal.setColor(Color.TRANSPARENT);
        normal.setCornerRadius(dp(c, 9));
        StateListDrawable sl = new StateListDrawable();
        sl.addState(new int[]{android.R.attr.state_pressed}, pressed);
        sl.addState(new int[]{}, normal);
        return sl;
    }

    public static void toast(Context c, String msg) {
        if (c == null || msg == null) return;
        try {
            Toast.makeText(c, msg, Toast.LENGTH_SHORT).show();
        } catch (Throwable ignored) {
        }
    }

    /** 去掉路径里的危险字符，只留文件名 */
    public static String safeName(String name, String fallback) {
        String n = name == null ? "" : name.trim();
        int cut = n.indexOf('?');
        if (cut >= 0) n = n.substring(0, cut);
        int hash = n.indexOf('#');
        if (hash >= 0) n = n.substring(0, hash);
        n = n.replace('\\', '/');
        int slash = n.lastIndexOf('/');
        if (slash >= 0) n = n.substring(slash + 1);
        n = n.replaceAll("[\\\\:*?\"<>|\\r\\n\\t]", "_");
        if (n.length() == 0 || n.equals(".") || n.equals("..")) n = fallback;
        if (n.length() > 90) {
            int dot = n.lastIndexOf('.');
            String ext = dot > 0 && n.length() - dot <= 8 ? n.substring(dot) : "";
            n = n.substring(0, 90 - ext.length()) + ext;
        }
        return n;
    }

    public static String humanSize(long bytes) {
        if (bytes <= 0) return "";
        if (bytes < 1024) return bytes + " B";
        if (bytes < 1024 * 1024) return String.format(java.util.Locale.US, "%.0f KB", bytes / 1024.0);
        if (bytes < 1024L * 1024 * 1024)
            return String.format(java.util.Locale.US, "%.1f MB", bytes / 1048576.0);
        return String.format(java.util.Locale.US, "%.2f GB", bytes / 1073741824.0);
    }

    // ------------------------------------------------------------ 弹窗统一主题

    /**
     * 显示并主题化一个 AlertDialog：
     *   1. 不压暗背景（dimAmount = 0），弹窗和页面显示原色，不分明暗；
     *   2. 弹窗底色 = 主题面板色（= 页面底色，同一个颜色，看起来是一个整体）；
     *   3. 标题 / 消息 / 按钮文字颜色跟着主题走；
     *   4. 高度最多 60% 屏高，留下背景可以点击（点击外部关闭）。
     *
     * 全项目的 AlertDialog 一律走这里，不要直接 builder.show()。
     */
    public static AlertDialog show(AlertDialog d) {
        try {
            d.show();
            themeDialog(d);
            // 候选列表（setItems 那种）要等 ListView 挂上去之后再换样式
            styleListItems(d);
            capHeight(d);
        } catch (Throwable t) {
            return d;
        }
        return d;
    }

    /** 同 show()，但列表项留到下一帧再换（有的列表是 onShow 里才填的） */
    public static AlertDialog showList(final AlertDialog d) {
        show(d);
        try {
            View decor = d.getWindow() == null ? null : d.getWindow().getDecorView();
            if (decor != null) {
                decor.post(new Runnable() {
                    @Override
                    public void run() {
                        styleListItems(d);
                    }
                });
            }
        } catch (Throwable ignored) {
        }
        return d;
    }

    /** 单选弹窗的回调 */
    public interface Choice {
        void onPick(int index);
    }

    /**
     * 单选弹窗：一行一个独立圆角色块，选中那行浅底色 + 强调色文字 + 右侧对勾。
     *
     * 为什么不直接用 setSingleChoiceItems：系统的列表行是贴着排的，Ui.styleListItems
     * 又给每行套了同色圆角底，「屏幕方向 / 初始页」这种选项一多就糊成一整块，
     * 分不清哪行是哪行。这里自己画，行与行之间留 6dp，视觉上和「转到网址」
     * 「收藏书签」那种弹窗是一套的。
     */
    public static AlertDialog choose(final Context c, String title, String[] items,
                                     int checked, final Choice pick) {
        if (c == null || items == null || items.length == 0) return null;
        final Theme.Palette p = Shell.of(c);
        final AlertDialog[] holder = new AlertDialog[1];

        LinearLayout list = new LinearLayout(c);
        list.setOrientation(LinearLayout.VERTICAL);

        for (int i = 0; i < items.length; i++) {
            final int index = i;
            final boolean on = i == checked;

            LinearLayout row = new LinearLayout(c);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(android.view.Gravity.CENTER_VERTICAL);
            row.setPadding(dp(c, 14), dp(c, 12), dp(c, 14), dp(c, 12));
            row.setBackground(rowChip(c, p, on));
            row.setClickable(true);
            row.setFocusable(true);

            TextView label = new TextView(c);
            label.setText(items[i]);
            label.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14.5f);
            label.setTextColor(on ? p.accent : p.text);
            if (on) label.getPaint().setFakeBoldText(true);
            row.addView(label, new LinearLayout.LayoutParams(0,
                    ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

            if (on) {
                TextView tick = new TextView(c);
                tick.setText("✓");
                tick.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f);
                tick.setTextColor(p.accent);
                tick.setPadding(dp(c, 8), 0, 0, 0);
                row.addView(tick);
            }

            row.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    AlertDialog d = holder[0];
                    if (d != null && d.isShowing()) d.dismiss();
                    if (pick != null) pick.onPick(index);
                }
            });

            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.bottomMargin = dp(c, 6);
            list.addView(row, lp);
        }

        final ScrollView scroller = new ScrollView(c);
        scroller.setFillViewport(false);
        scroller.addView(list, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        LinearLayout box = new LinearLayout(c);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(c, 14), 0, dp(c, 14), dp(c, 2));
        box.addView(scroller, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        AlertDialog d = new AlertDialog.Builder(c)
                .setTitle(title)
                .setView(box)
                .setNegativeButton("取消", null)
                .create();
        holder[0] = d;

        // 选项多的时候（初始页可能有七八个）卡在 45% 屏高，里面自己滚
        final int maxH = (int) (c.getResources().getDisplayMetrics().heightPixels * 0.45f);
        scroller.post(new Runnable() {
            @Override
            public void run() {
                if (list.getHeight() <= maxH) return;
                ViewGroup.LayoutParams lp = scroller.getLayoutParams();
                lp.height = maxH;
                scroller.setLayoutParams(lp);
            }
        });

        show(d);
        return d;
    }

    /** 单选行的底色：选中 = 页面底混一点强调色，按下再深一层 */
    private static StateListDrawable rowChip(Context c, Theme.Palette p, boolean on) {
        GradientDrawable pressed = new GradientDrawable();
        pressed.setColor(Theme.blend(p.accent, p.page, 0.16f));
        pressed.setCornerRadius(dp(c, 12));

        GradientDrawable normal = new GradientDrawable();
        normal.setColor(on ? Theme.blend(p.accent, p.page, 0.09f) : Color.TRANSPARENT);
        normal.setCornerRadius(dp(c, 12));

        StateListDrawable sl = new StateListDrawable();
        sl.addState(new int[]{android.R.attr.state_pressed}, pressed);
        sl.addState(new int[]{}, normal);
        return sl;
    }

    /** 给已经弹出的对话框换上主题色（主题切换后重新调一次也行） */
    public static void themeDialog(android.app.Dialog d) {
        if (d == null) return;
        Context c = d.getContext();
        Theme.Palette p = Shell.of(c);
        android.view.Window w = d.getWindow();
        if (w == null) return;
        try {
            w.setDimAmount(0f);
        } catch (Throwable ignored) {
        }
        try {
            GradientDrawable bg = new GradientDrawable();
            bg.setColor(p.panel);
            bg.setCornerRadius(dp(c, 16));
            bg.setStroke(Math.max(1, dp(c, 0.8f)), p.border);
            w.setBackgroundDrawable(bg);
        } catch (Throwable ignored) {
        }
        // 标题、消息（id 是系统内部资源，按名字取，取不到就算了）
        tint(w, c, "alertTitle", p.text);
        tint(w, c, "message", p.sub);
        // 三个按钮
        if (d instanceof AlertDialog) {
            int[] slots = {AlertDialog.BUTTON_POSITIVE, AlertDialog.BUTTON_NEGATIVE,
                    AlertDialog.BUTTON_NEUTRAL};
            for (int slot : slots) {
                try {
                    android.view.View b = ((AlertDialog) d).getButton(slot);
                    styleActionButton(b, c, p);
                } catch (Throwable ignored) {
                }
            }
        }
    }

    /**
     * 把弹窗底部那排按钮（保存 / 打开 / 取消 / 删除）改成
     * 「页面查找」里「上一个 / 下一个」那种胶囊样式：
     * 浅色底 + 强调色文字，按下再深一点。
     *
     * 系统默认给的是 Material 的 tonal 背景，安卓 12+ 上会跟着动态取色变蓝，
     * 和壳的配色完全不搭 —— 统一换成壳自己的配色。
     */
    public static void styleActionButton(android.view.View b, Context c, Theme.Palette p) {
        if (!(b instanceof TextView)) return;
        TextView t = (TextView) b;
        t.setTextColor(p.accent);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f);
        if (t instanceof android.widget.Button) {
            ((android.widget.Button) t).setAllCaps(false);
        }
        t.setMinWidth(0);
        t.setMinimumWidth(0);
        t.setMinHeight(0);
        t.setMinimumHeight(0);
        t.setPadding(dp(c, 14), dp(c, 7), dp(c, 14), dp(c, 7));
        t.setBackground(chipBackground(c, p));
    }

    /** 胶囊按钮背景：平时浅色块，按下加深一层 */
    public static StateListDrawable chipBackground(Context c, Theme.Palette p) {
        GradientDrawable pressed = new GradientDrawable();
        pressed.setColor(Theme.blend(p.accent, p.press, 0.16f));
        pressed.setCornerRadius(dp(c, 999));

        GradientDrawable normal = new GradientDrawable();
        normal.setColor(p.press);
        normal.setCornerRadius(dp(c, 999));

        StateListDrawable sl = new StateListDrawable();
        sl.addState(new int[]{android.R.attr.state_pressed}, pressed);
        sl.addState(new int[]{}, normal);
        return sl;
    }

    /**
     * 弹窗里的候选列表（setItems / setSingleChoiceItems 那种一行一行的选项）
     * 换成和「上一个 / 下一个」同一套胶囊样式。
     *
     * 系统默认给的列表行在安卓 12+ 上是 Material 的动态取色底，常常是蓝的，
     * 跟壳的配色完全打架。
     *
     * 注意：只改已有行的外观（文字色 / 背景 / 内边距），**不替换 adapter** ——
     * 之前试过给 ListView 换 adapter，某些机型上会把整个列表渲染成空白
     * （用户看到的「对话框里只有取消没有选项」就是这么来的）。
     * 外观 pass 在布局完成后跑，滚动时再补一遍。
     */
    public static void styleListItems(android.app.Dialog d) {
        if (d == null) return;
        try {
            final android.widget.ListView lv = findList(d.getWindow() == null
                    ? null : d.getWindow().getDecorView());
            if (lv == null) return;
            final Context c = d.getContext();
            final Theme.Palette p = Shell.of(c);
            lv.setDividerHeight(0);
            lv.setDivider(null);
            lv.setSelector(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
            lv.setCacheColorHint(Color.TRANSPARENT);
            lv.setPadding(dp(c, 10), dp(c, 4), dp(c, 10), dp(c, 4));

            final Runnable style = new Runnable() {
                @Override
                public void run() {
                    try {
                        for (int i = 0; i < lv.getChildCount(); i++) {
                            View child = lv.getChildAt(i);
                            styleRow(child, c, p,
                                    lv.getChoiceMode() == android.widget.ListView.CHOICE_MODE_SINGLE
                                            && lv.getCheckedItemPosition() == i);
                        }
                    } catch (Throwable ignored) {
                    }
                }
            };
            lv.getViewTreeObserver().addOnGlobalLayoutListener(
                    new android.view.ViewTreeObserver.OnGlobalLayoutListener() {
                        @Override
                        public void onGlobalLayout() {
                            style.run();
                        }
                    });
            lv.setOnScrollListener(new android.widget.AbsListView.OnScrollListener() {
                @Override
                public void onScrollStateChanged(android.widget.AbsListView v, int state) {
                }

                @Override
                public void onScroll(android.widget.AbsListView v, int first, int visible,
                                     int total) {
                    style.run();
                }
            });
            lv.post(style);
        } catch (Throwable ignored) {
        }
    }

    /** 给一整行（可能是 TextView，也可能包着文字的容器）套上胶囊样式 */
    private static void styleRow(View row, Context c, Theme.Palette p, boolean selected) {
        if (row == null) return;
        if (row instanceof TextView) {
            TextView t = (TextView) row;
            t.setTextColor(selected ? p.accent : p.text);
            t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f);
            if (selected) t.getPaint().setFakeBoldText(true);
            t.setMinHeight(0);
            t.setMinimumHeight(0);
            t.setPadding(dp(c, 14), dp(c, 11), dp(c, 14), dp(c, 11));
            t.setBackground(chipBackground(c, p));
            return;
        }
        // 容器行：改文字子 View 的颜色，背景给行本身
        if (row instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) row;
            boolean textFound = false;
            for (int i = 0; i < g.getChildCount(); i++) {
                View ch = g.getChildAt(i);
                if (ch instanceof TextView) {
                    TextView t = (TextView) ch;
                    t.setTextColor(selected ? p.accent : p.text);
                    textFound = true;
                }
            }
            row.setBackground(chipBackground(c, p));
            int pv = dp(c, 10);
            row.setPadding(pv, pv, pv, pv);
            if (!textFound) row.getBackground().mutate().setAlpha(0);
            return;
        }
    }

    /** 在一棵视图树里找那个列表（AlertDialog 的列表一般只有一个） */
    private static android.widget.ListView findList(View v) {
        if (v == null) return null;
        if (v instanceof android.widget.ListView) return (android.widget.ListView) v;
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) {
                android.widget.ListView r = findList(g.getChildAt(i));
                if (r != null) return r;
            }
        }
        return null;
    }

    private static void tint(android.view.Window w, Context c, String idName, int color) {
        try {
            int id = c.getResources().getIdentifier(idName, "id", "android");
            if (id <= 0) return;
            android.view.View v = w.findViewById(id);
            if (v instanceof TextView) ((TextView) v).setTextColor(color);
        } catch (Throwable ignored) {
        }
    }

    /** 统一的三段式确认框：标题 + 说明 + 「取消 / 确定」 */
    public static void confirm(Context c, String title, String message, String okText,
                               final Runnable ok, final Runnable cancel) {
        if (c == null) return;
        AlertDialog d = new AlertDialog.Builder(c)
                .setTitle(title)
                .setMessage(message)
                .setNegativeButton("取消", new android.content.DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(android.content.DialogInterface dlg, int w) {
                        if (cancel != null) cancel.run();
                    }
                })
                .setPositiveButton(okText == null ? "确定" : okText,
                        new android.content.DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(android.content.DialogInterface dlg, int w) {
                                if (ok != null) ok.run();
                            }
                        })
                .create();
        show(d);
    }

    /**
     * 弹窗限高：最多 60% 屏高，超出部分由弹窗内部滚动，
     * 底下留一截真实页面可以点（配合点外部关闭）。
     */
    public static void capHeight(final android.app.Dialog d) {
        if (d == null) return;
        final android.view.Window w = d.getWindow();
        if (w == null) return;
        final View decor = w.getDecorView();
        decor.post(new Runnable() {
            @Override
            public void run() {
                try {
                    int maxH = (int) (d.getContext().getResources()
                            .getDisplayMetrics().heightPixels * 0.6f);
                    int cur = decor.getHeight();
                    if (cur > maxH) {
                        WindowManager.LayoutParams lp = w.getAttributes();
                        lp.height = maxH;
                        w.setAttributes(lp);
                    }
                } catch (Throwable ignored) {
                }
            }
        });
    }
}
