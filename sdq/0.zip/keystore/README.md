# 签名证书放这里

仓库**不含任何私钥**。把你的证书和口令放在本目录，构建时自动识别：

```bash
cp /path/to/your.jks keystore/release.jks

cat > keystore/keystore.properties <<'PROP'
storeFile=release.jks
storePassword=你的口令
keyAlias=你的别名
keyPassword=你的口令
PROP
```

这两个文件已被 `.gitignore` 排除，`git status` 不会提示，也不会误传。

不放也能构建：`build.sh` 会现场生成一把临时自签名证书，够装上手机试跑，
但**无法覆盖安装正式版**。

GitHub Actions 上用 Secrets 代替本地文件：
`KEYSTORE_BASE64`（jks 的 base64）、`KEYSTORE_PASSWORD`、`KEY_ALIAS`、`KEY_PASSWORD`。
