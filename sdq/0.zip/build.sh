#!/usr/bin/env bash
# ============================================================================
# 无 Gradle 构建：aapt2 + javac + d8 + zipalign + apksigner
#
# 说明文档在 docs/BUILD.md，本文件只保留必要的阶段输出。
# 所有可变项都来自 app-config.json，由 tools/apply_config.py 先应用一遍。
# ============================================================================
set -Eeuo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"

on_error() {
  local code=$?
  echo "!! 第 ${BASH_LINENO[0]:-?} 行失败，退出码 $code"
  if [ -n "${OUT:-}" ] && [ -f "$OUT/javac.log" ]; then
    echo "---- javac.log 末尾 ----"
    tail -n 40 "$OUT/javac.log" || true
  fi
  exit "$code"
}
trap on_error ERR

step() {
  echo "==> $*"
}

if ! command -v python3 >/dev/null 2>&1; then
  echo "!! 需要 python3"; exit 1
fi
if ! command -v javac >/dev/null 2>&1; then
  echo "!! 需要 javac（JDK 8 以上）"; exit 1
fi

say_jdk="$(javac -version 2>&1 | head -n 1)"

SDK="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-}}"
if [ -z "$SDK" ] || [ ! -d "$SDK" ]; then
  for d in /usr/local/lib/android/sdk /root/sdk "$HOME/Android/Sdk" "$HOME/Library/Android/sdk"; do
    if [ -n "$d" ] && [ -d "$d" ]; then SDK="$d"; break; fi
  done
fi
if [ -z "$SDK" ] || [ ! -d "$SDK" ]; then
  echo "!! 找不到 Android SDK，请设置 ANDROID_HOME"; exit 1
fi
export ANDROID_HOME="$SDK"
export ANDROID_SDK_ROOT="$SDK"

pick_dir() {
  python3 - "$1" "$2" "$3" <<'PY'
import os
import re
import sys

base, need, want = sys.argv[1], sys.argv[2], sys.argv[3]
if not os.path.isdir(base):
    sys.exit(0)

items = []
for name in os.listdir(base):
    path = os.path.join(base, name)
    if os.path.isdir(path) and os.path.exists(os.path.join(path, need)):
        items.append(name)

if not items:
    sys.exit(0)

if want and want in items:
    print(os.path.join(base, want))
    sys.exit(0)

def sort_key(text):
    nums = [int(x) for x in re.findall(r"\d+", text)]
    stable = 0 if re.search(r"(rc|beta|preview|alpha)", text.lower()) else 1
    return (nums, stable)

items.sort(key=sort_key)
print(os.path.join(base, items[-1]))
PY
}

BT="$(pick_dir "$SDK/build-tools" aapt2 36.0.0)"
PDIR="$(pick_dir "$SDK/platforms" android.jar android-36)"

if [ -z "$BT" ] || [ ! -x "$BT/aapt2" ]; then
  echo "!! $SDK/build-tools 下没有带 aapt2 的版本"; exit 1
fi
if [ -z "$PDIR" ] || [ ! -f "$PDIR/android.jar" ]; then
  echo "!! $SDK/platforms 下没有 android.jar"; exit 1
fi

PLATFORM="$PDIR/android.jar"

for tool in d8 zipalign apksigner; do
  if [ ! -x "$BT/$tool" ]; then
    echo "!! $BT 里缺 $tool"; exit 1
  fi
done

if ! command -v zip >/dev/null 2>&1; then
  echo "!! 需要 zip（apt install zip）"; exit 1
fi

say_bt="$(basename "$BT")"
say_pf="$(basename "$PDIR")"
echo "    JDK: $say_jdk"
echo "    SDK: $SDK"
echo "    build-tools: $say_bt   platform: $say_pf"

step "0/8 应用 app-config.json"
CFG_ARGS=()
if [ "${VIE_PLAIN:-0}" = "1" ]; then
  CFG_ARGS=(--plain)
elif [ "${VIE_OBFUSCATE:-0}" = "1" ]; then
  CFG_ARGS=(--obfuscate)
elif [ "${VIE_HARDEN:-0}" = "1" ]; then
  CFG_ARGS=(--harden)
fi
# 支持临时覆盖版本号（CI 手动触发用），不改 app-config.json 本身
[ -n "${VIE_VERSION_NAME:-}" ] && CFG_ARGS+=(--version-name "$VIE_VERSION_NAME")
[ -n "${VIE_VERSION_CODE:-}" ] && CFG_ARGS+=(--version-code "$VIE_VERSION_CODE")
python3 "$ROOT/tools/apply_config.py" "${CFG_ARGS[@]}"

CFG="$ROOT/.resolved-config.json"
if [ ! -f "$CFG" ]; then
  echo "!! apply_config.py 没有生成 $CFG"; exit 1
fi

read_cfg() {
  python3 -c '
import json
import sys

with open(sys.argv[1], encoding="utf-8") as fh:
    print(json.load(fh)[sys.argv[2]])
' "$CFG" "$1"
}

APP_NAME="$(read_cfg appName)"
VERSION_CODE="$(read_cfg versionCode)"
VERSION_NAME="$(read_cfg versionName)"
PACKAGE="$(read_cfg packageName)"
MIN_SDK="$(read_cfg minSdk)"
TARGET_SDK="$(read_cfg targetSdk)"

if [ -z "$APP_NAME" ] || [ -z "$VERSION_NAME" ] || [ -z "$PACKAGE" ]; then
  echo "!! appName / versionName / packageName 不能为空"; exit 1
fi

# 下一版配置在这里就生成（而不是等打包末尾）：
# ① 它是 app-config.json 的完整复刻 + 版本号 1，和编译是否成功无关；
# ② 放在最前面，后面哪一步挂了，tools/update/app-config.next.json 也已经是这一版的，
#    不会停留在上一个版本的旧内容（以前新增的字段就是这么丢的）。
step "0/8 生成下一版配置（复刻 app-config.json，版本号 +1）"
NEXT_ARGS=()
[ -n "${VIE_NEXT_VERSION_NAME:-}" ] && NEXT_ARGS+=(--next-name "$VIE_NEXT_VERSION_NAME")
python3 "$ROOT/tools/gen_next_config.py" \
  --config "$ROOT/app-config.json" \
  --cur-name "$VERSION_NAME" \
  --cur-code "$VERSION_CODE" \
  ${NEXT_ARGS[@]+"${NEXT_ARGS[@]}"} \
  --out "$ROOT/tools/update/app-config.next.json" \
  || { echo "!! 下一版配置生成失败（配置有问题，先修好再出包）"; exit 5; }

LIBS="$ROOT/libs"
JARS=()
if [ -d "$LIBS" ]; then
  while IFS= read -r jar; do
    [ -n "$jar" ] && JARS+=("$jar")
  done < <(find "$LIBS" -maxdepth 1 -name '*.jar' | sort)
fi
if [ ${#JARS[@]} -gt 0 ]; then
  echo "    依赖 jar：${#JARS[@]} 个"
fi

OUT="$ROOT/build"
rm -rf "$OUT"
mkdir -p "$OUT/gen" "$OUT/classes" "$OUT/dex"

step "1/8 编译资源"
"$BT/aapt2" compile --dir "$ROOT/src/main/res" -o "$OUT/res.zip"

PACKAGE_ATTR="    package=\"$PACKAGE\""
MANIFEST_IN="$ROOT/src/main/AndroidManifest.xml"
MANIFEST_OUT="$OUT/AndroidManifest.xml"

python3 - "$MANIFEST_IN" "$MANIFEST_OUT" "$PACKAGE_ATTR" <<'PY'
import sys

src, dst, attr = sys.argv[1], sys.argv[2], sys.argv[3]

with open(src, encoding="utf-8") as fh:
    text = fh.read()

if "package=" in text.split(">", 1)[0]:
    print("    清单里已有 package 属性，跳过注入")
else:
    marker = '<manifest xmlns:android="http://schemas.android.com/apk/res/android"'
    if marker not in text:
        raise SystemExit("!! AndroidManifest.xml 里找不到 manifest 起始标签，无法注入 package")
    text = text.replace(marker, marker + "\n" + attr, 1)

with open(dst, "w", encoding="utf-8") as fh:
    fh.write(text)
PY

step "2/8 链接资源与 assets"
ASSETS_DIR="$ROOT/.assets-build"
if [ ! -d "$ASSETS_DIR" ]; then
  echo "    .assets-build 不存在，回退到 src/main/assets"
  ASSETS_DIR="$ROOT/src/main/assets"
fi
if [ ! -f "$ASSETS_DIR/index.html" ]; then
  echo "!! $ASSETS_DIR 里没有 index.html"; exit 1
fi

"$BT/aapt2" link \
  -o "$OUT/base.apk" \
  --manifest "$MANIFEST_OUT" \
  -I "$PLATFORM" \
  -A "$ASSETS_DIR" \
  --java "$OUT/gen" \
  --min-sdk-version "$MIN_SDK" \
  --target-sdk-version "$TARGET_SDK" \
  --version-code "$VERSION_CODE" \
  --version-name "$VERSION_NAME" \
  --auto-add-overlay \
  "$OUT/res.zip"

step "3/8 编译 Java"
find "$ROOT/src/main/java" "$OUT/gen" -name '*.java' > "$OUT/sources_all.txt"

python3 - "$CFG" > "$OUT/excluded.txt" <<'PY'
import json
import sys

with open(sys.argv[1], encoding="utf-8") as fh:
    cfg = json.load(fh)

for name in cfg.get("excludedSources", []):
    print(name)
PY

if [ -s "$OUT/excluded.txt" ]; then
  python3 - "$OUT/sources_all.txt" "$OUT/excluded.txt" "$OUT/sources.txt" <<'PY'
import sys

all_path, skip_path, out_path = sys.argv[1], sys.argv[2], sys.argv[3]

with open(skip_path, encoding="utf-8") as fh:
    skip = {line.strip() for line in fh if line.strip()}

kept = []
with open(all_path, encoding="utf-8") as fh:
    for line in fh:
        name = line.strip()
        if not name:
            continue
        if any(name.endswith(item) for item in skip):
            continue
        kept.append(name)

with open(out_path, "w", encoding="utf-8") as fh:
    fh.write("\n".join(kept) + "\n")

print("    已排除：" + " ".join(sorted(skip)))
PY
else
  cp "$OUT/sources_all.txt" "$OUT/sources.txt"
fi

if [ ! -s "$OUT/sources.txt" ]; then
  echo "!! 源码列表为空"; exit 1
fi

set +e
JAVAC_CP="$PLATFORM"
if [ ${#JARS[@]} -gt 0 ]; then
  for jar in "${JARS[@]}"; do JAVAC_CP="$JAVAC_CP:$jar"; done
fi

javac -source 8 -target 8 -encoding UTF-8 -nowarn \
  -bootclasspath "$PLATFORM" \
  -classpath "$JAVAC_CP" \
  -d "$OUT/classes" \
  @"$OUT/sources.txt" > "$OUT/javac.log" 2>&1
JAVAC_RC=$?
set -e

if [ "$JAVAC_RC" -ne 0 ]; then
  echo "!! javac 失败："
  cat "$OUT/javac.log"
  exit 1
fi

if [ -z "$(find "$OUT/classes" -name '*.class' -print -quit)" ]; then
  echo "!! javac 没有产出 class"; exit 1
fi

step "4/8 dex"
find "$OUT/classes" -name '*.class' > "$OUT/classes.txt"
D8_INPUTS=("@$OUT/classes.txt")
if [ ${#JARS[@]} -gt 0 ]; then
  D8_INPUTS+=("${JARS[@]}")
fi

if [ "${VIE_HARDEN:-0}" = "1" ]; then
  # 加固版：R8 全量混淆（类名/方法名/字段名 → a、b、c）
  # 规则见 tools/proguard-rules.pro，manifest 里按名字引用的组件不参与改名
  if ! command -v java >/dev/null 2>&1; then
    echo "!! 加固版需要 java 运行 R8"; exit 1
  fi
  if [ ! -f "$ROOT/tools/proguard-rules.pro" ]; then
    echo "!! 缺 tools/proguard-rules.pro"; exit 1
  fi
  echo "    使用 R8 混淆代码…"
  java -cp "$BT/lib/d8.jar" com.android.tools.r8.R8 \
    --release \
    --min-api "$MIN_SDK" \
    --lib "$PLATFORM" \
    --pg-conf "$ROOT/tools/proguard-rules.pro" \
    --output "$OUT/dex" \
    "${D8_INPUTS[@]}"
else
  "$BT/d8" --release --min-api "$MIN_SDK" --lib "$PLATFORM" --output "$OUT/dex" \
    "${D8_INPUTS[@]}"
fi

if [ ! -f "$OUT/dex/classes.dex" ]; then
  echo "!! d8 没有产出 classes.dex"; exit 1
fi

cp "$OUT/base.apk" "$OUT/unsigned.apk"
(
  cd "$OUT"
  zip -q -j unsigned.apk dex/classes.dex
)

step "5/8 对齐"
"$BT/zipalign" -f -p 4 "$OUT/unsigned.apk" "$OUT/aligned.apk"

step "6/8 签名"
# 密钥位置与口令：优先环境变量（KEYSTORE_PATH / KEYSTORE_PASSWORD / KEY_ALIAS / KEY_PASSWORD），
# 其次 keystore/keystore.properties，都没有就用 keystore/release.jks（首次构建自动生成）。
# 仓库里不放私钥；本地把 .jks + properties 放进去即可，它们已被 .gitignore 排除。
KS="$ROOT/keystore/release.jks"
KS_PASS=""
KEY_ALIAS=""
KEY_PASS=""

PROPS="$ROOT/keystore/keystore.properties"
if [ -f "$PROPS" ]; then
  eval "$(python3 - "$PROPS" <<'PY'
import sys

with open(sys.argv[1], encoding="utf-8") as fh:
    for line in fh:
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, v = line.split("=", 1)
        k = k.strip()
        v = v.strip()
        if k == "storeFile":
            print('KS="$(dirname "$PROPS")/%s"' % v)
        elif k == "storePassword":
            print('KS_PASS=%s' % v)
        elif k == "keyAlias":
            print('KEY_ALIAS=%s' % v)
        elif k == "keyPassword":
            print('KEY_PASS=%s' % v)
PY
)"
fi

KS="${KEYSTORE_PATH:-$KS}"
KS_PASS="${KEYSTORE_PASSWORD:-${KS_PASS:-android}}"

if [ ! -f "$KS" ]; then
  # 本地没放证书时，自动从 CI 工作流里内嵌的那段 base64 还原一份，
  # 保证本机与 GitHub 打出同一个签名（否则用户装不上，提示软件冲突）。
  WF="$ROOT/.github/workflows/build.yml"
  if [ -f "$WF" ]; then
    python3 - "$WF" "$KS" <<'PY'
import base64
import re
import sys

wf, out = sys.argv[1], sys.argv[2]
try:
    text = open(wf, encoding="utf-8").read()
    m = re.search(r"KS_B64:\s*\"([A-Za-z0-9+/=]+)\"", text)
    if not m:
        sys.exit(1)
    data = base64.b64decode(m.group(1))
    open(out, "wb").write(data)
    print("    已从工作流还原签名密钥：%s（%d 字节）" % (out, len(data)))
    # 口令也取工作流里的，省得本地再猜
    s = re.search(r"KS_PASS=\"([^\"]+)\"", text)
    if s:
        print("    KS_PASS 取自工作流：" + s.group(1))
except Exception:
    sys.exit(1)
PY
  fi
fi

# 口令 / 别名以工作流为准（还原出来的证书就用这套），除非外部显式指定
WF="$ROOT/.github/workflows/build.yml"
if [ -f "$WF" ]; then
  WF_PASS="$(sed -n 's/^[[:space:]]*KS_PASS="\([^"]*\)".*/\1/p' "$WF" | head -1)"
  WF_ALIAS="$(sed -n 's/^[[:space:]]*KS_ALIAS="\([^"]*\)".*/\1/p' "$WF" | head -1)"
  [ -z "${KEYSTORE_PASSWORD:-}" ] && [ -n "$WF_PASS" ] && KS_PASS="$WF_PASS"
  [ -z "${KEY_ALIAS:-}" ] && [ -n "$WF_ALIAS" ] && KEY_ALIAS="$WF_ALIAS"
  KEY_PASS="${KEY_PASSWORD:-$KS_PASS}"
fi
KEY_ALIAS="${KEY_ALIAS:-release}"
KEY_PASS="${KEY_PASS:-$KS_PASS}"

if [ ! -f "$KS" ]; then
  echo "    没找到签名密钥，正在生成：$KS"
  echo "    （测试用自签名；正式发布请换成自己的证书，见 README 第六节）"
  mkdir -p "$(dirname "$KS")"
  keytool -genkeypair \
    -keystore "$KS" \
    -storepass "$KS_PASS" \
    -keypass "$KEY_PASS" \
    -alias "$KEY_ALIAS" \
    -keyalg RSA \
    -keysize 2048 \
    -validity 10950 \
    -dname "CN=$PACKAGE, OU=App, O=App, L=Local, ST=Local, C=CN" \
    >/dev/null 2>&1
fi

if [ "${VIE_PLAIN:-0}" = "1" ]; then
  VARIANT="明文"
elif [ "${VIE_HARDEN:-0}" = "1" ]; then
  VARIANT="加固"
elif [ "${VIE_OBFUSCATE:-0}" = "1" ]; then
  VARIANT="混淆"
else
  # 不带参数 = 公开发行版（加固）。调试请显式 VIE_PLAIN=1 / VIE_OBFUSCATE=1
  VARIANT="加固"
fi
# 公开发行版 = 加固版：文件名不带修饰词，如 闪电球1.0.1.apk
# 明文 / 混淆是内部调试包，带后缀区分
if [ "$VARIANT" = "加固" ]; then
  APK="$OUT/$APP_NAME$VERSION_NAME.apk"
else
  APK="$OUT/$APP_NAME-$VERSION_NAME-$VARIANT.apk"
fi

"$BT/apksigner" sign \
  --ks "$KS" \
  --ks-pass "pass:$KS_PASS" \
  --key-pass "pass:$KEY_PASS" \
  --v1-signing-enabled true \
  --v2-signing-enabled true \
  --v3-signing-enabled true \
  --out "$APK" \
  "$OUT/aligned.apk"

"$BT/apksigner" verify --verbose --print-certs "$APK" > "$OUT/verify.txt" 2>&1 || true

python3 - "$OUT/verify.txt" "$ROOT/app-config.json" "${VIE_SKIP_CERT_CHECK:-0}" <<'PY'
import json
import sys

verify_path, cfg_path, skip = sys.argv[1], sys.argv[2], sys.argv[3]
with open(verify_path, encoding="utf-8", errors="replace") as fh:
    text = fh.read()

for scheme in ("v1", "v2", "v3"):
    if "Verified using " + scheme in text:
        print("    签名 %s：OK" % scheme)
    else:
        print("    !! 签名 %s：缺失" % scheme)

cert = ""
for line in text.splitlines():
    if "certificate SHA-256 digest" in line:
        cert = line.split(":", 1)[-1].strip().lower().replace(":", "")
        break
print("    证书 SHA-256：" + (cert or "读不出来"))

want = ""
try:
    with open(cfg_path, encoding="utf-8") as fh:
        want = (json.load(fh).get("certSha256") or "").strip().lower().replace(":", "")
except Exception:
    pass

for line in text.splitlines():
    if "WARNING" in line.upper():
        print("    ! " + line.strip())

if not cert:
    print("    !! 读不出证书指纹，无法确认能否覆盖安装")
    sys.exit(2)

if want and cert != want:
    if skip == "1":
        print("    !! 证书与 app-config.json 记录不一致（VIE_SKIP_CERT_CHECK=1 已跳过）")
        print("       本次 %s / 期望 %s" % (cert[:16] + "...", want[:16] + "..."))
    else:
        print("    !! 证书与 app-config.json 的 certSha256 不一致：")
        print("       本次 " + cert)
        print("       期望 " + want)
        print("       这样打出来的包装不到用户手机上（签名冲突，必须先卸载旧版）。")
        print("       请用同一份 keystore：放 keystore/release.jks 或设 KEYSTORE_PATH。")
        print("       确属换证书时，改 app-config.json 的 certSha256 后再构建。")
        sys.exit(3)
elif want:
    print("    签名一致性：OK（与 app-config.json 记录相同，可覆盖安装）")
else:
    print("    ! app-config.json 没有 certSha256，已跳过一致性校验")
PY

if [ ! -f "$APK" ]; then
  echo "!! 签名后没有生成 APK"; exit 1
fi

step "7/8 版本连续性 + 体积核对"

# 版本号不能往后退：apk/ 里最后一版是用户手上的版本，新包 versionCode 必须 >= 它。
# 等于允许（同一版重打），小于说明忘了改版本号 —— 用户装不上还提示更新。
if compgen -G "$ROOT/apk/*.apk" > /dev/null 2>&1; then
  OLD_MAX=0
  OLD_NAME=""
  for f in "$ROOT"/apk/*.apk; do
    vc="$("$BT/aapt2" dump badging "$f" 2>/dev/null | grep -o "versionCode='[0-9]*'" | head -1 | tr -dc '0-9')"
    [ -z "$vc" ] && continue
    if [ "$vc" -gt "$OLD_MAX" ]; then
      OLD_MAX="$vc"
      OLD_NAME="$(basename "$f")"
    fi
  done
  echo "    apk/ 已发布最高版本：$OLD_MAX（$OLD_NAME）"
  if [ "$VERSION_CODE" -lt "$OLD_MAX" ]; then
    echo "    !! 本次 versionCode=$VERSION_CODE 小于已发布的 $OLD_MAX —— 用户无法覆盖安装"
    echo "       请把 app-config.json 的 versionCode 改成 $OLD_MAX 或更大"
    exit 4
  fi
  echo "    版本连续性：OK（本次 $VERSION_CODE）"
fi
python3 - "$APK" <<'PY'
import os
import sys
import zipfile

apk = sys.argv[1]
with zipfile.ZipFile(apk) as zf:
    infos = sorted(zf.infolist(), key=lambda i: i.file_size, reverse=True)

print("   APK 总大小 %.1f KB" % (os.path.getsize(apk) / 1024.0))
print("   体积前十：")
for info in infos[:10]:
    print("     %8.1f KB  %s" % (info.file_size / 1024.0, info.filename))

brands = [i for i in infos if i.filename.endswith("ic_brand.png")]
legacy = [i for i in infos
          if i.filename.startswith("res/mipmap-") and i.filename.endswith(".png")]
print("   品牌位图 ic_brand：%d 份；旧式 mipmap PNG：%d 张" % (len(brands), len(legacy)))

if len(brands) != 1:
    print("   !! ic_brand 数量异常（应为 1）")
if legacy:
    print("   !! 仍有 mipmap PNG 残留（应为 0）")
PY

ls -lh "$APK"

step "8/8 发布文件（tools/update/）"
python3 "$ROOT/tools/gen_update_json.py" \
  --config "$ROOT/app-config.json" \
  --apk "$APK" \
  --app-name "$APP_NAME" \
  --variant "$VARIANT" \
  --version-code "$VERSION_CODE" \
  --version-name "$VERSION_NAME" \
  --min-version-code "${VIE_MIN_VERSION_CODE:-0}" \
  --out "$ROOT/tools/update/update.json" || echo "!! 更新模板生成失败（不影响 APK）"

# 自检：两个发布文件必须真的落地，且 app-config.next.json 必须是本版配置的完整复刻
MISSING=0
for f in "$ROOT/tools/update/update.json" "$ROOT/tools/update/app-config.next.json"; do
  [ -f "$f" ] || { echo "!! 缺少发布文件：$f"; MISSING=1; }
done

python3 "$ROOT/tools/gen_next_config.py" \
  --config "$ROOT/app-config.json" \
  --cur-name "$VERSION_NAME" \
  --cur-code "$VERSION_CODE" \
  ${NEXT_ARGS[@]+"${NEXT_ARGS[@]}"} \
  --verify "$ROOT/tools/update/app-config.next.json" || MISSING=1

if [ "$MISSING" = "0" ]; then
  echo "   ┌──────────────────────────────────────────────────────────────"
  echo "   │ tools/update/ 下两个文件已刷新："
  echo "   │   update.json            ← 本版模板，对应 $(basename "$APK")（$VERSION_NAME / $VERSION_CODE）"
  echo "   │   app-config.next.json   ← 下版配置（本版完整复刻，版本号已 +1）"
  echo "   │ 发下一版：cp tools/update/app-config.next.json app-config.json && bash build.sh"
  echo "   └──────────────────────────────────────────────────────────────"
  echo ""
else
  echo "!! 发布文件不完整，先别发这一版"
  exit 6
fi

echo "OK -> $APK"
