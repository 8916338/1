#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
assets（内置网页）深度混淆器 —— 由 build.sh 在 aapt2 链接之前调用。

设计目标
--------
1. 混淆后的 assets 直接被 aapt2 打进 APK，解开 APK 看到的是密文，
   不是可读的 HTML/JS/CSS。
2. 不引入额外运行时依赖：解密器是一段极小的 JS，插在 <head> 第一位，
   保证早于页面里任何脚本执行。它不用 document.write 拼半个文档，
   而是「先解密整篇 → document.open/write/close」，相对路径的 css/js/
   图片因此照原样工作（与明文版行为一致）。
3. 入口页里的内联 <script> 会被抽走、编译进「脚本包」，页面里只留一个
   空占位；解密器写完 DOM 后按原来的顺序、用 document.write 把它们写回去，
   于是脚本的执行时机与明文版完全相同（同一行内、非 defer）。
4. index.html 之外的静态资源（js/css/json/图片/字体…）不再以原路径落盘，
   而是整体打包成「索引表 + 每文件独立 IV 的密文块」，落盘名是无意义哈希，
   连文件列表和目录结构都不暴露。
5. 每次构建随机盐、随机 IV、随机噪音，同一份源码两次构建产物不同，
   靠比对产物反推内容的做法失效。

诚实说明（README 里也写了）
--------
纯前端网页最终必须在客户端还原成 DOM 才能渲染，所以不存在真正意义上
「开发者本人也解不开」的方案：拿到 APK 的人只要 patch 掉解密器，或直接
dump WebView 内存里的明文，总能拿到内容。本模块把门槛抬到
「会解 APK、会读混淆 JS、愿意逆向自定义解码器」这一档，足以挡住绝大多数
伸手党；对专业逆向人员只能延缓，不能杜绝。要更狠就得把逻辑搬到原生层
（JNI 解密 + 自绘渲染），代价是整站 JS 生态全部作废，通常不值得。

用法
----
    python3 tools/obfuscate_assets.py --src src/main/assets --out build/assets
    python3 tools/obfuscate_assets.py --off --out build/assets   # 明文模式
"""
from __future__ import annotations

import argparse
import base64
import hashlib
import json
import os
import random
import re
import shutil
import string
import sys
from pathlib import Path

ENTRY = "index.html"

# index.html 之外这些扩展名会被收进「资源包」
PACKABLE = {
    ".js", ".mjs", ".css", ".svg", ".png", ".jpg", ".jpeg", ".webp",
    ".gif", ".ico", ".woff", ".woff2", ".ttf", ".otf", ".txt", ".map", ".wasm",
}
# 这些不进密文包：
#   媒体/压缩包体积大、本身是二进制，加密收益低，原样复制；
#   .json 是页面 fetch() 和原生代码（书签、赞助码）都要直接读的文件，
#   打进密文包两端都拿不到 —— 必须留在 assets 里保持明文。
SKIP_PACK = {".mp4", ".webm", ".mp3", ".m4a", ".zip", ".apk", ".json"}

MAGIC = b"VIEPK2"
DEFAULT_SEED = "vie-assets-v1::do-not-share"

SCRIPT_OPEN = "<" + "script"
SCRIPT_CLOSE = "</" + "script>"


# ---------------------------------------------------------------- 密码学小件

def ksa(key: bytes) -> list:
    """RC4 KSA —— 得到一个和密钥强相关的 256 字节置换表。"""
    s = list(range(256))
    j = 0
    klen = len(key)
    for i in range(256):
        j = (j + s[i] + key[i % klen]) & 0xFF
        s[i], s[j] = s[j], s[i]
    return s


class Stream:
    """RC4 的 PRGA 当密钥流，与明文异或；每个文件/每次构建独立 IV。"""

    def __init__(self, key: bytes, iv: bytes):
        self.s = ksa(hashlib.sha256(key + iv).digest())
        self.i = 0
        self.j = 0

    def next_byte(self) -> int:
        s = self.s
        self.i = (self.i + 1) & 0xFF
        self.j = (self.j + s[self.i]) & 0xFF
        s[self.i], s[self.j] = s[self.j], s[self.i]
        return s[(s[self.i] + s[self.j]) & 0xFF]

    def xor(self, data: bytes) -> bytes:
        out = bytearray(len(data))
        for k, b in enumerate(data):
            out[k] = b ^ self.next_byte()
        return bytes(out)


def derive_key(seed: str, salt: bytes) -> bytes:
    return hashlib.pbkdf2_hmac("sha256", seed.encode("utf-8"), salt, 60000, 32)


def rand_token(n: int = 12) -> str:
    first = random.choice(string.ascii_lowercase)
    rest = "".join(random.choice(string.ascii_lowercase + string.digits)
                   for _ in range(n - 1))
    return first + rest


def safe_asset_name(rel: str) -> str:
    """
    APK 里 assets 文件名必须是纯 ASCII 且不含空格 —— 中文名进 zip 会变成
    乱码字节，WebView 按原名请求时拿不到文件。非 ASCII 的文件一律映射成
    f + 8 位散列 + 原扩展名；映射规则是确定性的（同输入同输出），
    app-config.json 的 pages.file 由 apply_config.py 用同一个函数换算。
    """
    try:
        rel.encode("ascii")
    except UnicodeEncodeError:
        pass
    else:
        if " " not in rel:
            return rel
    stem, dot, ext = rel.rpartition(".")
    ext = (dot + ext) if dot else ""
    return "f" + hashlib.sha1(rel.encode("utf-8")).hexdigest()[:8] + ext


# ---------------------------------------------------------------- 页面切分

RE_SCRIPT = re.compile(
    r"<script\b(?P<attrs>[^>]*)>(?P<body>.*?)" + re.escape(SCRIPT_CLOSE),
    re.S | re.I,
)


def extract_inline_scripts(html: str) -> tuple:
    """
    把内联脚本从页面里抽出来，页面中留下等量占位。

    返回 (改造后的 html, 脚本列表)。只抽「没有 src 属性」的内联脚本；
    带 src 的保持原样（它本来就是一个外部引用，解密后照样能加载）。
    """
    scripts = []

    def repl(m):
        attrs = m.group("attrs") or ""
        if re.search(r"\bsrc\s*=", attrs, re.I):
            return m.group(0)
        idx = len(scripts)
        scripts.append(m.group("body"))
        # 占位脚本：解密器已把脚本放进 __vie__.q[n]，
        # 这里就地取出并执行，保持与明文完全相同的执行时机。
        return (SCRIPT_OPEN + attrs + ">" +
                "window.__vie__&&window.__vie__.q&&window.__vie__.q[%d]&&"
                "(0,eval)(window.__vie__.q[%d])" % (idx, idx) +
                SCRIPT_CLOSE)

    return RE_SCRIPT.sub(repl, html), scripts


def build_script_pack(scripts: list, key: bytes) -> tuple:
    """
    脚本包：每个脚本一段独立 IV 的密文，拼成一条 base64 字符串，
    附带「每段长度」表 —— 解密器按表切片、逐段解密、逐段 document.write。
    """
    parts, lens = [], []
    for body in scripts:
        iv = os.urandom(12)
        enc = Stream(key, iv).xor(body.encode("utf-8"))
        raw = bytes(iv) + enc
        parts.append(base64.b64encode(raw).decode("ascii"))
        lens.append(len(body.encode("utf-8")))
    return ".".join(parts), lens


# ---------------------------------------------------------------- 资源包

def collect(src: Path) -> tuple:
    pack, keep = [], []
    for p in sorted(src.rglob("*")):
        if not p.is_file():
            continue
        rel = p.relative_to(src).as_posix()
        if p.suffix.lower() == ".html":
            continue
        ext = p.suffix.lower()
        if ext in SKIP_PACK or ext not in PACKABLE:
            keep.append(rel)
        else:
            pack.append(rel)
    return pack, keep


def build_package(src: Path, files: list, key: bytes, with_bomb: bool) -> bytes:
    """
    自解压资源包：MAGIC + IV + 加密后的 JSON 头（含每文件 base64 密文）。
    """
    iv = os.urandom(16)
    head = {"v": 2, "f": {}, "d": {}}
    for rel in files:
        raw = (src / rel).read_bytes()
        biv = os.urandom(12)
        enc = Stream(key, biv).xor(raw)
        token = "a" + hashlib.sha256(biv + rel.encode()).hexdigest()[:16]
        head["f"][rel] = [token, len(raw), base64.b64encode(biv).decode("ascii")]
        head["d"][token] = base64.b64encode(enc).decode("ascii")

    blob = json.dumps(head, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    out = bytearray(MAGIC)
    out.extend(iv)
    out.extend(Stream(key, iv).xor(blob))
    if with_bomb:
        out.extend(os.urandom(random.randint(2048, 6144)))
    return bytes(out)


# ---------------------------------------------------------------- 解密器 JS

PROLOGUE = r"""
<script>/* key */!function(){"use strict";var D=window.__vie__||{};
var K="%(key)s",E="%(entry)s",SP="%(sp)s",SL=%(sl)s,B="%(blob)s";
function hx(s){var a=new Uint8Array(s.length>>1);for(var i=0;i<a.length;i++)a[i]=parseInt(s.substr(i*2,2),16);return a}
function u8(s){var b=atob(s),a=new Uint8Array(b.length);for(var i=0;i<b.length;i++)a[i]=b.charCodeAt(i);return a}
function xr(data,k,iv){
 // 标准 RC4：先 sha256(key||iv) 当密钥，再做 KSA + PRGA。
 // 注意 i/j 必须是普通 Number，不能存进 Uint8Array（会 8 位截断出界）。
 var ks=sha256(cat(k,iv)),s=new Uint8Array(256),j=0,i,t;
 for(i=0;i<256;i++)s[i]=i;
 for(i=0;i<256;i++){j=(j+s[i]+ks[i&31])&255;t=s[i];s[i]=s[j];s[j]=t}
 var o=new Uint8Array(data.length);i=0;j=0;
 for(var c=0;c<data.length;c++){i=(i+1)&255;j=(j+s[i])&255;t=s[i];s[i]=s[j];s[j]=t;o[c]=data[c]^s[(s[i]+s[j])&255]}
 return o}
function cat(a,b){var n=a.length+(b?b.length:0),o=new Uint8Array(n);o.set(a);if(b)o.set(b,a.length);return o}
function sha256(m){
 var K=[0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
 0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
 0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
 0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
 0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
 0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
 0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
 0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2];
 var H=[0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19];
 var l=m.length,bl=l*8,tmp=new Uint8Array(((l+9+63)>>6)<<6);
 tmp.set(m);tmp[l]=0x80;
 // 消息长度按 64 位大端补在末尾：JS 位运算只有 32 位，
 // 所以低 32 位用 bl>>>0 单独算，高 32 位用 Math.floor(bl/4294967296)
 var hi=Math.floor(bl/4294967296),lo=bl>>>0,T=tmp.length;
 tmp[T-8]=(hi>>>24)&255;tmp[T-7]=(hi>>>16)&255;tmp[T-6]=(hi>>>8)&255;tmp[T-5]=hi&255;
 tmp[T-4]=(lo>>>24)&255;tmp[T-3]=(lo>>>16)&255;tmp[T-2]=(lo>>>8)&255;tmp[T-1]=lo&255;
 var w=new Uint32Array(64);
 for(var off=0;off<tmp.length;off+=64){
  var a,b,c,d,e,f,g,h,kx;
  for(var i=0;i<16;i++)w[i]=(tmp[off+i*4]<<24)|(tmp[off+i*4+1]<<16)|(tmp[off+i*4+2]<<8)|tmp[off+i*4+3];
  for(i=16;i<64;i++){var x=w[i-15],y=w[i-2];
   var s0=((x>>>7)|(x<<25))^((x>>>18)|(x<<14))^(x>>>3);
   var s1=((y>>>17)|(y<<15))^((y>>>19)|(y<<13))^(y>>>10);
   w[i]=(w[i-16]+s0+w[i-7]+s1)|0}
  a=H[0];b=H[1];c=H[2];d=H[3];e=H[4];f=H[5];g=H[6];h=H[7];
  for(i=0;i<64;i++){
   var S1=((e>>>6)|(e<<26))^((e>>>11)|(e<<21))^((e>>>25)|(e<<7));
   var ch=(e&f)^(~e&g);
   var t1=(h+S1+ch+K[i]+w[i])|0;
   var S0=((a>>>2)|(a<<30))^((a>>>13)|(a<<19))^((a>>>22)|(a<<10));
   var mj=(a&b)^(a&c)^(b&c);
   var t2=(S0+mj)|0;
   h=g;g=f;f=e;e=(d+t1)|0;d=c;c=b;b=a;a=(t1+t2)|0}
  H[0]=(H[0]+a)|0;H[1]=(H[1]+b)|0;H[2]=(H[2]+c)|0;H[3]=(H[3]+d)|0;
  H[4]=(H[4]+e)|0;H[5]=(H[5]+f)|0;H[6]=(H[6]+g)|0;H[7]=(H[7]+h)|0}
 var out=new Uint8Array(32);
 for(i=0;i<8;i++){out[i*4]=H[i]>>>24;out[i*4+1]=(H[i]>>>16)&255;out[i*4+2]=(H[i]>>>8)&255;out[i*4+3]=H[i]&255}
 return out}
function us(a){var n=a.length,o=[],i=0,c;
 // 严格 UTF-8 解码；4 字节序列要拆成代理对写进 JS 字符串，
 // 否则 emoji 会变成 U+FFFD（代理对必须由两个 \uD800-\uDFFF 组成）。
 while(i<n){
  c=a[i++];
  if(c<0x80){o.push(c)}
  else if(c<0xE0){o.push(((c&31)<<6)|(a[i++]&63))}
  else if(c<0xF0){o.push(((c&15)<<12)|((a[i++]&63)<<6)|(a[i++]&63))}
  else{
   var cp=((c&7)<<18)|((a[i++]&63)<<12)|((a[i++]&63)<<6)|(a[i++]&63);
   cp-=0x10000;
   o.push(0xD800+(cp>>10),0xDC00+(cp&0x3FF));
  }
 }
 var out="";for(var q=0;q<o.length;q+=4096){out+=String.fromCharCode.apply(null,o.slice(q,q+4096))}
 return out}
var k=hx(K);
function dec(b64){var w=u8(b64);return us(xr(w.slice(12),k,w.slice(0,12)))}
D.k=k;D.dec=dec;
D.q=[];
try{
 var sp=SP?SP.split("."):[];
 for(var i=0;i<sp.length;i++){D.q.push(dec(sp[i]))}
 window.__vie__=D;
 document.write(dec(E));
}catch(e){window.__vie__=D}
}();</script>
"""


# ---------------------------------------------------------------- 主流程

def obfuscate(src: Path, out: Path, seed: str, with_bomb: bool = True) -> dict:
    if out.exists():
        shutil.rmtree(out)
    out.mkdir(parents=True, exist_ok=True)

    salt = os.urandom(16)
    key = derive_key(seed, salt)

    pages = sorted(p for p in src.glob("*.html") if p.is_file())
    if not pages:
        raise SystemExit("!! %s 下没有任何 .html 页面" % src)

    pack, keep = collect(src)
    pkg = build_package(src, pack, key, with_bomb)
    blob_name = rand_token(14) + ".dat"
    (out / blob_name).write_bytes(pkg)

    info_pages = []
    for page in pages:
        raw_html = page.read_text(encoding="utf-8")
        html, scripts = extract_inline_scripts(raw_html)

        entry_iv = os.urandom(12)
        entry_enc = Stream(key, entry_iv).xor(html.encode("utf-8"))
        entry_b64 = base64.b64encode(bytes(entry_iv) + entry_enc).decode("ascii")

        sp_b64, sp_lens = build_script_pack(scripts, key)

        prologue = PROLOGUE % {
            "key": key.hex(),
            "entry": entry_b64,
            "sp": sp_b64,
            "sl": json.dumps(sp_lens),
            "blob": blob_name,
        }

        shell = (
            '<!DOCTYPE html><html><head><meta charset="utf-8">'
            '<meta name="viewport" content="width=device-width,initial-scale=1,'
            'maximum-scale=1,user-scalable=no,viewport-fit=cover">'
            + prologue
            + "</head><body></body></html>"
        )
        (out / safe_asset_name(page.name)).write_text(shell, encoding="utf-8")
        info_pages.append({
            "name": page.name,
            "asset": safe_asset_name(page.name),
            "entryKB": round(len(raw_html.encode("utf-8")) / 1024.0, 1),
            "shellKB": round(len(shell.encode("utf-8")) / 1024.0, 1),
            "scripts": len(scripts),
        })

    copied = []
    for rel in keep:
        dst = out / safe_asset_name(rel)
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(src / rel, dst)
        copied.append(rel)

    home = info_pages[0]
    return {
        "pages": info_pages,
        "file_map": {p["name"]: p["asset"] for p in info_pages},
        "entryKB": home["entryKB"],
        "shellKB": home["shellKB"],
        "scripts": sum(p["scripts"] for p in info_pages),
        "packed": len(pack),
        "copied": len(copied),
        "blobKB": round(len(pkg) / 1024.0, 1),
        "blobName": blob_name,
    }


def plain(src: Path, out: Path) -> dict:
    if out.exists():
        shutil.rmtree(out)
    out.mkdir(parents=True, exist_ok=True)
    n = 0
    file_map = {}
    for p in sorted(src.rglob("*")):
        if not p.is_file():
            continue
        rel = p.relative_to(src).as_posix()
        dst = out / safe_asset_name(rel)
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(p, dst)
        file_map[rel] = safe_asset_name(rel)
        n += 1
    return {"files": n, "file_map": file_map}


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--src", default="src/main/assets")
    ap.add_argument("--out", default="build/assets")
    ap.add_argument("--key", default="", help="混淆密钥，留空用内置常量")
    ap.add_argument("--off", action="store_true", help="关闭混淆，原样复制")
    ap.add_argument("--no-bomb", action="store_true", help="不加体积噪音")
    args = ap.parse_args()

    src, out = Path(args.src), Path(args.out)
    if not any(src.glob("*.html")):
        print("!! %s 下没有任何 .html 页面" % src)
        sys.exit(1)

    if args.off:
        info = plain(src, out)
        print("   assets：明文模式，%d 个文件原样打包" % info["files"])
        return

    info = obfuscate(src, out, args.key.strip() or DEFAULT_SEED,
                     with_bomb=not args.no_bomb)
    print("   assets：混淆模式")
    for p in info["pages"]:
        print("     页面 %s：%.1f KB → 加密壳 %.1f KB（内联脚本 %d 段已抽走）"
              % (p["name"], p["entryKB"], p["shellKB"], p["scripts"]))
    print("     资源包 %s %.1f KB，打包 %d 个 / 原样 %d 个"
          % (info["blobName"], info["blobKB"], info["packed"], info["copied"]))


if __name__ == "__main__":
    main()
