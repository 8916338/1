#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
把仓库根目录的 app-config.json 应用到工程里。

做四件事：
  1. 改包名 —— 目录、每个 java 的 package、build.gradle 的 namespace/applicationId
  2. 改版本号、应用名
  3. 生成 Config.java（在线地址 / 备份站点 / 悬浮球文字）
  4. 生成 assets/preset_bookmarks.json（内置书签）
  5. 如果配了 icon，用 Pillow 重新生成各尺寸图标（没装 Pillow 就跳过）

用法：
    python3 tools/apply_config.py
    python3 tools/apply_config.py --version-name 1.2.0 --version-code 12

脚本可重复执行（幂等）；最终生效的值会写到 .resolved-config.json 供 build.sh 读取。
"""
from __future__ import annotations

import argparse
import io
import json
import re
import shutil
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
CFG_PATH = ROOT / "app-config.json"
MANIFEST = ROOT / "src/main/AndroidManifest.xml"
GRADLE = ROOT / "build.gradle"
STRINGS = ROOT / "src/main/res/values/strings.xml"
ASSETS = ROOT / "src/main/assets"
JAVA = ROOT / "src/main/java"
RESOLVED = ROOT / ".resolved-config.json"

MIN_SDK = 21
# 跟随最新稳定版：Android 16 = API 36。
# 提示「针对旧版 Android 构建」的判定阈值由厂商 ROM 决定（AOSP 默认 23，部分 ROM 会抬高），
# 所以 targetSdk 越高，被判定为「旧」的概率越小。
TARGET_SDK = 35
COMPILE_SDK = 36

# 悬浮球菜单：id → 默认标题；顺序以 app-config.json 的数组为准
FAB_TITLES = {
    "refresh": "刷新本页",
    "bookmark": "收藏本页",
    "forward": "前进",
    "back": "后退",
    "home": "返回首页",
    "openurl": "输入网址访问",
    "bookmarks": "书签",
    "pages": "更多页面",
    "downloads": "下载",
    "history": "历史",
    "find": "页面查找",
    "scan": "扫描二维码",
    "share": "分享本页网址",
    "coffee": "赞助",
    "background": "后台",
    "more": "更多",
    "sniff": "视频嗅探",
}
FAB_IDS = list(FAB_TITLES.keys())
DEFAULT_FAB = [
    "openurl", "bookmark", "bookmarks", "pages", "downloads", "history", "find",
    "coffee", "more",
]

# 悬浮球弹窗默认显示顺序（可在 app-config.json 的 fab.sections 里改）
DEFAULT_SECTIONS = [
    "openurl", "bookmark", "bookmarks", "pages", "downloads", "history", "find",
    "coffee", "more",
]

# 弹窗靠球那一侧的横向图标条（fab.toolbar），顺序、开关、分排都可配。
# row = 1/2 … 第几排；同排按数组顺序从左到右，满宽均分。
TOOLBAR_IDS = [
    "refresh", "home", "forward", "back", "scan", "share",
    "history", "downloads", "background", "bookmark", "find", "more", "sniff",
]
DEFAULT_TOOLBAR = [
    # 第一排
    "home", "back", "find", "scan", "share", "more",
    # 第二排
    "refresh", "forward", "history", "downloads", "background", "bookmark",
]

# 「更多」面板：更新 + 7 个浏览设置，全部可排序 / 隐藏 / 改名
MORE_TITLES = {
    "update": "检查更新",
    "sniff": "视频嗅探",
    "play": "在网页里看视频",
    "privacy": "隐私模式",
    "guard": "网页控制",
    "desktop": "网页版本",
    "ua": "浏览器标识",
    "orient": "屏幕方向",
    "font": "字体大小",
    "theme": "主题",
    "start": "初始页",
    "coffee": "赞助",
}
MORE_IDS = list(MORE_TITLES.keys())
DEFAULT_MORE = ["update", "privacy", "desktop", "ua", "orient", "font",
                "theme", "start", "coffee"]

# 所有可裁剪的功能模块：源码文件名 → (开关名, 说明)
OPTIONAL_MODULES = {
    "DownloadsDialog.java": ("downloads", "下载面板"),
    "HistoryDialog.java": ("history", "浏览历史"),
    "Updater.java": ("update", "检测更新"),
}

# mipmap 密度 → 传统图标边长
DENSITIES = {"mdpi": 48, "hdpi": 72, "xhdpi": 96, "xxhdpi": 144, "xxxhdpi": 192}


def die(msg: str) -> None:
    print("!! " + msg)
    sys.exit(1)


def load_config() -> dict:
    if not CFG_PATH.exists():
        die("找不到 app-config.json")
    try:
        cfg = json.loads(CFG_PATH.read_text(encoding="utf-8"))
    except Exception as e:  # noqa: BLE001
        die("app-config.json 不是合法 JSON：%s" % e)
    if not isinstance(cfg, dict):
        die("app-config.json 顶层必须是对象")
    return cfg


def current_package() -> str:
    for p in JAVA.rglob("MainActivity.java"):
        m = re.search(r"^package\s+([\w.]+)\s*;", p.read_text(encoding="utf-8"), re.M)
        if m:
            return m.group(1)
    return ""


def prune_empty(path: Path, stop: Path) -> None:
    while path != stop and path.is_dir():
        try:
            path.rmdir()
        except OSError:
            break
        path = path.parent


def migrate_package(old: str, new: str) -> None:
    """改了包名就把源码目录和 package 行一起搬过去，避免编译报错。"""
    if not old or old == new:
        return

    src = JAVA / old.replace(".", "/")
    dst = JAVA / new.replace(".", "/")
    if not src.is_dir():
        print("   ! 找不到源码目录 %s，跳过包名迁移" % src.relative_to(ROOT))
        return

    if dst.exists():
        shutil.rmtree(dst)
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.move(str(src), str(dst))

    changed = 0
    for f in dst.rglob("*.java"):
        text = f.read_text(encoding="utf-8")
        out = text.replace("package " + old, "package " + new)
        out = out.replace("import " + old, "import " + new)
        if out != text:
            f.write_text(out, encoding="utf-8")
            changed += 1

    prune_empty(src.parent, JAVA)
    print("   包名 %s → %s（%d 个文件）" % (old, new, changed))


def java_str(s: str) -> str:
    return '"' + str(s).replace("\\", "\\\\").replace('"', '\\"').replace("\n", "\\n") + '"'


def norm_fab(cfg: dict) -> tuple:
    """把 app-config.json 的 fab 段规范化：只保留已知 id，按用户给的顺序输出。"""
    fab = cfg.get("fab") or {}
    if not isinstance(fab, dict):
        fab = {}
    enabled = bool(fab.get("enabled", True))
    raw = fab.get("items")
    if not isinstance(raw, list) or not raw:
        raw = [{"id": i} for i in DEFAULT_FAB]

    items = []
    for it in raw:
        if isinstance(it, str):
            item = {"id": it}
        elif isinstance(it, dict):
            item = it
        else:
            continue
        fid = str(item.get("id", "")).strip()
        if fid not in FAB_IDS:
            print("   ! 未知的悬浮球项 id=%s，已跳过（可用：%s）"
                  % (fid, ", ".join(FAB_IDS)))
            continue
        title = str(item.get("title", "") or FAB_TITLES[fid]).strip()
        items.append({
            "id": fid,
            "title": title,
            "enabled": bool(item.get("enabled", True)),
            "_order": item.get("order", None),
        })

    # 可选 order 字段：有就按它排，没有就保持数组顺序
    if any(i["_order"] is not None for i in items):
        items.sort(key=lambda i: (i["_order"] is None, i["_order"] if i["_order"] is not None else 0))
    for i in items:
        i.pop("_order", None)
    return enabled, items


def norm_sections(cfg: dict) -> list:
    """
    悬浮球弹窗的板块列表（fab.sections）：
      数组顺序 = 从下往上显示的顺序的基准（实际按「就近球的位置」上下排布）；
      enabled=false 的板块整块不显示。
    兼容老配置：fab.items 里已有的项自动补进来。
    """
    fab = cfg.get("fab") or {}
    raw = fab.get("sections") if isinstance(fab, dict) else None
    if not isinstance(raw, list) or not raw:
        raw = []

    out = []
    seen = set()
    for it in raw:
        if isinstance(it, str):
            item = {"id": it}
        elif isinstance(it, dict):
            item = it
        else:
            continue
        sid = str(item.get("id", "")).strip()
        if sid not in FAB_IDS or sid in seen:
            continue
        seen.add(sid)
        out.append({
            "id": sid,
            "title": str(item.get("title", "") or FAB_TITLES[sid]).strip(),
            "enabled": bool(item.get("enabled", True)),
        })

    # 老写法：只有 fab.items，没有 sections，就按 items 的 id 顺序当板块顺序
    if not out:
        _, items = norm_fab(cfg)
        ids = [i["id"] for i in items] or DEFAULT_FAB
        for sid in ids:
            if sid in seen:
                continue
            seen.add(sid)
            out.append({"id": sid, "title": FAB_TITLES[sid], "enabled": True})
    return out


def norm_more(cfg: dict) -> list:
    """
    「更多」面板里的项目（fab.more）。

    可用 id：update + 7 个浏览设置（privacy / desktop / ua / orient / font /
    theme / start）。数组顺序就是面板里的显示顺序，enabled=false 整项不显示，
    title 可以改成任何叫法。
    """
    fab = cfg.get("fab") or {}
    raw = fab.get("more") if isinstance(fab, dict) else None
    if not isinstance(raw, list) or not raw:
        raw = list(DEFAULT_MORE)
    out = []
    seen = set()
    for it in raw:
        if isinstance(it, str):
            item = {"id": it}
        elif isinstance(it, dict):
            item = it
        else:
            continue
        mid = str(item.get("id", "")).strip()
        if mid not in MORE_TITLES:
            print("   ! 未知的「更多」项 id=%s，已跳过（可用：%s）"
                  % (mid, ", ".join(MORE_IDS)))
            continue
        if mid in seen:
            continue
        seen.add(mid)
        out.append({
            "id": mid,
            "title": str(item.get("title", "") or MORE_TITLES[mid]).strip(),
            "enabled": bool(item.get("enabled", True)),
        })
    return out


def norm_toolbar(cfg: dict) -> list:
    """
    横向图标条（fab.toolbar）：顺序 + 开关 + 提示文案。

    可用 id：refresh / home / forward / back / scan / share。
    全关掉时 ActionBar 不占位，弹窗只剩列表。
    """
    fab = cfg.get("fab") or {}
    raw = fab.get("toolbar") if isinstance(fab, dict) else None
    if not isinstance(raw, list) or not raw:
        raw = list(DEFAULT_TOOLBAR)
    out = []
    seen = set()
    for it in raw:
        if isinstance(it, str):
            item = {"id": it}
        elif isinstance(it, dict):
            item = it
        else:
            continue
        tid = str(item.get("id", "")).strip()
        if tid not in TOOLBAR_IDS:
            print("   ! 未知的横向栏项 id=%s，已跳过（可用：%s）"
                  % (tid, ", ".join(TOOLBAR_IDS)))
            continue
        if tid in seen:
            continue
        seen.add(tid)
        out.append({
            "id": tid,
            "title": str(item.get("title", "") or FAB_TITLES[tid]).strip(),
            "enabled": bool(item.get("enabled", True)),
            "row": max(1, int(item.get("row", 1) or 1)),
        })
    return out


def norm_start_pages(cfg: dict) -> list:
    """
    初始页候选（startPages）：像内置书签一样，一条一个名字 + 一个指向。

        { "name": "接口大全", "url": "https://..." }
        { "name": "接口大全", "file": "api.html" }

    列表原样进 Config.START_PAGES_JSON，App 里「更多 → 初始页」直接列出来。
    url 优先于 file；两个都空的那条会被丢弃。
    """
    raw = cfg.get("startPages")
    if not isinstance(raw, list) or not raw:
        # 没配就退化成「首页 + 各内置页」，保证旧配置也能用
        raw = []
        for p in norm_pages(cfg):
            if p.get("url"):
                raw.append({"name": p["title"], "url": p["url"]})
            elif p.get("file"):
                raw.append({"name": p["title"], "file": p["file"]})

    out = []
    for it in raw:
        if not isinstance(it, dict):
            continue
        url = str(it.get("url", "") or "").strip()
        f = str(it.get("file", "") or "").strip()
        if not url and not f:
            continue
        name = str(it.get("name", "") or it.get("title", "") or "").strip()
        if not name:
            name = Bookmarks_label(url or f)
        out.append({"name": name, "url": url, "file": f})
    return out


def Bookmarks_label(s: str) -> str:
    """没写名字时，用地址里最像名字的一段兜底。"""
    t = str(s or "").strip()
    if not t:
        return "未命名"
    t = re.sub(r"^[a-zA-Z]+://", "", t)
    t = t.split("?")[0].split("#")[0].rstrip("/")
    parts = [p for p in t.split("/") if p and "." not in p]
    if parts:
        return parts[-1]
    host = t.split("/")[0]
    return host or t


def write_config_java(pkg: str, cfg: dict) -> None:
    path = JAVA / pkg.replace(".", "/") / "Config.java"
    path.parent.mkdir(parents=True, exist_ok=True)

    fab_enabled, fab_items = norm_fab(cfg)
    features = cfg.get("features") or {}
    if not isinstance(features, dict):
        features = {}
    downloads = bool(features.get("downloads", True))
    background = bool(features.get("background", True))
    obf = load_obfuscator()
    if obf is None:
        class _Obf:
            @staticmethod
            def safe_asset_name(rel):
                return rel
        obf = _Obf()

    # 多内置网页：home 指定首页（首页按钮用）；start 指定初始页（打开 App 时加载）
    # 注意：中文文件名进 APK 会乱码，混淆器会把非 ASCII 的 assets 文件重命名，
    # 这里用同一个函数换算出真正的 assets 文件名写进配置。
    pages = norm_pages(cfg)
    home_file = "index.html"
    home_url = ""
    start_file = ""
    start_url = ""
    if pages:
        home_idx = next((i for i, p in enumerate(pages) if p.get("home")), 0)
        home = pages[home_idx]
        if home.get("url"):
            home_url = home["url"]
        else:
            home_file = obf.safe_asset_name(home["file"])
        # 初始页：pages 里 start:true 的那项；没配就和首页一致
        start = next((p for p in pages if p.get("start")), None)
        if start is not None:
            if start.get("url"):
                start_url = start["url"]
            else:
                start_file = obf.safe_asset_name(start["file"])
    pages_json = json.dumps(
        [{"title": p["title"], "file": obf.safe_asset_name(p["file"]) if p.get("file") else "",
          "url": p.get("url", ""), "home": bool(p.get("home")), "start": bool(p.get("start"))}
         for p in pages],
        ensure_ascii=False, separators=(",", ":"))

    # 悬浮球菜单：顺序 = 数组顺序，enabled=false 的项不出现；标题可自定义
    fab_json = json.dumps(
        [{"id": i["id"], "title": i["title"], "enabled": i["enabled"]} for i in fab_items],
        ensure_ascii=False, separators=(",", ":"))

    sections = norm_sections(cfg)
    sections_json = json.dumps(
        [{"id": i["id"], "title": i["title"], "enabled": i["enabled"]} for i in sections],
        ensure_ascii=False, separators=(",", ":"))
    more_json = json.dumps(
        [{"id": i["id"], "title": i["title"], "enabled": i["enabled"]} for i in norm_more(cfg)],
        ensure_ascii=False, separators=(",", ":"))
    upd = cfg.get("update") or {}
    if not isinstance(upd, dict):
        upd = {}

    # 初始页候选：名称 + 指向（内置文件要换成混淆后的真实文件名）
    start_pages = norm_start_pages(cfg)
    start_pages_json = json.dumps(
        [{"name": sp["name"],
          "url": sp["url"],
          "file": obf.safe_asset_name(sp["file"]) if sp["file"] else ""}
         for sp in start_pages],
        ensure_ascii=False, separators=(",", ":"))

    toolbar = norm_toolbar(cfg)
    toolbar_json = json.dumps(
        [{"id": i["id"], "title": i["title"], "enabled": i["enabled"],
          "row": int(i.get("row", 1))} for i in toolbar],
        ensure_ascii=False, separators=(",", ":"))

    cf = cfg.get("coffee") or {}
    if not isinstance(cf, dict):
        cf = {}

    text = """package %s;

/**
 * 由 tools/apply_config.py 根据 app-config.json 生成，不要手改（下次构建会覆盖）。
 */
public final class Config {

    public static final String APP_NAME = %s;
    public static final String VERSION_NAME = %s;
    public static final int VERSION_CODE = %d;
    public static final String ONLINE = %s;
    public static final String FAB_TEXT = %s;

    // ---------------------------------------------------------------- 赞助码
    // 写死在壳里，不依赖 assets/data.json —— 网页数据被替换、被改版都不影响。
    /** 赞赏码图片地址（http/https 或 assets 里的相对路径），空 = 菜单里不出现这一项 */
    public static final String COFFEE_QR = %s;
    /** QQ 号，空 = 不显示那一行 */
    public static final String COFFEE_QQ = %s;
    /** 二维码下面的说明文案，空 = 用默认文案 */
    public static final String COFFEE_TIP = %s;

    /** 允不允许用户自己加书签（false = 书签完全由打包决定） */
    public static final boolean ALLOW_USER_BOOKMARKS = %s;

    /** 悬浮球总开关（fab.enabled） */
    public static final boolean FAB_ENABLED = %s;

    /** 悬浮球菜单项（fab.sections，按数组顺序排列，enabled 控制是否显示） */
    public static final String FAB_ITEMS_JSON = %s;

    /** 弹窗靠球那一侧的横向图标条（fab.toolbar）：顺序 + 开关 + 标题 */
    public static final String FAB_TOOLBAR_JSON = %s;

    /**
     * 构建期功能开关（features.*）。
     * 为 false 时 tools/apply_config.py 会生成不带该分支的 FabRegistry，
     * build.sh 同时把对应源码排除在编译之外 —— 功能真的不进包，不是运行时隐藏。
     */
    public static final boolean FEATURE_DOWNLOADS = %s;

    /** 浏览历史模块是否打包进来（features.history） */
    public static final boolean FEATURE_HISTORY = %s;

    /** 检测更新模块是否打包进来（features.update） */
    public static final boolean FEATURE_UPDATE = %s;

    /** 后台 / 多窗口模块是否打包进来（features.background） */
    public static final boolean FEATURE_BACKGROUND = %s;

    /** 悬浮球弹窗板块（fab.sections）：顺序 + 开关；数组顺序即由近到远 */
    public static final String FAB_SECTIONS_JSON = %s;

    /** 「更多」面板项目（fab.more）：update + 7 个浏览设置，全部可配 */
    public static final String FAB_MORE_JSON = %s;

    // ---------------------------------------------------------------- 多内置网页
    /** 页面列表：title + file（内置）/ url（在线）+ home（首页按钮用）+ start（初始页） */
    public static final String PAGES_JSON = %s;
    /** 初始页候选：name + url / file，供「更多 → 初始页」直接列出 */
    public static final String START_PAGES_JSON = %s;
    /** 首页（首页按钮的目标）是内置文件时，这个文件名（默认 index.html） */
    public static final String HOME_FILE = %s;
    /** 首页是在线地址时，那个地址（为空表示首页不是在线页） */
    public static final String HOME_URL = %s;
    /** 初始页（打开 App 时加载）是内置文件时，这个文件名（空 = 跟首页一致） */
    public static final String START_FILE = %s;
    /** 初始页是在线地址时，那个地址（空 = 跟首页一致） */
    public static final String START_URL = %s;

    /** pages 数组；配置损坏时返回空数组，调用处不用判空 */
    public static org.json.JSONArray pages() {
        try {
            return new org.json.JSONArray(PAGES_JSON);
        } catch (Throwable t) {
            return new org.json.JSONArray();
        }
    }

    /** 第 i 个页面的打开地址：file 转成内置虚拟域名，url 原样返回 */
    public static String pageUrl(int i) {
        org.json.JSONObject o = pages().optJSONObject(i);
        if (o == null) return "";
        String u = o.optString("url", "");
        if (u != null && u.trim().length() > 0) return u.trim();
        String f = o.optString("file", "");
        if (f == null || f.trim().length() == 0) return "";
        return Site.ORIGIN + "/" + f.trim();
    }

    /** 初始页候选；配置损坏时返回空数组 */
    public static org.json.JSONArray startPages() {
        try {
            return new org.json.JSONArray(START_PAGES_JSON);
        } catch (Throwable t) {
            return new org.json.JSONArray();
        }
    }

    // ---------------------------------------------------------------- 检测更新
    /** 更新校验链接（JSON 地址），为空则不做自动检测 */
    public static final String UPDATE_URL = %s;
    /** 是否在启动时自动检测更新 */
    public static final boolean UPDATE_ENABLED = %s;
    /** 启动后延迟多少秒检测 */
    public static final int UPDATE_DELAY_SECONDS = %d;
    /** 忽略本版后，同一版本多少天内不再提示 */
    public static final int UPDATE_IGNORE_DAYS = %d;
    /** 下载新版安装包的提示文案 */
    public static final String UPDATE_HINT = %s;

    private Config() {
    }
}
""" % (pkg,
       java_str(cfg.get("appName", "")),
       java_str(cfg.get("versionName", "")),
       int(cfg.get("versionCode", 0)),
       java_str(cfg.get("online", "")),
       java_str(cfg.get("fabText", "")),
       java_str(str(cf.get("qr", "") or "").strip()),
       java_str(str(cf.get("qq", "") or "").strip()),
       java_str(str(cf.get("tip", "") or "").strip()),
       "true" if cfg.get("allowUserBookmarks", True) else "false",
       "true" if fab_enabled else "false",
       java_str(fab_json),
       java_str(toolbar_json),
       "true" if downloads else "false",
       "true" if bool(features.get("history", True)) else "false",
       "true" if bool(features.get("update", True)) else "false",
       "true" if background else "false",
       java_str(sections_json),
       java_str(more_json),
       java_str(pages_json),
       java_str(start_pages_json),
       java_str(home_file),
       java_str(home_url),
       java_str(start_file),
       java_str(start_url),
       java_str(str(upd.get("url", "") or "").strip()),
       "true" if bool(upd.get("enabled", True)) else "false",
       max(3, int(upd.get("delaySeconds", 6) or 6)),
       max(0, int(upd.get("ignoreDays", 7) or 7)),
       java_str(str(upd.get("hint", "") or "")))
    path.write_text(text, encoding="utf-8")


def write_fab_registry(pkg: str, cfg: dict) -> list:
    """
    生成 FabRegistry：只引用「已启用」的功能模块。

    关掉某个功能时，这里不会出现它的类名，build.sh 又把源码排除掉，
    于是该类既不编译也不进 dex —— 真正意义上的「不打包」。
    """
    features = cfg.get("features") or {}
    if not isinstance(features, dict):
        features = {}

    branches = []
    excluded = []

    if bool(features.get("downloads", True)):
        branches.append(
            '        if ("downloads".equals(id)) { DownloadsDialog.show(a); return true; }')
    else:
        excluded.append("DownloadsDialog.java")

    if bool(features.get("history", True)):
        branches.append(
            '        if ("history".equals(id)) { HistoryDialog.show(a); return true; }')
    else:
        excluded.append("HistoryDialog.java")

    if bool(features.get("update", True)):
        branches.append(
            '        if ("update".equals(id)) { Updater.checkManually(a); return true; }')
    else:
        excluded.append("Updater.java")

    if bool(features.get("background", True)):
        bg_methods = """
    /** 后台 / 多窗口模块是否打包进来（features.background） */
    public static boolean hasBackground() {
        return true;
    }

    /** 书签列表末尾的「后台」项：打开后台窗口管理 */
    public static void openBackgroundPanel(MainActivity a) {
        Background.show(a);
    }

    /** 后台打开（预加载，不打断当前页） */
    public static void openInBackground(MainActivity a, String url) {
        Background.openBackground(a, url);
    }

    /** 新窗口打开（当前页转入后台列表） */
    public static void openInNewWindow(MainActivity a, String url) {
        Background.openNewWindow(a, url);
    }

    /** 长按书签 / 链接时弹的二选一 */
    public static void chooseWindow(MainActivity a, String url) {
        Background.chooseWindow(a, url);
    }

    /** 新建窗口：直接加载初始页 */
    public static void openNewStartWindow(MainActivity a) {
        Background.newStartWindow(a);
    }

    /** 后台页的渲染进程挂了：清掉 */
    public static void onWebGone(android.webkit.WebView v) {
        Background.onWebGone(v);
    }

    /** 退出时清理所有后台页 */
    public static void destroyBackgrounds() {
        Background.destroyAll();
    }
"""
    else:
        excluded.append("Background.java")
        bg_methods = """
    /** 后台 / 多窗口模块没有打包进来（features.background=false） */
    public static boolean hasBackground() {
        return false;
    }

    public static void openBackgroundPanel(MainActivity a) {
    }

    public static void openInBackground(MainActivity a, String url) {
    }

    public static void openInNewWindow(MainActivity a, String url) {
    }

    public static void chooseWindow(MainActivity a, String url) {
    }

    public static void openNewStartWindow(MainActivity a) {
    }

    public static void onWebGone(android.webkit.WebView v) {
    }

    public static void destroyBackgrounds() {
    }
"""


    body = "\n".join(branches) if branches else ""
    auto = ('        Updater.autoCheck(a);' if bool(features.get("update", True))
            else "        // features.update=false：检测更新模块没有打包进来")
    text = """package %s;

/**
 * 由 tools/apply_config.py 生成，不要手改。
 * 只登记 features 中开启的悬浮球功能模块；关闭的模块连类名都不会出现。
 *
 * 注意：其它类（MainActivity / MoreMenu）一律通过本类间接调用可裁剪模块，
 * 不要直接写 Updater.xxx / DownloadsDialog.xxx，否则关掉开关就编译不过。
 */
public final class FabRegistry {

    private FabRegistry() {
    }

    /** 处理由功能模块负责的菜单项；返回 true 表示已消费。 */
    public static boolean handle(MainActivity a, String id) {
%s
        return false;
    }

    /** 启动时的自动检测更新（模块被裁掉时是空实现）。 */
    public static void autoUpdateCheck(MainActivity a) {
%s
    }
%s
}
""" % (pkg, body if body else "        // 当前没有启用任何可裁剪的功能模块", auto, bg_methods)
    (JAVA / pkg.replace(".", "/") / "FabRegistry.java").write_text(text, encoding="utf-8")
    return excluded


def norm_pages(cfg: dict) -> list:
    """
    多内置网页（pages 段）。

      "pages": [
        { "title": "首页",   "file": "index.html", "home": true },
        { "title": "内容一", "file": "内容一.html" },
        { "title": "公告",   "url": "https://..." }
      ]

    file = assets 根目录下的 html 文件（打包时内置）；url = 在线地址。
    home:true 的那项是「首页」（首页按钮的目标）；
    start:true 的那项是「初始页」（打开 App 时加载）；
    都没有时首页和初始页都取第一项；连 pages 都没配就是 index.html。
    """
    raw = cfg.get("pages")
    pages = []
    if isinstance(raw, list):
        for p in raw:
            if not isinstance(p, dict):
                continue
            title = str(p.get("title", "")).strip()
            file = str(p.get("file", "")).strip()
            url = str(p.get("url", "")).strip()
            home = bool(p.get("home", False))
            start = bool(p.get("start", False))
            if file:
                if "/" in file or "\\" in file or ".." in file:
                    die("pages.file 只能是 assets 根目录下的文件名：%s" % file)
                if not file.lower().endswith(".html"):
                    die("pages.file 必须是 .html 文件：%s" % file)
                if not (ASSETS / file).exists():
                    die("pages.file 在 src/main/assets 里不存在：%s" % file)
                pages.append({"title": title or file, "file": file,
                              "home": home, "start": start})
            elif url:
                if not url.startswith(("http://", "https://")):
                    die("pages.url 必须是 http / https 地址：%s" % url)
                pages.append({"title": title or url, "url": url,
                              "home": home, "start": start})
    return pages


def norm_obfuscate(cfg: dict) -> dict:
    """
    assets 混淆开关（obfuscate 段）。

      obfuscate.enabled  true  = 打包混淆版（默认）；false = 打包明文版
      obfuscate.key      混淆密钥，留空用内置常量

    混淆版会把 index.html 整篇加密、内联脚本抽走编译进脚本包，
    其余资源打进一个随机命名的密文包 —— APK 解开后看不到可读网页。
    """
    ob = cfg.get("obfuscate")
    if isinstance(ob, bool):
        ob = {"enabled": ob}
    if not isinstance(ob, dict):
        ob = {}
    enabled = bool(ob.get("enabled", True))
    key = str(ob.get("key", "") or "").strip()
    return {"enabled": enabled, "key": key}


def apply_assets(cfg: dict) -> dict:
    """
    按 obfuscate 配置把 src/main/assets 处理成 build/assets，返回信息供 build.sh 使用。

    这里直接调用 tools/obfuscate_assets.py 的逻辑（同一份实现，避免两处走样）。
    """
    ob = norm_obfuscate(cfg)
    src = ASSETS
    # 注意：不能放 build/ 下 —— build.sh 在编译前会 rm -rf build
    out = ROOT / ".assets-build"
    mod = load_obfuscator()
    if mod is None:
        print("   ! 找不到 tools/obfuscate_assets.py，assets 原样打包")
        return {"enabled": False, "out": str(out), "fallback": True}

    if not ob["enabled"]:
        info = mod.plain(src, out)
        return {"enabled": False, "out": str(out), "files": info["files"],
                "file_map": info.get("file_map", {})}

    info = mod.obfuscate(src, out, ob["key"] or mod.DEFAULT_SEED)
    info["enabled"] = True
    info["out"] = str(out)
    return info


def load_obfuscator():
    import importlib.util
    path = ROOT / "tools" / "obfuscate_assets.py"
    if not path.exists():
        return None
    spec = importlib.util.spec_from_file_location("vie_obfuscator", path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def norm_bookmarks(cfg: dict) -> list:
    """
    内置书签（bookmarks 段）。

      "bookmarks": [
        { "name": "演示站", "url": "https://0.wudaozhe.net" },
        { "title": "内容一", "file": "内容一.html" },
        { "title": "内容二", "file": "内容二.html" },
        { "name": "外链", "url": "https://..." }
      ]

    两种写法：
      url  = 在线地址，原样打开；
      file = src/main/assets 根目录下的 html，打包成「内置书签」，
             地址在运行时换算成内置页地址（与「更多页面」里的同一份文件等价）。
    title / name 等价，name 优先。
    混淆版里中文文件名会被重命名，所以这里只记原文件名，
    真正的 assets 文件名在 apply_config 主流程里按混淆器的映射写入。
    """
    items = []
    raw = cfg.get("bookmarks")
    if not isinstance(raw, list):
        return items
    for b in raw:
        if not isinstance(b, dict):
            continue
        name = str(b.get("name", "") or b.get("title", "")).strip()
        url = str(b.get("url", "")).strip()
        file = str(b.get("file", "")).strip()
        if file:
            if "/" in file or "\\" in file or ".." in file:
                die("bookmarks.file 只能是 assets 根目录下的文件名：%s" % file)
            if not file.lower().endswith(".html"):
                die("bookmarks.file 必须是 .html 文件：%s" % file)
            if not (ASSETS / file).exists():
                die("bookmarks.file 在 src/main/assets 里不存在：%s" % file)
            items.append({"name": name or file, "url": "", "file": file})
            continue
        if not url:
            continue
        items.append({"name": name, "url": url, "file": ""})
    return items


def write_presets(cfg: dict, file_map: dict | None = None,
                  out_dir: Path | None = None) -> int:
    """
    file_map：原文件名 → 实际 assets 文件名（混淆版重命名后的）。
    内置书签的 url 在这里换算成固定格式 bookmark:文件名，
    App 启动时再拼成内置页地址（见 Bookmarks.presets）。

    out_dir：本次真正打包的 assets 目录（.assets-build）。混淆版会先把
    assets 拷进这个目录，只写 src 的话打出来的 APK 会少这张表。
    """
    file_map = file_map or {}
    items = []
    for b in norm_bookmarks(cfg):
        if b["file"]:
            real = file_map.get(b["file"], b["file"])
            items.append({"name": b["name"], "url": "bookmark:" + real})
        else:
            items.append({"name": b["name"], "url": b["url"]})

    seen = set()
    dedup = []
    for i in items:
        key = i["url"].rstrip("/").lower()
        if key in seen:
            continue
        seen.add(key)
        dedup.append(i)

    payload = json.dumps(dedup, ensure_ascii=False, indent=2) + "\n"
    ASSETS.mkdir(parents=True, exist_ok=True)
    (ASSETS / "preset_bookmarks.json").write_text(payload, encoding="utf-8")
    if out_dir is not None and Path(out_dir) != ASSETS:
        Path(out_dir).mkdir(parents=True, exist_ok=True)
        (Path(out_dir) / "preset_bookmarks.json").write_text(payload, encoding="utf-8")
    return len(dedup)


def apply_versions(cfg: dict) -> None:
    vc = int(cfg["versionCode"])
    vn = str(cfg["versionName"])
    pkg = str(cfg["packageName"])

    t = MANIFEST.read_text(encoding="utf-8")
    t = re.sub(r'android:versionCode="\d+"', 'android:versionCode="%d"' % vc, t)
    t = re.sub(r'android:versionName="[^"]*"', 'android:versionName="%s"' % vn, t)
    MANIFEST.write_text(t, encoding="utf-8")

    g = GRADLE.read_text(encoding="utf-8")
    g = re.sub(r"versionCode \d+", "versionCode %d" % vc, g)
    g = re.sub(r'versionName "[^"]*"', 'versionName "%s"' % vn, g)
    g = re.sub(r"namespace '[^']*'", "namespace '%s'" % pkg, g)
    g = re.sub(r'applicationId "[^"]*"', 'applicationId "%s"' % pkg, g)
    GRADLE.write_text(g, encoding="utf-8")


def apply_sdk(cfg: dict) -> None:
    """把 minSdk / targetSdk / compileSdk 同步到清单和 build.gradle（Gradle 构建与 CI 保持一致）。"""
    compile_sdk = max(COMPILE_SDK, TARGET_SDK)
    t = MANIFEST.read_text(encoding="utf-8")
    t = re.sub(
        r"<uses-sdk\b[^>]*/>",
        '<uses-sdk android:minSdkVersion="%d" android:targetSdkVersion="%d" />'
        % (MIN_SDK, TARGET_SDK),
        t,
    )
    MANIFEST.write_text(t, encoding="utf-8")

    g = GRADLE.read_text(encoding="utf-8")
    g = re.sub(r"compileSdk \d+", "compileSdk %d" % compile_sdk, g)
    g = re.sub(r"targetSdk \d+", "targetSdk %d" % TARGET_SDK, g)
    g = re.sub(r"minSdk \d+", "minSdk %d" % MIN_SDK, g)
    GRADLE.write_text(g, encoding="utf-8")


def apply_app_name(cfg: dict) -> None:
    name = str(cfg.get("appName", "")).strip()
    if not name:
        die("appName 不能为空")
    esc = name.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    s = STRINGS.read_text(encoding="utf-8")
    s = re.sub(r'<string name="app_name">[^<]*</string>',
               '<string name="app_name">%s</string>' % esc, s)
    STRINGS.write_text(s, encoding="utf-8")


def apply_authority(pkg: str) -> None:
    """
    ContentProvider 的 authority 必须全机唯一，必须跟着包名走。

    漏掉这一步的后果不是构建失败，而是装不上：
    旧包名版本还在手机上时，两个 App 声明同一个 authority，
    安装直接报 INSTALL_FAILED_CONFLICTING_PROVIDER。
    """
    want = pkg + ".files"

    t = MANIFEST.read_text(encoding="utf-8")
    t2 = re.sub(r'android:authorities="[^"]*"', 'android:authorities="%s"' % want, t)
    if t2 != t:
        MANIFEST.write_text(t2, encoding="utf-8")

    f = JAVA / pkg.replace(".", "/") / "LocalFiles.java"
    if f.exists():
        s = f.read_text(encoding="utf-8")
        s2 = re.sub(r'(\bAUTHORITY\s*=\s*")[^"]*(")', r'\g<1>' + want + r'\g<2>', s)
        if s2 != s:
            f.write_text(s2, encoding="utf-8")


def argb(color: str):
    c = str(color).strip().lstrip("#")
    if len(c) == 6:
        return "#FF" + c.upper()
    if len(c) == 8:
        return "#" + c.upper()
    return None


def radial_subject(img):
    """
    以图形中心为基准，量出「最大内切圆」的半径，返回 (cx, cy, r)。

    这是图标的取景基准：不管源图是方是长、圆形图形有没有偏，都按
    「主体自身轮廓能包住的最大圆」来收，再把这个圆缩放到图标里去。

    做法：
      1. 从几何中心打 360 条射线，每条找出最后一个属于主体的像素；
      2. 每条射线得到一个「主体边界点」，把这些点拟合成一个圆
         （圆心 = 边界点均值，半径 = 边界点的 15% 分位 —— 取分位而不是均值，
          是因为图标要的是「能完整装下图形」的圆，宁可略小也不能切掉轮齿）；
      3. 半径再夹在画面内，保证内切圆不越界。

    判据「像主体」：够亮 且 有饱和度（金色/彩色立体图形），
    或用整图亮度分布自适应出的阈值，深色实心 logo 也能取到。
    """
    import math

    w, h = img.size
    if w < 16 or h < 16:
        return ((w - 1) / 2.0, (h - 1) / 2.0, min(w, h) / 2.0)

    rgb = img.convert("RGB")
    px = rgb.load()
    step = max(1, min(w, h) // 260)

    # 主体判据：用整图亮度分布自适应，避免整图偏暗/偏亮时失效
    q = max(1, min(w, h) // 60)
    samples = []
    for y in range(0, h, q):
        for x in range(0, w, q):
            p = px[x, y]
            samples.append(0.299 * p[0] + 0.587 * p[1] + 0.114 * p[2])
    samples.sort()
    med = samples[len(samples) // 2]
    hi = samples[int(len(samples) * 0.9)]
    gate = max(60.0, min(190.0, med + (hi - med) * 0.35))

    def is_subject(p):
        lum = 0.299 * p[0] + 0.587 * p[1] + 0.114 * p[2]
        sat = max(p) - min(p)
        return lum >= gate and (sat >= 26 or lum >= gate + 40)

    cx0, cy0 = (w - 1) / 2.0, (h - 1) / 2.0

    # 中心不在主体上时（图形偏心），在中心附近找主体最亮的一块作为新圆心
    if not is_subject(px[int(cx0), int(cy0)]):
        rad = max(6, min(w, h) // 8)
        best = None
        for dy in range(-rad, rad + 1, max(1, rad // 10)):
            for dx in range(-rad, rad + 1, max(1, rad // 10)):
                x, y = int(cx0 + dx), int(cy0 + dy)
                if not (0 <= x < w and 0 <= y < h):
                    continue
                p = px[x, y]
                if not is_subject(p):
                    continue
                lum = 0.299 * p[0] + 0.587 * p[1] + 0.114 * p[2]
                if best is None or lum > best[0]:
                    best = (lum, x, y)
        if best is not None:
            cx0, cy0 = float(best[1]), float(best[2])

    # ---- 打射线，收集主体边界点 ----
    max_r = math.hypot(w, h)
    pts = []
    for deg in range(0, 360, 2):
        a = math.radians(deg)
        dx, dy = math.cos(a), math.sin(a)
        last = 0.0
        r = float(step)
        while r < max_r:
            x = cx0 + dx * r
            y = cy0 + dy * r
            if not (0 <= x < w and 0 <= y < h):
                break
            if is_subject(px[int(x), int(y)]):
                last = r
            r += step
        if last > 0:
            # 稍微内收一个像素级余量，避免把边缘抗锯齿的暗边带进来
            rr = max(0.0, last - step * 0.5)
            pts.append((cx0 + dx * rr, cy0 + dy * rr, rr, a))

    if len(pts) < 12:
        return (cx0, cy0, min(w, h) / 2.0)

    # ---- 拟合内切圆 ----
    # 圆心：先取几何中心；主体明显偏心时，把圆心移到「最远边界点与最近边界点的中点」
    # 那一侧 —— 简单说就是让圆心尽量落在主体轮廓中间，四方向到边的距离接近。
    xs = sorted(p[0] for p in pts)
    ys = sorted(p[1] for p in pts)
    # 用 10%~90% 分位的中点当圆心，避免个别方向的离群点把圆心带偏
    cx = (xs[int(len(xs) * 0.10)] + xs[int(len(xs) * 0.90)]) / 2.0
    cy = (ys[int(len(ys) * 0.10)] + ys[int(len(ys) * 0.90)]) / 2.0

    def ray_reach(deg, ox, oy):
        a = math.radians(deg)
        dx, dy = math.cos(a), math.sin(a)
        last = 0.0
        r = float(step)
        while r < max_r:
            x = ox + dx * r
            y = oy + dy * r
            if not (0 <= x < w and 0 <= y < h):
                break
            if is_subject(px[int(x), int(y)]):
                last = r
            r += step
        return last

    # 圆心微调两轮：每次让圆心朝「较远那侧」挪动缺口的 40%
    for _ in range(3):
        reach_u = ray_reach(270, cx, cy)
        reach_d = ray_reach(90, cx, cy)
        reach_l = ray_reach(180, cx, cy)
        reach_r = ray_reach(0, cx, cy)
        cx += (reach_r - reach_l) * 0.2
        cy += (reach_d - reach_u) * 0.2
        cx = max(0.0, min(float(w - 1), cx))
        cy = max(0.0, min(float(h - 1), cy))

    # 以内切圆半径 = 四个方向到边的最近距离（这就是「正方形里的最大内切圆」）
    radii = [ray_reach(d, cx, cy) for d in range(0, 360, 2)]
    radii = [x for x in radii if x > step]
    if not radii:
        return (cx0, cy0, min(w, h) / 2.0)

    r_in = min(radii)          # 最近的一侧：只当参考，用来判断判据是否失效
    r_in = min(r_in, cx, w - 1 - cx, cy, h - 1 - cy)

    # 取景半径 = 「能装下全部主体」的外接半径。
    # 不能用最近距离：圆盘外圈的铆钉、装饰耳、凸起只在少数方向，
    # 按最近距离撑满会把这些凸起推到画外（实测 8 个铆钉全被切）。
    # 用 96% 分位：既能兜住 8 个方向的凸起（约占 4.4%），又能滤掉个别噪点。
    rs = sorted(radii)
    r_out = rs[min(len(rs) - 1, int(len(rs) * 0.96))]
    # 外接半径不可能超过短边一半；超过说明量到了画面边界
    r_out = min(r_out, min(w, h) / 2.0)

    # 兜底只在「测出来的圆小到不合理」时触发：4% 短边以内视为判据失效。
    # 阈值不能设大 —— 长图里主体圆本来就只占短边一成多，设 15% 会把正常结果误杀。
    if r_out <= min(w, h) * 0.04:
        return (cx0, cy0, min(w, h) / 2.0)
    return (cx, cy, r_out)


def circle_to_square(img, cx, cy, r, side: int):
    """
    取景规则：把「装得下全部主体的外接圆」放大到正好内切于正方形。

    也就是：
      · 圆贴正方形四边中点（画面用满，不留背景环）；
      · 圆心对准正方形中心；
      · 圆外的四角是放大后的原图边缘，不挖透明、不填色、不做圆角 ——
        交给启动器的遮罩去裁，图标本体永远是一整张图。

    关键在 r 的定义：r 必须是「含凸起的外接半径」（96% 分位），
    不能是最近距离。圆盘外圈的铆钉只在 8 个方向露头，
    按最近距离撑满会把这些凸起推到画外 —— 实测 1.53 倍放大把 8 个铆钉全切了。
    用外接半径后，铆钉恰好落在圆上，一个不丢。
    """
    import math
    from PIL import Image

    w, h = img.size
    if r <= 1:
        r = min(w, h) / 2.0
    # 放大倍数：让「含全部凸起的外接圆」正好内切于正方形。
    # r 已经是 96% 分位的外接半径，所以圆盘外的铆钉/装饰会留在圆内，不会被切。
    k = (side / 2.0) / float(r)
    # 源图本来就很小时，放大倍数上限 4 倍，避免糊成一团
    k = min(k, 4.0)

    src = img.convert("RGBA")
    nw = max(1, int(round(w * k)))
    nh = max(1, int(round(h * k)))
    scaled = src.resize((nw, nh), Image.LANCZOS)

    # 放大后的圆心位置
    gx, gy = cx * k, cy * k

    # 以圆心为中心取 side×side。contain 时短边方向会出现留白，
    # 留白用「最近边缘像素延展」，绝不拉伸整图（拉伸会让画面比例变形）。
    paste_x = int(round(side / 2.0 - gx))
    paste_y = int(round(side / 2.0 - gy))
    canvas = Image.new("RGBA", (side, side))
    canvas.paste(scaled, (paste_x, paste_y), scaled)

    lw = max(0, paste_x)
    rw = max(0, side - (paste_x + nw))
    tw = max(0, paste_y)
    bw = max(0, side - (paste_y + nh))
    if lw:
        canvas.paste(canvas.crop((lw, 0, lw + 1, side)).resize((lw, side), Image.NEAREST), (0, 0))
    if rw:
        canvas.paste(canvas.crop((side - rw - 1, 0, side - rw, side)).resize((rw, side), Image.NEAREST), (side - rw, 0))
    if tw:
        canvas.paste(canvas.crop((0, tw, side, tw + 1)).resize((side, tw), Image.NEAREST), (0, 0))
    if bw:
        canvas.paste(canvas.crop((0, side - bw - 1, side, side - bw)).resize((side, bw), Image.NEAREST), (0, side - bw))

    return canvas


def trim_dark_border(img, thresh: int = 105):
    """
    自动去掉图片四周过暗的一圈「黑边 / 描边」。

    做法：从四条边往里扫，只要该行/列的亮度均值低于 thresh 就继续内缩，
    最多削掉 12% 的边长（防止把整体偏暗的图当边框削光）。
    源图本身没有黑边时（四边都够亮）原样返回，不做任何裁剪。
    """
    def row_lum(y):
        return sum(sum(px[0:3]) / 3.0 for px in
                   [img.getpixel((x, y)) for x in range(0, img.width, max(1, img.width // 40))]) \
               / max(1, len(range(0, img.width, max(1, img.width // 40))))

    def col_lum(x):
        xs = range(0, img.height, max(1, img.height // 40))
        return sum(sum(img.getpixel((x, y))[0:3]) / 3.0 for y in xs) / max(1, len(list(xs)))

    limit_x = max(1, int(img.width * 0.12))
    limit_y = max(1, int(img.height * 0.12))
    l = t = 0
    while l < limit_x and col_lum(l) < thresh:
        l += 1
    while t < limit_y and row_lum(t) < thresh:
        t += 1
    r, b = img.width - 1, img.height - 1
    while (img.width - 1 - r) < limit_x and col_lum(r) < thresh:
        r -= 1
    while (img.height - 1 - b) < limit_y and row_lum(b) < thresh:
        b -= 1

    if l or t or (r < img.width - 1) or (b < img.height - 1):
        if r - l > img.width * 0.5 and b - t > img.height * 0.5:
            print("   · 已去掉四周深色边框：左%d 上%d 右%d 下%d px"
                  % (l, t, img.width - 1 - r, img.height - 1 - b))
            return img.crop((l, t, r + 1, b + 1))
    return img


def apply_icon(cfg: dict) -> None:
    """
    单一图标源 → 只产出一张位图 + 几个 XML，杜绝「同一张图打包 6 份」。

    产物（整个 APK 里只有一份位图）：
      res/drawable-nodpi/ic_brand.png        唯一品牌位图（UI + 图标共用）
      res/drawable/ic_launcher_foreground.xml  自适应前景，内缩到 60% 安全区
      res/mipmap-anydpi/ic_launcher.xml      旧系统（API 23-25）用的图标
      res/mipmap-anydpi-v26/ic_launcher.xml  自适应图标
    同时清理历史遗留的 mipmap-*/ic_launcher*.png 与 drawable/ic_brand.png，
    避免旧图残留或重复占体积。
    """
    icon = str(cfg.get("icon", "")).strip()
    if not icon:
        return

    path = ROOT / icon
    if not path.exists():
        print("   ! 图标文件不存在：%s，跳过" % icon)
        return

    # 支持 png / jpg / jpeg / webp / bmp：统一由 Pillow 打开，这里只做校验与提示
    ext = path.suffix.lower()
    if ext not in (".png", ".jpg", ".jpeg", ".webp", ".bmp", ".gif"):
        print("   ! 不认识的图片格式 %s，请用 png / jpg / webp（跳过）" % ext)
        return

    try:
        from PIL import Image, ImageOps
    except ImportError:
        print("   ! 没装 Pillow，跳过图标替换（pip install pillow）")
        return

    try:
        img = Image.open(path)
        # 手机拍的 jpg 常带 EXIF 方向标记，不摆正会横躺 / 倒置
        img = ImageOps.exif_transpose(img)
    except Exception as e:
        print("   ! 图片打不开（%s）：%s，跳过" % (path.name, e))
        return

    # 超大图先缩，避免 4000×3000 级别的手机照片吃满内存
    if img.width * img.height > 4096 * 4096:
        img.thumbnail((4096, 4096), Image.LANCZOS)

    # 去掉 EXIF（含拍摄方向、内嵌缩略图）：部分 JPEG 带 160×160 缩略图 +
    # ExifImageWidth/Height 字段，不清理会让 Pillow 只按缩略图尺寸解码（图变糊变小）
    clean = img.copy()
    clean.info.pop("exif", None)
    clean.info.pop("icc_profile", None)
    buf = io.BytesIO()
    clean.save(buf, format="PNG")
    buf.seek(0)
    img = Image.open(buf)
    img.load()
    if img.size != (clean.width, clean.height):
        print("   ! 解码异常：%dx%d≠%dx%d" % (img.size + clean.size))
    side = min(img.width, img.height)
    # 源图偏小：放大到 480 会糊，所以按源尺寸出图，但不再额外缩小
    print("   · 实际读取像素 %d×%d（%.0f KB 源文件）"
          % (img.width, img.height, path.stat().st_size / 1024.0))

    # CMYK 的 jpg（印刷稿）直接转 RGBA 会偏色，先走 RGB
    if img.mode == "CMYK":
        img = img.convert("RGB")
    img = img.convert("RGBA")

    res = ROOT / "src/main/res"

    # ---- 1. 量主体中心（只用来把主体摆正，不用来定放大倍数）----
    cx, cy, r = radial_subject(img)
    print("   · 主体中心(%.0f,%.0f) 主体半径 %.0fpx（源图 %d×%d）"
          % (cx, cy, r, img.width, img.height))

    # ---- 2. 目标边长：自适应图标 108dp × xxxhdpi 4x = 432，取 480 更稳 ----
    #        位图固定输出正方形（内容 = 整张原图完整装入，不裁边）
    MAX_SIDE = 480
    target = MAX_SIDE
    if min(img.width, img.height) < 192:
        print("   ! 源图只有 %dpx，建议换成 512×512 以上（当前按 %dpx 输出）"
              % (min(img.width, img.height), target))

    # ---- 3. 含凸起的外接圆 → 放大到内切正方形（圆贴四边中点，铆钉不丢）----
    logo = circle_to_square(img, cx, cy, r, target)

    # ---- 4. 压缩到 30KB 以下：先减色，再降边长，最后才动色彩数 ----
    MAX_KB = 30.0
    ndpi = res / "drawable-nodpi"
    ndpi.mkdir(parents=True, exist_ok=True)
    brand_path = ndpi / "ic_brand.png"

    def _write(im, colors):
        q = im.quantize(colors=colors, method=Image.FASTOCTREE)
        q.save(brand_path, format="PNG", optimize=True, compress_level=9)
        return brand_path.stat().st_size / 1024.0

    kb = None
    dim = target
    for side_try in (target, 384, 320, 288, 256, 224, 192, 160):
        cur = logo if side_try == target else logo.resize((side_try, side_try), Image.LANCZOS)
        for colors in (256, 192, 128, 96, 64, 48):
            kb = _write(cur, colors)
            if kb <= MAX_KB:
                dim = side_try
                break
        if kb is not None and kb <= MAX_KB:
            break
    if kb is None or kb > MAX_KB:
        print("   ! 压不到 30KB 以内（当前 %.1f KB），已用最低配置输出" % (kb or 0))
    print("   · 外接圆内切正方形（含装饰凸起，不切边）；已压缩到 %.1f KB（%dpx，目标 ≤%.0f KB）"
          % (kb, dim, MAX_KB))

    # 老的 drawable/ic_brand.png（无密度目录，既糊又重复）删掉
    legacy = res / "drawable/ic_brand.png"
    if legacy.exists():
        legacy.unlink()

    # 2. 自适应前景：必须内缩，否则图形会被启动器裁掉
    #    108dp 画布里只有中间 72dp 是「任何遮罩都保证可见」的安全区，
    #    所以内缩 (108-72)/2/108 = 16.7%。之前的 0% 会把轮盘外圈切掉。
    (res / "drawable").mkdir(parents=True, exist_ok=True)
    (res / "drawable/ic_launcher_foreground.xml").write_text(
        """<?xml version="1.0" encoding="utf-8"?>
<inset xmlns:android="http://schemas.android.com/apk/res/android"
    android:inset="16.7%"
    android:drawable="@drawable/ic_brand" />
""", encoding="utf-8")

    # 3. 旧系统图标：直接引用同一张位图（anydpi 适配所有密度）
    anydpi = res / "mipmap-anydpi"
    anydpi.mkdir(parents=True, exist_ok=True)
    for name in ("ic_launcher.xml", "ic_launcher_round.xml"):
        (anydpi / name).write_text(
            """<?xml version="1.0" encoding="utf-8"?>
<bitmap xmlns:android="http://schemas.android.com/apk/res/android"
    android:src="@drawable/ic_brand"
    android:gravity="fill" />
""", encoding="utf-8")

    # 4. 自适应图标（API 26+）背景层：纯色，不再用同图铺满
    #    同图铺满会和内缩后的前景叠出「一大一小两个轮盘」的重影
    bg_color = str(cfg.get("iconBackground") or "").strip()
    if not bg_color:
        # 没配就取位图四角的主色，和图形边缘无缝衔接
        cs = [logo.convert("RGB").getpixel(p)[:3] for p in
              ((6, 6), (target - 7, 6), (6, target - 7), (target - 7, target - 7))]
        bg_color = "#%02X%02X%02X" % tuple(sum(c[i] for c in cs) // 4 for i in range(3))
    (res / "drawable/ic_launcher_bg.xml").unlink(missing_ok=True)
    (res / "drawable/ic_launcher_bg.xml").write_text(
        """<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android"
    android:shape="rectangle">
    <solid android:color="%s" />
</shape>
""" % bg_color, encoding="utf-8")

    v26 = res / "mipmap-anydpi-v26"
    v26.mkdir(parents=True, exist_ok=True)
    adaptive = """<?xml version="1.0" encoding="utf-8"?>
<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">
    <background android:drawable="@drawable/ic_launcher_bg" />
    <foreground android:drawable="@drawable/ic_launcher_foreground" />
</adaptive-icon>
"""
    (v26 / "ic_launcher.xml").write_text(adaptive, encoding="utf-8")
    (v26 / "ic_launcher_round.xml").write_text(adaptive, encoding="utf-8")

    # 5. 清理历史遗留：五套密度各三张 PNG（合计 200~900KB 的冗余来源）
    removed = 0
    for dens in DENSITIES:
        d = res / ("mipmap-" + dens)
        if not d.is_dir():
            continue
        for f in d.glob("ic_launcher*.png"):
            f.unlink()
            removed += 1
        try:
            d.rmdir()
        except OSError:
            pass

    print("   图标 %s → drawable-nodpi/ic_brand.png（%.1f KB），清理旧 PNG %d 张"
          % (icon, kb, removed))


def write_resolved(cfg: dict, excluded: list, assets_info: dict = None) -> None:
    fab_enabled, fab_items = norm_fab(cfg)
    features = cfg.get("features") or {}
    data = {
        "appName": cfg["appName"],
        "packageName": cfg["packageName"],
        "versionCode": cfg["versionCode"],
        "versionName": cfg["versionName"],
        "minSdk": MIN_SDK,
        "targetSdk": TARGET_SDK,
        "fabEnabled": fab_enabled,
        "fabItems": [i["id"] for i in fab_items if i["enabled"]],
        "fabSections": [i["id"] for i in norm_sections(cfg) if i["enabled"]],
        "excludedSources": excluded,
        "assets": assets_info or {"enabled": False, "out": str(ASSETS)},
    }
    RESOLVED.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def sdk_int(cfg: dict, key: str, default: int, minimum: int) -> int:
    raw = cfg.get(key, default)
    if raw is None or (isinstance(raw, str) and not raw.strip()):
        return default
    try:
        val = int(raw)
    except (TypeError, ValueError):
        die("%s 必须是整数" % key)
    if val < minimum:
        die("%s 不能小于 %d" % (key, minimum))
    return val


def check_asset_names() -> None:
    """
    assets 下所有文件名必须是纯 ASCII 且不含空格。

    原因：AAPT2 不支持非 ASCII 的 assets 文件名，混淆器会把这类文件
    重命名成「f + 散列」——配置和 HTML 里的引用就会断链。与其各处换算，
    不如源头禁掉：名字保持原样，明文/混淆两端天然一致。
    """
    bad = []
    for p in ASSETS.rglob("*"):
        if p.is_file():
            rel = p.relative_to(ASSETS).as_posix()
            try:
                rel.encode("ascii")
                ok = " " not in rel
            except UnicodeEncodeError:
                ok = False
            if not ok:
                bad.append(rel)
    if bad:
        die("assets 里的文件名必须是纯 ASCII 且不含空格（中文文件名会导致混淆版引用断链）：\n  "
            + "\n  ".join(bad))


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--version-name", default="", help="覆盖 versionName（不改 app-config.json）")
    ap.add_argument("--version-code", default="", help="覆盖 versionCode（不改 app-config.json）")
    ap.add_argument("--plain", action="store_true", help="强制打明文版（不管 app-config.json）")
    ap.add_argument("--obfuscate", action="store_true", help="强制打混淆版（不管 app-config.json）")
    ap.add_argument("--harden", action="store_true",
                    help="加固版：assets 混淆 + 代码交给 R8 全量混淆")
    args = ap.parse_args()

    cfg = load_config()

    check_asset_names()

    if sum([bool(args.plain), bool(args.obfuscate), bool(args.harden)]) > 1:
        die("--plain / --obfuscate / --harden 只能选一个")
    if args.plain or args.obfuscate or args.harden:
        obf = cfg.get("obfuscate")
        if not isinstance(obf, dict):
            obf = {}
        obf["enabled"] = bool(args.obfuscate or args.harden)
        cfg["obfuscate"] = obf

    if args.version_code.strip():
        try:
            cfg["versionCode"] = int(args.version_code)
        except ValueError:
            die("versionCode 必须是整数")
    if args.version_name.strip():
        cfg["versionName"] = args.version_name.strip()

    pkg = str(cfg.get("packageName", "")).strip()
    if not re.fullmatch(r"[a-zA-Z][\w]*(\.[a-zA-Z][\w]*)+", pkg):
        die("packageName 不合法：%s（例：com.example.browser）" % pkg)
    cfg["packageName"] = pkg

    try:
        vc = int(cfg.get("versionCode", 0))
    except (TypeError, ValueError):
        die("versionCode 必须是整数")
    if vc <= 0:
        die("versionCode 必须大于 0")
    cfg["versionCode"] = vc

    vn = str(cfg.get("versionName", "")).strip()
    if not vn:
        die("versionName 不能为空")
    cfg["versionName"] = vn

    if not str(cfg.get("appName", "")).strip():
        die("appName 不能为空")

    global MIN_SDK, TARGET_SDK
    MIN_SDK = sdk_int(cfg, "minSdk", MIN_SDK, 21)
    TARGET_SDK = sdk_int(cfg, "targetSdk", TARGET_SDK, MIN_SDK)

    old_pkg = current_package()
    migrate_package(old_pkg, pkg)

    write_config_java(pkg, cfg)
    excluded = write_fab_registry(pkg, cfg)
    apply_versions(cfg)
    apply_sdk(cfg)
    apply_app_name(cfg)
    apply_authority(pkg)
    apply_icon(cfg)
    assets_info = apply_assets(cfg)
    # 书签里的内置网页要按混淆后的文件名换算，所以放在 apply_assets 之后
    n_marks = write_presets(cfg, assets_info.get("file_map"), assets_info.get("out"))
    write_resolved(cfg, excluded, assets_info)

    print("   %s  %s (%d)  %s" % (cfg["appName"], vn, vc, pkg))
    print("   minSdk %d / targetSdk %d" % (MIN_SDK, TARGET_SDK))
    pages = norm_pages(cfg)
    if pages:
        home_idx = next((i for i, p in enumerate(pages) if p.get("home")), 0)
        home = pages[home_idx]
        where = home.get("url") or ("内置 " + home.get("file", ""))
        print("   启动页：%s   共 %d 个页面" % (where, len(pages)))
    else:
        print("   启动页：%s" % (cfg.get("online") or "内置 index.html"))
    fab_enabled, fab_items = norm_fab(cfg)
    print("   悬浮球：%s，菜单 %d 项%s"
          % ("开" if fab_enabled else "关",
             len([i for i in fab_items if i["enabled"]]),
             "" if not excluded else "；构建期排除 " + ", ".join(excluded)))
    if assets_info.get("enabled"):
        print("   assets：混淆版（入口页 %.1f KB → %.1f KB，内联脚本 %d 段已抽走，资源包 %s %.1f KB）"
              % (assets_info["entryKB"], assets_info["shellKB"],
                 assets_info["scripts"], assets_info["blobName"], assets_info["blobKB"]))
    elif assets_info.get("fallback"):
        print("   assets：未处理（缺少混淆脚本），按原目录打包")
    else:
        print("   assets：明文版（%d 个文件）" % assets_info.get("files", 0))



if __name__ == "__main__":
    main()
