#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
生成本版更新校验 JSON（tools/update/update.json）—— 由 build.sh 出包末尾调用。

数据来源全部是 app-config.json，无需手改模板：
    apkUploadDir      → downloadUrl 的目录前缀
    update.changelog  → 更新说明
    versionCode/Name  → 与本次 APK 完全一致

只输出 App 真正会读的 5 个字段：
    versionCode / versionName / downloadUrl / changelog / minVersionCode

downloadUrl = apkUploadDir + 文件名，例如：
    apkUploadDir = "https://0.wudaozhe.net/sdq/"
    加固版文件名  = 闪电球1.0.0.apk
    → https://0.wudaozhe.net/sdq/闪电球1.0.0.apk
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path


def public_apk_name(app_name: str, version_name: str, variant: str) -> str:
    """线上文件名：公开发行版（加固）不带修饰词，其余带变体后缀。"""
    if variant == "加固":
        return "%s%s.apk" % (app_name, version_name)
    return "%s%s-%s.apk" % (app_name, version_name, variant)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="app-config.json",
                    help="app-config.json 路径（取 apkUploadDir / changelog）")
    ap.add_argument("--apk", required=True, help="本次构建出的 APK")
    ap.add_argument("--app-name", required=True)
    ap.add_argument("--variant", required=True, help="明文 / 混淆 / 加固")
    ap.add_argument("--version-code", type=int, required=True)
    ap.add_argument("--version-name", required=True)
    ap.add_argument("--min-version-code", type=int, default=0)
    ap.add_argument("--out", required=True, help="输出文件路径")
    args = ap.parse_args()

    cfg_path = Path(args.config)
    if not cfg_path.is_file():
        print("!! 找不到 %s" % cfg_path)
        sys.exit(1)
    if not Path(args.apk).is_file():
        print("!! 找不到 APK：%s" % args.apk)
        sys.exit(1)

    cfg = json.loads(cfg_path.read_text(encoding="utf-8"))
    upload_dir = (cfg.get("apkUploadDir") or "").strip().rstrip("/")
    changelog = (cfg.get("update") or {}).get("changelog") or ""

    name = public_apk_name(args.app_name, args.version_name, args.variant)
    if upload_dir:
        url = "%s/%s" % (upload_dir, name)
    else:
        # 没配上传目录时给占位，提醒去 app-config.json 补 apkUploadDir
        url = "https://你的上传目录/%s" % name

    release = {
        "versionCode": args.version_code,
        "versionName": args.version_name,
        "downloadUrl": url,
        "changelog": changelog,
        "minVersionCode": args.min_version_code,
    }

    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(release, ensure_ascii=False, indent=2) + "\n",
                   encoding="utf-8")

    print("   更新模板  %s → 版本 %s (%d) → %s"
          % (out, args.version_name, args.version_code, name))
    if not upload_dir:
        print("   !! app-config.json 没配 apkUploadDir，downloadUrl 是占位地址")


if __name__ == "__main__":
    main()
