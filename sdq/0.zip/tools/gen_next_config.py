#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
生成「下一版的 app-config.json」—— 由 build.sh 在出包开头调用。

规则只有一条：**完整复刻当前这版 app-config.json**，只把
versionCode + 1、versionName 末位 + 1，其余字段一个字都不动 ——
包名、图标、书签、菜单、赞助码、update.url（更新校验地址）…… 连以后
新加的字段也自动带上，因为它们本来就在源文件里。

写法是「按原文复制 + 只替换两处版本号」，不是重新 dump JSON，所以缩进、
字段顺序、`_note` 这类说明字段都和源文件一模一样。

写完还会自己逐字段比一遍（也可以 `--verify` 单独比一个已有文件）：
只要除 versionCode / versionName 之外有任何一处不一致，就直接报错退出，
不会再出现「下版配置少了某个字段却没人发现」的情况。
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path

# 允许变化、且必须变化的字段
BUMPED = ("versionCode", "versionName")

# 用来标记「这一层在另一份 JSON 里根本不存在」
MISSING = object()


def bump_name(version_name: str) -> str:
    """1.0.0 → 1.0.1；不是纯数字分段就原样返回。"""
    parts = version_name.split(".")
    if not parts or not all(p.isdigit() for p in parts):
        return version_name
    parts[-1] = str(int(parts[-1]) + 1)
    return ".".join(parts)


def count_leaves(obj) -> int:
    """数一数字段个数（用于报告「复刻了多少项」）。"""
    if isinstance(obj, dict):
        return sum(count_leaves(v) for v in obj.values())
    if isinstance(obj, list):
        return sum(count_leaves(v) for v in obj)
    return 1


def diff(a, b, path: str = "", out=None):
    """
    逐层比较两份 JSON，返回不一致的路径列表 [(路径, 源值, 目标值)]。
    dict 缺键、list 长度不同、标量不同都算不一致（True 与 1 也分开算）。
    """
    if out is None:
        out = []
    if isinstance(a, dict) and isinstance(b, dict):
        for k in sorted(set(a) | set(b), key=str):
            p = "%s.%s" % (path, k) if path else str(k)
            if k not in a:
                out.append((p, MISSING, b[k]))
            elif k not in b:
                out.append((p, a[k], MISSING))
            else:
                diff(a[k], b[k], p, out)
    elif isinstance(a, list) and isinstance(b, list):
        if len(a) != len(b):
            out.append((path or "(根)", "%d 项" % len(a), "%d 项" % len(b)))
        for i in range(min(len(a), len(b))):
            diff(a[i], b[i], "%s[%d]" % (path, i), out)
    else:
        if type(a) is not type(b) or a != b:
            out.append((path or "(根)", a, b))
    return out


def show(value) -> str:
    if value is MISSING:
        return "<缺失>"
    text = value if isinstance(value, str) else json.dumps(value, ensure_ascii=False)
    return text if len(text) <= 46 else text[:43] + "..."


def report_bad(bad) -> None:
    print("!! 生成的下一版配置和源配置不一致（除版本号外不允许有差异）：")
    for path, src, dst in bad[:20]:
        print("     %s：源 %s → 下一版 %s" % (path, show(src), show(dst)))
    if len(bad) > 20:
        print("     …… 还有 %d 处" % (len(bad) - 20))
    print("   这是生成逻辑的 bug，请修 gen_next_config.py，别拿这份配置发版。")


def load_json(text: str, what: str):
    try:
        return json.loads(text)
    except Exception as e:
        print("!! %s 不是合法 JSON：%s" % (what, e))
        sys.exit(1)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="app-config.json", help="当前配置")
    ap.add_argument("--out", action="append", default=[],
                    help="输出路径，可重复传多个")
    ap.add_argument("--verify", default="",
                    help="只校验这个文件是不是 --config 的完整复刻（版本号 +1）")
    ap.add_argument("--next-name", default="", help="下一版 versionName，留空自动 +1")
    ap.add_argument("--next-code", type=int, default=0, help="下一版 versionCode，留空自动 +1")
    ap.add_argument("--cur-name", default="",
                    help="覆盖当前 versionName（CI 临时版本构建时与文件值不同）")
    ap.add_argument("--cur-code", type=int, default=0,
                    help="覆盖当前 versionCode")
    ap.add_argument("--quiet", action="store_true")
    args = ap.parse_args()

    if not args.out and not args.verify:
        print("!! 要么给 --out，要么给 --verify")
        sys.exit(1)

    src_path = Path(args.config)
    if not src_path.is_file():
        print("!! 找不到 %s" % src_path)
        sys.exit(1)

    # 逐字改文本而不是 json.dump，尽量保留原文件的排版和字段顺序
    text = src_path.read_text(encoding="utf-8-sig")
    src = load_json(text, str(src_path))
    if not isinstance(src, dict):
        print("!! %s 顶层应该是一个对象" % src_path)
        sys.exit(1)

    m_code = re.search(r'("versionCode"\s*:\s*)(\d+)', text)
    m_name = re.search(r'("versionName"\s*:\s*")([^"]*)(")', text)
    if not m_code or not m_name:
        print("!! app-config.json 里没找到 versionCode / versionName")
        sys.exit(1)

    cur_code = args.cur_code or int(m_code.group(2))
    cur_name = args.cur_name.strip() or m_name.group(2)

    next_code = args.next_code or (cur_code + 1)
    next_name = args.next_name.strip() or bump_name(cur_name)

    if next_code <= cur_code:
        print("!! 下一版 versionCode(%d) 必须大于当前(%d)" % (next_code, cur_code))
        sys.exit(1)

    # ---------------------------------------------------------------- 只校验
    if args.verify:
        target = Path(args.verify)
        if not target.is_file():
            print("!! 找不到 %s（这一版没有生成下一版配置）" % target)
            sys.exit(1)
        dst = load_json(target.read_text(encoding="utf-8-sig"), str(target))
        bad = [x for x in diff(src, dst) if x[0] not in BUMPED]
        if bad:
            report_bad(bad)
            sys.exit(1)
        if dst.get("versionCode") != next_code or dst.get("versionName") != next_name:
            print("!! %s 的版本号不是下一版（应为 %s / %d，实际 %s / %s）"
                  % (target, next_name, next_code,
                     dst.get("versionName"), dst.get("versionCode")))
            sys.exit(1)
        print("   %s 是本版配置的完整复刻（%d 个字段），仅版本号 +1：%s / %d"
              % (target.name, count_leaves(src), next_name, next_code))
        return

    # ---------------------------------------------------------------- 生成
    out_text = text
    out_text = re.sub(r'("versionCode"\s*:\s*)\d+',
                      lambda m: m.group(1) + str(next_code), out_text, count=1)
    out_text = re.sub(r'("versionName"\s*:\s*")([^"]*)(")',
                      lambda m: m.group(1) + next_name + m.group(3), out_text, count=1)

    dst = load_json(out_text, "生成的配置")

    # 自检 1：能被解析，且版本字段确实是下一版
    if dst.get("versionCode") != next_code or dst.get("versionName") != next_name:
        print("!! 版本字段改写失败")
        sys.exit(1)

    # 自检 2：除版本号以外，每一个字段都必须和源配置一模一样
    bad = [x for x in diff(src, dst) if x[0] not in BUMPED]
    if bad:
        report_bad(bad)
        sys.exit(1)

    for target in args.out:
        p = Path(target)
        if p.parent != Path(""):
            p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(out_text, encoding="utf-8")
        if not args.quiet:
            print("   下一版配置 %s（%s / %d，完整复刻 %d 个字段）"
                  % (p, next_name, next_code, count_leaves(src)))


if __name__ == "__main__":
    main()
