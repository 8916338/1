#!/usr/bin/env bash
# ============================================================================
# 定位 / 补装 Android SDK（GitHub Actions 与本地共用）
#
# 说明文档在 docs/BUILD.md。本文件只做三件事：
#   1. 找一个可用的 SDK 根目录；
#   2. 检查 build-tools 与 platforms 是否齐全，缺了尝试用 sdkmanager 补；
#   3. 把 ANDROID_HOME / ANDROID_SDK_ROOT 写进 GITHUB_ENV。
# ============================================================================
set -Eeuo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

say() {
  echo "   $*"
}

fail() {
  echo "::error::$*"
  exit 1
}

find_sdk() {
  local candidates=(
    "${ANDROID_HOME:-}"
    "${ANDROID_SDK_ROOT:-}"
    /usr/local/lib/android/sdk
    "${HOME}/Android/Sdk"
    /root/sdk
    "${HOME}/Library/Android/sdk"
  )

  local dir
  for dir in "${candidates[@]}"; do
    if [ -n "$dir" ] && [ -d "$dir/build-tools" ]; then
      printf '%s\n' "$dir"
      return 0
    fi
  done

  for dir in "${candidates[@]}"; do
    if [ -n "$dir" ] && [ -d "$dir" ]; then
      printf '%s\n' "$dir"
      return 0
    fi
  done

  return 1
}

printf '%s\n' '==> 准备 Android SDK'

SDK="$(find_sdk)" || fail "找不到 Android SDK（ANDROID_HOME 与常见路径都不存在）"
say "SDK 目录：${SDK}"

REQ_API="$(python3 - "${ROOT}/app-config.json" <<'PY'
import json
import sys

try:
    with open(sys.argv[1], encoding="utf-8") as fh:
        print(int(json.load(fh).get("targetSdk") or 35))
except Exception:
    print(35)
PY
)"

case "${REQ_API}" in
  ''|*[!0-9]*) REQ_API=35 ;;
esac
say "工程 targetSdk：${REQ_API}"

has_aapt2() {
  find "${SDK}/build-tools" -mindepth 2 -maxdepth 2 -name aapt2 -type f -print -quit 2>/dev/null | grep -q .
}

has_platform() {
  find "${SDK}/platforms" -mindepth 2 -maxdepth 2 -name android.jar -type f -print -quit 2>/dev/null | grep -q .
}

has_platform_for() {
  [ -f "${SDK}/platforms/android-$1/android.jar" ]
}

has_build_tools_for() {
  python3 - "${SDK}/build-tools" "$1" <<'PY'
import os
import re
import sys

base, want = sys.argv[1], int(sys.argv[2])

if not os.path.isdir(base):
    sys.exit(1)

for name in os.listdir(base):
    exe = os.path.join(base, name, "aapt2")
    if not os.path.exists(exe):
        continue
    nums = re.findall(r"\d+", name)
    if nums and int(nums[0]) >= want:
        sys.exit(0)

sys.exit(1)
PY
}

find_sdkmanager() {
  local candidate
  for candidate in \
    "${SDK}/cmdline-tools/latest/bin/sdkmanager" \
    "${SDK}"/cmdline-tools/*/bin/sdkmanager \
    "${SDK}/bin/sdkmanager" \
    "${SDK}/tools/bin/sdkmanager"; do
    if [ -x "$candidate" ]; then
      printf '%s\n' "$candidate"
      return 0
    fi
  done

  command -v sdkmanager 2>/dev/null || return 1
}

INSTALL=()
has_build_tools_for "${REQ_API}" || INSTALL+=("build-tools;${REQ_API}.0.0")
has_platform_for "${REQ_API}" || INSTALL+=("platforms;android-${REQ_API}")

if [ ${#INSTALL[@]} -gt 0 ]; then
  say "缺少组件：${INSTALL[*]}"

  if SM="$(find_sdkmanager)"; then
    say "sdkmanager：${SM}"
    ( yes 2>/dev/null | "$SM" --sdk_root="$SDK" --licenses >/dev/null 2>&1 ) || true

    if ! "$SM" --sdk_root="$SDK" --install "${INSTALL[@]}" >/tmp/sdkmanager-install.log 2>&1; then
      say "sdkmanager 安装失败，将使用现有最高版本（不影响出包）"
      tail -n 15 /tmp/sdkmanager-install.log || true
    fi

    if ! has_aapt2; then
      say "仍然没有 build-tools，尝试 build-tools;34.0.0"
      "$SM" --sdk_root="$SDK" --install "build-tools;34.0.0" \
        >>/tmp/sdkmanager-install.log 2>&1 || true
    fi
  else
    say "没有 sdkmanager，跳过补装"
  fi
fi

has_aapt2 || fail "${SDK}/build-tools 下没有可用的 aapt2"
has_platform || fail "${SDK}/platforms 下没有 android.jar"

export ANDROID_HOME="$SDK"
export ANDROID_SDK_ROOT="$SDK"

if [ -n "${GITHUB_ENV:-}" ]; then
  {
    echo "ANDROID_HOME=$SDK"
    echo "ANDROID_SDK_ROOT=$SDK"
  } >> "$GITHUB_ENV"
fi

say "build-tools：$(find "$SDK/build-tools" -mindepth 1 -maxdepth 1 -type d -printf '%f ' 2>/dev/null || true)"
say "platforms  ：$(find "$SDK/platforms" -mindepth 1 -maxdepth 1 -type d -printf '%f ' 2>/dev/null || true)"

if ! has_platform_for "${REQ_API}"; then
  say "没有 platforms/android-${REQ_API}，构建会使用现有最高版本链接（targetSdk 仍写 ${REQ_API}）"
fi

say "SDK 就绪"
