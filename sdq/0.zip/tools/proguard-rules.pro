# ============================================================================
# 加固版（VIE_HARDEN=1）交给 R8 的规则
#
# 目标：类名 / 方法名 / 字段名全部改成 a、b、c，但不动任何会被系统
#       按字符串查找的类 —— AndroidManifest 里写的组件名、自定义 View
#       的构造器、Parcelable、枚举，这些被改名就会运行时崩溃。
#
# 只混淆，不裁剪（-dontshrink）：本项目大量用反射式 id 分发，
# 裁剪风险大于收益，体积靠 assets 混淆和资源压缩来控。
# ============================================================================

-dontshrink
-dontoptimize

-keepattributes *Annotation*,Signature,InnerClasses,EnclosingMethod

# AndroidManifest 里按名字引用的组件（.MainActivity / .ScanActivity / .LocalFiles）
# 只保留类名 —— 成员（方法/字段）照常混淆；
# 系统回调 onCreate/onResume 等是 override，父类方法名不能改，R8 自动保留。
-keep class **.MainActivity
-keep class **.ScanActivity
-keep class **.LocalFiles
-keep class **.PlayerActivity

# 系统会实例化的基类
-keep public class * extends android.app.Activity
-keep public class * extends android.app.Application
-keep public class * extends android.app.Service
-keep public class * extends android.content.BroadcastReceiver
-keep public class * extends android.content.ContentProvider

# 布局 / 代码里 new 出来的自定义 View：构造器必须保留
-keep public class * extends android.view.View {
    public <init>(android.content.Context);
    public <init>(android.content.Context, android.util.AttributeSet);
    public <init>(android.content.Context, android.util.AttributeSet, int);
}

# Parcelable / 枚举
-keep class * implements android.os.Parcelable { *; }
-keepclassmembers enum * {
    public static **[] values();
    public static ** valueOf(java.lang.String);
}

# 保留 R 的字段名（aapt2 生成，运行时按 id 取）
-keepclassmembers class **.R$* { public static <fields>; }
