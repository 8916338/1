# 闪电球 · Android 浏览器壳（第一版正式说明）

**闪电球** —— 一个不依赖 Gradle、一条命令就能出包的 Android 浏览器壳。网页放在 `assets/`，壳子负责地址栏以外的一切：闪电球悬浮球、书签、历史、下载、视频嗅探与播放、多窗口、主题、扫码、更新。

| 项目 | 值 |
| --- | --- |
| 应用名 | 闪电球 |
| 包名 | `com.shanqiu.app` |
| 版本 | 1.0.0（versionCode 18） |
| 产物 | 明文版 / 混淆版 / 加固版，三版同一张证书签名，可互相覆盖安装 |
| 签名 SHA-256 | `66468219e162d9d5ec254eeb2318d42cf83d08d4d43816f379c7be68c75b2b9a` |

---

## 一、三分钟上手

```bash
# 1. 改配置（应用名、包名、图标、书签、悬浮球菜单……全在这一个文件里）
vim app-config.json

# 2. 出包（三选一）
VIE_PLAIN=1     bash build.sh   # 明文版：assets 不加密，代码不混淆
VIE_OBFUSCATE=1 bash build.sh   # 混淆版：assets 加密，代码不混淆
VIE_HARDEN=1    bash build.sh   # 加固版：assets 加密 + R8 全代码混淆

# 3. 产物在 build/
#    闪电球-1.0.0-明文.apk   ← 内部调试
#    闪电球-1.0.0-混淆.apk   ← 内部调试
#    闪电球1.0.0.apk        ← 公开发行版（加固），文件名不带修饰词
```

前置条件：JDK 8+、Android SDK（build-tools 带 aapt2 / d8 / apksigner）、`python3` + `Pillow`、`zip`。

> 加固版额外需要 `java` 能跑 R8 —— 就在 build-tools 自带的 `lib/d8.jar` 里，不用另装。

**发版节奏**：每次改完配置 → `versionCode` 加 1 → 出包。只有 `versionCode` 变了才能覆盖安装。

### 1.1 克隆后试跑（GitHub 工程）

```bash
git clone <你的仓库地址> vie && cd vie
export ANDROID_HOME=/path/to/android-sdk   # 或用 local.properties.sample 里的路径
VIE_PLAIN=1 bash build.sh
```

目录干净时**不需要任何额外安装**：`build.sh` 会自己找 SDK、build-tools、platform，用 `aapt2 + javac + d8` 直接出包，全程不碰 Gradle。跑通后会看到 `OK -> build/闪电球-1.0.0-明文.apk`。

仓库里已经带好：

| 文件 | 作用 |
| --- | --- |
| `.gitignore` | 排除 `build/`、`dist/`、`.resolved-config.json`、`__pycache__`、IDE 文件、**keystore 私钥与口令** |
| `.github/workflows/build.yml` | 推送到 `main`/`master` 或手动触发，自动出明文 + 混淆 + 加固三版并上传 Artifact；**构建完把 `apk/` 与 `tools/update/` 提交回仓库**（`[skip ci]`，不会循环）；打 tag 自动发 Release |
| `docs/BUILD.md` | 构建细节、SDK 准备、常见报错 |
| `LICENSE` | MIT |

CI 的签名密钥**直接内嵌在工作流里**（`.github/workflows/build.yml` 的「还原签名密钥」步骤），不需要配任何 Secrets：
步骤里有一段 keystore 的 base64 和口令，构建前还原成 `keystore/release.jks`，于是 CI 与本地打出的包证书完全相同，用户能覆盖安装。

项目不涉密，这样最省事；哪天要收紧了，把那段挪进 Secrets 即可（改一个 `env:` 就行）。

> 本地构建与 CI 用同一套环境变量名，所以本机把 jks 放 `keystore/`、CI 配 Secrets，两边打出的包指纹一致，可互相覆盖。

---

## 二、目录结构

```
app-config.json              ← 唯一需要日常改的文件
build.sh                     ← 构建脚本（aapt2 → javac → d8/R8 → zipalign → apksigner）
build.gradle / settings.gradle   ← 给 Android Studio 看的壳，命令行构建用不到
icon/                        ← 图标源图
apk/                         ← 发行版 APK（闪电球1.0.0.apk，发版后放入提交）
keystore/                    ← 空目录（放你自己的 jks + properties，已被忽略）
libs/                        ← 第三方 jar（zxing 扫码）
tools/
tools/
  apply_config.py            ← 把 app-config.json 写进工程（包名/版本/图标/书签/菜单/assets）
  obfuscate_assets.py        ← assets 加密 + 文件名混淆
  proguard-rules.pro         ← 加固版的 R8 保留规则
  update/                    ← 构建时自动刷新：update.json + app-config.next.json
src/main/
  AndroidManifest.xml
  assets/                    ← 内置网页（index.html 首页、api.html 接口大全、preset_bookmarks.json）
  java/com/shanqiu/app/      ← 壳源码（改配置即可，一般不用动）
  res/                       ← 图标 XML、颜色、样式、动画
docs/BUILD.md                ← 构建细节与排错
```

---

## 三、`app-config.json` 全字段攻略

### 3.1 基础

| 字段 | 说明 |
| --- | --- |
| `appName` | 桌面显示的应用名，弹窗、设置页文案同步替换 |
| `packageName` | 包名。改了就是另一个 App，不能覆盖安装旧的 |
| `versionCode` | 整数，每次发版必须递增，否则装不上 |
| `versionName` | 显示给用户看的版本号 |
| `online` | 在线站点地址。为空只用内置页；非空优先加载它，打不开回落内置页 |
| `fabText` | 闪电球上的文字（留空只显示图形） |
| `allowUserBookmarks` | 允不允许用户在 App 里自己加书签 |

### 3.2 赞助（原「请开发者喝咖啡」）

```json
"coffee": {
  "qr": "https://0.wudaozhe.net/vip/zsm.jpg",
  "qq": "1480570637",
  "tip": "凭赞助截图可加 Q，有资源优先分享"
}
```

写进 `Config.COFFEE_*` 编译到 APK 里，**不读 assets 里的任何数据文件** —— 网页被整套替换、改版，赞赏码也不会丢。`qr` 留空则菜单里不出现「赞助」这一项。

> 首页 `index.html` 里也内联了一份同样的弹窗逻辑（`applySponsor`），改了 `coffee` 记得同步改 `assets/index.html` 里的 `SPONSOR` 常量，两边是独立维护的（见 3.9）。

### 3.3 书签与初始页

```json
"bookmarks": [
  { "name": "接口大全", "url": "https://0.wudaozhe.net" },
  { "title": "接口大全", "file": "api.html", "home": true, "start": true }
],
"startPages": [
  { "name": "接口大全", "url": "https://0.wudaozhe.net" },
  { "name": "接口大全", "file": "api.html" }
]
```

| 字段 | 说明 |
| --- | --- |
| `bookmarks[].name` / `title` | 书签名（两种写法都认） |
| `bookmarks[].url` | 在线地址 |
| `bookmarks[].file` | assets 里的 html 文件名，运行时走内置虚拟域名 |
| `bookmarks[].home` / `start` | 标记为首页 / 默认初始页 |
| `startPages[].name` | 「更多 → 初始页」面板里显示的名字 |
| `startPages[].url` / `file` | 指向：在线地址或内置页 |

`startPages` 决定「更多 → 初始页」里能选哪些；用户在 App 里选完会记住，下次打开生效。

### 3.4 图标

| 字段 | 说明 |
| --- | --- |
| `icon` | 图片路径，如 `icon/logo4.jpg`。PNG/JPG/WEBP/BMP 都行 |
| `iconBackground` | 自适应图标背景色，留空自动取（白底图会用主体色） |

取景规则：以图形中心量出「装得下全部主体的外接圆」，放大到正好内切正方形；圆外四角保留原图内容或涂背景色，避免方圆遮罩下露白角。压缩上限默认 30 KB，超出自动降边长。

### 3.5 悬浮球（闪电球）：三个位置，全部可配

弹窗里一共有三块，分别由 `fab.toolbar` / `fab.sections` / `fab.more` 三个数组控制。**数组顺序就是显示顺序，`enabled: false` 就是隐藏，`title` 可以改成任何叫法。**

```json
"fab": {
  "enabled": true,
  "toolbar":  [ ... ],   // 弹窗靠球那一侧的横向图标条
  "sections": [ ... ],   // 弹窗列表里的板块
  "more":     [ ... ]    // 「更多」面板里的项目
}
```

**① `toolbar` —— 横向图标条（支持多排）**

每一项可带 `"row": 1` / `"row": 2` 指定排数，同一排按数组顺序从左到右**等宽均分**。当前默认两排 12 项：

| | 第 1 排 | 第 2 排 |
| --- | --- | --- |
| 当前 | 首页 后退 查找 扫描 分享 更多 | 刷新 前进 历史 下载 后台 收藏 |

想要一排只放 6 个？把 12 项全设成 `"row": 1`（超出一排会自动换行）或各留 6 个分两排。

| 可用 id | 默认标题 | 说明 |
| --- | --- | --- |
| `home` | 首页 | 回到 `bookmarks` 里标 `home: true` 的页面 |
| `back` | 后退 | 网页后退 |
| `forward` | 前进 | 网页前进 |
| `refresh` | 刷新 | 刷新当前页 |
| `find` | 查找 | 页面内查找 |
| `scan` | 扫描 | 打开扫一扫（相机扫码页） |
| `share` | 分享 | 分享当前页 |
| `more` | 更多 | 打开「更多」面板 |
| `history` | 历史 | 浏览历史 |
| `downloads` | 下载 | 下载记录 |
| `background` | 后台 | 多窗口/标签管理 |
| `bookmark` | 收藏 | 收藏当前页 |

**② `sections` —— 弹窗列表板块**

| 可用 id | 默认标题 | 说明 |
| --- | --- | --- |
| `openurl` | 转到网址 | 手动输网址跳转（地址栏留空，不预填） |
| `bookmarks` | 书签 | 书签列表（长按直接删除，不询问） |
| `bookmark` | 收藏本页 | 收藏当前网页 |
| `pages` | 更多页面 | `app-config.json` 的 `pages` 列表 |
| `downloads` | 下载内容 | 同 toolbar 的 `downloads` |
| `history` | 历史 | 同上 |
| `find` | 页面查找 | 同上 |
| `coffee` | 赞助 | 赞助弹窗（读 3.2 的配置） |
| `more` | 更多 | 打开「更多」面板 |

**③ `more` —— 「更多」面板**

| 可用 id | 默认标题 | 说明 |
| --- | --- | --- |
| `update` | 检查更新 | 手动触发检查更新 |
| `privacy` | 隐私模式 | 无痕浏览开关 |
| `desktop` | 网页版本 | 桌面版 UA 切换 |
| `ua` | 浏览器标识 | UA 选择面板 |
| `orient` | 屏幕方向 | 竖屏/横屏/自动 |
| `font` | 字体大小 | 页面缩放 |
| `theme` | 主题 | 深浅色 |
| `start` | 初始页 | 初始页选择 |
| `coffee` | 赞助 | 同 sections 的 `coffee` |

> 视频嗅探与播放是全局常驻能力，不占菜单位：网页里点播视频会自动在页面内弹出壳的播放层叠（双击或按钮全屏），无需任何配置。

### 3.6 `pages` —— 内置页面列表

```json
"pages": [
  { "title": "首页", "file": "index.html", "home": true, "start": true },
  { "title": "接口大全", "file": "api.html" }
]
```

决定「更多页面」面板里能跳转的内置页；`home: true` 的是首页地址，`start: true` 的是默认初始页。运行时通过内置虚拟域名 `https://appassets.androidplatform.net/<文件名>` 加载，网页间互相跳转、AJAX 都正常。

> **⚠️ assets 文件名必须是纯 ASCII 且不含空格**（如 `api.html`，不能用 `接口.html`）。构建时会强制校验：中文名进 APK 会乱码、混淆版还会被重命名成散列名导致配置和页面内引用全部断链。页面的中文标题写在 `title` / `name` 字段里，文件名本身用英文。

### 3.7 `features` —— 功能裁剪开关

```json
"features": {
  "downloads": true,
  "history": true,
  "update": true,
  "background": true
}
```

设为 `false` 会把对应能力整体下线（菜单不显示、入口禁用）。想做一个「纯净阅读壳」就把这四个全关、`fab.sections` 只留 `openurl` + `bookmarks`。

### 3.8 更新检查与发布文件

```json
"update": {
  "enabled": true,
  "url": "",
  "delaySeconds": 6,
  "ignoreDays": 7,
  "hint": "",
  "changelog": "1. 首个正式版本"
}
```

`url` 填服务器上 update.json 的地址即可启用在线更新提示。`delaySeconds` 是启动后延迟检查的秒数，`ignoreDays` 是用户点「忽略」后的静默天数，`hint` 是自定义提示语。**`changelog` 是本次版本的更新说明，构建时会被写进发布模板。**

另有顶层字段 `apkUploadDir` —— APK 的上传目录，例如 `"https://0.wudaozhe.net/sdq/"`。构建时它决定模板里 `downloadUrl` 的前缀，不再用占位地址。

**每次 `bash build.sh` 都会把两个文件刷到 `tools/update/`（构建一开始就生成，收尾再逐字段校验一遍），没有别的**：

| 文件 | 内容 |
| --- | --- |
| **`update.json`** | 本版验校模板：`versionCode` / `versionName` 与刚打出的 APK 一致；`downloadUrl = apkUploadDir + 闪电球<版本>.apk`；`changelog` 取自配置；`minVersionCode` 强制更新线 |
| **`app-config.next.json`** | 本版配置的完整复刻，只把版本号 +1（如 18 → 19、1.0.0 → 1.0.1），其余逐字不动 |

> `app-config.next.json` 是按原文复制、只替换两处版本号，所以新增的字段（比如后加的
> `update.url`）一定会跟着走；生成后还会逐字段和源配置比对一遍，除版本号以外有任何差异
> 直接报错退出，不会再出现「下版配置悄悄少了一项」。

模板 5 个字段之外什么都不写：

```json
{
  "versionCode": 18,
  "versionName": "1.0.0",
  "downloadUrl": "https://0.wudaozhe.net/sdq/闪电球1.0.0.apk",
  "changelog": "1. 首个正式版本",
  "minVersionCode": 0
}
```

`downloadUrl` 不用改：`apkUploadDir` 配好了就自动拼出来。发布时把 APK 传到 `apkUploadDir` 指向的目录，再把 `update.json` 传到 `update.url` 指向的位置即可。

**发下一版就两步**：

```bash
cp tools/update/app-config.next.json app-config.json   # 版本号变成 1.0.1 / 19
bash build.sh                                          # 出包，tools/update/ 自动刷新
```

> **铁律：模板的 `versionCode` 必须等于它指向的 APK。**
> 写成更大的数（打包 18 却发 19 的模板），用户装完版本号仍是 18，下次启动又提示 —— 死循环。
> 所以 `update.json` 永远对应当前构建，`+1` 的只出现在 `app-config.next.json` 里。

不带参数 `bash build.sh` 直接出**公开发行版**（加固）；调试请显式 `VIE_PLAIN=1` 或 `VIE_OBFUSCATE=1`。
可选参数：`VIE_NEXT_VERSION_NAME`（下版号）、`VIE_MIN_VERSION_CODE`（强制更新线）、
`VIE_VERSION_NAME` / `VIE_VERSION_CODE`（临时覆盖本次构建的版本号，不改 app-config.json，
GitHub Actions 手动触发时填的就是它们，下一版模板会基于覆盖后的版本 +1）。

### 3.9 assets 首页与壳的关系：两方独立，互不统属

这是本项目最重要的设计约定：

- **壳（Java 部分）**：负责闪电球、弹窗、书签、下载、嗅探播放、扫码、主题。改这些菜单只动 `app-config.json`，**不需要重新设计网页**。
- **首页 `assets/index.html`**：完全独立的一张网页，零外部依赖（不 fetch data.json、不请求任何外部脚本），自带：
  - 浅蓝椭圆 SVG logo（闪电 + 飞鸟）、圆角描边地址栏（聚焦蓝边）、右侧扫码图标（跳 `hjk://scan`）；
  - 地址归一化逻辑：自动补 `https://`、纯关键词走 Bing 搜索兜底；
  - `api.html` 快捷入口 chip；
  - **内联继承的风险提示 + 赞助弹窗**（`applySponsor({qr, qq})`），localStorage 频控 key 与壳一致，改 `coffee` 时同步改这里的 `SPONSOR` 常量。
- **`assets/api.html`**：原「接口大全」数据页，数据已内联（原 `data.json` 已并入并删除），单文件即可运行。
- 两边**没有共享代码、没有构建期注入**。你完全可以把 `index.html` 换成任何网页（只要保留 `hjk://` 跳转协议的使用），壳照常工作。

**`hjk://` 内置协议**（网页 → 壳的跳转通道，在地址栏或 `location.href` 里用）：

| 协议 | 作用 |
| --- | --- |
| `hjk://home` | 回首页 |
| `hjk://reload` | 刷新 |
| `hjk://url:<网址>` | 打开网址 |
| `hjk://scan` | 打开扫一扫 |

---

## 四、壳内置功能速览

### 4.1 下载管理

- 下载记录支持：打开（走系统文件类型分发，可调起视频/图片/文档 App）、复制、剪切、移动、删除、重命名。
- **删除**：弹窗内提供两个选项 —— 「只删除记录」/「删除记录和文件」，选中后点「确认删除」生效；取消不动作。
- **复制/剪切/移动**：调起系统文件管理器（SAF 目录选择），选中目标目录后自动完成，不需要手输路径。
- 网页里下载的文件（.apk 也一样）下完只弹「打开文件 / 分享文件 / 打开下载目录」，交给系统的「打开方式」决定，不替用户装。
- **应用内更新另走一条通道**：落私有目录、不进下载记录、也不出现在系统「下载」里；下完问一句「是否马上更新」，选「稍后再说」会留着安装包，下次点「检查更新」直接用它装，不用重下。
- 安装前会先比对包名与签名：不一致时直接说明原因（「签名与已装版本不一致，需先卸载」），不会再只给一句系统级的「应用未安装 / 软件冲突」。

### 4.2 视频嗅探与播放

- 网页内视频开始播放时自动弹出壳的播放层叠（页面内浮层，带全屏按钮，双击画面也能全屏），`blob:` 地址自动过滤。
- 层叠可拖动、可关闭；全屏后横屏播放。

### 4.3 扫一扫

- 相机全屏扫码页：取景框 + 底部**手电筒**（可开关）与**相册**（从图片识别二维码）两个白色线性图标按钮。
- 识别策略：整帧四方向 → 中心 70% 区域再试 → 全局直方图二值化兜底；开启 `ALSO_INVERTED` 支持深底浅字反色码；对焦优先连续对焦，机型只支持 AUTO 时每 1.2 秒主动触发一次，避免近距离虚焦扫不出。
- **长按二维码图片**弹出的面板里，除常规操作外还有三个直达入口：
  - 微信扫一扫（`weixin://dl/scan`）
  - QQ 扫一扫（`mqqapi://qrcode/scan_qrcode`）
  - 支付宝扫一扫（`alipay://platformapi/startapp?appId=10000007`）
  - 调不起对应 App 时会提示并退回壳自带扫码页。

### 4.4 其它

- 收藏本页：网页无 title 时用网址作为书签名。
- 删除历史/书签：横划即删，不再二次询问。
- 长按链接/图片的面板使用与闪电球同风格的半透明线性图标。
- **「用其他应用打开 / 分享 / 选浏览器 / 点 mqq: 之类链接」改成自绘面板**（`AppPicker`）：应用图标 + 名称 + 包名，和闪电球其它面板同一套半透明风格，不再是系统那个灰白 chooser。
- **电脑版（网页版本）**：切到电脑版会同时换桌面 UA 并把页面 viewport 改成 `width=1280`，响应式站点才会命中桌面断点；只换 UA 的写法对 `width=device-width` 的站点无效，这是之前「切了还是小屏」的原因。

---

## 五、改图标与改名

1. 换图：把新图放进 `icon/`，改 `app-config.json` 的 `"icon"` 字段即可（自动裁形、压缩）。
2. 换名：改 `appName`。弹窗、设置、关于页里的文案会同步替换。
3. 换包名：改 `packageName`。注意这是全新 App，老用户要重新安装，数据不迁移。
4. 扫码页按钮图标：`src/main/res/drawable/` 下的 `ic_scan_torch.xml` / `ic_scan_torch_on.xml` / `ic_scan_album.xml`，可直接换 vector path。

---

## 六、签名与证书

**证书在 CI 工作流里，本地自己放。** 只要证书不变，同包名、更高 versionCode 就能覆盖安装。

本地取值优先级（`build.sh` 第 6 步）：

1. 环境变量 `KEYSTORE_PATH` / `KEYSTORE_PASSWORD` / `KEY_ALIAS` / `KEY_PASSWORD`
2. `keystore/keystore.properties`（本地自建，已被 `.gitignore` 排除）
3. 兜底 `keystore/release.jks`，不存在就 `keytool` 现场生成一把自签名证书

> **本地零配置就行**：`keystore/` 里没证书时，`build.sh` 会自动从 `.github/workflows/build.yml`
> 的 `KS_B64` 还原一份（口令、别名一并从工作流读），于是本机与 CI 打出的包签名完全一致。
> 想用别的证书时，放 `keystore/release.jks` + `keystore.properties` 覆盖即可。

本地固定用自己的证书，只要放两个文件：

```bash
mkdir -p keystore
cp /path/to/your.jks keystore/release.jks
cat > keystore/keystore.properties <<'PROP'
storeFile=release.jks
storePassword=你的口令
keyAlias=你的别名
keyPassword=你的口令
PROP
```

两个文件都在 `.gitignore` 里，不会误提交。

> 没有证书也能构建：会自动生成一把临时自签名证书，仅够装上手机试跑，**无法覆盖安装正式版**（构建的第 6、7 步会拦下来说清楚）。

### 签名一致性是构建的硬门槛

`app-config.json` 里记录了正式证书的指纹：

```json
"certSha256": "66468219e162d9d5ec254eeb2318d42cf83d08d4d43816f379c7be68c75b2b9a"
```

`build.sh` 第 6 步签名后会**强制比对**：本次包的证书指纹与之不同就直接构建失败（退出码 3），并打印两份指纹和排查建议。这样不会出现「包发出去了、用户装不上、提示软件冲突」的情况。

- 临时绕过：`VIE_SKIP_CERT_CHECK=1`（仅限测试，产物不要发）
- 手机上装不了、提示「软件冲突」：多半是装过更早的测试包（不同证书）。应用内安装会直接说明，并给一个「卸载本应用后手动安装」的按钮 —— 卸载会清掉本机书签和历史，装完新版再重新加
- 真换证书：把新指纹填进 `certSha256`，同时要知道老用户必须卸载重装

### 版本连续性

第 7 步会读 `apk/` 里已发布的最大 `versionCode`，本次小于它就失败（退出码 4）。同一版重打允许（等于），避免「忘了改版本号 → 用户装完还提示更新」。

手动校验签名指纹：

```bash
$ANDROID_HOME/build-tools/<版本>/apksigner verify --print-certs 闪电球1.0.0.apk
```

换证书 = 换应用身份，老用户必须卸载重装；想保留升级能力就沿用原证书。

---

## 七、构建排错

详见 `docs/BUILD.md`。常见问题速查：

| 现象 | 原因/处理 |
| --- | --- |
| `找不到 Android SDK` | 设置 `ANDROID_HOME`，或确认 `/usr/local/lib/android/sdk` 存在 |
| `versionCode` 装不上 | 覆盖安装必须递增 versionCode、包名一致、证书一致 |
| 改了配置没生效 | `apply_config.py` 在 build.sh 里自动执行；确认改的是根目录的 `app-config.json` |
| assets 中文文件名报错 | 明文/混淆版都支持中文文件名；加固版若报错可改用英文文件名 |
| javac 报错 | 看 `build/javac.log` 末尾 40 行 |

---

## 八、发布清单（每次发版过一遍）

- [ ] `versionCode` 已递增
- [ ] `coffee` 配置与 `assets/index.html` 里的 `SPONSOR` 常量一致
- [ ] `bookmarks` / `startPages` / `pages` 三处指向的文件都存在于 `assets/`，且文件名全部纯 ASCII
- [ ] `index.html` 等页面内部的相互引用（`href="api.html"` 这类）用的也是 ASCII 文件名
- [ ] 三版都出包，`apksigner verify` 签名指纹一致，且与 `certSha256` 相同（构建会强制校验）
- [ ] `versionCode` 不小于 `apk/` 里已发布的最大值（构建会强制校验）
- [ ] APK 已传到 `apkUploadDir` 指向的目录，`tools/update/update.json` 已传到 `update.url` 指向的位置
- [ ] 发下一版：`cp tools/update/app-config.next.json app-config.json` 后再构建
- [ ] 真机覆盖安装验证：首页、书签、下载、扫码、视频播放各点一遍
