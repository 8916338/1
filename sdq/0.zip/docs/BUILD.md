# 构建说明

本文件承接原先散落在 `build.sh` / `tools/prepare_sdk.sh` / `.github/workflows/build.yml`
里的注释。脚本里只保留阶段输出，背景原因和踩过的坑都记在这里。

---

## 一、构建链路

```
app-config.json
      │
      ▼
tools/apply_config.py         改包名 / 版本 / 应用名 / 图标 / 书签 / 悬浮球 / assets 处理
      │
      ├── .resolved-config.json   本次构建最终生效的值（build.sh 读它）
      ├── .assets-build/          混淆后（或明文）的 assets
      └── src/main/java/<包名>/Config.java、FabRegistry.java
      │
      ▼
build.sh
  1 aapt2 compile   资源编译
  2 aapt2 link      资源 + 清单 + assets → base.apk（含 R.java）
  3 javac           Java 源码 → class
  4 d8              class → classes.dex
  5 zipalign        4 字节对齐
  6 apksigner       v1 + v2 + v3 签名
  7 体积核对
      │
      ▼
build/<应用名>-<版本名>-混淆.apk
```

---

## 二、为什么不用 Gradle

CI 上跑 Gradle 需要下载 Gradle 本体 + AGP + 依赖，动辄几分钟且容易卡网络。
`aapt2 + javac + d8 + zipalign + apksigner` 这条链是 AGP 内部真正干活的工具，
直接用它们能在 1 分钟内出包，且完全离线可控。

代价是要自己处理：

- 清单注入 `package` 属性（AGP 8 之后清单里不再写 `package`，但 `aapt2` 需要）
- `R.java` 由 `aapt2 link --java` 生成，编译时要把生成目录一起加进源码列表
- `minSdk / targetSdk / versionCode / versionName` 要同时传给 `aapt2 link`

---

## 三、`build.sh` 关键点

### 3.1 严格模式与错误回溯

脚本开头启用 `set -Eeuo pipefail`：

| 选项 | 作用 |
| --- | --- |
| `-e` | 任一命令非 0 退出即中止 |
| `-u` | 引用未定义变量即报错（防手滑写错变量名） |
| `-o pipefail` | 管道中任一环失败即整体失败，而不是只看最后一个命令 |
| `-E` | 配合 `trap ... ERR` 让错误能在函数内定位 |

`trap on_error ERR` 会打印出错行号，并把 `build/javac.log` 末尾 40 行打出来——
javac 的错误全被重定向进日志了，不主动打印的话 CI 上只能看到「构建失败」四个字。

> `pipefail` 的副作用：`cmd | head` 这种写法里，`head` 读够行数就退出，
> 上游进程会收到 SIGPIPE 返回 141，整条命令判失败。
> 所以脚本里凡是要看前几行的地方，都改成先写文件再读，不用管道接 `head`。

### 3.2 SDK 版本自动挑选

`pick_dir` 的逻辑：

1. 优先用调用方指定的版本（`36.0.0` / `android-36`）；
2. 找不到就按版本号数字排序取最大的；
3. 排序键里带一个「稳定性」位，`rc / beta / preview / alpha` 排在正式版之后。

这样在没装 `android-36` 的机器上也能退回到 `android-35` 正常出包。
`--target-sdk-version` 仍然按 `app-config.json` 写入，不受实际平台版本影响。

### 3.3 清单 `package` 注入

`aapt2` 要求 `<manifest>` 上有 `package` 属性；AGP 8 起官方模板要求**不能**写。
为了同一份清单既能被 `build.sh` 用、也能被 Android Studio 打开，构建时临时复制一份到
`build/AndroidManifest.xml` 并注入 `package`，**不改动仓库里的源文件**。

注入用 Python 完成，而不是 `sed`：`sed` 处理带换行和引号的多行替换时，
在 GNU sed / BSD sed 上行为不一致，CI（Linux）和 macOS 本地会得到不同结果。

### 3.4 功能裁剪

`app-config.json` 的 `features` 关掉某个模块时：

1. `apply_config.py` 把对应文件名写进 `.resolved-config.json` 的 `excludedSources`；
2. `FabRegistry.java` 不再引用该类的类名；
3. `build.sh` 用 Python 过滤源码列表时把这些文件剔掉。

结果是这些类**既不编译也不进 dex**，不是运行时隐藏。

过滤之所以不用 `grep -vFf`：当排除列表为空、或者文件名里含正则元字符时，
`grep` 的行为不好控制，Python 的 `endswith` 更直白。

### 3.5 签名

三个签名方案全部显式开启：

- **v1（JAR 签名）**：Android 7 以下只认它；
- **v2（APK Signature Scheme v2）**：Android 7+ 首选，覆盖整个 zip；
- **v3**：支持密钥轮换，Android 9+ 使用。

`apksigner` 新版本默认只做 v3，部分国产 ROM 的自检仍按 v2 校验，
只签 v3 会提示「安装包损坏 / 解析包出错」。所以这里三个都开，签完再逐项验证。

密钥解析顺序：环境变量 → `keystore/keystore.properties`（本地自建）→ 现场生成一份自签名证书。
**现场生成的密钥会导致老版本无法覆盖升级**，正式发版请用固定的 keystore 或 Secrets。

---

## 四、`tools/prepare_sdk.sh`

### 为什么不用 `android-actions/setup-android@v3`

该 action 内部固定执行 `sdkmanager tools`，而 2025 年后的 runner 镜像带的是
cmdline-tools 16+，已经没有名为 `tools` 的包，这一步必然报
`Failed to find package 'tools'` 并让整个 job 失败。

GitHub 的 `ubuntu-latest` 镜像本身预装了 build-tools 和 platforms，
所以本脚本只负责：**找到它们 → 缺什么补什么 → 导出环境变量**。

### 失败处理

- 补装失败不算致命，`build.sh` 会退回现有最高版本；
- 但「一个 build-tools 都没有」或「一个 android.jar 都没有」是硬失败，直接报 `::error::`。
- 接受 license 时 `yes | sdkmanager` 会被 sdkmanager 提前关闭管道而拿到 SIGPIPE(141)，
  脚本开了 `pipefail`，所以整条包在子 shell 里并 `|| true`。

---

## 五、GitHub Actions 工作流

### 5.1 触发方式

| 方式 | 说明 |
| --- | --- |
| `workflow_dispatch` | 网页 Actions → Build APK → Run workflow，可临时覆盖版本名 / 版本号 |
| `push` 到 main/master | 仅当 `app-config.json`、`src/**`、`build.sh`、`tools/**`、工作流自身变化时触发 |

`inputs.versionName` / `inputs.versionCode` 只在手动触发时有值，
`push` 触发时是空字符串，`apply_config.py` 会忽略空值并沿用 `app-config.json`。

### 5.2 并发控制

```yaml
concurrency:
  group: build-apk-${{ github.ref }}
  cancel-in-progress: true
```

同一分支连续提交时，旧的构建会被取消，避免多个 job 抢同一个 Artifact 名字。

### 5.3 签名密钥

默认只认 Secrets 里的 `KEYSTORE_BASE64`；没配就现场生成测试证书（无法覆盖安装正式版）。
要换成自己的密钥，在仓库 Settings → Secrets and variables → Actions 里配：

| Secret | 内容 |
| --- | --- |
| `KEYSTORE_BASE64` | `base64 -w0 your.jks` 的输出 |
| `KEYSTORE_PASSWORD` | keystore 密码 |
| `KEY_ALIAS` | 别名，缺省 `release` |
| `KEY_PASSWORD` | 密钥密码，缺省同 keystore 密码 |

本地生成 base64：

```bash
base64 -w0 keystore/release.jks > ks.txt
```

Windows 用 `certutil -encode release.jks ks.txt` 后去掉首尾两行。

### 5.4 产物

- Artifact 名 `apk-<run_number>`，保留 30 天；
- 打 `v*` tag 时额外走 `softprops/action-gh-release@v2` 发布到 Release。

---

## 六、本地构建

```bash
export ANDROID_HOME=/path/to/android-sdk
bash build.sh
```

需要：JDK 8+（推荐 17）、Android SDK 任一 `build-tools` + `platforms`、Python 3、`zip`。

Windows 建议用 Git Bash 或 WSL，脚本大量使用 bash 特性（数组、`[[ ]]`、进程替换）。

---

## 七、常见构建失败与处理

| 现象 | 原因 | 处理 |
| --- | --- | --- |
| `找不到 Android SDK` | 未设 `ANDROID_HOME`，且常见路径也没有 | 设环境变量，或先跑 `bash tools/prepare_sdk.sh` |
| `build-tools 下没有带 aapt2 的版本` | SDK 不全 | 用 sdkmanager 装 `build-tools;35.0.0` |
| `javac 失败` | 源码错误，或 `features` 裁掉了被引用的类 | 看脚本打印的 `javac.log` 末尾 |
| `源码列表为空` | `excludedSources` 把主代码也排了 | 检查 `apply_config.py` 的裁剪逻辑 |
| `d8 没有产出 classes.dex` | class 目录为空 | 多半是上一步 javac 静默没跑 |
| 装包提示「安装包损坏」 | 签名方案不全 | 确认 v1/v2/v3 都是 OK |
| 覆盖安装失败 | 签名密钥变了，或 `versionCode` 没递增 | 固定 keystore，递增 versionCode |

## assets 混淆与多页面

- 所有顶层 `*.html` 各自成壳加密（支持多内置网页），内联脚本抽进脚本包；
- `.json` 不进密文包：`data.json` / `preset_bookmarks.json` 要被内置页 `fetch()`
  和原生代码（书签、赞助码）直接读，打进密文包谁都拿不到，保持明文；
- 非 ASCII 文件名（如 `内容一.html`）进 APK 会乱码，打包时统一重命名成
  `f + sha1 前 8 位 + 扩展名`；`app-config.json` 的 `pages.file` 由
  `apply_config.py` 用同一个 `safe_asset_name()` 换算，两边必然一致；
- `features.background=false` 时 `Background.java` 被排除出编译，
  `FabRegistry` 生成空实现，所有入口（长按项、后台行）同步消失。

## 依赖 jar（扫码）

`libs/` 下的 `*.jar` 由 `build.sh` 自动收集：

- javac 的 `-classpath` 追加这些 jar；
- d8 的输入多一个 `@classes.txt` 之外的 jar 参数（注意 argfile 必须带 `@`，漏了会报
  `Unsupported source file type`）。

目前只有 `zxing-core-3.5.3.jar`（Apache 2.0，纯 Java 解码，约 594 KB）。
它不带相机代码——扫码走系统相机拍一张 / 相册选一张，再解码，
这样避开了国产 ROM 上 Camera2 预览不对焦的一堆坑。

## 明文版 / 混淆版

`apply_config.py` 支持 `--plain` / `--obfuscate` 覆盖 `app-config.json` 的 `obfuscate.enabled`，
`build.sh` 用环境变量转发：

| 命令 | 结果 |
| --- | --- |
| `bash build.sh` | 按 `app-config.json` 来 |
| `VIE_PLAIN=1 bash build.sh` | 强制明文版 |
| `VIE_OBFUSCATE=1 bash build.sh` | 强制混淆版 |

产物名自动带后缀：`<应用名>-<版本名>-明文.apk` / `<应用名>-<版本名>-混淆.apk`，
避免两版互相覆盖。GitHub 工作流就是先 `--plain` 再 `--obfuscate`，一次产出两份。

## 签名

**仓库里不放私钥。** `build.sh` 第 6 步的取值优先级：

1. 环境变量 `KEYSTORE_PATH` / `KEYSTORE_PASSWORD` / `KEY_ALIAS` / `KEY_PASSWORD`（CI 里由 Secrets 注入）；
2. `keystore/keystore.properties`（本地自建，已被 `.gitignore` 排除）；
3. 兜底 `keystore/release.jks`，不存在就用 `keytool` 现场生成一把自签名证书。

前两种用于正式发布；第三种只适合本地试打包 —— 每次清空 `keystore/` 后生成的证书都不同，
**打出来的包无法覆盖安装上一版**。

本地固定使用自己的证书：

```bash
mkdir -p keystore
cp /path/to/your.jks keystore/release.jks
cat > keystore/keystore.properties <<'PROP'
storeFile=release.jks
storePassword=你的口令
keyAlias=你的别名
keyPassword=你的口令
PROP
```

这两个文件都在 `.gitignore` 里，不会误传。CI 上则配置 Secrets（`KEYSTORE_BASE64` 等），见 README 第 1.1 节。

签名完成后 `apksigner verify --print-certs` 的结果会解析成两行输出：
`签名 v1/v2/v3：OK` 与 `证书 SHA-256：...`，两版 APK 的指纹必须一致。
